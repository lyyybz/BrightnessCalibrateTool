/*
 * Copyright@2014, �ൺ�����ز��Ƽ��ɷ����޹�˾, All rights reserved
 *
 * �ļ�����: viuart.c
 *
 * ����:    UART���ƼĴ�������
 *
 * ��ǰ�汾: 1.0
 * ��Ҫ�޸�:
 * �������: 2015-12-18
 *
 */

#include <stdarg.h>
#include "irq.h"
//#include "sys.h"
#include "alloter.h"
#include "viuart.h"
#include "visys.h"
#include "uart_67.h"
#include "uart_reg.h"

static void empty_a_chn_slot(struct _CHN_SLOT *pCHN_SLOT);

struct _UART_FILE_INFOR uart_file_infor[0x04] = {
	       	    {{INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*tx_slot */,
		        {INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*rx_slot*/,
		        {115200, SIZE8, STOPBITS1, PARITY_NO}/*uart_cfg*/,
		        0x00/*busy_rxing*/, UART_OVER_TICK/*over_time_tick*/},

            	{{INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*tx_slot */,
		        {INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*rx_slot*/,
				{9600, SIZE8, STOPBITS1, PARITY_EVEN}/*uart_cfg*/,
				0x00/*busy_rxing*/, UART_OVER_TICK/*over_time_tick*/},

            	{{INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*tx_slot */,
		        {INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*rx_slot*/,
				{115200, SIZE8, STOPBITS1, PARITY_NO}/*uart_cfg*/,
				0x00/*busy_rxing*/, UART_OVER_TICK/*over_time_tick*/},

            	{{INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*tx_slot */,
		        {INVALID_PTR, INVALID_PTR, 0x00, 0x800}/*rx_slot*/,
				{115200, SIZE8, STOPBITS1, PARITY_NO}/*uart_cfg*/,
				0x00/*busy_rxing*/, UART_OVER_TICK/*over_time_tick*/}};

void UART_IT_Ctrl(int chn,int TxItNewState, int RxItNewState)
{
  if (TxItNewState == IT_ENABLE)
    uart_ITsend_start(chn);
  else
    uart_ITsend_stop(chn);
}

void UART_CHN_Init(int chn, struct _UART_CFG *pUART_CFG)
{
  uart_init(chn, uart_chn_rx_bytes, uart_chn_tx_bytes);
  
  if (uart_file_infor[chn].uart_cfg.parity == PARITY_EVEN)
    uart_config(chn, uart_file_infor[chn].uart_cfg.baud, UART_DataMode_8Even);    
  
  return;
}

int UART_CHN_CFG(int chn, int baud, int parity)
{
  if (parity > PARITY_ODD)
    return -1;

  uart_file_infor[chn].uart_cfg.baud = baud;
  uart_file_infor[chn].uart_cfg.parity = parity;
  UART_CHN_ReInit(chn);

  return 0;
}

void uart_rx_hook(int chn)
{
  if(uart_file_infor[chn].over_time_tick > 0x00)
    uart_file_infor[chn].busy_rxing = uart_file_infor[chn].over_time_tick;
}

int uart_chn_tx_bytes(int chn, unsigned char buffer[], int len)
{
  return(get_chn_bytes(&(uart_file_infor[chn].tx_slot), buffer, len));
}

int uart_chn_rx_bytes(int chn, unsigned char buffer[], int len)
{
  if (len > 0)
    uart_rx_hook(chn);
  return(put_chn_bytes(&(uart_file_infor[chn].rx_slot),buffer,len));
}

int sys_uart_read(int chn, unsigned char buffer[], int len)
{
  return(get_chn_bytes(&(uart_file_infor[chn].rx_slot),buffer,len));
}

int sys_uart_write(int chn, unsigned char buffer[], int len)
{
  int result ;
  
#if 0  //hua
  int type = check_rout_mng();
  int ans_chnl = get_ans_chnl();
  
  if ((0x0 == type || 0x01 == type || 0x01 == ans_chnl) && 0x0 == chn)
    {
	  plc_send_rly_frm(buffer, len, 0); /* Ӧ�����ݷ������� */
	  
	  if (0x0 == type || 0x01 == ans_chnl)
	    {
		  clear_ans_chnl_info();
		  return 0;
	    }
    }
#endif
  result = put_chn_bytes(&(uart_file_infor[chn].tx_slot), buffer, len);
  UART_IT_Ctrl(chn, IT_ENABLE, IT_ENABLE);

  return(result);

}

int sys_uart_peek_data(int chn, unsigned char buffer[], int len)
{
  return(peek_chn_byte(&(uart_file_infor[chn].rx_slot), buffer, len));
}

int sys_uart_clr_rx_data(int chn)
{
  empty_a_chn_slot(&(uart_file_infor[chn].rx_slot));
  return 0;
}

void uart_tick_hook(int chn)
{
  if(uart_file_infor[chn].busy_rxing > 0x00)
    {
      uart_file_infor[chn].busy_rxing--;
      if(0x00 == uart_file_infor[chn].busy_rxing)
        sys_uart_clr_rx_data(chn);
    }
}

static void empty_a_chn_slot(struct _CHN_SLOT *pCHN_SLOT)
{
  unsigned char buffer[0x80];
  int k ;

  do
    {
      k = get_chn_bytes(pCHN_SLOT, buffer, sizeof(buffer));
    }
  while(k > 0x00);
}

void UART_CHN_ReInit(int chn)
{
  OS_CPU_SR cpu_sr;

  if (chn > 4)
    return;

  OS_ENTER_CRITICAL();
  
  empty_a_chn_slot(&(uart_file_infor[chn].rx_slot));
  empty_a_chn_slot(&(uart_file_infor[chn].tx_slot));

  UART_CHN_Init(chn, &(uart_file_infor[chn].uart_cfg));
  UART_IT_Ctrl(chn, IT_DISABLE, IT_ENABLE);

  OS_EXIT_CRITICAL();
}



