/*********************************************************
*Copyright (C), 2016~2020, �ൺ�����ز��Ƽ��ɷ����޹�˾��
*�ļ���:  sys.c
*��  ��:  ES Application Team
*��  ��:  V1.0
*��  ��:  2017/06/30
*��  ��:  ϵͳ��ʼ��������֧�ֺ������塣
*��  ע:  ������ssc1667&68��
**********************************************************/
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "lib_dma.h"
#include "scu.h"
#include "gpio.h"
#include "iwdt.h"
#include "dev_ctrl.h"
#include "viuart.h"
#include "vinets.h"
#include "visys.h"
#include "flash.h"
#include "timer.h"
//#include "../rt/tp.h"
#include <rt_heap.h>
#include <stdlib.h>
#include "irq.h"
#include "router.h"

static void gpio_init();
static void clock_init();
static void timer_event_init(void);
static void register_simuart_hook(EXT_IRQ_HANDLE hook, void *arg);
static void simuart_irq_handle();
static int simuart_get_char(unsigned int now, unsigned char *c);

volatile unsigned int systick_cnt = 0; //msΪ��λ��
#define SIMUARTBUFLEN  100
unsigned char simuartbuf[SIMUARTBUFLEN];
int simuartlen = 0;

void wdog_init()
{
#ifdef WDOG_ALLOW
	if (IS_DBG_FLAG)
		diable_wdog();
  else
    iwdt_init(10);
#endif
}

void wdog_fed()
{
#ifdef WDOG_ALLOW
 iwdt_watchdog();
#endif
}

void SysTick_Handler(void)
{
  systick_cnt += 10;
  uart_tick_hook(0x00);
}

//extern struct tid_info tid_var[MAX_TID_NUM];
void modules_init(void)
{ 
  OS_CPU_SR cpu_sr;

  OS_ENTER_CRITICAL();
  msys_init();
  gpio_init();
  clock_init();
  eeprom_init();
//  CACHE_ENABLE();
//  viphy_init(freq);
  init_chn_pool_mgr();
  /* ���ڳ�ʼ�� */
  UART_CHN_ReInit(0x00);  /* A */
  UART_CHN_ReInit(0x01);  /* ��ʼ��DM */
  UART_CHN_ReInit(0x02);  /* C */
  UART_CHN_ReInit(0x03);  /* B */
  
  //_init_alloc(0x20025e30, 0x20035e30);
  db_init0();
  
  rx_led_off();  /* 55-67���ŷ��ˣ����ǿ�*/
  delay_ms(100);
  rx_led_on();   /* 55-67���ŷ��ˣ����ǿ�*/
  
  timer_init();
  timer_event_init();
  
  //IV���ĺ���
//  get_flash_mac();
  //ses_init();
  //db_build();
  //app_init();
  //appbuf_init();
  tp_init();
  init_taskmanager_info();  /* 43ע��Ҫ�� */
//hua  memset(tid_var, 0x00, MAX_TID_NUM * sizeof(struct tid_info));  /* �����ʱtid */
  
//  adp_init();
//  net_init();
//  mac_init();
  OS_EXIT_CRITICAL();

}

void delay_ms(unsigned int time)
{
  delay_us(1000 * time);
}

void delay_us(unsigned int time)
{
 time = time * 10;

 while(time)time--;
#if 0
  unsigned int start, current, diff;

  start = xthal_get_ccount();
  while (1) {
    current = xthal_get_ccount();
    if (current < start)
  	  diff = ~(start - current);
  	else
  	  diff = current - start;

    if (diff >= (time) * CPU_CYCLE_PER_US)  /* CPU CLK: 200M */
  	  break;
  	}
#endif
}
#if 0 //hua
void tx_led_on()
{
  gipo_out_high(TX_LED);
}

void tx_led_off()
{
  gipo_out_low(TX_LED);
}
#endif
void rx_led_on()
{
  gipo_out_high(RX_LED);
}

void rx_led_off()
{
  gipo_out_low(RX_LED);
}

uint8_t get_mode_sel()
{
#if 0
  uint32_t cpu_sr;
  uint32_t input;
  uint32_t state;

  cpu_sr = OS_ENTER_CRITICAL();

  state = RD_GPIO_GPIO_SHARE_EN0();
  WR_GPIO_GPIO_SHARE_EN0(0xFFFFFFF0&state);
  input = vigpio_input(MOD_SEL);
  WR_GPIO_GPIO_SHARE_EN0(state);

  OS_EXIT_CRITICAL(cpu_sr);

  return input;
#endif
  return 1;
}

int get_powercut()
{
#if 0
  uint32_t input;

  input = vigpio_input(PWR_CUT);

  return input;
#endif
  return 0;
}

struct
{
  struct timer_t timer_event[TIMID_END];
  unsigned char map[TIMID_END];
}vtimer;

static void timer_event_init(void)
{
  memset(&vtimer, 0x00, sizeof(vtimer));
}

int timers_create(unsigned int timerid, unsigned int overtime, void (*func)(unsigned int timerid))
{
  if (timerid >= TIMID_END ||(NULL == func))
    return -1;
  vtimer.timer_event[timerid].overtime = overtime;
  vtimer.timer_event[timerid].inittick = get_sys_tick();
  vtimer.timer_event[timerid].action = func;
  vtimer.map[timerid] = 1;

  return 0;
}

int timers_find(unsigned int timerid)
{
  if (timerid >= TIMID_END || vtimer.map[timerid] == 0)
    return -1;
  return timerid;
}

int timers_delete(unsigned int timerid)
{
  int n;

  if ((n = timers_find(timerid)) < 0)
    return -1;
  vtimer.map[timerid] = 0;
  return 0;
}

void timers_event_deal()
{
  unsigned int tick;

  for (int i = 0; i < TIMID_END; i++)
    {
      if (vtimer.map[i] == 0x00)
        continue;
      tick = get_sys_tick() - vtimer.timer_event[i].inittick;
      if (tick >= vtimer.timer_event[i].overtime)
        {
          vtimer.map[i] = 0;
          vtimer.timer_event[i].action(i);
        }
    }
}

void set_a_timer_done(unsigned int timer_id)
{
  int n;

  if ((n = timers_find(timer_id)) < 0)
    return;

  vtimer.map[timer_id] = 0;
  vtimer.timer_event[timer_id].action(timer_id);
  
  return;
}

void adjust_a_timer_overtime(unsigned int timer_id, unsigned int time)
{
  int n;

  if ((n = timers_find(timer_id)) < 0)
    return;

  vtimer.timer_event[timer_id].overtime = time;
  
  return;
}

unsigned int get_specific_timer(unsigned int timer_id)
{
  unsigned int i = 0, retv = 0;
  int n;

  if ((n = timers_find(timer_id)) < 0)
    return 0;

  retv = vtimer.timer_event[timer_id].overtime;

  return retv;
}

unsigned int get_sys_tick(void)
{
  return systick_cnt;
}

static void gpio_init(void)
{ 
  gpio_set_dir(RX_LED, GPIO_DIR_OUT); /* led */
  rx_led_on();   /* 55-67���ŷ��ˣ����ǿ�*/
  //gpio_set_dir(TX_LED, GPIO_DIR_OUT);

  //gpio_set_dir(ZCP_DET, GPIO_DIR_IN);
  
  //gpio_set_dir(PLC_TX_SDN, GPIO_DIR_OUT);
  
  gpio_set_map(DM_TX, GPIO_FUNC2); /* uart 1 */
  gpio_set_map(DM_RX, GPIO_FUNC2);
  gpio_set_dir(DM_TX, GPIO_DIR_OUT);
  gpio_set_dir(DM_RX, GPIO_DIR_IN);
  
  gpio_set_map(TX_A_SEL, GPIO_FUNC1); /* uart 0 */
  gpio_set_map(RX_A_SEL, GPIO_FUNC1);
  gpio_set_dir(TX_A_SEL, GPIO_DIR_OUT);
  gpio_set_dir(RX_A_SEL, GPIO_DIR_IN);
  gpio_ode(TX_A_SEL);
  
  gpio_set_map(TX_B_SEL, GPIO_FUNC3); /* uart 3 */
  gpio_set_map(RX_B_SEL, GPIO_FUNC3);
  gpio_set_dir(TX_B_SEL, GPIO_DIR_OUT);
  gpio_set_dir(RX_B_SEL, GPIO_DIR_IN);
  gpio_ode(TX_B_SEL);
  
  gpio_set_map(TX_C_SEL, GPIO_FUNC2); /* uart 2 */
  gpio_set_map(RX_C_SEL, GPIO_FUNC2);
  gpio_set_dir(TX_C_SEL, GPIO_DIR_OUT);
  gpio_set_dir(RX_C_SEL, GPIO_DIR_IN);
  gpio_ode(TX_C_SEL);
  
  /* �����ز�оƬ��λ���� */
  gpio_set_map(RST_38, GPIO_FUNC3);  /* GPIO_PA10 */
  gpio_set_dir(RST_38, GPIO_DIR_OUT);
  gipo_out_low(RST_38);
  delay_ms(50);
  gipo_out_high(RST_38);
  
  /* ģ�⴮�� */
  gpio_set_map(SIM_UART_SEND, GPIO_FUNC0);  /* GPIO_PA11 */
  gpio_set_dir(SIM_UART_SEND, GPIO_DIR_OUT);
  gipo_out_high(SIM_UART_SEND);
  gpio_set_map(SIM_UART_RCV, GPIO_FUNC0);  /* GPIO_PA15 */
  gpio_set_dir(SIM_UART_RCV, GPIO_DIR_IN);
  unsigned short irqpin = SIM_UART_RCV;
  register_simuart_hook(simuart_irq_handle, &irqpin);
  
}

static void clock_init()
{
  scu_clk_en(SCU_IWDT);
  scu_clk_en(SCU_IWDT);
  scu_clk_en(SCU_T32N0);
  scu_clk_en(SCU_T32N1);
  scu_clk_en(SCU_UART0);
  scu_clk_en(SCU_UART1);
  scu_clk_en(SCU_UART2);
  scu_clk_en(SCU_UART3);
  //scu_clk_en(SCU_BPLC);
}

void second_tick()
{
  static unsigned int _tick_count = 0;
  static unsigned int second_tick = 0;

  if ((unsigned int)(get_sys_tick() - _tick_count) >= 10)
    {
      if (++second_tick >= (1000 / 10))
        {
          second_tick = 0;
//          app_sectick();
//          net_sectick();
        }
      _tick_count += 10;
    }
}

void set_tx_phase(uint8_t opt)
{
    gipo_out(TX_A_SEL, opt&PHASE_A_);
    gipo_out(TX_B_SEL, opt&PHASE_B_);
    gipo_out(TX_C_SEL, opt&PHASE_C_);
}

void set_rx_phase(uint8_t opt)
{
    gipo_out(RX_A_SEL, opt&PHASE_A_);
    gipo_out(RX_B_SEL, opt&PHASE_B_);
    gipo_out(RX_C_SEL, opt&PHASE_C_);
}

__asm uint32_t __get_PRIMASK_(void)
{
  mrs r0, primask
  cpsid i
  bx lr

}

__asm void __set_PRIMASK_(uint32_t priMask)
{
  msr primask, r0
  bx lr
}
#if 0
void sys_tick_hook(void)
{
  unsigned char print5[3] = {0xDD, 0xDD, 0xDD};
  static unsigned int _tick_count = 0;
  static unsigned int second_tick = 0;
  if((unsigned int)(get_sys_tick() - _tick_count) >= SYS_TICK_INTERVAL)
  {
    if(++second_tick >= (1000 / SYS_TICK_INTERVAL))
    {
      second_tick = 0;
      ses_task_time_tick();
      ses_task_switch();
      //update_sec_tick();
    }
    uart_tick_hook(0x00);
    uart_tick_hook(0x01);
    uart_tick_hook(0x02);
    uart_tick_hook(0x03);
    timers_event_deal();
    app_rt_test_tick();
    _tick_count += SYS_TICK_INTERVAL;
  }
}
#endif
void reset_to_main(void)
{
  unsigned int addr = 0x14000;  //#define IMAGE_RUN_ADDR      0x14000
  
  diable_wdog();
	
	NVIC_SetVectorTable(0x0, addr);
	__set_MSP(*((unsigned int *)addr));
	((void (*)()) (*((unsigned int *)(addr + 4))))();
}

//���������rt_heap.h������,��Ҫ�û��Լ�ȥʵ��,��������ֵ  
// unsigned __rt_heap_extend(unsigned size, void **block)  
// {  
//   return 0;  
// }

#define INTER_115200 217

int sim_uart_delay()
{
  unsigned int now = t32n_get_cnt(0);

  while(1)
    {
      if (t32n_get_cnt(0) - now > INTER_115200)
        break;
    }

  return 0;
}

int simuart_send_char(unsigned char c)
{
  unsigned int now = t32n_get_cnt(0);
  OS_CPU_SR cpu_sr;

  /*���ж�*/
  cpu_sr = OS_ENTER_CRITICAL();  /* OS�����ٽ�����ʵ���޴��ŷ��� */
  /* ��ʼλ */
  gipo_out_low(SIM_UART_SEND);

  /* ����λ */
  for (int i = 0; i < 8; i++)
    {
      while(1)
        {
          if ((t32n_get_cnt(0) - now >= (i + 1) * INTER_115200))
            {
              if (((c >> i) & 0x01) == 1)
                gipo_out_high(SIM_UART_SEND);
              else
                gipo_out_low(SIM_UART_SEND);
              break;
            }
        }
    }
  /* ֹͣλ */
  while(1)
    {
      if ((t32n_get_cnt(0) - now >= 9 * INTER_115200))
        break;
    }
  gipo_out_high(SIM_UART_SEND);
  /* �����һ����ʱ */
  while(1)
    {
      if ((t32n_get_cnt(0) - now >= 10 * INTER_115200))
        break;
    }
  OS_EXIT_CRITICAL();
  return 0;
}

static void register_simuart_hook(EXT_IRQ_HANDLE hook, void *arg)
{
  unsigned short pin = *((unsigned short *)arg);

  gpio_pint_init((GPIO_PIN)pin, PINT_TRI_TEDGE, hook);
}

static void simuart_irq_handle()
{
  unsigned int now = t32n_get_cnt(0), cnt = 2;
  unsigned char c = 0;
  OS_CPU_SR cpu_sr;

  /*���ж�*/
  cpu_sr = OS_ENTER_CRITICAL();  /* OS�����ٽ�����ʵ���޴��ŷ��� */

  pint_clear_itflag(SIM_UART_RCV);
  
  /* ���� */
  while(cnt--);
  if (gpio_input(SIM_UART_RCV) != 0)
    {
      OS_EXIT_CRITICAL();
      return;
    }
  /* ������ */
  while(1)
    {
      if (simuart_get_char(now, &c) == 0)
        {
          if (simuartlen < sizeof(simuartbuf) - 1)
            simuartbuf[simuartlen++] = c;
          now = t32n_get_cnt(0);
          
          /* ����һ���ֽڼ�����һ��, �����Ƿ��к����ֽ� */
          while(1)
            {
              if (gpio_input(SIM_UART_RCV) == 0)
                {
                  now = t32n_get_cnt(0);
                    /* ���� */
                  cnt = 2;
                  while(cnt--);
                  if (gpio_input(SIM_UART_RCV) == 0)
                    break;
                }
              if (t32n_get_cnt(0) - now >= 100000)
                {
                  OS_EXIT_CRITICAL();
                  return;
                }
            }
        }
      else
        {
          OS_EXIT_CRITICAL();
          return;
        }
    }
  OS_EXIT_CRITICAL();

  return;
}

static int simuart_get_char(unsigned int now, unsigned char *c)
{
  *c = 0;
  /* ������, ��1��������(����),�жϵ�ƽ */
  for (int i = 0; i < 8; i++)
    {
      while(1)
        {
          if ((t32n_get_cnt(0) - now >= (i+1)*INTER_115200 + INTER_115200 / 2))
            {
              if (gpio_input(SIM_UART_RCV) == 1)
                *c |= (1 << i); /* bit0 */
              break;
            }
        }
    }
  /* ��ֹͣλ */
  while(1)
    {
      if ((t32n_get_cnt(0) - now >= 9*INTER_115200 + INTER_115200 / 2))
        {
          if (gpio_input(SIM_UART_RCV) != 1) /* ֹͣλ��Ϊ1, �˳� */
            return -1;
          return 0;
        }
    }
  return 0;
}

char simuart_getchar()
{
  char c;
  if (simuartlen <= 0)
    return 128;
  simuartlen--;
  c = (char)simuartbuf[0];
  memmove(simuartbuf, simuartbuf+1, sizeof(simuartbuf) - 1);
  return c;
}
