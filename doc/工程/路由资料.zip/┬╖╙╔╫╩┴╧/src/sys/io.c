/*
 * File:		io.c
 * Purpose:		Serial Input/Output routines
 *
 * Notes:       TERMINAL_PORT defined in <board>.h
 */

#include "ssc1667.h"
#include "uart_67.h"

#define TERM_PORT           (UART1)
/********************************************************************/
void
out_char (char ch)
{
	//uart_put_char(TERM_PORT, ch);
  simuart_send_char(ch);
}
/********************************************************************/

