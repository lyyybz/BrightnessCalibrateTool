/*
 * File:		io.h
 * Purpose:		Serial Input/Output routines
 *
 */

#ifndef _IO_H
#define _IO_H

#define PHS_PRINT_OPT 1
/********************************************************************/

char	
in_char(void);

void
out_char(char);

int
char_present(void);

int		
printf(const char *, ... );

int
sprintf(char *, const char *, ... );

#if 0
int
printf_s(const char *, ...);

int
es_printf(unsigned int, const char *, ... );
#endif
/********************************************************************/

#endif
