
#include "dev_ctrl.h"
//#include "sys.h"
#include "flash.h"
#include "boot.h"
#include <string.h>


static unsigned char _cal_sum(unsigned char buf[], int len);
static unsigned char _cal_xor(unsigned char buf[], int len);
extern void NVIC_SystemReset(void);
 
void reboot()
{
	hard_reset();
}

int get_boot_cfg(unsigned int idx)
{
	unsigned int data;
	
	if (idx >= CFG_NUMN)
	  return -1;
	
	if (0 != flash_read((BOOT_INFO_ADDR + (sizeof(unsigned int)) * idx), (unsigned char *)&data, sizeof(unsigned int)))
	  return -1;
	
	return data;
}

int set_boot_cfg(unsigned int idx, unsigned int data)
{
	unsigned int cfg_buf[CFG_NUMN];
	
	if (idx >= CFG_NUMN)
	  return -1;
	
	if (data == get_boot_cfg(idx))
	  return 0;
	
	if (0 != flash_read(BOOT_INFO_ADDR, (unsigned char *)cfg_buf, sizeof(cfg_buf)))
	  return -1;
	
	cfg_buf[idx] = data;
	cfg_buf[CHECK_SUM] = _cal_sum((unsigned char *)cfg_buf, CFG_END * (sizeof(unsigned int)));
	cfg_buf[CHECK_XOR] = _cal_xor((unsigned char *)cfg_buf, CFG_END * (sizeof(unsigned int)));
	
    if (0 != flash_erase_write(BOOT_INFO_ADDR, (unsigned char *)cfg_buf, sizeof(cfg_buf), (~(BOOT_INFO_ADDR)), HPRI_FLAG))
		{
//		  printf_s(" set cfg ERR!!!\n");
			return -1;
		}
		
  return 0;
}

static unsigned char _cal_sum(unsigned char buf[], int len)
{
    int i = 0;
    unsigned char sum = 0;

    for (i = 0; i < len; i++)
      sum = sum + buf[i++];

    return sum;
}

static unsigned char _cal_xor(unsigned char buf[], int len)
{
    int i=0;
    unsigned char xor = buf[0];

    for (i = 1; i < len; i++)
      xor = xor ^ buf[i++];

    return xor;
}
