
#ifndef BOOT_H
#define BOOT_H

#define BOOTLOADER_LEN   		0xE000  /* boot������56K */
#define IMAGE_RUN_LEN       0x40000 /* image������256K */
#define IMAGE_STORE_LEN     0x28000 /* image�洢��160K */

#define BOOT_RUN_ADDR			  0x0
#define IMAGE_RUN_ADDR      0x14000
#define IMAGE0_ADDR         (IMAGE_RUN_ADDR + IMAGE_RUN_LEN)
#define IMAGE1_ADDR         (IMAGE0_ADDR + IMAGE_STORE_LEN)

#define BOOT_INFO_ADDR			0xE000
#define BOOT_INFO_LEN			  0x400

#define IMG_IDENT       "Eastsoft"
#define NO_ENC_FLAG		  0x5a
#define SZ_IMG_IDENT    10
#define SZ_IMG_RESV     1

enum
{
    BIN_TYPE_STA   = 0x41,
    BIN_TYPE_CCO   = 0x42,
    BIN_TYPE_II    = 0x43,
    BIN_TYPE_RELAY = 0x44,
    BIN_TYPE_I     = 0x45,
    BIN_TYPE_CKQ   = 0x46,
    BIN_TYPE_BOOT  = 0x47,
};

enum
{
    PRO_GW_NEW = 1,
    PRO_GW,
    PRO_GD,
    PRO_55_5,
    PRO_55_3,
    PRO_55_C,
    PRO_55_G3,
};

enum
{
    CHIP_63 = 1,
    CHIP_64,
    CHIP_63E,
    CHIP_64E,
    CHIP_67,
    CHIP_68,
    CHIP_55,
};
enum
{
    BIN_55_STA = 1,
    BIN_55_CCO,
    BIN_55_II,
    BIN_55_RELAY,
    BIN_55_I,
    BIN_55_CKQ,
    BIN_55_BOOT,
    BIN_55_END
};

typedef struct imghdr {
    unsigned int    version;
    unsigned char   ident[SZ_IMG_IDENT];
    unsigned char   no_enc_flag;
    unsigned char   bin_type;
    unsigned char   bin_cut;
    unsigned char   bin_chip;
    unsigned char   pro_type;
    unsigned char   resv[SZ_IMG_RESV];
    unsigned int    crc;
    unsigned int    sz_file;
    unsigned int    sz_ih;
    unsigned int    sz_raw;
    unsigned int    crc_raw;
}imghdr_t;

#define SINGLE_MODE 1
#define DUAL_MODE   2

#define IMAGE0_ACT 1
#define IMAGE1_ACT 2   

#define RENEW_FLAG 0xAA

enum
  {
		BOOT_VER = 0,
		MODE,
		ACTIVE,
		RENEW,  /* ֻ�иñ�־��Ч��ȥ���ش洢�ĳ���? */
		CUR_SIZE,
		CUR_CRC,
		UPD_FLAG,
		RUN_TIME,
		UPD_SIZE,
		UPD_CRC,
		CFG_END,
		
		CHECK_SUM = 254,
		CHECK_XOR = 255,
		CFG_NUMN  = 256,
	};

#define BOOTLOADER_START        BOOT_RUN_ADDR
#define IMAGE_LEN_SINGLE        IMAGE_RUN_LEN
#define IMAGE_LEN               IMAGE_STORE_LEN
#define IMAGE_SINGLE_MODE       SINGLE_MODE
#define IMAGE_DUAL_MODE         DUAL_MODE
#define IF_IMAGE_SINGLE_MODE    (SINGLE_MODE == get_boot_cfg(MODE))
#define IF_IMAGE_DUAL_MODE      (DUAL_MODE == get_boot_cfg(MODE))
#define IF_IMAGE0_ACTIVE        (IMAGE0_ACT == get_boot_cfg(ACTIVE))
#define IF_IMAGE1_ACTIVE        (IMAGE1_ACT == get_boot_cfg(ACTIVE))

void reboot(void);
int get_boot_cfg(unsigned int idx);
int set_boot_cfg(unsigned int idx, unsigned int data);

#endif

