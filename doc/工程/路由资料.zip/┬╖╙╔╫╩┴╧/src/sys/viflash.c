/*
 * Copyright: (c) 2006-2007, 2008 Triductor Technology, Inc.
 * All Rights Reserved.
 *
 * File:    flash.c
 * Purpose:
 * History:
 *      06/26/2007, Created, Haiqiang Feng.
 */

#include "viflash.h"
#include "sys.h"
#include <string.h>


#if 0
/* flash_erase_sector - Erase flash sector starting from `@addr'.
 * @addr: sector-aligned address in flash area
 * @return:
 */
static int32_t flash_erase_sector(uint32_t addr);


/* flash_write_page - Write data into a flash's page, that's, `@dst' + `@len'
 * shall not cross a page boundary.
 * @dst: 4-byte-aligned destination address in flash area
 * @src: 4-byte-aligned source address in non-flash area
 * @len: 4-byte-aligned amount of bytes
 * @return:
 */
static int32_t flash_write_page(uint32_t dst, uint32_t src, uint32_t len);




struct {
    uint32_t start;
    uint32_t len;
} _FIRST, _LAST;

//uint32_t FIRST_buffer[FLASH_SECTOR_SIZE >> 2];
//uint32_t LAST_buffer[FLASH_SECTOR_SIZE >> 2];

#ifdef FPGA_VERSION
uint8_t last_buf[0x10000];
uint8_t first_buf[0x10000];
uint8_t temp_buf[0x20000];
#else
uint8_t first_buffer[4096];
uint8_t last_buffer[4096];
uint8_t temp_buffer[8192];
#endif



static inline void spi_busy_wait()
{
    while(GET_SPI_SPI_BUSY())           /* SPI Interrupt state */
        ;
    return;
}

static inline void flash_set_cmd(uint8_t cs, uint8_t bnum, uint32_t cmd)
{
	//viwdog_fed();
    spi_busy_wait();
    SET_SPI_SPI_CSS_STOP(cs);           /* SPI css stop command��this bit must be set "1" before the last data is transmitted. */
    SET_SPI_SPI_WDATA_BNUM(bnum);           /* SPI transfers byte number: 0 4-byte, 1 1-byte, 2 2-byte, 3 3-byte */
    SET_SPI_SPI_WDATA(cmd);             /* SPI write data register. if cpu read data from spi slaver, it must write one data. */
}

static uint32_t flash_read_status(void)
{
    uint8_t spi_mode;

    //viwdog_fed();
    spi_busy_wait();
    spi_mode = GET_SPI_SPI_SPC0();          /* spi mode: 0 Normal mode, 4-wire, 1 Bidirectional mode, 3-wire*/

    if (spi_mode) { /* bidirectional mode */
        flash_set_cmd(CS_LOW, 1, OPCODE_RDSR);
        spi_busy_wait();
        SET_SPI_SPI_MIMO(1);            /* SPI bidirectional mode: 0 mosi output enable, 1 mosi input enable*/
        flash_set_cmd(CS_HIGH, 2, 0);
    }
    else { /* normal mode */
        flash_set_cmd(CS_HIGH, 3, OPCODE_RDSR);
    }

    spi_busy_wait();
    SET_SPI_SPI_MIMO(0);                /* SPI bidirectional mode: 0 mosi output enable, 1 mosi input enable */

    return GET_SPI_SPI_RDATA();
}

static int32_t flash_is_busy(void)
{
    uint32_t ulCount = 5000000 * CPU_CYCLE_PER_US;
    uint32_t ulCcountStart;
    uint32_t ulCcountCur;
    uint32_t diff;
    uint32_t status;

    //viwdog_fed();
    ulCcountStart = xthal_get_ccount();

    while(1)
    {
        status = flash_read_status();
        if (!((status >> 24) & SR_WIP))     /* ״̬�Ĵ������λ��ֵΪ1��ʾоƬbusy��Ϊ0��ʾno busy */
            return 0;

        ulCcountCur = xthal_get_ccount();
        if(ulCcountCur < ulCcountStart)
            diff = ~(ulCcountStart - ulCcountCur);
        else
            diff = ulCcountCur - ulCcountStart;

        if(diff >= ulCount)
            break;
    }

    //printf_s("[%s:%d]WAIT ERROR\n", __func__, __LINE__);
    return 1;
}


/* flash_erase_sector - Erase flash sector starting from `@addr'.
 * @addr: sector-aligned address in flash area
 * @return:
 */
static int32_t flash_erase_sector(uint32_t addr)
{
#if OS_CRITICAL_METHOD == 3
    OS_CPU_SR  cpu_sr = 0;
#endif
    uint32_t cpu_sr = 0;
    if (flash_is_busy())
        return FLASH_ERROR;

    //viwdog_fed();

    cpu_sr = OS_ENTER_CRITICAL();
    /* flash write enable */
    flash_set_cmd(CS_HIGH, 1, OPCODE_WREN);

    /* erase sector */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(1);
    flash_set_cmd(CS_HIGH, 0, (OPCODE_SE << 24) | (addr & 0x00ffffff));

    /* recover data msb */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(0);
    OS_EXIT_CRITICAL(cpu_sr);

    if (flash_is_busy())
        return FLASH_ERROR;

    return FLASH_OK;
}


/* flash_write_page - Write data into a flash's page, that's, `@dst' + `@len'
 * shall not cross a page boundary.
 * @dst: 4-byte-aligned destination address in flash area
 * @src: 4-byte-aligned source address in non-flash area
 * @len: 4-byte-aligned amount of bytes
 * @return:
 */
static int32_t flash_write_page(uint32_t dst, uint32_t src, uint32_t len)
{
    int32_t i, ret = FLASH_OK;
#if OS_CRITICAL_METHOD == 3
    OS_CPU_SR  cpu_sr = 0;
#endif

    uint32_t cpu_sr = 0;

    //viwdog_fed();
    if (flash_is_busy())
        return FLASH_ERROR;

    cpu_sr = OS_ENTER_CRITICAL();
    /* write enable */
    flash_set_cmd(CS_HIGH, 1, OPCODE_WREN);

    /* page program */
    flash_set_cmd(CS_LOW, 1, OPCODE_PP);

    /* set 24-bit address */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(1);
    SET_SPI_SPI_WDATA_BNUM(3);
    SET_SPI_SPI_WDATA(dst & 0xffffff);

    /* fill data */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(0);
    SET_SPI_SPI_WDATA_BNUM(0);

    len -= 4;
    for (i = 0; i < len; ) {
        spi_busy_wait();
        SET_SPI_SPI_WDATA(REG32(src));

        i   += 4;
        src += 4;
    }

    /* fill last 4-byte */
    spi_busy_wait();
    SET_SPI_SPI_CSS_STOP(1);
    SET_SPI_SPI_WDATA(REG32(src));

    sys_delayus(10,1);
    if (flash_is_busy())
        ret = FLASH_ERROR;

    OS_EXIT_CRITICAL(cpu_sr);

    return ret;
}

/* flash_erase - 64K in one sector
 * @addr: 4-byte-aligned address in flash area
 * @len: amount of bytes �ֽڳ���
 * @return:
 */
int32_t _flash_erase(uint32_t addr, uint32_t len)
{
    int32_t i;

    /* �����Ϸ��Լ�� */
    if (len & 3)// > 4 bytes
        len = (len + 3) & ~3UL;

    if ((addr & 3) || (!len) || (addr < FLASH_BASE_ADDR) || ((addr + len) > (FLASH_BASE_ADDR + FLASH_SIZE))) {
        //printf_s("ARGUEMENT ERROR\n");
        return FLASH_PARA_ERR;
    }

    /* ����ǰ�˱���������� */
    _FIRST.start = addr & ~FLASH_SECTOR_MASK;
    if (_FIRST.len = (addr & FLASH_SECTOR_MASK)) {
        //_flash_store(FIRST.start, FIRST_buffer, FIRST.len);
    }

    /* �����˱���������� */
    _LAST.start = addr + len;
    if ((_LAST.len = _LAST.start & FLASH_SECTOR_MASK)) {
        _LAST.len  = FLASH_SECTOR_SIZE - _LAST.len;
        //_flash_store(LAST.start, LAST_buffer, LAST.len);

        if (flash_erase_sector(_LAST.start) != FLASH_OK) {
            //printf_s("ERASE ERROR\n");
            return FLASH_ERROR;
        }
    }

    for (i = _FIRST.start; i < (_LAST.start & ~FLASH_SECTOR_MASK); i += FLASH_SECTOR_SIZE) {
        if (flash_erase_sector(i) != FLASH_OK) {
            //printf_s("ERASE ERROR\n");
            return FLASH_ERROR;
        }
    }

    /* ����������ɺ󣬽���������ݽ��лָ� */
    //if (FIRST.len)
        //_flash_write(FIRST.start, (uint32_t)FIRST_buffer, FIRST.len, 0);

    //if (LAST.len)
        //_flash_write(LAST.start, (uint32_t)LAST_buffer, LAST.len, 0);

    return FLASH_OK;
}

/* flash_write - Write data into flash.
 * @dst: 4-byte-aligned destination address in flash area
 * @src: 4-byte-aligned source address in non-flash area
 * @len: amount of bytes
 * @erase: check to erase
 * @return:
 */
int32_t _flash_write(uint32_t dst, uint32_t src, uint32_t len, int32_t erase)
{
    int32_t i;
    uint32_t tmp, _dst, _src, _len;

    /* �����Ϸ��Լ�� */
    if (len & 3)
        len = (len + 3) & ~3UL;

    if ((dst & 3) || (src & 3) || (!len) ||
            (dst < FLASH_BASE_ADDR) ||
            ((dst + len) > (FLASH_BASE_ADDR + FLASH_SIZE))) {
        //printf_s("ARGUEMENT ERROR\n");
        return FLASH_PARA_ERR;
    }
    if (! (((src + len) <= FLASH_BASE_ADDR) || (src > FLASH_END_ADDR))) {
        //printf_s("source address in flash.\n");
        return FLASH_PARA_ERR;
    }

    /* ����д������������� */
    if (erase)
    {
        _dst = dst;

        for (i = 0; i < len; i+=4, _dst+=4)
        {
            if (REG32(_dst) != 0xffffffff)
            {
                if (_flash_erase(dst, len) != FLASH_OK)
                    return FLASH_ERROR;
                break;
            }
            //viwdog_fed();
        }
    }

    _dst = dst;
    _src = src;
    _len = len;
    i    = 0;

    //printf_s(".");

    /* ���ݶε�ǰ�˷ַ���ҳ���ݵ�д�봦�� */
    if ((tmp = _dst & FLASH_PAGE_MASK)) {
        tmp = FLASH_PAGE_SIZE - tmp;
        tmp = (tmp > _len) ? _len : tmp;

        if (flash_write_page(_dst, _src, tmp) == FLASH_ERROR)
            return FLASH_ERROR;

        _len -= tmp;
        _dst += tmp;
        _src += tmp;
        ++i;
    }
    /* ���ݶ���ҳ���ֵ�д�봦�� */
    while (_len >= FLASH_PAGE_SIZE)
    {
        if (flash_write_page(_dst, _src, FLASH_PAGE_SIZE) == FLASH_ERROR)
            return FLASH_ERROR;

        _len -= FLASH_PAGE_SIZE;
        _dst += FLASH_PAGE_SIZE;
        _src += FLASH_PAGE_SIZE;

        if (!(++i & 255));
            //printf_s(".");
        //viwdog_fed();
    }
    /* ���ݶεĺ�˷���ҳ���ݵ�д�봦�� */
    if (_len) {
        if (flash_write_page(_dst, _src, _len) == FLASH_ERROR)
            return FLASH_ERROR;
    }

    if (flash_is_busy())
        return FLASH_ERROR;

    /* �������д���Ƿ���ȷ */
    _dst = dst;
    _src = src;
    for (i = 0; i < len; i+=4, _dst+=4, _src+=4) {
        if ((tmp = REG32(_dst)) != REG32(_src)) {
            //printf_s("write %08x with %08x error: %08x\n", _dst, REG32(_src), tmp);
            return FLASH_ERROR;
        }
    }

    return FLASH_OK;
}

/* flash_store - Store flash content out.
 * @addr: 4-byte-aligned address in flash area
 * @buf: buffer
 * @len: amount of bytes
 */
int32_t _flash_store(uint32_t addr, uint32_t *buf, uint32_t len)
{
    int32_t i;

    if (flash_is_busy())
        return FLASH_ERROR;

    if (buf) {
        for (i = 0; i < len>>2; ++i, addr+=4) //len�ֽڳ��ȣ�������λ��ʾint����
            buf[i] = REG32(addr);//���addr����4�����������˴�������
    }
    return FLASH_OK;
}


/****************************our flash function definition******************************/

uint8_t viflash_get(uint32_t addr)
{
    addr=FLASH_BASE_ADDR|addr;
    return *(unsigned char*)addr;
}

void viflash_set(uint32_t addr, uint8_t c)
{
    addr=FLASH_BASE_ADDR|addr;
    //viflash_erase_write(addr, &c, 1);
}
#define TEMP_BUF_LEN 4096
uint8_t w_buf[TEMP_BUF_LEN]__attribute__((aligned(4)));//�����豣֤����
int32_t viflash_write(uint32_t addr, uint8_t  buffer[], uint32_t len)
{
    uint32_t _len;
    int32_t res;
    int i;
    addr=FLASH_BASE_ADDR|addr;

    _len=len%4;

    if(_len==0)
    {
    	res = _flash_write(addr, (unsigned int)buffer, len, 0);
    }
    else
    {
        if( len > (TEMP_BUF_LEN - 4) )
        {
            return 1;
        }

        memcpy( w_buf, buffer,len );

        for(i=0;i<(4-_len);i++)
            w_buf[len+i]=*((unsigned char*)addr+len+i);
        //less than 4 byte,first read, then write back,there`s problem
        len=len+(4-_len);
        res =  _flash_write(addr, (unsigned int)w_buf, len, 0);

    }

    return res;
}

int viflash_read(uint32_t addr ,uint8_t  buffer[], uint32_t len)
{
    int32_t i;
    addr=FLASH_BASE_ADDR|addr;

    if (flash_is_busy())
        return FLASH_ERROR;

    if (buffer) {
        for (i = 0; i < len; ++i, addr+=1)
            buffer[i] = *(unsigned char*)addr;
    }
    return FLASH_OK;

}

/*@addr: can be any address in one sector,
the size of one sector is 4K,FPGA version is 64K*/
void viflash_erase(uint32_t addr)
{
#if OS_CRITICAL_METHOD == 3
    OS_CPU_SR  cpu_sr = 0;
#endif
    uint32_t cpu_sr = 0;
    addr=FLASH_BASE_ADDR|addr;

    if (flash_is_busy())
        return ;

    cpu_sr = OS_ENTER_CRITICAL();
    /* flash write enable */
    flash_set_cmd(CS_HIGH, 1, OPCODE_WREN);

    /* erase sector */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(1);
    flash_set_cmd(CS_HIGH, 0, (OPCODE_SE_4K << 24) | (addr & 0x00ffffff));//

    /* recover data msb */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(0);
    OS_EXIT_CRITICAL(cpu_sr);

    if (flash_is_busy())
        return ;
    return ;

}

/*@addr: can be any address in one BLOCK,
the size of one BLOCK is 64K*/
void viflash_erase64K(uint32_t addr)
{
#if OS_CRITICAL_METHOD == 3
    OS_CPU_SR  cpu_sr = 0;
#endif
    uint32_t cpu_sr = 0;
    addr=FLASH_BASE_ADDR|addr;

    if (flash_is_busy())
        return ;

    cpu_sr = OS_ENTER_CRITICAL();
    /* flash write enable */
    flash_set_cmd(CS_HIGH, 1, OPCODE_WREN);

    /* erase sector */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(1);
    flash_set_cmd(CS_HIGH, 0, (OPCODE_SE << 24) | (addr & 0x00ffffff));//

    /* recover data msb */
    spi_busy_wait();
    SET_SPI_SPI_WDATA_MSB(0);
    OS_EXIT_CRITICAL(cpu_sr);

    if (flash_is_busy())
        return ;
    return ;
}


#ifdef FPGA_VERSION

#if 1
int32_t viflash_erase_write(uint32_t addr, uint8_t  buffer[], uint32_t len)
{
    int32_t i;
    //uint8_t first_buffer[0x10000];
    //uint8_t last_buffer[0x10000];

    addr=FLASH_BASE_ADDR|addr;

        /* �����Ϸ��Լ�� */
    //  if (len & 3)// > 4 bytes
    //      len = (len + 3) & ~3UL;

        if (/*(addr & 3) || */(!len) || (addr < FLASH_BASE_ADDR) || ((addr + len) > (FLASH_BASE_ADDR + FLASH_SIZE))) {
            //printf_s("ARGUEMENT ERROR\n");
            return FLASH_PARA_ERR;
        }

        //backup(addr);

        /* ����ǰ�˱���������� */
        _FIRST.start = addr & ~FLASH_SECTOR_MASK;
        if ((_FIRST.len = addr & FLASH_SECTOR_MASK)) {
            viflash_read(_FIRST.start, first_buf, _FIRST.len);
        }

        /* �����˱���������� */
        _LAST.start = addr + len;
        if ((_LAST.len = _LAST.start & FLASH_SECTOR_MASK)) {
            _LAST.len  = FLASH_SECTOR_SIZE - _LAST.len;
            viflash_read(_LAST.start, last_buf, _LAST.len);

            viflash_erase(_LAST.start);

        }

        for (i = _FIRST.start; i < (_LAST.start & ~FLASH_SECTOR_MASK); i += FLASH_SECTOR_SIZE) {
            viflash_erase(i);

        }

        /* ����������ɺ󣬽���������ݺʹ�д��������ϵ�һ�� */
            if (_FIRST.len)
            {
                memcpy(temp_buf, first_buf, _FIRST.len);
            }

            memcpy(&temp_buf[_FIRST.len], buffer, len);

            if (_LAST.len)
            {
                memcpy(&temp_buf[_FIRST.len+len], last_buf, _LAST.len);
            }

            len=len+_FIRST.len+_LAST.len;
            viflash_write(_FIRST.start,temp_buf,len);//������д��

            //erase_backup();

            return FLASH_OK;
}
#endif

#else
/* flash_erase_write - first erase and store, then write back
 * @addr: 4-byte-aligned address in flash area
 * @buffer: the size of buffer can be 1 to 4096 bytes
 * @len: amount of bytes��
 * @return:
 */
int32_t viflash_erase_write(uint32_t addr, uint8_t  buffer[], uint32_t len)
{
    int32_t i;
    addr=FLASH_BASE_ADDR|addr;

    if (/*(addr & 3) || */(!len) || (addr < FLASH_BASE_ADDR) || ((addr + len) > (FLASH_BASE_ADDR + FLASH_SIZE))) {

        return FLASH_PARA_ERR;
    }

    /* ����ǰ�˱���������� */
    _FIRST.start = addr & ~FLASH_SECTOR_MASK_4k;
    if ((_FIRST.len = addr & FLASH_SECTOR_MASK_4k)) {
        viflash_read(_FIRST.start, first_buffer, _FIRST.len);
    }

    /* �����˱���������� */
    _LAST.start = addr + len;
    if ((_LAST.len = _LAST.start & FLASH_SECTOR_MASK_4k))
    {
        _LAST.len  = FLASH_SECTOR_SIZE_4K - _LAST.len;
        viflash_read(_LAST.start, last_buffer, _LAST.len);

        viflash_erase(_LAST.start);
    }

    for (i = _FIRST.start; i < (_LAST.start & ~FLASH_SECTOR_MASK_4k); i += FLASH_SECTOR_SIZE_4K)
    {
        viflash_erase(i);
    }

    /* ����������ɺ󣬽���������ݺʹ�д��������ϵ�һ�� */
    if (_FIRST.len)
    {
        memcpy(temp_buffer, first_buffer, _FIRST.len);
    }

    memcpy(&temp_buffer[_FIRST.len], buffer, len);

    if (_LAST.len)
    {
        memcpy(&temp_buffer[_FIRST.len+len], last_buffer, _LAST.len);
    }

    len=len+_FIRST.len+_LAST.len;
    return viflash_write(_FIRST.start,temp_buffer,len);//������д��

}
#endif
#endif

int viflash_read(uint32_t addr ,uint8_t  buffer[], uint32_t len)
{

    return FLASH_OK;

}

static int32_t flash_is_busy(void)
{
  return 1;
}

/*@addr: can be any address in one sector,
the size of one sector is 4K,FPGA version is 64K*/
void viflash_erase(uint32_t addr)
{
  return ;
}

int32_t viflash_write(uint32_t addr, uint8_t  buffer[], uint32_t len)
{
  return 0;
}
