/*
 * Copyright@2015, �ൺ�����ز��Ƽ��ɷ����޹�˾, All rights reserved
 *
 * �ļ�����: alloter.c
 *
 * ����:    ���ڻ������
 *
 * ��ǰ�汾:
 * ��Ҫ�޸�:
 * ���ʱ��:
 *
 */

#include <string.h>
#include "visys.h"
#include "alloter.h"

struct _CHN_POOL_MGR chn_pool_mgr;

#define mymin(x,y)      (x > y ? y : x )

/*******************************************************************************
* Function Name  : init_chn_pool_mgr
* Description    : Initializes the chn_pool_mgr.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void init_chn_pool_mgr(void)
{ 
  //int k;  
  while((sizeof(chn_pool_mgr.buffer) / BLK_SZ) > 8*sizeof(chn_pool_mgr.free_bitmap));
   
  chn_pool_mgr.free_bitmap = ((unsigned int)1 << (sizeof(chn_pool_mgr.buffer) / BLK_SZ)) -1;
}
 
/*******************************************************************************
* Function Name  : get_last_bit_seqno
* Description    : return the last bit of 1
* Input          : x
* Output         : None
* Return         : k
*******************************************************************************/
int get_last_bit_seqno(unsigned int x)
{
  int k = 0x00;
  while(0x00 == (x & 0x01)) 
  {
    k++;
    x >>= 0x01;
  }
  return(k);
} 

//return block no,  invalid
/*******************************************************************************
* Function Name  : alloc_a_slot
* Description    : allocate a slot
* Input          : None
* Output         : None
* Return         : ���п����ţ�FFΪ��Ч
*******************************************************************************/
unsigned int alloc_a_slot(void)
{
  int k;
  unsigned int bitmap;
    
  bitmap = chn_pool_mgr.free_bitmap ;
  if(0x00 == bitmap )
    return(INVALID_BLK_NO);
  k = get_last_bit_seqno(bitmap);
  
  /*���÷ǿ��п��־*/
  bitmap &= (bitmap -1);
  chn_pool_mgr.free_bitmap = bitmap;
  
  /*��������һ���ֽ��ó�FF*/
  chn_pool_mgr.buffer[(k << BLK_NO_SHIFT)| (BLK_SZ - 1)] = INVALID_BLK_NO;
  return(k);
}

/*******************************************************************************
* Function Name  : free_a_slot
* Description    : �ͷŻ����
* Input          : blk_no
* Output         : None
* Return         : None
************************************************************************** */
void free_a_slot(int blk_no)
{
  chn_pool_mgr.free_bitmap |=  1 << blk_no ;
}

/*******************************************************************************
* Function Name  : put_chn_bytes
* Description    : �����ڽ��յ����ݷŵ����ڶ�Ӧ�Ļ������
* Input          : *pCHN_SLOT,buffer[],len
* Output         : None
* Return         : i
*******************************************************************************/
int put_chn_bytes(struct _CHN_SLOT *pCHN_SLOT,unsigned char buffer[] ,int len)
{ 
  int k,i = 0x00;

  OS_CPU_SR cpu_sr;
  
  if(len < 0x01)  
    return(0);
  
  /*���ж�*/

  cpu_sr = OS_ENTER_CRITICAL();  /* OS�����ٽ�����ʵ���޴��ŷ��� */

  while(len > 0x00) 
  {
    /*������*/
    if(pCHN_SLOT->data_cnt > pCHN_SLOT->data_max ) 
    {
      goto put_chn_exit;
    }
    
    /*δ���仺���*/
    if(INVALID_BLK_NO == (pCHN_SLOT->rx >> BLK_NO_SHIFT))
    {
      pCHN_SLOT->tx = pCHN_SLOT->rx = alloc_a_slot() << BLK_NO_SHIFT;
      
      /*��ȡ���п�ʧ��*/
      if(INVALID_BLK_NO == (pCHN_SLOT->rx >> BLK_NO_SHIFT))
      {
        pCHN_SLOT->tx = pCHN_SLOT->rx = INVALID_PTR;
        pCHN_SLOT->data_cnt = 0x00;           
        goto put_chn_exit;
      }		  
    }
    
    /*��ǰ������Ѿ�����*/
    if((BLK_SZ - 1) == (pCHN_SLOT->rx & (BLK_SZ - 1))) 
    {
      /*��������һ���µĻ����,ÿ��������һ���ֽڼ�¼��һ������*/
      chn_pool_mgr.buffer[pCHN_SLOT->rx] = alloc_a_slot(); 
      
      /*��ȡ���п�ʧ��*/
      if(INVALID_BLK_NO == chn_pool_mgr.buffer[pCHN_SLOT->rx])
      { 
        goto put_chn_exit;
      }
      
      pCHN_SLOT->rx = chn_pool_mgr.buffer[pCHN_SLOT->rx] << BLK_NO_SHIFT;
    }
	   
    /*�Ƚ������������д������������ֽ������·����µĿ��п����д*/
    k = pCHN_SLOT->rx & (BLK_SZ - 1);
    k = (BLK_SZ - 1) - k;
    k = mymin(len,k);
    memcpy(&chn_pool_mgr.buffer[pCHN_SLOT->rx],&buffer[i],k);
    len -= k;
    pCHN_SLOT->rx += k;
    i += k; 
  }
  
put_chn_exit:
  pCHN_SLOT->data_cnt += i;
  OS_EXIT_CRITICAL();
  return(i);
}



/*******************************************************************************
* Function Name  : peek_chn_byte
* Description    : ��ȡ���ջ����е�����
* Input          : *pCHN_SLOT,buffer[],len
* Output         : None
* Return         : i
*******************************************************************************/
int peek_chn_byte(struct _CHN_SLOT *pCHN_SLOT,unsigned char data[],int len)
{ 
  int n = 0;
  struct _CHN_SLOT chn_slot;
  OS_CPU_SR cpu_sr;
   
  cpu_sr = OS_ENTER_CRITICAL(); 
  chn_slot.rx = pCHN_SLOT->rx;
  chn_slot.tx = pCHN_SLOT->tx;
  chn_slot.data_cnt = pCHN_SLOT->data_cnt;
  OS_EXIT_CRITICAL();

  while((len > 0) && (chn_slot.tx != chn_slot.rx))
  {
    if((BLK_SZ - 1) == (chn_slot.tx & (BLK_SZ - 1))) 
    {
      chn_slot.tx = chn_pool_mgr.buffer[chn_slot.tx] << BLK_NO_SHIFT;
    }
    data[n++] = chn_pool_mgr.buffer[chn_slot.tx];
    chn_slot.tx++;
    len--;
  }
  
  return(n);
}

/*******************************************************************************
* Function Name  : get_chn_bytes
* Description    : ��ȡ���ͻ����������
* Input          : *pCHN_SLOT,buffer[],len
* Output         : None
* Return         : i
*******************************************************************************/
int get_chn_bytes(struct _CHN_SLOT *pCHN_SLOT ,unsigned char buffer[] ,int len)
{
 
  int k,i = 0x00;
  OS_CPU_SR cpu_sr;
  
  if(len < 0x01) 
    return(0);

  OS_ENTER_CRITICAL(); 
  while(len > 0x00) 
  {
    /*���ͻ���û������*/
    if(0x00000 == pCHN_SLOT->data_cnt) 
    {
      pCHN_SLOT->tx = pCHN_SLOT->rx = INVALID_PTR;
      goto get_chn_exit;
    }
    
    /*��ǰ��������Ѿ������꣬�ͷŻ����*/
    if((BLK_SZ - 1) == (pCHN_SLOT->tx  & (BLK_SZ - 1)))
    { 
      free_a_slot(pCHN_SLOT->tx >> BLK_NO_SHIFT);
      /*û����һ��*/
      if(INVALID_BLK_NO ==chn_pool_mgr.buffer[pCHN_SLOT->tx] )
      {
        pCHN_SLOT->tx = pCHN_SLOT->rx = INVALID_PTR;
        if(0x00 != pCHN_SLOT->data_cnt)
        {
          while(1) 
          {
            //error
          }
        }
        pCHN_SLOT->data_cnt = 0x00;
        goto get_chn_exit;
      }
      
      /*������һ������*/
      pCHN_SLOT->tx = chn_pool_mgr.buffer[pCHN_SLOT->tx] << BLK_NO_SHIFT;
    }
    
    //some space free
    k = pCHN_SLOT->tx & (BLK_SZ - 1);
    k = (BLK_SZ - 1) - k; 
    k = mymin(len ,k);
    k = mymin(k ,pCHN_SLOT->data_cnt );
    memcpy(&buffer[i],&chn_pool_mgr.buffer[pCHN_SLOT->tx],k);
    len -= k;
    pCHN_SLOT->tx += k;
    i += k;
    pCHN_SLOT->data_cnt -= k;
#if 0
    if((BLK_SZ - 1) == (pCHN_SLOT->tx & (BLK_SZ - 1)))
    {
      free_a_slot(pCHN_SLOT->tx >> BLK_NO_SHIFT);
      if( INVALID_BLK_NO == chn_pool_mgr.buffer[pCHN_SLOT->tx])
      {
        pCHN_SLOT->data_cnt = 0x00;
      }
      else
      {
        pCHN_SLOT->tx = chn_pool_mgr.buffer[pCHN_SLOT->tx]<<BLK_NO_SHIFT;
      }
    }
#endif        
    
    /*���ݷ������*/
    if( pCHN_SLOT->data_cnt <= 0x00)
    {
      free_a_slot(pCHN_SLOT->tx >> BLK_NO_SHIFT);
      pCHN_SLOT->tx = pCHN_SLOT->rx = INVALID_PTR;
      goto get_chn_exit;
    }
  }

get_chn_exit: 
  OS_EXIT_CRITICAL(); 
  return(i);
}


 

