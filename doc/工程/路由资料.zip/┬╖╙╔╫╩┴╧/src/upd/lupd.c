/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: lupd.c
 *
 * Description: ����������Ӧ��·�ɺͽڵ�ͨ��
 *
 * Version: v1.0
 * Time:
 *
 */

#include "type.h"
#include "update.h"
#include "ague.h"
#include "vinets.h"
#include "tlib.h"
#include "lupd.h"
#include "visys.h"
#include "boot.h"
#include "flash.h"
#include "iwdt.h"
#include "aupd.h"
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "router.h"

#define BITMAP_UNIT 32
#define MAX_BITNUM  1024*32
#define MOVE_BIT    5
#define MTIMET      2000000

#define REBOOT_WAIT_TIME    5000 //5s

typedef struct
{
  uint32_t state;
  uint32_t result;
  uint32_t process_num;// �������̱�ţ�����cco�����Լ����������ģ�ÿ���������̶���++��
  // sta���Ǽ�¼��cco�ģ��ɱ��Ĵ�������ģ����Ұ�����CCO�ĸ�λ����
  // ����ͬһ���������̣�CCO�˺�STA�����ֵ�ǲ�һ���ģ����Ǳ��������sta�˴洢����һ����
  uint32_t file_ident; //�����ļ���ʶ(376.2����������ʶ������CCO��Ҫ������Щ�ڵ㣬�����Լ��Ƿ�����)
  uint32_t seg_len;
  uint32_t last_seg_len;
  uint32_t nr_seg;
  uint32_t image_addr;

  struct
  {
    uint8_t *img_buf;
    uint32_t seg_len;
    uint32_t buf_len;
    uint32_t seg_x[1024];
  }entirety_para;

}upgrd_t;
static upgrd_t upgrd;

uint32_t g_boot_upgrd_flag = 0;           /*�Ƿ�������boot��־*/
uint32_t g_local_bin_type = BIN_TYPE_CCO; /*���������ļ����ͣ��������ֲ�ͬ�豸�ĳ���*/
uint32_t g_local_chip_type = CHIP_67;  /* 55-67·������оƬ���� */

unsigned char upgrd_file_buf[192 * 1024];

static uint32_t check_seg_sn(uint32_t sn);
static void record_seg_sn(uint32_t sn);
static uint32_t recv_seg_finished(uint32_t total_num);

void viwdog_fed()
{
  iwdt_watchdog();
}
/////
int32_t bin_check(unsigned char *ident)
{
  char *__s = IMG_IDENT;
  char *__d = (char *)ident;
  int32_t ret;

  while ((ret = *__d++ - *__s) == 0 && *__s++);

  if (ret == 0)
    {
      //es_printf(UPD_PRINT_OPT,"image header identify is right\n");
    }
  else
    {
      //es_printf(UPD_PRINT_OPT,"image header identify is unknown\n");
    }

  return ret == 0 ? 0 : -1;
}
/////
int boot_check(unsigned int file, unsigned int size, imghdr_t *header, unsigned int unit)
{
  int i, type = BIN_TYPE_BOOT;
  imghdr_t *hdr;
	unsigned char buf[sizeof(imghdr_t)];

  if (NULL == header || NULL == file || size > 128 * 1024)
	  return -1;

  /* �ļ�size���ܲ�׼���ӽ�β��ʼ��imghdr_t */

  if (unit == 16)
    type = (BIN_TYPE_BOOT & 0xF);

	if (EX_STORE_ADDR != file)
		{
			for (i = size / unit; i > 0; i--)
				{
					hdr = (imghdr_t *)(file + i * unit);

					if (0 == bin_check(hdr->ident) && type == hdr->bin_type && size >= hdr->sz_file)
						{
							if (hdr->crc == crc32_soft((unsigned char *)file, hdr->sz_raw))
								{
									memcpy(header, hdr, sizeof(imghdr_t));
									return 0;
								}
						}
				}
		}

  return -1;
}

#if 0
int32_t get_bin_type(uint8_t *img_buf)
{
  imghdr_t *header;

  header = (imghdr_t *)img_buf;

  return header->bin_type;
}
#endif
/////
int image_setmode(uint32_t mode)
{
	if (IMAGE_SINGLE_MODE == mode || IMAGE_DUAL_MODE == mode)
	  {
		  if (0 == set_boot_cfg(MODE, mode))
			  return 0;
	  }

	//printf_s("image_setmode ERR!!!\n");
  return -1;
}
/////
/********************************************************
 * �״�������׼��_��ʼ��
 * ���룺��
 * �����
 ********************************************************/
void upgrd_is_ready(struct upgrd_req *req)
{
  //uint32_t sys_ver;
  uint32_t procs_num_bk;

  //sys_ver = req->file_ident & 0x0000FFFF;

  if (upgrd.entirety_para.img_buf)                    //����д���ͷŻ���
    {
      upgrd.entirety_para.img_buf = NULL;
    }

  procs_num_bk = upgrd.process_num;                       //������Ϊ�˽�process_num���ݻ�ԭ
  memset(&upgrd, 0, sizeof(upgrd));                       //���ȫ������
  //if (npib_find(RUN_MODE) == MODE_COOR)
    {
      upgrd.process_num = procs_num_bk;
    }

  if (req != NULL)
    {
      set_upgrd_state(UPGRD_UPDATING);
      set_upgrd_result(UPGRD_UPDATE_FAILED);
      set_upgrd_process_num(req->process_num);
      set_upgrd_file_ident(req->file_ident);
      upgrd.nr_seg = req->nr_seg;
    }
  else                                                    //����CCO�����
    {
      set_upgrd_state(UPGRD_NEVER_UPDATE);
      set_upgrd_result(UPGRD_UPDATE_FAILED);
    }

  //es_printf(UPD_PRINT_OPT, "update is ready!\n");
}
/////
/********************************************************
* �鿴��ǰ���IMAG_id
* ���룺��
* ��������IMAG_id
********************************************************/
static int32_t get_image_id(void)
{
	uint32_t img_id = 0;

	if (IF_IMAGE_DUAL_MODE)
	  {
			if (IF_IMAGE1_ACTIVE)
			  img_id = 1;
			else if (IF_IMAGE0_ACTIVE)
			  img_id = 0;
			else
			  {
					//es_printf(UPD_PRINT_OPT,"double mode: Have not an active image \n");
					return -1;
			  }
	  }
	else
	  {
			//es_printf(UPD_PRINT_OPT,"get_image_id: can't be SINGLE \n");
			return -2;
	  }

  return img_id;
}
/////
static int32_t write_image(uint32_t img_addr, uint8_t *img_buf, uint32_t buf_len)
{
	uint32_t image_len;
	uint32_t cpu_sr;

	if (IF_IMAGE_DUAL_MODE)
	  {
			image_len = IMAGE_LEN;
	  }
	else
	  {
		  //es_printf(UPD_PRINT_OPT, "write_image: not DUAL!!!\n");
			return -1;
	  }

	if (img_addr == BOOTLOADER_START)
	  {
		  image_len = BOOTLOADER_LEN;
	  }

	if (image_len < buf_len)
	  {
		  //es_printf(UPD_PRINT_OPT, "image length error...\n");
		  return -1;
	  }

	//es_printf(UPD_PRINT_OPT, "image write start...\n");

  if ((unsigned int)img_buf != EX_STORE_ADDR)
	{
			cpu_sr = OS_ENTER_CRITICAL();

			flash_erase(img_addr, image_len, (~img_addr), HPRI_FLAG);
		  viwdog_fed();

			if (0 == flash_erase_write(img_addr, img_buf, buf_len, (~img_addr), HPRI_FLAG))
				{
					viwdog_fed();
					OS_EXIT_CRITICAL();
					//es_printf(UPD_PRINT_OPT, "write image OK !!!\n");
					return 1;
				}

			OS_EXIT_CRITICAL();
  }
	//es_printf(UPD_PRINT_OPT, " write image ERR !!!\n");
	return -1;
}
/////
/***********************************************************
* ����image_active��Ϣ
* ���룺
*   img_id:
*   0:��image 0 active
*   1:��image 1 active
*
********************************************************/
static int32_t image_active(uint8_t img_id)
{
	unsigned int value;

  if (IF_IMAGE_DUAL_MODE)
    {
			if (img_id == 0)
				{
					if (IF_IMAGE0_ACTIVE)
					  {
							//es_printf(UPD_PRINT_OPT, "In dual-mode,Image#0 is already active!\n");
							return 0;
					  }
					else
					  {
							value = IMAGE0_ACT;
					  }
				}
			else if (img_id == 1)
				{
					if (IF_IMAGE1_ACTIVE)
					  {
							//es_printf(UPD_PRINT_OPT, "In dual-mode,Image#1 is already active!\n");
							return 0;
					  }
					else
					  {
							value = IMAGE1_ACT;
					  }
				}
			else
				{
					//es_printf(UPD_PRINT_OPT, "\nimage_active: img_id ERR!!!\n");
					return -1;
				}
    }
	else
		{
			//es_printf(UPD_PRINT_OPT, "\n mode err: can't be SINGLE!!!\n");
			return -1;
		}

	if (0 == set_boot_cfg(ACTIVE, value))
	  {
			//es_printf(UPD_PRINT_OPT, "Image#%d is already active!\n", img_id);
			return 0;
	  }

	return -1;
}
/////
/***********************************************************
* reboot
* ���룺
* ע�⣺boot������������������imageһ��Ҫ������д��ĵ�ַ��Ӧ
********************************************************/
void upgrd_reboot(void)
{
	int32_t img_id,res;
	uint32_t cpu_sr;

	if (g_boot_upgrd_flag)                                   //boot����������
	  {
			//es_printf(UPD_PRINT_OPT,"do not reboot...\n");
			return;
	  }

	img_id = get_image_id();
	if (img_id < 0)
	  {
			//es_printf(UPD_PRINT_OPT,"get_image_id error!\n");
			return;
	  }

	cpu_sr = OS_ENTER_CRITICAL();

	if (0 == img_id)
		res = image_active(1);
	else
		res = image_active(0);

	set_boot_cfg(RENEW, RENEW_FLAG);

	OS_EXIT_CRITICAL();

	if (0 != res)
		return;

	viwdog_fed();
	//es_printf(UPD_PRINT_OPT, "upd reboot...\n");
	reboot();
}
/////
static void upgrd_reboot_tmout(unsigned int timerid)
{
	upgrd_reboot();
}
/////
/********************************************************
 * ���������ļ�����
 * ���룺��
 * �����
 ********************************************************/
uint32_t get_local_bin_type(void)
{
  return g_local_bin_type;
}
/////
void set_local_bin_type(uint32_t type)
{
  g_local_bin_type = type;
}
/////
/********************************************************
 * ���������ļ���ʶ
 * ���룺��
 * �����
 ********************************************************/
uint32_t get_upgrd_file_ident(void)
{
  return upgrd.file_ident;
}
//////
void set_upgrd_file_ident(uint32_t ident)
{
  upgrd.file_ident = ident;
}
/////
/********************************************************
 * �����������
 ********************************************************/
uint32_t get_upgrd_result(void)
{
  return upgrd.result;
}
/////
void set_upgrd_result(uint32_t result)
{
  upgrd.result = result;

  if (result == UPGRD_UPDATE_FAILED)
    {
      //es_printf(UPD_PRINT_OPT, "upgrd result failed\n");
    }
  else
    {
      //es_printf(UPD_PRINT_OPT, "upgrd result success\n");
    }
}
/////
/********************************************************
 * �����������
 ********************************************************/
uint32_t get_upgrd_process_num(void)
{
//  if (MODE_COOR == npib_find(RUN_MODE))
    {
      //return (upgrd.process_num + (get_sys_rstcnt() << 16));
      //return (1); /*none zero*/
    }
  return (upgrd.process_num);
}
/////
void set_upgrd_process_num(uint32_t num)
{
//  if (MODE_COOR == npib_find(RUN_MODE))
//     {
//       return;
//     }

  upgrd.process_num = num;
}
/////
uint32_t inc_upgrd_process_num(void)
{
  upgrd.process_num++;
  return (upgrd.process_num);
}
/////
/********************************************************
 * ��������״̬
 * ���룺��
 * �����
 ********************************************************/
uint32_t get_upgrd_state(void)
{
  return upgrd.state;
}
/////
void set_upgrd_state(uint32_t sta)
{
  upgrd.state = sta;
}
/////
static uint32_t check_seg_sn(uint32_t sn)
{
  uint32_t x,y;
  uint32_t sn_tmp = sn;

  if (sn > MAX_BITNUM)
    return 0;

  x = sn_tmp & (BITMAP_UNIT - 1);
  y = sn_tmp >> MOVE_BIT;

  return((1<<x)&upgrd.entirety_para.seg_x[y]);
}
/////
static void record_seg_sn(uint32_t sn)
{
  uint32_t x,y;
  uint32_t sn_tmp = sn;

  if (sn > MAX_BITNUM)
    return;

  x = sn_tmp & (BITMAP_UNIT - 1);
  y = sn_tmp >> MOVE_BIT;

  upgrd.entirety_para.seg_x[y] = upgrd.entirety_para.seg_x[y] | (1<<x);
}
/////
static uint32_t recv_seg_finished(uint32_t total_num)
{
  uint32_t x,y;
  uint32_t num_tmp = total_num;

  if (num_tmp > MAX_BITNUM)
    return 0;

  x = num_tmp & (BITMAP_UNIT - 1);
  y = num_tmp >> MOVE_BIT;

  if (x != 0)
    {
      if (upgrd.entirety_para.seg_x[y] ^ (0xFFFFFFFF >> (BITMAP_UNIT - x)))
        return 0;
    }

  while (y--)
    {
      if (upgrd.entirety_para.seg_x[y] ^ 0xFFFFFFFF)
        return 0;
    }

//  es_printf(UPD_PRINT_OPT, "recv seg finished\n");
  return 1;
}
/////
unsigned int file_len = 0;
void put_upgrd_seg(struct upgrd_req *req)
{
  uint32_t cpu_sr;
  uint32_t addr = 0,crc;
  imghdr_t * header;
  uint32_t mode = 0;
	unsigned char hdr_buf[sizeof(imghdr_t)];

  struct upgrd_req *req_tmp = req;

  if (NULL == req_tmp)
	return;

  if (upgrd.entirety_para.img_buf == NULL)
    {
#if 1
      if (req_tmp->nr_seg == (req_tmp->sn + 1))//���һ���޷��ж��ܳ���
        {
          return;// δ�غ��ʣ����ĵ�վ���˳���ǲ�ȷ���ġ�
        }
#endif
      upgrd.entirety_para.seg_len = req_tmp->len;
      upgrd.entirety_para.buf_len = req_tmp->nr_seg * req_tmp->len;
      if (upgrd.entirety_para.buf_len & 0xFF)
        {
          upgrd.entirety_para.buf_len = upgrd.entirety_para.buf_len + (0x100 - (upgrd.entirety_para.buf_len & 0xFF));
        }
#if 0
			if (upgrd.entirety_para.buf_len > sizeof(upgrd_file_buf))
			{
				//es_printf(UPD_PRINT_OPT,"NOT ENOUGH SRAM SPACE, USE EX-FLASH!!!\n");
				//return;
				//int cnt1 = ntb_get_cur();
				ex_upd_flash_init(upgrd.entirety_para.buf_len);
				upgrd.entirety_para.img_buf = (unsigned char *)EX_STORE_ADDR;
				//int cnt2 = ntb_get_cur();

				//printf_s(" %dms \n", (cnt2 - cnt1)/25000);
			}
			else
#endif
			{
				memset(upgrd_file_buf, 0x00, sizeof(upgrd_file_buf));
        upgrd.entirety_para.img_buf = upgrd_file_buf;
			}
      file_len = 0;
      if (upgrd.entirety_para.img_buf == NULL)
        return;
    }

  if (check_seg_sn(req_tmp->sn))
    return;

  if ((req_tmp->offset + req_tmp->len) > upgrd.entirety_para.buf_len)
    return;

  cpu_sr = OS_ENTER_CRITICAL();

  //memcpy(((uint8_t*)upgrd.entirety_para.img_buf + req_tmp->offset),req_tmp->data,req_tmp->len);
	set_upd_file_blk(req_tmp->data, (uint32_t)upgrd.entirety_para.img_buf, req_tmp->offset, req_tmp->len);

  OS_EXIT_CRITICAL();

  record_seg_sn(req_tmp->sn);

  //es_printf(UPD_PRINT_OPT, "recv right seg: %d\n", req_tmp->sn);

  if (req_tmp->nr_seg == (req_tmp->sn + 1))
    file_len =  upgrd.entirety_para.seg_len * (req_tmp->nr_seg - 1) + req_tmp->len;
  if (recv_seg_finished(req_tmp->nr_seg))
    {
      // check bin
      //header = (imghdr_t *)upgrd.entirety_para.img_buf;
			get_upd_file_blk(hdr_buf, (unsigned int)upgrd.entirety_para.img_buf, 0, sizeof(hdr_buf));
			header = (imghdr_t *)hdr_buf;

      if (0 == bin_check(header->ident))
        {
          //crc = crc32_soft((uint8_t*)upgrd.entirety_para.img_buf + header->sz_ih, header->sz_file - header->sz_ih);
		  int flag = ((EX_STORE_ADDR == (unsigned int)upgrd.entirety_para.img_buf) ? 1 : 0);
		  crc = get_upd_file_crc((unsigned int)(upgrd.entirety_para.img_buf + header->sz_ih), header->sz_file - header->sz_ih, flag);

          if (crc != header->crc )
            {
        	    //es_printf(UPD_PRINT_OPT,"file crc err!!!!\n");
              upgrd.entirety_para.img_buf = NULL;
              set_upgrd_result(UPGRD_UPDATE_FAILED);
              return;
            }

          mode = IMAGE_DUAL_MODE;
          addr = (get_image_id() ? IMAGE0_ADDR : IMAGE1_ADDR);//doubleģʽ����active id = 0�������������IMAGE0_ADDRд

          //es_printf(UPD_PRINT_OPT,"ES bin ok: addr = %08X \n",addr);
        }
      else
        {
          if (upgrd.entirety_para.buf_len < BOOTLOADER_LEN)
            {
        	    header = (imghdr_t *)hdr_buf;
          	  if (0 == boot_check((unsigned int)upgrd.entirety_para.img_buf, upgrd.entirety_para.buf_len, header, 1024)
			    || 0 == boot_check((unsigned int)upgrd.entirety_para.img_buf, file_len, header, 16))
          	    {
          		if (NULL == header)
          		  {
          			  //es_printf(UPD_PRINT_OPT,"BOOT file err!!!!\n");
                  upgrd.entirety_para.img_buf = NULL;
                  set_upgrd_result(UPGRD_UPDATE_FAILED);
              		return;
          		  }

                  addr = BOOTLOADER_START; //�����bin�ļ��жϲ���������������һ����֤�ļ���ȷ��
                  //es_printf(UPD_PRINT_OPT,"BOOT bin ok: addr = %08X \n",addr);
          	    }
          	  else
          	    {
          		  //es_printf(UPD_PRINT_OPT,"NOT ES FILE!!!\n");
          		  if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO)
          	        {
                      upgrd.entirety_para.img_buf = NULL;
                      set_upgrd_result(UPGRD_UPDATE_FAILED);
              		    return;
          	        }
          	    }

            }
          else
            {
        	  //es_printf(UPD_PRINT_OPT,"NOT ES FILE!!!\n");
      		  if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO)
      	        {
                  upgrd.entirety_para.img_buf = NULL;
                  set_upgrd_result(UPGRD_UPDATE_FAILED);
            	    return;
      	        }

              //mode = IMAGE_SINGLE_MODE;
              //addr = IMAGE0_ADDR;                         //singleģʽ��ֻ��IMAGE0_ADDRд
            }
        }
        if (CHIP_55 == header->bin_chip)
          {
			int node_type = UPD_STA;
			if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO)
		      node_type = UPD_CCO;
            upd_route_start(upgrd.entirety_para.img_buf, file_len, header->bin_type, header->bin_chip, header->pro_type, node_type);
			set_upgrd_state(UPGRD_UPDATED);
			return;
          }

      if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO &&
			  ((addr != BOOTLOADER_START && g_local_chip_type != header->bin_chip )
			    || (addr == BOOTLOADER_START && CHIP_67 != header->bin_chip)))
        {
          upgrd.entirety_para.img_buf = NULL;
          set_upgrd_result(UPGRD_UPDATE_FAILED);
    	    //es_printf(UPD_PRINT_OPT,"chip err: %d %d \n",g_local_chip_type, header->bin_chip);

    	    return;
        }

//      if (MODE_COOR != npib_find(RUN_MODE)
//          || (MODE_COOR == npib_find(RUN_MODE) && get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO))  //STA����CCO��������дFLASH
        {

          if (addr != BOOTLOADER_START && get_local_bin_type() != header->bin_type)  //bin_type����
            {
              //es_printf(UPD_PRINT_OPT, "bin type ERR: local = %d,bin = %d!!!\n", get_local_bin_type(),header->bin_type);

              upgrd.entirety_para.img_buf = NULL;
              set_upgrd_result(UPGRD_UPDATE_SUCCESS);
              set_upgrd_state(UPGRD_UPDATED);

              g_boot_upgrd_flag = 1;

              return;
            }

          g_boot_upgrd_flag = 0;

					if (IMAGE_DUAL_MODE == mode)
					  {
							if (image_setmode(mode) < 0)
							  {
                  upgrd.entirety_para.img_buf = NULL;
                  set_upgrd_result(UPGRD_UPDATE_FAILED);
                  return;
							  }
					  }

          if (write_image(addr,(uint8_t*)upgrd.entirety_para.img_buf,upgrd.entirety_para.buf_len) == 1)
            {
              upgrd.entirety_para.img_buf = NULL;
            }
          else
            {
              //flash writing is falied, free...
              upgrd.entirety_para.img_buf = NULL;
              set_upgrd_result(UPGRD_UPDATE_FAILED);
              set_upgrd_state(UPGRD_UPDATED);

              return;
            }
        }

      g_boot_upgrd_flag = 0;

      set_upgrd_result(UPGRD_UPDATE_SUCCESS);
      set_upgrd_state(UPGRD_UPDATED);

        {
          if (addr == BOOTLOADER_START)
            {
              //es_printf(UPD_PRINT_OPT, "CCO boot update success\n");
              g_boot_upgrd_flag = 1;
            }

          if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO)
            {
        	  //es_printf(UPD_PRINT_OPT, "CCO update, reboot wait 5s...\n");
        	  timers_create(UPGRD_REBOOT_TIMER, REBOOT_WAIT_TIME, upgrd_reboot_tmout);
              //upgrd_reboot();                                                         //����ִ������
            }
        }
    }
}
/////
void free_upgrd_buf()
{
  if (NULL != upgrd.entirety_para.img_buf)
    {
	    //es_printf(UPD_PRINT_OPT, "over:%08X \n",(uint32_t)upgrd.entirety_para.img_buf);
	    upgrd.entirety_para.img_buf = NULL;
    }
}
/////
void lupd_init(void)
{
  memset(&upgrd, 0, sizeof(upgrd));
}
/////
unsigned int get_upd_file_crc(unsigned int addr, unsigned int len, int flag)
{
	unsigned char r_buf[EX_CRC_LEN];
	unsigned int crc = 0x0;
	unsigned int addr_t, i, len_t;

  if (0 == addr || 0 == len)
    return 0;
  crc = crc32_soft((unsigned char *)addr, len);

	return crc;
}
/////
/* addr�Ǵ洢����ʼ��ַ */
int get_upd_file_blk(unsigned char *buf, unsigned int addr, unsigned int offset, unsigned int len)
{
  if (0 == addr || 0 == len || NULL == buf)
	  return -1;

  memcpy(buf, (unsigned char *)(addr + offset), len);

  return 0;
}
/////
int set_upd_file_blk(unsigned char *buf, unsigned int addr, unsigned int offset, unsigned int len)
{
  if (0 == addr || 0 == len || NULL == buf)
    return -1;

  memcpy((unsigned char *)(addr + offset), buf, len);

  return 0;
}
uint32_t check_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn)
{
  uint32_t x,y;
  uint32_t sn_tmp = sn;
  if (sn > max_sn)
    return 0;
  x = sn_tmp & 0x1F;
  y = sn_tmp >> 5;
  return((1<<x)&bitmap[y]);
}
void record_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn)
{
  uint32_t x,y;
  uint32_t sn_tmp = sn;
  if (sn > max_sn)
    return;
  x = sn_tmp & 0x1F;
  y = sn_tmp >> 5;
  bitmap[y] = bitmap[y] | (1<<x);
}
void clear_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn)
{
  uint32_t x,y;
  uint32_t sn_tmp = sn;
  if (sn > max_sn)
    return;
  x = sn_tmp & 0x1F;
  y = sn_tmp >> 5;
  bitmap[y] = bitmap[y] & ~((uint32_t)1<<x);
}
void cpy_errmap_by_byte(uint8_t *dst, uint8_t *src, uint32_t len)
{
  int i;
  if (NULL == dst || NULL == src || 0 == len)
    return;
  for (i = 0; i < len; i++)
    {
      dst[i] |= (~src[i]);
    }
}
