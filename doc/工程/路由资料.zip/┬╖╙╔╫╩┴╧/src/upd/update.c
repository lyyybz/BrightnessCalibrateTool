/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: update.c
 *
 * Description: �������̿���
 *
 * Version: v1.0
 * Time:
 *
 */

#include "type.h"
#include "update.h"
//#include "viflash.h"
#include "vinets.h"
#include "tlib.h"
#include "visys.h"
//#include "db.h"
#include "lupd.h"
#include "boot.h"
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "router.h"

/*****************cco����sta���̿���********************************/
#define UPGRD_START_FLAG          0x55
 
#define UPGRD_SEND_BLK_40        40  /* ���ĳ���һ��136 */
#define UPGRD_SEND_BLK_400       400  /* ���ĳ���һ��520 */
#define UPGRD_SEND_BLK_1400      1400  /* ���ĳ���3*520 */
#define UPGRD_SEND_FLAG           0xAA
#define UPGRD_SEND_TIMES          1
#define UPGRD_SEND_INTERVAL   500 //ms

#define UPGRD_REBOOT_FLAG     0xAA
#define UPGRD_REBOOT_TIMES    5
#define UPGRD_REBOOT_INTERVAL 2000 //ms

#define UPGRD_CHECK_FLAG      0x55
#define UPGRD_CHECK_INTERVAL  500 //ms
#define UPGRD_CHECK_ROUND     20
#define UPGRD_CHECK_TIMES     1
#define UPGRD_RESEND_FLAG     0xAA
#define UPGRD_RESEND_INTERVAL  500 //ms
#define UPGRD_CHECK_BROAD_FLAG 0xAA

#define CCO_SEND_ACTIVE_FLAG    0x55
#define CCO_SEND_ACTIVE_TIMES   5
#define STA_ACTIVE_TMOUT_FLAG   0xAA
#define ACTIVE_SEND_INTERVAL    1000 //ms

#define UPGRD_GD_INFO_FLAG     0xAA
#define UPGRD_GD_INFO_TIMES    3
#define UPGRD_GD_INFO_INTERVAL 2000 //ms

#ifdef UPD_GD

#define GD_USE_DELAY  60 /* ��ʱ����ʱ�� s */
#define GD_UPD_TIM_WD 2*60 /* ��ʱ����ʱ�� min */

typedef struct
{
  unsigned char  type;
  unsigned char  rsv[3];
  unsigned int   crc;
  unsigned int   size;
  unsigned short blk_num;
  unsigned short blk_len;
  unsigned short last_len;
  unsigned short tim_wd;
}__attribute__((packed))gd_file_t;

typedef struct
{
  unsigned char valid;
  unsigned char len;
  unsigned char info[4];
}__attribute__((packed))gd_info_unit_t;

typedef struct
{
  unsigned short cur_tei;
  unsigned char  num;
  unsigned char  id[0x07];
  gd_info_unit_t info[0x07];
}__attribute__((packed))gd_node_info_t;

typedef struct
{
  unsigned short  cur_tei;
  unsigned short  start_sn;
  unsigned short  check_num;
  unsigned short  map_len;
}__attribute__((packed))gd_check_t;

#endif

enum
  {
    UPGRD_PROCESS_SEND_BLK = 1,
    UPGRD_PROCESS_CHECK,
    UPGRD_PROCESS_STA_ACTIVE,
    UPGRD_PROCESS_REBOOT_STA,
    UPGRD_PROCESS_OVER,
    
    UPGRD_PROCESS_GD_CLEAR,
    UPGRD_PROCESS_GD_INFO,
    UPGRD_PROCESS_GD_NODE_INFO,
  };

typedef struct
{
  uint32_t start_flag;
  uint32_t cur_process;
  uint32_t send_times;
  uint32_t send_flag;
  struct
  {
    uint8_t *file;
    uint32_t file_size;
    uint32_t cur_sn;
    uint32_t blk_len;
    uint32_t last_len;
    uint32_t blk_num;
  }/*__attribute__((packed))*/data_blk;
    
  struct
  {  
    uint32_t  check_flag;
    uint32_t  send_flag;
    uint32_t  check_round;
    uint32_t  check_times;
    uint32_t  broad_flag;
    uint32_t total_num;
    uint32_t suces_num;
    uint32_t fail_num;
    uint32_t bit_num;
    uint32_t cur_sn;
    uint32_t tei_sn;
    uint32_t cur_dst;
    uint32_t bitmap[1024]; /* ��Ҫ���� */
    uint32_t teimap[32];
  }/*__attribute__((packed))*/check; //��ѯ ����
    
  struct
  {
    uint32_t flag;
    uint32_t times;
  }/*__attribute__((packed))*/reboot; //�Ƿ���Ҫ��λָ��վ�� 
  
  struct
  {
    uint32_t time;  //����ʱ��
    uint32_t tmot_flag;
    uint32_t send_flag;
    uint32_t send_times;
    uint32_t active_cnt;
  }/*__attribute__((packed))*/sta_active;
  
#ifdef UPD_GD  
  struct
  {
    uint32_t flag;
    uint32_t times;
  }/*_attribute__((packed))*/gd_info;
#endif
}/*__attribute__((packed))*/upgrd_ctrl_t;

static upgrd_ctrl_t g_upgrd_ctrl;
unsigned int g_sta_upgrd_state = UPGRD_STA_NEVER_UPDATE;
unsigned int g_net_upgrd_mode = UPD_MODE_ES;
unsigned int g_upd_csma = UPD_CSMA_DIS;

struct iv_update_info update_info;  /* ��ʱ���岻һ���� */
extern struct _update_frame_nw update_nw;
extern struct _update_content_nw content_nw;
struct update_program *pro_upd;
int to_reply = 0;
unsigned int get_upgrd_mode(void)
{
  return g_net_upgrd_mode;
}

void set_upgrd_mode(unsigned int mode)
{
  g_net_upgrd_mode = mode;
}

/////
int32_t upgrd_going_on(void)
{
  if (UPGRD_START_FLAG == g_upgrd_ctrl.start_flag)
    return 0;
  else
    return -1;
}
/////
int32_t get_upgrd_process(void)
{
  return g_upgrd_ctrl.cur_process;
}

void upgrd_init(void)
{
  lupd_init();
  memset(&g_upgrd_ctrl,0,sizeof(g_upgrd_ctrl));
  set_upgrd_state(UPGRD_NEVER_UPDATE);
  
#ifdef UPD_GD
  gd_upd_init();
#endif
  
  //upd_init();
}

void upgrd_recv_image_seg(struct upgrd_req *req)
{
  if (0 == upgrd_going_on() && UPGRD_PROCESS_REBOOT_STA == get_upgrd_process())
    {
      return;//�����׶β�����ֹ
    }
        
  //if (MODE_COOR == npib_find(RUN_MODE))
    {
      if (req->sn == 0)
        {
          upgrd_is_ready(req);
          inc_upgrd_process_num();
          upd_stop_cur(0);
        }
    }
    
  put_upgrd_seg(req);
}
/////
int stop_cur_upgrd(unsigned int rbt_flg)
{
  set_upgrd_state(UPGRD_NEVER_UPDATE);
  
  if (get_upgrd_file_ident() == UPGRD_FILE_IDENT_ONLY_CCO)
    {
	  if (UPGRD_UPDATE_SUCCESS != get_upgrd_result())
	    {
		  free_upgrd_buf();
		  set_upgrd_result(UPGRD_UPDATE_FAILED);
		  //es_printf(UPD_PRINT_OPT, "stop_cur_upgrd \n");
		  return 0;
	    }
	  else
		return -1;
    }
  return -1;
}
/* ����ʹ�õĺ��� */
int check_content_nw(struct _update_content_nw *pframe)
{
  if (pframe->file_segnum >= update_nw.file_seg)
    return -1;

  /* ����Ĭ�ϳ������һ֡��ÿһ֡����ĳ��ȶ�һ�� */
  if ((pframe->file_segnum != (update_nw.file_seg - 1)) 
  && ((pframe->file_segnum * pframe->file_seglen) > update_nw.file_len))  /* �Ż����Զ�file_segnum�������� */
    return -1;
  
  /* �����������ĳ��ȣ��ݲ����� */
  //if ((pframe->file_seglen != 64) && (pframe->file_seglen != 128))  /* �����ϲ����� */
  //if (pframe->file_seglen > 128)  //<=128������������
  //  return -1;
  
  memcpy((unsigned char *)&content_nw.file_segnum, pframe, sizeof(struct _update_content_nw));
  
  return 0;
}

int check_frame_nw(struct _update_frame_nw *pframe)  /* �ϵ��������ļ�����û��,��Ҫ���� */
{
  if ((pframe->file_statue != 0x01) && (pframe->file_statue != 0x00) && (pframe->file_statue != 0x02))
    return -1;
#if 0  
  if (memcmp(pframe->dst, jzq_address, 6) != 0)  /* memcmp,·�ɳ������ڵ��ַ��ͬ�������� */
    return -1;
#endif  
  //�ж�ȥ����̨������� if (pframe->file_seg < 10)
    //return -1;
  /* �����ǲ��ǿ��Էų��㣬boot������û���ж� */
  if (pframe->file_len > 192 * 1024)
    return -1;
  
  memcpy(&update_nw.file_statue, pframe, sizeof(struct _update_frame_nw));
  
  return 0;
}

unsigned int set_update_blk_nw(struct _update_content_nw *pframe)
{
  unsigned int sno;
  unsigned short st = 0;
  unsigned int cpu_sr;
  unsigned char req_buf[0x800];
  struct upgrd_req *req = (struct upgrd_req *)req_buf;
  
  sno = pframe->file_segnum;
  
  if (0x00 == update_nw.file_statue)
    {
      init_update_info();
      return sno;  //�����װ����
    }
    
  /* ������ϣ��ȴ���λ�ڼ� */
  if (sno >= update_nw.file_seg)  /* ����᲻��©һ֡ */
    return sno;
  
  if (sno == 0)
    init_update_info();
  
  update_info.sec_tick = update_nw.overtime;  /* �����ȷ���Բ��� */
  
  update_info.blk_no = update_nw.file_seg;
  
  if (sno != (update_nw.file_seg - 1))
    {
      /* �����һ֡ */
      update_info.blk_sz = pframe->file_seglen;
    }
    
  if (0 == update_info.blk_sz)
    return sno;
  
  //��ʱ����if (sno == 0)
  //  init_update(update_nw.file_len);  /* �ļ���С */
  
  /* ��ṹ��д�����ļ� */
  req->ver = 0;
  req->file_ident = update_nw.file_statue;
  req->process_num = get_upgrd_process_num();
  req->nr_seg = update_nw.file_seg;
  req->sn = pframe->file_segnum;
  req->offset = pframe->file_segnum * update_info.blk_sz;
  req->len = pframe->file_seglen;

  cpu_sr = OS_ENTER_CRITICAL();
  memcpy(req->data, pframe->file_date, pframe->file_seglen);
  OS_EXIT_CRITICAL();

  //�ύ��������
  upgrd_recv_image_seg(req);
    
  return 0;  /* �����ļ���ʵ�� */
}

/*
  �����װ
*/
void init_update_info()
{
  stop_cur_upgrd(0);
}

int check_update_frame(struct _update_frame_gw *pframe)
{
    int sno = pframe->sno;

    if((0x00 == pframe->file_flag) || (0x07 == pframe->file_flag) || (0x08 == pframe->file_flag))
    {
        return(0);
    }

    if((0x00 != pframe->file_flag) && (0x03 != pframe->file_flag))
    {
        return(-1);
    }
    
    if((pframe->file_prop > 0x01) || pframe->file_comm)
    {
        return(-1);
    }
    
    //ӦΪ0x03��������������
    if((pframe->max_sno < 10) || (sno >= pframe->max_sno))
    {
        return(-1);
    }

    if(update_info.blk_no && (update_info.blk_no != pframe->max_sno))
    {
        return(-1);
    }


    if(sno != (pframe->max_sno - 1))
    {
        if((pframe->data_len * pframe->max_sno) > 250000)
        {
            return(-1);
        }
        //�����һ֡
        if(update_info.blk_sz && (update_info.blk_sz != pframe->data_len))
        {
            return(-1);
        }
    }

    return(0);
}

/*****************IV��·�ɴ���**************/
void update_sec_tick(void)
{
  if(update_info.sec_tick)
  {
    update_info.sec_tick--;
  }
}

unsigned int set_update_blk_data(struct _update_frame_gw *pframe)
{
  #if 0
    unsigned int sno;
    unsigned short st = 0;

    sno = pframe->sno;

    if(0x00 == pframe->file_flag)
    {
        init_update_info();
        return(sno);  //�����װ����
    }

    if((0x07 == pframe->file_flag) || (0x08 == pframe->file_flag))
    {
        return(sno);
    }

    //������ϣ��ȴ���λ�ڼ�
    if(_stage_over == update_info.stage)
    {
        return(sno);
    }

    update_info.sec_tick = UPDATE_SEC_TICK;

    update_info.blk_no = pframe->max_sno;

    if(sno != (pframe->max_sno - 1))
    {
        //�����һ֡
        update_info.blk_sz = pframe->data_len;
    }

    if(0 == update_info.blk_sz)
    {
        return(sno);
    }

    memcpy(&pro_upd->data[update_info.blk_sz * sno], &pframe->data[st], pframe->data_len);

    if(0x00 == (update_info.bitmap[sno/8] & (1<<(sno%8))))
    {
        update_info.bitmap[sno/8] |= (1<<(sno%8));
        update_info.file_len += pframe->data_len;
    }

    if(check_rcvd_data_valid(sno, pframe->data_len) < 0)
    {
        return(UPDATE_ERR);
    }

    if(get_update_block(&update_info.bitmap[0], update_info.blk_no, &st) == 0)
    {
        check_to_update();
    }

    return(sno);
  #endif
}

void clr_update_sec_tick(void)
{
  update_info.sec_tick = 0;
}

int get_update_block(unsigned char s[], unsigned int blk_len, unsigned short *start)
{
    unsigned int i, len, t, k = 0, count;

    len = blk_len / 8;
    if(blk_len & 0x07)
    {
        len++;
    }

    for(i = 0; i < len; i++)
    {
        if(s[i] != 0xff)
        {
            break;
        }
    }

    if(i >= len)
    {
        return(0);
    }

    t = s[i];
    k = 0;
    while(t & 0x01)
    {
        t>>=1;
        k++;
    }

    if((8 * i + k) >= blk_len)
    {
        return(0);
    }

    *start = 8 * i + k;
    while(i < len)
    {
        t = s[i];
        if(t != 0x00)
        {
            k = 0;
            while(k < 8)
            {
                if((t & 0x01) && (((8 * i + k) > *start)))
                {
                    goto find_bit;
                }
                t>>=1;
                k++;
            }
        }

        k = 0;
        i++;
    }
find_bit:
    if((8 * i + k) >= blk_len)
    {
        count = blk_len - *start;
    }
    else
    {
        count = 8 * i + k - *start;
    }

    (*start)++;

    return(count);
}

unsigned int get_update_block_array(unsigned char buf[])
{
    unsigned int i = 0, j, count, t;
    unsigned char s[sizeof(update_info.bitmap)];
    unsigned short start;
    struct _update_block_info *blk_info;

    memcpy(&s[0], &update_info.bitmap[0], sizeof(update_info.bitmap));

    while(i < 30)
    {
        blk_info = (struct _update_block_info *)&buf[4 * i];

        if(count = get_update_block(&s[0], update_info.blk_no, &start))
        {
            blk_info->req_start = (unsigned short)start;
            blk_info->req_count = (unsigned short)count;
        }
        else
        {
            break;
        }

        j = 0;
        while(j < count)
        {
            t = (start - 1) + j;
            s[t / 8] |= (1<<(t % 8));
            j++;
        }
        i++;
    }

    return(i);
}

int get_update_info(unsigned char s[])
{
    unsigned short version;
    struct _update_reply *rframe = (struct _update_reply *)&s[0];
    
    version = *(unsigned short *)&s[0];

    rframe->state = VER_NO_MATCH;
    rframe->version = 0;
    rframe->blk_cnt = 0;

    if(UPDATING == update_info.update_flag)
    {
        if(version == update_info.version)
        {
            rframe->blk_cnt = get_update_block_array(&rframe->data[0]);
            rframe->version = update_info.version;
            rframe->state = IN_UPDATING;
        }
    }
    else
    {
        if(version == RT_VERSION)
        {
            rframe->state = UPDATE_SUCC;
            rframe->version = RT_VERSION;
        }
    }

    return(1 + 4 * rframe->blk_cnt + 1 + 2);
}

int start_update_program(unsigned char s[], int len)
{
    unsigned int file_len;
    struct _start_frame *sframe = (struct _start_frame *)&s[0];

#if 0
    if((sframe->version & 0xf000) != (RT_VERSION & 0xf000))
    {
        s[2] = 0x01;
        goto send_data;
    }
    
    if(sframe->version == RT_VERSION)
    {
        s[2] = 0xff;
    }
    else
    {
#endif
        file_len = sframe->blk_no * sframe->blk_sz;
        if((file_len > 250000) || (file_len < 20000) || (sframe->blk_sz < 20))
        {
            s[2] = 0x01;
            goto send_data;
        }

        if(UPDATING != update_info.update_flag)
        {
            init_update_info();
            memset((unsigned char *)pro_upd, 0x00, 100);
        }

        if(UPDATING == update_info.update_flag)
        {
            if((update_info.blk_sz != sframe->blk_sz) || (update_info.blk_no != sframe->blk_no) || 
               (update_info.version != sframe->version))
            {
                init_update_info();
                memset((unsigned char *)pro_upd, 0x00, 100);
            }
        }

        update_info.version = sframe->version;
        update_info.blk_no = sframe->blk_no;
        update_info.blk_sz = sframe->blk_sz;
        pro_upd->blk_no = sframe->blk_no;
        pro_upd->blk_sz = sframe->blk_sz;
        update_info.update_flag = UPDATING;
        s[2] = 0x00;

        if((15 + 7) == len)
        {
            to_reply = s[5];   //�µı����£��ж��Ƿ���ҪӦ��
        }
        else if((15 + 6) == len)
        {
            to_reply = 0;      //�ɱ����£�������Ӧ��
        }
//    }

send_data:
    s[0] = (unsigned char)RT_VERSION;
    s[1] = (unsigned char)RT_VERSION>>8;
    return(3);
}


int save_update_program(unsigned char s[], unsigned int len)
{

    return(0);
}

