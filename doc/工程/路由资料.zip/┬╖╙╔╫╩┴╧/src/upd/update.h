/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: update.h
 *
 * Description: �������̿���
 *
 * Version: v1.0
 * Time:
 *
 */
#ifndef __UPGRADE_H
#define __UPGRADE_H

#include "type.h"
//#include "viflash.h"
#include <stddef.h>
//#include "ague.h"
#include "visys.h"
#pragma pack(1)

#ifdef GDPLC//MODE_GD
#define UPD_GD
#else
#define UPD_GW
#endif

//#define UPD_CSMA
#define UPDATE_FAIL      0x04
#define VER_NO_MATCH     0x03
#define IN_UPDATING      0x02
#define UPDATE_SUCC      0x01
#define UPDATING     0x33


enum
  {
	UPD_MODE_ES = 0x00,
	UPD_MODE_GW = 0x01,
	UPD_MODE_GD = 0x02,
  };

enum
  {
	UPD_CSMA_DIS = 0,
	UPD_CSMA_EN,
  };

/********************** es pro ************************/
enum
{
    UPGRD_NEVER_UPDATE = 0,       //δ������
    UPGRD_UPDATING     = 1,       //������
    UPGRD_UPDATED      = 2,       //������
};

enum
{
    UPGRD_UPDATE_FAILED  = 0,
    UPGRD_UPDATE_SUCCESS = 1,
};

enum
{
    UPGRD_STA_NEVER_UPDATE  = 0,
    UPGRD_STA_UPDATING      = 1,
    UPGRD_STA_UPDATED       = 2,
};

enum
{
    UPGRD_FRM_DATA = 1,
    UPGRD_FRM_CHECK,
    UPGRD_FRM_REPORT,
    UPGRD_FRM_REBOOT,
    UPGRD_FRM_ACTIVE
};

enum
{
	STA_ACTIVE_START = 1,
	STA_ACTIVE_FIND_SRC,
	STA_ACTIVE_SRC_CFM,
	STA_ACTIVE_DATA_REQ,
	STA_ACTIVE_DATA_CFM,
};

/**
 * struct upgrd_req - �����ֶ�
 *
 * @ver: �汾��
 * @nr_seg: �ֶθ���
 * @sn: �������к�
 * @crc: ����crcֵ
 */
struct upgrd_req
{
	uint32_t ver;
    uint32_t file_ident;                                    /*����CCO����������Ч*/
    uint32_t process_num;
    uint32_t nr_seg;
    uint32_t sn;                                            /* ��0��ʼ*/
    uint32_t offset;
    uint32_t len;
    uint8_t data[1];
}__attribute__((packed));

typedef struct
{
    uint32_t process_num;
}__attribute__((packed))upgrd_reboot_t;

typedef struct
{
    uint32_t process_num;
    uint16_t tei;
    uint8_t  check_round;
}__attribute__((packed))upgrd_check_t;

typedef struct
{
    uint32_t  process_num;
    uint32_t  map_len;
    uint16_t  tei : 12;
    uint16_t  result : 4;
    uint8_t   bit_map[1];
}__attribute__((packed))upgrd_report_t;

typedef struct
{
    uint32_t process_num;
    uint32_t data_len;
    uint8_t  frm_type;
    uint8_t  data[1];
}__attribute__((packed))upgrd_active_t;

typedef struct
{
	uint8_t  frm_type;
	uint32_t frm_len;
	uint8_t  frm_data[1];
}__attribute__((packed))upgrd_frm_t;

/*********************** gd pro *************************/
/* �ļ�������ϢID */  
enum
  {
    GD_DOC_MES = 0x00,           /* �·��ļ���Ϣ */
    GD_DOC_DATA = 0x01,          /* �·��ļ����� */
    GD_DOC_STATE = 0x02,         /* ��ѯ�ļ����ݰ�����״̬ */
    GD_DOC_OVER = 0x03,          /* �ļ��������֪ͨ */
    GD_DOC_TRA = 0x04,           /* �ļ����ݱ��ع㲥ת�� */
  };

enum
  {
	QLTY_CLEAR    = 0x00,
	QLTY_STA_FILE = 0x02,
	QLTY_CJQ_FILE = 0x03,
	QLTY_METER_FILE = 0x04,
	
	GD_UPD_ES = 0xFF,
  };

enum
  {
	NO_RSP = 0,
	NEED_RSP = 1,
  };

enum
  {
	INFO_FCODE = 0x00,
	INFO_VER   = 0x01,
	INFO_BOOT  = 0x02,
	INFO_CRC   = 0x03,
	INFO_SIZE  = 0x04,
	INFO_CHIP  = 0x05,
	INFO_DATE  = 0x06,
  };

enum
  {
	STA_IDLE      = 0x00,
	STA_FILE_TRNS = 0x01,
	STA_RCV_FNSH  = 0x02,
	STA_TRNS_SUCS = 0x05,
	STA_TRNS_FAIL = 0x06,
  };

typedef struct
{
  unsigned char  frm_id;
  unsigned char  rsv[3];
}__attribute__((packed))FILE_TRNS_T;

typedef struct
{
  unsigned int  trns_id;
  unsigned int  rslt;
}__attribute__((packed))CMN_UP_T;

typedef struct
{
  unsigned char  qlty;
  unsigned char  rsv;
  unsigned char  dst[6];
  unsigned int   crc;
  unsigned int   size;
  unsigned short num;
  unsigned short tim;
  unsigned int   trns_id;
}__attribute__((packed))FILE_INFO_T;

typedef struct
{
  unsigned short  sn;
  unsigned short  num;
  unsigned int    trns_id;
  unsigned short  len;
  unsigned char   data[1];
}__attribute__((packed))DATA_TRNS_T;

typedef struct
{
  unsigned int    trns_id;
  unsigned short  dly_tim;
}__attribute__((packed))FNSH_NOTICE_T;

typedef struct
{
  unsigned int    trns_id;
  unsigned short  start_sn;
  unsigned short  check_num;
}__attribute__((packed))CHECK_STA_DN_T;

typedef struct
{
  unsigned int    trns_id;
  unsigned short  start_sn;
  unsigned char   trns_sta;
  unsigned char   rsv;
  unsigned char   data[1];
}__attribute__((packed))CHECK_STA_UP_T;

/* IV��·�ɽṹ�� */
struct iv_update_info {
  unsigned int sec_tick;
  unsigned int file_len;
  unsigned char update_flag;
  unsigned short req_start;
  unsigned short req_count;
  unsigned char blk_sz;
  unsigned short blk_no;
  unsigned short version;
  unsigned char stage;
  unsigned char bitmap[0x400];
};

struct _update_frame_nw {
  unsigned char file_statue;  /* �ļ����� */
  unsigned char file_id;      /* �ļ�ID */
  unsigned char dst[6];       /* Ŀ�ĵ�ַ */
  unsigned short file_seg;    /* �ļ��ܶ��� n */
  unsigned int file_len;      /* �ļ���С */
  unsigned short file_crc;    /* �ļ���У�� */
  unsigned char overtime;     /* �ļ����䳬ʱʱ�� */
};

struct _update_content_nw {
  unsigned short file_segnum;  /* �ļ��κ� */
  unsigned short file_seglen;  /* �ļ��γ��� L */
  unsigned char file_date[1]; /* �ļ������ݣ����2���ֽ����ļ���У�� */
};

struct _update_frame_gw {
    unsigned char file_flag;
    unsigned char file_prop;
    unsigned char file_comm;
    unsigned short max_sno;
    unsigned int sno;
    unsigned short data_len;
    unsigned char data[1];
};

struct _update_reply {
    unsigned char state;
    unsigned short version;
    unsigned char blk_cnt;
    unsigned char data[1];
};

struct _update_block_info {
    unsigned short req_start;
    unsigned short req_count;
};

struct _start_frame {
    unsigned short version;
    unsigned short blk_no;
    unsigned char  blk_sz;
};

struct update_program{

    unsigned short blk_no;
    unsigned char blk_sz;

    unsigned char data[1];
};

struct _update_frame {
    unsigned short seq_no;
    unsigned short version;
    unsigned char len;
    unsigned char  data[1];
};

/************************gd end*************************/
  
void upgrd_init(void);
void upgrd_recv_image_seg(struct upgrd_req *req);
void upgrade_run(void);
void recv_upgrd_frm(uint8_t *frm, uint32_t len);

uint32_t get_sta_upgrd_state(void);
void set_sta_upgrd_state(uint32_t sta);
int stop_cur_upgrd(unsigned int rbt_flg);
uint32_t get_node_num();
int check_node_result(unsigned int tei);
int get_upd_nodes_num(unsigned int type);
int32_t cco_start_upgrd(uint8_t *file, uint32_t file_size);
int gd_cco_start_upgrd(unsigned char *file, unsigned int blk_len, int gd_type);
void set_upgrd_mode(unsigned int mode);
unsigned int get_upgrd_mode(void);

uint32_t check_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn);
void record_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn);
void clear_bitmap_sn(uint32_t bitmap[], uint32_t sn, uint32_t max_sn);

void cpy_errmap_by_byte(uint8_t *dst, uint8_t *src, uint32_t len);
void cpy_errmap_by_sn(int start_sn, int blk_num, unsigned char *src_map, unsigned char *dst_map);

void upd_print_fail_node(void);

unsigned int get_upd_csma();
void set_upd_csma(unsigned int csma);

int check_content_nw(struct _update_content_nw *pframe);
int check_frame_nw(struct _update_frame_nw *pframe);
unsigned int set_update_blk_nw(struct _update_content_nw *pframe);
void init_update_info();

void update_sec_tick(void);
unsigned int set_update_blk_data(struct _update_frame_gw *pframe);
int get_update_info(unsigned char s[]);

#endif

