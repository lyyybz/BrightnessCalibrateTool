/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: lupd.h
 *
 * Description: ����������Ӧ��·�ɺͽڵ�ͨ��
 *
 * Version: v1.0
 * Time:
 *
 */
 
#define EX_STORE_ADDR 0xF0010000  /* �����ļ��ⲿflash�洢��ַ��ʵ�ʵ�ַΪ0x10000 */
#define EX_CRC_LEN    0x800

enum
{
    UPGRD_FILE_IDENT_CLEAR    = 0,
    UPGRD_FILE_IDENT_ONLY_CCO = 1,  /* NW 01H�� ����������ͨ��ģ���ļ� */
    UPGRD_FILE_IDENT_ONLY_STA = 2,
    UPGRD_FILE_IDENT_ONLY_CJQ = 3,
    //UPGRD_FILE_IDENT_ONLY_CCO = 3,
//    UPGRD_FILE_IDENT_ALL_NODE = 7,
//    UPGRD_FILE_IDENT_ONLY_STA = 8,
};


void lupd_init(void);
int32_t bin_check(unsigned char *ident);
void free_upgrd_buf();
void put_upgrd_seg(struct upgrd_req *req);
uint32_t get_upgrd_result();
void set_upgrd_result(uint32_t result);
uint32_t get_upgrd_process_num();
void set_upgrd_process_num(uint32_t num);
uint32_t inc_upgrd_process_num();
void upgrd_is_ready(struct upgrd_req *req);
void upgrd_reboot(void);
uint32_t get_local_bin_type(void);
void set_local_bin_type(uint32_t type);
uint32_t get_upgrd_state();
void set_upgrd_state(uint32_t sta);
uint32_t get_upgrd_file_ident(void);
void set_upgrd_file_ident(uint32_t ident);
uint32_t get_upgrd_state(void);
uint32_t get_upgrd_process_num(void);

unsigned int get_upd_file_crc(unsigned int addr, unsigned int len, int flag);
void ex_upd_flash_init(unsigned int len);
int set_upd_file_blk(unsigned char *buf, unsigned int addr, unsigned int offset, unsigned int len);
int get_upd_file_blk(unsigned char *buf, unsigned int addr, unsigned int offset, unsigned int len);
