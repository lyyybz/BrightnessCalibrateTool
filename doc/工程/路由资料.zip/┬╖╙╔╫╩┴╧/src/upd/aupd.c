/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: aupd.c
 *
 * Description: �������������̿���
 *
 * Version: v1.0
 * Time:
 *
 */
#include "aupd.h"
#include "update.h"
#include "visys.h"
#include "lupd.h"
#include "ague.h"
//#include "db.h"
#include "boot.h"
#include "pib.h"
#include "tp.h"
#include "uart_67.h"
#include "appgb.h"
#include "router.h"
#include "shell.h"
#include "../rtiii/include/db/db.h"
#include "plcnl.h"
// #include "../rtiii/include/db/node.h"
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "rtpara.h"

#define UPD_MAX_BIN  (384 * 1024)
#define UPD_TIM_WD   (0 * 60) //min
#define UPD_SEG_LEN  180
#define UPD_RBT_DLY  30
#define MAX_7F_LEN   256

#define UPD_PARA_VALID 0x55AA
#define UPD_WAIT_FLAG  0x55AA

#define UPD_MAP_ALL    0xFFFF

#define UPD_SEND_FLAG   0x55AA

#define UPD_DATA_INTERVAL  6000 //���ݿ鷢�ͼ��
#define UPD_SRC_ACTV_FLAG  0xAA55

#define ROUTE_SEND_FLAG   0x5A

#define ROUTE_CHECK_FLAG   0x5A

#define AUPD_ACTIVE_FLAG    0x55

#define AUPD_ACTIVE_TIM     20 //s
#define AUPD_ALL_ES         1
#define AUPD_SF_ROUND       5
#define AUPD_SRC_INIT       0xFF

enum
  {
    MODE_BR = 0x00,
    //MODE_SF = 0x01,
  };

enum
  {
    ROLE_SRC = 0x01,
    //ROLE_REQ = 0x02,
  };

enum
  {
    UPD_CMD_START  = 0x01,
    UPD_CMD_STOP   = 0x02,
    UPD_CMD_REBOOT = 0x03,
    UPD_CMD_ACTIVE = 0x04,
  };

enum
  {
    ROUTE_ACTION_START  = 0x01,
    ROUTE_ACTION_SRC    = 0x02,
    ROUTE_ACTION_CHECK  = 0x03,
    ROUTE_ACTION_REBOOT = 0x04,
    ROUTE_ACTION_STOP   = 0x05,
    ROUTE_ACTION_SEND   = 0x06,
    ROUTE_ACTION_OVER   = 0x07,
    ROUTE_ACTION_BRD    = 0x08,
  };

enum
  {
    ROUTE_SEND_CMD   = 0x01,
    ROUTE_SEND_CHECK = 0x02,
  };

enum
  {
    AUPD_EMPTY   = 0x00,
    AUPD_PENDING = 0x01,
  };

enum
  {
    AUPD_CHECK_RSLT = 0x00,
    AUPD_CHECK_INFO = 0x01,
  };

enum
  {
    P_TYPE = 0,
    P_OPT,
    P_CHNL,
    P_TIM,
    P_SEG,
    P_DLY,
    P_END,
  };

enum
{
  UPD_ADDR_DFT = 0,
  UPD_ADDR_APP,
  UPD_ADDR_MAC,
};

typedef struct
{
  unsigned int   valid;
  unsigned int   upd_id;
  struct
  {
    unsigned char  *file;
    unsigned int   size;
    unsigned int   crc;
    unsigned int   blk_num;
    unsigned int   blk_len;
    unsigned int   last_len;
    unsigned char  file_type;
    unsigned char  hw_type;
    unsigned char  pro_type;
    unsigned char  addr_type;
    unsigned char  ntype;
    unsigned char  resv[3];
  }/*__attribute__((packed))*/file;
}/*__attribute__((packed))*/upd_para_t;

typedef struct
{
  unsigned int   cur_cmd;
  unsigned int   upd_role;
  unsigned int   upd_mode;
}/*__attribute__((packed))*/upd_ctrl_t;

typedef struct
{
  unsigned int  wait_flag;

  unsigned int  send_flag;
  unsigned int  cur_blk;
  unsigned int  send_intvl;

  unsigned int  tei_map[32]; /* �������ݵĽڵ�λͼ */
  unsigned int  rslt_map[32]; /* ���λͼ */
}/*__attribute__((packed))*/upd_src_t;

typedef struct
{
  unsigned int  action;
  unsigned int  next_action;

  unsigned char  send_flag;
  unsigned char  send_times;
  unsigned char  send_type;
  unsigned char  rsv;
  unsigned int  send_intvl;  /* ��λ ms */

  unsigned int   total_num;  /* �����ڵ����� */
  unsigned int   suces_num;  /* �����ļ����������ڵ����� */
  unsigned int   finish_num; /* ������ɲ���λ�����³���ڵ����� */
  unsigned int   renet_num;  /* ������������������ */

  unsigned int   cur_sn;
  unsigned char  cur_dst[32];
  unsigned char  dst_len;
  unsigned char  dst_type;
  unsigned char  dst_opt;
  unsigned char  dst_hop;
  unsigned char  check_flag;
  unsigned char  check_type;
  unsigned char  check_round;
  unsigned char  src_flag;

  unsigned short  active_flag;
  unsigned short  active_cnt;
  unsigned int    active_tim;

  unsigned int    sys_cnt;

  unsigned int    net_state;

  unsigned int  finish_map[32];/* ������ɽڵ�λͼ */
  unsigned int  suces_map[32]; /* ���������ɹ��ڵ�λͼ */
}/*__attribute__((packed))*/upd_route_t;

typedef struct
{
  unsigned int upd_info; /* 0-δ�� 1-������ 2-�����ɹ� 3-����ʧ�� 4-����δ�ɹ������� 5-�޻�Ӧ */
  unsigned int upd_sn;   /* ������ */
  unsigned int upd_rate; /* 0-100% */
}upd_uart_t;

static upd_para_t g_upd_para;
static upd_ctrl_t g_upd_ctrl;
static upd_src_t  g_upd_src;
static upd_route_t g_upd_route;
static upd_uart_t g_upd_uart[3];

extern struct ram_node rnode[MAX_NODE];
extern unsigned char dc_succ_flag[MAX_NODE];

unsigned int upd_blk_map[64];

static struct
{
  unsigned int sta;
  unsigned int chnl;
  unsigned int frm_id;
  unsigned int upd_id;
  unsigned int alen;
  unsigned char addr[32];
  unsigned int dlen;
  unsigned char frm[512];
}aupd_frm;

unsigned int g_check_cnt = 0;

unsigned int upd_dpara[P_END] = {UPD_NET, UPD_GEN, UPD_CHN_DFT, UPD_TIM_WD, UPD_SEG_LEN, UPD_RBT_DLY};

void upd_send_cmd(int type, int node_type);
int upd_send_start(unsigned char *dst_addr, int alen, int atype, int anum, int chnl);
int upd_send_stop(unsigned int flag, unsigned char *dst_addr, int alen, int atype, int chnl);
int upd_send_data(unsigned int sn, unsigned char *dst_addr, int alen, int atype, int chnl);
int upd_check_state(int num, int sn, unsigned char *dst_addr, int alen, int atype, int chnl);
int upd_send_exec(unsigned char *dst_addr, int alen, int atype, int chnl);
int upd_deal_frm();
static void encrypt_7F(unsigned char *data, int len);
static void decode_7F(unsigned char *data, int len);
int upd_get_hops(int type, int opt);

unsigned short upd_crc16(unsigned char *data, unsigned int len)
{
  return crc16_soft(data, len);
}

unsigned int get_node_num()
{
  #if 1
  struct mtinfo *mt;
  int num = 0;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    num++;

  return num;
  #else
  return pib_find(MT_NUM);
  #endif
}

int upd_init_node_info(int node_type)
{
  if (UPD_CCO == node_type)
    {
      memset(&g_upd_uart, 0x00, sizeof(g_upd_uart));
      return 0;
    }
  #if 1
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      mt->upd_info = 0;
      mt->upd_rate = 0;
      mt->upd_sn = 0;
    mt->upd_cnt = 0;
    }
  return 0;
  #else
  int n = pib_find(MT_NUM);

  for (int i = 0; i < n; i++)
    {
      rnode[i].upd_info = 0;
      rnode[i].upd_sn = 0;
      rnode[i].upd_rate = 0;
    rnode[i].upd_cnt = 0;
    }
  return 0;
  #endif
}

unsigned int get_cur_upd_mode()
{
  return g_upd_ctrl.upd_mode;
}

int get_max_bitmap_sn(unsigned int *map, unsigned int map_size)
{
  int i;
  int sn = -1;

  for (i = 0; i < map_size; i++)
    {
      if (check_bitmap_sn(map, i, map_size))
        sn = i;
    }

  return sn;
}

int check_bitmap_all(unsigned int *map, unsigned int map_size, unsigned int opt)
{
  int i;

  if (0 == opt)
    {
      for (i = 0; i < map_size; i++)
        {
          if (check_bitmap_sn(map, i, map_size))
            return -1;
        }
    }
  else
    {
      for (i = 0; i < map_size; i++)
        {
          if (0 == check_bitmap_sn(map, i, map_size))
            return -1;
        }
    }

  return 0;
}

void upd_record_blk_map(unsigned char *map, unsigned int len)
{
  unsigned char *dst_map = (unsigned char *)upd_blk_map;
  int len_t = (g_upd_para.file.blk_num + 7)/8;

  if (UPD_MAP_ALL == len)
    memset(dst_map, 0xFF, len_t); /* �����ܻ��м�����Чbit */
  else
    {
      if (NULL == map || 0 == len)
        return;

      cpy_errmap_by_byte(dst_map, map, len);
    }
}

void upd_record_rslt_map(unsigned char *map, unsigned int len, int tei)
{
  int i;
  unsigned char *rslt_map = (unsigned char *)g_upd_src.rslt_map;
  int len_t = sizeof(g_upd_src.rslt_map);

  if (tei > 1 && tei < 1024)
    record_bitmap_sn(g_upd_src.rslt_map, tei, 8 * len_t);

  if (0 == len || NULL == map || len > len_t)
    return;

  for (i = 0; i < len; i++)
    rslt_map[i] |= map[i];
}

void upd_record_req_src(unsigned int req_src)
{
  if (req_src < 2 || req_src > 1024)
  return;

  record_bitmap_sn(g_upd_src.tei_map, req_src, sizeof(g_upd_src.tei_map));
}

void upd_stop_cur(int rbot_flag)
{
    g_upd_route.action = 0;
}

static void upd_send_tmout(unsigned int timerid)
{
  g_upd_src.send_flag = UPD_SEND_FLAG;
}

static void upd_src_wait_tmout(unsigned int timerid)
{
  g_upd_src.wait_flag = 0;
}

void upd_put_off_send(unsigned int tim)
{
  if (tim > 0)
    timers_create(UPD_SEND_TIMER, tim, upd_send_tmout);
  else
    upd_send_tmout(UPD_SEND_TIMER);
}

void upd_src_start_wait(unsigned int tim)
{
  g_upd_src.wait_flag = UPD_WAIT_FLAG;

  if (tim > 0)
    timers_create(UPD_WAIT_TIMER, tim, upd_src_wait_tmout);
  else
    upd_src_wait_tmout(UPD_WAIT_TIMER);
}

int upd_get_blk_sn(unsigned int cur_sn, unsigned int blk_num, unsigned int bit_map[])
{
  unsigned int next = cur_sn;

  if (cur_sn > blk_num)
    return -1;

  while (next < blk_num)
    {
      if (check_bitmap_sn(bit_map, next, blk_num))
        return next;
      next++;
    }

  return -1;
}

void upd_start_send_blk(unsigned int tim)
{
  if (UPD_SEND_FLAG == g_upd_src.send_flag)
    return;

  upd_put_off_send(tim);
}

unsigned int upd_get_file_addr(int opt)
{
    return 0;
}

void upd_init_data_src(int opt)
{
  upd_para_t *upd_para = &g_upd_para;

  upd_para->file.file = (unsigned char *)upd_get_file_addr(opt);
}

extern struct rtpara _rtparas;  /* global parameter */
unsigned int upd_get_upgrd_id()
{
  static unsigned short process_num = 0x0;
  //extern unsigned char jzq_address[6];
  return (((++process_num) & 0xFF) + (((get_sys_tick() >> 4) & 0xFF) << 8) + ((crc16_soft(_rtparas.jzqid_nw, sizeof(_rtparas.jzqid_nw))) << 16));
}

int upd_rout_init_para(unsigned char *file, int size, int file_type, int hw_type, int pro_type, int ntype)
{
  upd_para_t *upd_para = &g_upd_para;

  if (NULL == file)
    return -1;

  if (size > UPD_MAX_BIN)
      return -1;

  upd_para->upd_id = upd_get_upgrd_id();

  upd_para->file.pro_type = pro_type;
  upd_para->file.hw_type = hw_type;
  upd_para->file.file_type = file_type;
  upd_para->file.file = file;
  upd_para->file.size = size;
  upd_para->file.blk_len = upd_dpara[P_SEG];
  upd_para->file.addr_type = UPD_ADDR_APP;

  if (BIN_55_CCO == upd_para->file.file_type || UPD_CCO == ntype)
    upd_para->file.ntype = UPD_CCO;
  else
    upd_para->file.ntype = UPD_STA;

  int flag = ((unsigned int)upd_para->file.file == EX_STORE_ADDR) ? 1 : 0;
  upd_para->file.crc = get_upd_file_crc((unsigned int)upd_para->file.file, upd_para->file.size, flag);

  upd_para->file.blk_num = upd_para->file.size / upd_para->file.blk_len;
  upd_para->file.last_len = upd_para->file.size % upd_para->file.blk_len;

  if (upd_para->file.last_len)
    upd_para->file.blk_num++;
  else
    upd_para->file.last_len = upd_para->file.blk_len;

  upd_para->valid = UPD_PARA_VALID;

  return 0;
}

int upd_route_start(unsigned char *file, int size, int file_type, int hw_type, int pro_type, int ntype)
{
  upd_route_t *upd_route = &g_upd_route;
  upd_ctrl_t *upd_ctrl = &g_upd_ctrl;
  upd_para_t *upd_para = &g_upd_para;

  if (UPD_CCO != ntype && 0 == get_node_num())
    return -1;

  if (0 == pro_type)
    pro_type = PRO_55_3; /* boot����Э������ */

  if (0 != upd_rout_init_para(file, size, file_type, hw_type, pro_type, ntype))
    return -1;

  upd_init_node_info(upd_para->file.ntype);

  upd_route->action = ROUTE_ACTION_STOP;
  upd_route->next_action = ROUTE_ACTION_START;

  upd_ctrl->upd_mode = MODE_BR;

  return 0;
}

int cmd_start_upgrd(unsigned char *file, unsigned int blk_len, int boot_flg, int node_type)
{
  imghdr_t *hdr;
  uint32_t file_size;
	unsigned char buf[sizeof(imghdr_t)];
  if (NULL == file || blk_len > 200)
	  return -1;
  if (0 == get_node_num()) /* û����Ч�ڵ� */
	  return -1;
	get_upd_file_blk(buf, (unsigned int)file, 0, sizeof(buf));
  hdr = (imghdr_t *)buf;
  if (0 == boot_flg && 0 == bin_check(hdr->ident))
    {
		int flag = (((unsigned int)file == EX_STORE_ADDR) ? 1 : 0);
		if (hdr->crc != get_upd_file_crc((unsigned int)(file + hdr->sz_ih), hdr->sz_file - hdr->sz_ih, flag))
      {
	      es_printf(UPD_PRINT_OPT, "cmd upd image err!!! \n");
	      return -1;
      }
    }
  else if (0x1 == boot_flg)
	  {
			if (0 != boot_check((unsigned int)file, 16 * 1024, hdr, 16))
	    {
		    es_printf(UPD_PRINT_OPT, "cmd upd boot err!!! \n");
				return -1;
			}
	  }
  else
	  return -1;
  file_size = hdr->sz_file;
  inc_upgrd_process_num();
  if (CHIP_55 == hdr->bin_chip)
    {
      upd_route_start(file, file_size, hdr->bin_type, hdr->bin_chip, hdr->pro_type, node_type);
      es_printf(UPD_PRINT_OPT, "cmd upd start!!!\n");
    }
  else
    es_printf(UPD_PRINT_OPT, "upd file is not for 1655!!!\n");
  return 0;
}
int upd_get_wait_tim(int type, int hop, int snd_len, int ans_len, int node_type)
{
  int tim = 0;

  if (UPD_CCO == node_type)
    {
      tim = (snd_len + 2 * ans_len);
      return tim;
    }

  if (1/* PRO_55_3 == type */)
    {
      if (0xF == hop)
        {
          if (upd_get_hops(type, 0x0))
            hop = upd_get_hops(type, 0x1);
          else
           hop = 0x7;
        }
      else if (0x0 == hop)
        hop = 0x7;
      tim = (snd_len + ans_len) * 5 * (hop + 1) + (hop + 1) * 100 + 400;
    }
  else
    {
      if (0xF == hop)
        {
            hop = upd_get_hops(type, 0x1);
      if (0 == hop)
           hop = 0x7;
        }
      else if (0x0 == hop)
        hop = 0x7;
	if (ans_len <= 0 && hop > 0x4)
      hop = 0x4;
    tim = (1000 + (ans_len > 0 ? 1000 : 0)) * hop;
    }

  return tim;
}

int upd_src_run()
{
  int blk_sn;
  upd_src_t *upd_src = &g_upd_src;
  upd_para_t *upd_para = &g_upd_para;

  if (UPD_WAIT_FLAG == upd_src->wait_flag)
    return 0;

  if (UPD_SEND_FLAG == upd_src->send_flag)
    {
      upd_src->send_flag = 0;

      blk_sn = upd_get_blk_sn(upd_src->cur_blk, upd_para->file.blk_num, upd_blk_map);

      if (blk_sn >= 0)
        {
          upd_send_data(blk_sn, NULL, 0, 0, ((UPD_STA == upd_para->file.ntype) ? UPD_APP : UPD_ABC));
          upd_src->cur_blk = blk_sn;
          clear_bitmap_sn(upd_blk_map, blk_sn, upd_para->file.blk_num);

          if (upd_src->cur_blk < upd_para->file.blk_num)
            {
              upd_put_off_send(upd_get_wait_tim(upd_para->file.pro_type, 0xF, upd_para->file.blk_len + 50, 0, upd_para->file.ntype)); /* ���ͼ�� */
            }
        }
      else /* ������һ�飬�ټ��ǰ���λͼ���£���ĳЩ�ڵ㾡��ɹ� */
        {
          upd_src->cur_blk = 0;

          blk_sn = upd_get_blk_sn(upd_src->cur_blk, upd_para->file.blk_num, upd_blk_map);

          if (blk_sn >= 0)
            upd_put_off_send(upd_get_wait_tim(upd_para->file.pro_type, 0xF, upd_para->file.blk_len + 50, 0, upd_para->file.ntype)); /* ���ͼ����һЩ */
          else
            return -1;
        }
    }

  return 0;
}

static void route_send_tmout(unsigned int timerid)
{
    g_upd_route.send_flag = ROUTE_SEND_FLAG;
}

void upd_put_off_route_send(unsigned int tim)
{
  if (tim > 0)
    timers_create(ROUTE_SEND_TIMER, tim, route_send_tmout);
  else
    route_send_tmout(ROUTE_SEND_TIMER);
}

static void route_check_tmout(unsigned int timerid)
{
    g_upd_route.check_flag = ROUTE_CHECK_FLAG;
}

void upd_put_off_route_check(unsigned int tim)
{
  if (tim > 0)
    timers_create(ROUTE_CHECK_TIMER, tim, route_check_tmout);
  else
    {
      timers_delete(ROUTE_CHECK_TIMER);
      route_check_tmout(ROUTE_CHECK_TIMER);
    }
}

int update_node_upd_info(unsigned char *nid, int rate, int res, int node_type)
{
  if (UPD_CCO == node_type)
    {
      g_upd_uart[*nid].upd_info = res;
      g_upd_uart[*nid].upd_rate = rate;
      return 0;
    }
  #if 1
  struct mtinfo *mt = db_find(nid);

  if (NULL == mt)
    return -1;
  if (rate > mt->upd_rate)
      mt->upd_cnt = 0;
  mt->upd_info = res;
  mt->upd_rate = rate;
 #else
  int pos = 0;
  if (db_find(AID, nid, &pos) == 0)
    {
    if (rate > rnode[pos].upd_rate)
      rnode[pos].upd_cnt = 0;
    else
      rnode[pos].upd_cnt += 3;
      rnode[pos].upd_info = res;
      rnode[pos].upd_rate = rate;
    }
 #endif
  return 0;
}

int update_node_check_sn(unsigned char *nid, int check_sn, int node_type)
{
    if (UPD_CCO == node_type)
      {
        g_upd_uart[*nid].upd_sn = check_sn;
        return 0;
      }
  #if 1
  struct mtinfo *mt = db_find(nid);

  if (NULL == mt)
    return -1;

  mt->upd_sn = check_sn;
  mt->upd_cnt++;
  #else
  int pos = 0;
  if (db_find(AID, nid, &pos) == 0)
    {
      rnode[pos].upd_sn = check_sn;
    rnode[pos].upd_cnt++;
    }
  #endif
  return 0;
}

int upd_get_upding_node(int type, unsigned char *dst_addr, int *hop, int check_sn, int node_type, int flag)
{
  if (UPD_CCO == node_type)
    {
      for (int i = 0; i < (sizeof(g_upd_uart) / sizeof(g_upd_uart[0])); i++)
        {
          if (g_upd_uart[i].upd_sn > 30 &&
            (0x0 == g_upd_uart[i].upd_info || 0x4 == g_upd_uart[i].upd_info))
            g_upd_uart[i].upd_info = 0x5;

          if ((0x1 == g_upd_uart[i].upd_info || 0x0 == g_upd_uart[i].upd_info || 0x4 == g_upd_uart[i].upd_info)
            && g_upd_uart[i].upd_sn != check_sn)
            {
              *hop = (i + UPD_A);
			  #if 0
			  extern unsigned char jzq_address[6];
              memcpy(dst_addr, jzq_address, sizeof(jzq_address));
              return (sizeof(jzq_address));
			  #else
              memset(dst_addr, i, 6);
              return (6);
			  #endif
            }
        }
      return 0;
    }
  #if 1
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if ((0x1 == mt->upd_info || 0x0 == mt->upd_info) && mt->upd_sn != check_sn)
        {
          memcpy(dst_addr, mt->node.id, sizeof(mt->node.id));
		      *hop = mt->node.succhops;
          return (sizeof(mt->node.id));
        }
    }
  #else
  int n = pib_find(MT_NUM);

  for (int i = 0; i < n; i++)
    {
	  if (rnode[i].upd_sn > 30 && (0x0 == rnode[i].upd_info || 0x4 == rnode[i].upd_info))
	    rnode[i].upd_info = 0x5;

    if (flag && rnode[i].upd_cnt > 30 && (0 == rnode[i].upd_info || 0x1 == rnode[i].upd_info || 0x4 == rnode[i].upd_info))
      rnode[i].upd_info = 0x5;
    if (((0x1 == rnode[i].upd_info && flag) || 0x0 == rnode[i].upd_info || 0x4 == rnode[i].upd_info)
        && rnode[i].upd_sn != check_sn)
        {
		  *hop = rnode[i].depth;/* ������Ҫ����4����5�� */
          memcpy(dst_addr, rnode[i].node.aid, sizeof(rnode[i].node.aid));
          return (sizeof(rnode[i].node.aid));
        }
    }
  #endif
  return 0;
}

int upd_check_fnsh_rate(unsigned int *t_num, unsigned int *f_num, unsigned int *u_num, int node_type)
{
  if (UPD_CCO == node_type)
    {
      int total_num = 0, upding_num = 0;

      for (int i = 0; i < (sizeof(g_upd_uart) / sizeof(g_upd_uart[0])); i++)
        {
          total_num++;
          if (0x1 == g_upd_uart[i].upd_info || 0x0 == g_upd_uart[i].upd_info || 0x4 == g_upd_uart[i].upd_info)
            upding_num++;
        }

      *t_num = total_num;
      *f_num = total_num - upding_num;

      if (0 == total_num)
        return 0;

      return ((total_num - upding_num) * 100) / total_num;
    }
  #if 1
  struct mtinfo *mt;
  int total_num = 0, upding_num = 0;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      total_num++;
      if (mt->upd_info == 1 || mt->upd_info == 0)
        upding_num++;
    }

  *t_num = total_num;
  *f_num = total_num - upding_num;

  if (0 == total_num)
    return 0;

  return ((total_num - upding_num) * 100) / total_num;
  #else
  int total_num = 0, upding_num = 0, upding_num1 = 0;
  int n = pib_find(MT_NUM);

  for (int i = 0; i < n; i++)
    {
      total_num++;
      if (0x1 == rnode[i].upd_info || 0x0 == rnode[i].upd_info || 0x4 == rnode[i].upd_info)
        upding_num++;
    if (0x1 == rnode[i].upd_info)
      upding_num1++;
    }

  *t_num = total_num;
  *f_num = total_num - upding_num;
  if (NULL != u_num)
    *u_num = upding_num1;
  if (0 == total_num)
    return 0;

  return ((total_num - upding_num) * 100) / total_num;
  #endif
}

int upd_get_bit_num(unsigned int *map, unsigned int max_sn)
{
  int i = 0, num = 0;

  if (NULL == map)
    return -1;

  while (i < max_sn)
    {
      if (check_bitmap_sn(map, i, max_sn))
        num++;

      i++;
    }

  return num;
}

void upd_route_check_next(unsigned char *addr, int alen, int tim)
{
  upd_route_t *upd_route = &g_upd_route;

  if (0 == memcmp(upd_route->cur_dst, addr, alen)
    && ROUTE_ACTION_CHECK == upd_route->action)
    upd_put_off_route_check(tim);  /* ��ǰ��ѯ��Ӧ����������һ�� */
}

int upd_get_hops(int type, int opt)
{
//  int n = pib_find(MT_NUM), hops;
  int hops;
  struct mtinfo *mt;
  if (1/* PRO_55_3 == type */)  /* 4���Ĵ��� */
    {
    db_trav_reset(CHAN_TMP);
	  if (opt)
		{
		  hops = 0;
      #if 0
		  for (int i = 0; i < n; i++)
		    {
		      if (rnode[i].depth > hops)
			    hops = rnode[i].depth;
	        }
      #else
        while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
          {
            if ((mt->node.succhops & NFSUC) && ((mt->node.succhops & NHMASK) > hops))
              hops = mt->node.succhops & NHMASK;
          }
      #endif
		}
	   else
	    {
		  hops = 7;
      #if 0
		  for (int i = 0; i < n; i++)
		    {
		      if (rnode[i].depth < hops)
			    hops = rnode[i].depth;
	        }
      #else
        while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
          {
            if ((mt->node.succhops & NFSUC) && ((mt->node.succhops & NHMASK) < hops))
              hops = mt->node.succhops & NHMASK;
          }
      #endif
	    }
    }
  else  /*  V���Ĵ��� */
    {
	  if (opt)
		{
		  hops = 0;
      #if 0
		  for (int i = 0; i < n; i++)
		    {
		      if (rnode[i].hop > hops)
			    hops = rnode[i].hop;
	        }
      #else
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if (mt->hop > hops)
            hops = mt->hop;
        }
      #endif
		}
	   else
	    {
		  hops = 7;
      #if 0
		  for (int i = 0; i < n; i++)
		    {
		      if (rnode[i].hop < hops)
			    hops = rnode[i].hop;
	        }
      #else
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if (mt->hop < hops)
            hops = mt->hop;
        }
      #endif
	    }
    }

  return hops;
}

void upd_route_run()
{
    upd_route_t *upd_route = &g_upd_route;
    upd_ctrl_t *upd_ctrl = &g_upd_ctrl;
    upd_para_t *upd_para = &g_upd_para;
    unsigned char cur_addr[32];
    int addr_len, src_rslt;
    unsigned int rate = 0, t_num = 0, f_num = 0;
	int hop = 0;

    if (ROUTE_ACTION_START == upd_route->action)
      {
        if (UPD_PARA_VALID != upd_para->valid)
          return;

        upd_ctrl->upd_role = ROLE_SRC;
        upd_ctrl->cur_cmd = UPD_CMD_START;

        upd_route->send_times = 15;
        upd_route->send_type = ROUTE_SEND_CMD;
        upd_route->send_intvl = (upd_get_wait_tim(upd_para->file.pro_type, 0xF, 80, 0, upd_para->file.ntype));
        upd_put_off_route_send(upd_route->send_intvl);

        upd_route->action = ROUTE_ACTION_SEND;
        upd_route->next_action = ROUTE_ACTION_SRC;

        upd_route->total_num = get_node_num();
        upd_route->suces_num = 0;
        memset(upd_route->cur_dst, 0x00, sizeof(upd_route->cur_dst));
        upd_route->dst_len = 0;
        upd_route->dst_type = 0;
        upd_route->dst_opt = 0;
        upd_route->cur_sn = 0;
        upd_route->check_flag = 0;
        upd_route->check_type = 0;
        upd_route->check_round = 0;
        upd_route->active_flag = 0;
        upd_route->active_cnt = 0;

        memset(&g_upd_src, 0x00, sizeof(upd_src_t));
        memset((unsigned char *)&upd_route->suces_map, 0x00, sizeof(upd_route->suces_map));
        memset((unsigned char *)&upd_route->finish_map, 0x00, sizeof(upd_route->finish_map));

        if (MODE_BR == upd_ctrl->upd_mode)
          {
            memset(upd_blk_map, AUPD_SRC_INIT, ((upd_para->file.blk_num + 7)/8));
            upd_start_send_blk(0);
          }
        //set_sta_upgrd_state(UPGRD_STA_UPDATING);
#if 1
    if (UPD_CCO != upd_para->file.ntype)
    {
	    upd_route->check_flag = 0;
      upd_route->src_flag = 0;
		upd_route->next_action = ROUTE_ACTION_CHECK;
		upd_route->check_round = 1;
		memset(upd_blk_map, 0x00, ((upd_para->file.blk_num + 7)/8));
    }
#endif
      }
    else if (ROUTE_ACTION_SRC == upd_route->action)
      {
        src_rslt = upd_src_run();

        if (MODE_BR == upd_ctrl->upd_mode)
          {
            if (-1 == src_rslt)
              {
                upd_route->action = ROUTE_ACTION_CHECK;
                upd_route->next_action = 0;

                upd_put_off_route_check(6000);
                upd_route->check_flag = 0;
                upd_route->check_type = AUPD_CHECK_RSLT;
        upd_route->src_flag = 0x1;
                g_check_cnt++;
                return;
              }
          }

    rate = upd_check_fnsh_rate(&t_num, &f_num, NULL, upd_para->file.ntype);
        upd_route->total_num = t_num;
        upd_route->suces_num = f_num;
        if (upd_route->total_num == upd_route->suces_num)
          {
            upd_route->action = ROUTE_ACTION_REBOOT;
            upd_route->next_action = 0;
          }
      }
    else if (ROUTE_ACTION_CHECK == upd_route->action)
      {
        if (ROUTE_CHECK_FLAG == upd_route->check_flag)
          {
            upd_route->check_flag = 0;

            if (0 == upd_route->dst_opt)
              {
        addr_len = upd_get_upding_node(upd_para->file.pro_type, cur_addr, &hop, upd_route->check_round, upd_para->file.ntype, upd_route->src_flag);

                if (addr_len > 0)
                  {
                    memcpy(upd_route->cur_dst, cur_addr, addr_len);
                    upd_route->dst_len = addr_len;
                    upd_route->dst_hop = hop;
                    upd_check_state(0xFFFF, 0, cur_addr, addr_len, upd_para->file.addr_type, ((UPD_STA == upd_para->file.ntype) ? UPD_APP : hop));
                    upd_put_off_route_check(upd_get_wait_tim(upd_para->file.pro_type, hop, 60, 120, upd_para->file.ntype));
          if (UPD_CCO == upd_para->file.ntype)
            cur_addr[0] = hop - UPD_A;
                    update_node_check_sn(cur_addr, upd_route->check_round, upd_para->file.ntype);
                  }
                else
                  {
                    upd_route->check_round++;

          unsigned int upding_num = 0;
          rate = upd_check_fnsh_rate(&t_num, &f_num, &upding_num, upd_para->file.ntype);
                    upd_route->total_num = t_num;
                    upd_route->suces_num = f_num;

          es_printf(UPD_PRINT_OPT," total_num = %d, finish_num = %d, upding_num = %d\n",upd_route->total_num,upd_route->suces_num, upding_num);
          if (UPD_CCO != upd_para->file.ntype && t_num > 0 && f_num == 0 && ((upding_num) * 100 / t_num) < 50)
          {
            upd_route->check_flag = ROUTE_CHECK_FLAG;
            return;
          }

                    upd_route->action = ROUTE_ACTION_SRC;
                    upd_route->next_action = 0;

                    upd_route->dst_len = 0;
                    memset(upd_route->cur_dst, 0x00, sizeof(upd_route->cur_dst));

                    if (MODE_BR == upd_ctrl->upd_mode) /* ?? */
                      upd_start_send_blk(1000);
                  }
              }
            else
              {
                int tim = 0;
                if (0x1 == upd_route->dst_opt)
                  {
                    tim = upd_get_wait_tim(upd_para->file.pro_type, 0xF, 120, 80, upd_para->file.ntype);
                    upd_send_start(upd_route->cur_dst, upd_route->dst_len, upd_route->dst_type, 1, ((UPD_STA == upd_para->file.ntype) ? UPD_APP : upd_route->dst_hop));
					upd_route->dst_opt = 0;
                  }
                else if (0x2 == upd_route->dst_opt)
                  {
                    tim = upd_get_wait_tim(upd_para->file.pro_type, 0xF, 100, 0, upd_para->file.ntype);
                    upd_send_stop(0, upd_route->cur_dst, upd_route->dst_len, upd_route->dst_type, ((UPD_STA == upd_para->file.ntype) ? UPD_APP : upd_route->dst_hop));
                    upd_route->dst_opt = 0x1;
                  }
				else
			      upd_route->dst_opt = 0;
                upd_put_off_route_check(tim);
              }

          }

        if (upd_route->total_num == upd_route->suces_num)
          {
            upd_route->action = ROUTE_ACTION_REBOOT;
            upd_route->next_action = 0;
          }
      }
    else if (ROUTE_ACTION_REBOOT == upd_route->action)
      {
        upd_ctrl->cur_cmd = UPD_CMD_REBOOT;

    upd_route->send_times = 15;
        upd_route->send_type = ROUTE_SEND_CMD;
    upd_route->send_intvl = (upd_get_wait_tim(upd_para->file.pro_type, 0xF, 80, 0, upd_para->file.ntype));
        upd_put_off_route_send(0);

        upd_route->action = ROUTE_ACTION_SEND;
        upd_route->next_action = ROUTE_ACTION_OVER;

        es_printf(UPD_PRINT_OPT," total_num = %d, finish_num = %d\n",upd_route->total_num,upd_route->suces_num);
      }
    else if (ROUTE_ACTION_STOP == upd_route->action)
      {
        upd_ctrl->cur_cmd = UPD_CMD_STOP;

    upd_route->send_times = 5;
        upd_route->send_type = ROUTE_SEND_CMD;
    upd_route->send_intvl = (upd_get_wait_tim(upd_para->file.pro_type, 0xF, 60, 0, upd_para->file.ntype));
        upd_put_off_route_send(0);

        upd_route->action = ROUTE_ACTION_SEND;

        if (ROUTE_ACTION_START != upd_route->next_action)
          upd_route->next_action = ROUTE_ACTION_OVER;
      }
    else if (ROUTE_ACTION_SEND == upd_route->action)
      {
        if (ROUTE_SEND_FLAG == upd_route->send_flag)
          {
            if (0 == upd_route->send_times)
              return;

            upd_route->send_flag = 0;
            upd_route->send_times--;

            if (ROUTE_SEND_CMD == upd_route->send_type)
              {
                upd_send_cmd(upd_ctrl->cur_cmd, upd_para->file.ntype);
              }

            if (upd_route->send_times > 0)
        upd_put_off_route_send(((upd_route->send_times < 3) ?  (2*upd_route->send_intvl) : upd_route->send_intvl));
            else
              {
				if (ROUTE_ACTION_SRC == upd_route->next_action)
          upd_src_start_wait(upd_route->send_intvl);
				else if (ROUTE_ACTION_CHECK == upd_route->next_action)
          upd_put_off_route_check(upd_route->send_intvl);
                upd_route->action = upd_route->next_action;
                upd_route->next_action = 0;
              }
          }
      }
    else if (ROUTE_ACTION_OVER == upd_route->action)
      {
        upd_route->action = 0;
        upd_route->next_action = 0;

        free_upgrd_buf();
        //set_sta_upgrd_state(UPGRD_STA_UPDATED);
        //aupd_mode_change(0);
        es_printf(UPD_PRINT_OPT," upd over!!!!\n");

        /* ��״̬����������� */
      }
}

void upd_run()
{
  upd_route_run();
  upd_deal_frm();
}

void aupd_reboot()
{
  g_upd_route.action = ROUTE_ACTION_REBOOT;
  g_upd_route.next_action = 0;
}

void aupd_stop()
{
  g_upd_route.action = ROUTE_ACTION_STOP;
  g_upd_route.next_action = 0;
}

void aupd_show_info()
{
  int num_t = 0;
  int num_f = 0;
  int rate = upd_check_fnsh_rate(&num_t, &num_f, NULL, g_upd_para.file.ntype);
  printf_s("finish_num = %d total_num = %d \n",num_f, num_t);
  printf_s("finish rate:  %d%%\n", rate);
}

void aupd_print_fail_node(int opt)
{
  if (UPD_CCO == g_upd_para.file.ntype)
    {
      int j = 1;
      for (int i = 0; i < (sizeof(g_upd_uart) / sizeof(g_upd_uart[0])); i++)
        {
          if ((0x2 == opt && (0x1 == g_upd_uart[i].upd_info || 0x0 == g_upd_uart[i].upd_info))
            || (0x4 == opt && (0x1 != g_upd_uart[i].upd_info && 0x0 != g_upd_uart[i].upd_info))
            || (0x1 == opt && (0x2 == g_upd_uart[i].upd_info))
            || (0x3 == opt && (0x3 == g_upd_uart[i].upd_info || 0x4 == g_upd_uart[i].upd_info))
            || (0x0 == opt))
            {
              printf_s("uart-channel-%03d: state:%d rate:%d%% \n",j++,
              g_upd_uart[i].upd_info, g_upd_uart[i].upd_rate);
            }
        }
    }
  
  struct mtinfo *mt;
  int j = 1;
    
  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {  
    
  //int n = pib_find(MT_NUM), j = 1;

//   for (int i = 0; i < n; i++)
//     {
      if ((0x2 == opt && (0x1 == mt->upd_info || 0x0 == mt->upd_info))
        || (0x4 == opt && (0x1 != mt->upd_info && 0x0 != mt->upd_info))
        || (0x1 == opt && (0x2 == mt->upd_info))
        || (0x3 == opt && (0x3 == mt->upd_info || 0x4 == mt->upd_info))
        || (0x0 == opt))
        {
          printf_s("%03d-AID:%02X%02X%02X%02X%02X%02X state:%d rate:%d%% cnt:%d hop:%d depth:%d\n",j++,
          mt->node.id[5],mt->node.id[4],mt->node.id[3],mt->node.id[2],mt->node.id[1],mt->node.id[0],
          mt->upd_info, mt->upd_rate, mt->upd_cnt, mt->hop, mt->node.succhops & NHMASK);
        }
    }
}

int upd_send(unsigned char *buf, int len, unsigned char *dst, int pro, int chnl)
{
  int seq = get_next_flood_sno() << 4;//pib_find(P2P_SEQ);
  unsigned char dst_addr[IDLEN] = {0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F};
  unsigned char dst_addr5[IDLEN] = {0x99, 0x99, 0x99, 0x99, 0x99, 0x99};

  if (chnl >= UPD_A)
    {
      if (UPD_A == chnl || UPD_ABC == chnl)
        {
          sys_uart_write(CHN_38_1, buf ,len);
        }

      if (UPD_B == chnl || UPD_ABC == chnl)
        {
          sys_uart_write(CHN_38_2, buf ,len);
        }

     if (UPD_C == chnl || UPD_ABC == chnl)
        {
          sys_uart_write(CHN_38_3, buf ,len);
        }
      return 0;
    }

  if (1/* pro == PRO_55_3 */)
    {
	  if (NULL != dst)
        memcpy(dst_addr, dst, sizeof(dst_addr));
// 	  seq++;
// 	  pib_update(P2P_SEQ, seq);
      rt_mntplc_update_iv(dst_addr, buf, len);//rt_mntplc_flood(dst_addr, buf, len, seq, PLC_UPDATE);
    }
  else
    {
// 	  seq++;
// 	  pib_update(P2P_SEQ, seq);
	  if (NULL != dst)
        memcpy(dst_addr5, dst, sizeof(dst_addr5));
	  nl_p2p_53(dst_addr5, buf, len, seq, 1);
    }

  return 0;
}

static void encrypt_7F(unsigned char *data, int len)
{
  unsigned int len_t, alen, i;
  unsigned char seed;

  len_t = data[2] + 0x100 * data[3];
  alen = data[4];

  if (0x7F != data[0] || (len_t + alen + 10) > len)
	return;

  seed = data[len_t + alen + 8] ^ data[len_t + alen + 9];

  for (i = 8; i < (len_t + 8); i++)
    {
      seed = seed ^ data[i];
      data[i] = seed;
    }

  len_t = (len_t ^ 0x2129) + 0x0A5A;
  data[2] = len_t & 0xFF;
  data[3] = (len_t & 0xFF00) >> 8;
}

static void decode_7F(unsigned char *data, int len)
{
  unsigned int len_t, alen, i;
  unsigned char seed;

  len_t = ((data[2] + 0x100 * data[3]) - 0x0A5A) ^ 0x2129;
  alen = data[4];

  if (0x7F != data[0] || (len_t + alen + 10) > len)
	return;

  data[2] = len_t & 0xFF;
  data[3] = (len_t & 0xFF00) >> 8;

  seed  = data[len_t + alen + 8] ^ data[len_t + alen + 9];

  for (i = len_t + 7; i > 8; i--)
	data[i] = data[i] ^ data[i-1];

  data[8] =  data[8] ^ seed;
}

static int upd_org_hdr(unsigned char *frm, int dlen, int alen, int atype, unsigned char *addr, int chnl)
{
  unsigned char *data = frm;

  data[0] = 0x7F;
  data[1] = UPD_VER;
  data[2] = dlen & 0xFF;
  data[3] = (dlen >> 8) & 0xFF;
  data[4] = alen;
  data[5] = 0;
  if (chnl >= UPD_A)
    data[5] = 0xF;
  data[6] = atype;
  data[7] = 0;
  data += UPD_HDR_LEN;


  if (alen > 0)
    memcpy((data + dlen), addr, alen);

  unsigned short crc16 = upd_crc16(data, (dlen + alen));
  data += (dlen + alen);

  data[0] = crc16 & 0xFF;
  data[1] = (crc16 >> 8) & 0xFF;

  int len_t = UPD_HDR_LEN + alen + dlen + 2;
  encrypt_7F(frm, len_t);

  return len_t;
}

int upd_send_start(unsigned char *dst_addr, int alen, int atype, int anum, int chnl)
{
  unsigned char buf[256];
  upd_frm_t *upd_frm = (upd_frm_t *)(buf + UPD_HDR_LEN);
  upd_start_t *upd_start = (upd_start_t *)(upd_frm + 1);
  upd_para_t *para = &g_upd_para;
  int len = 0;

  if (UPD_PARA_VALID != para->valid)
    return -1;

  memset(buf, 0x00, sizeof(buf));
  upd_frm->frm_id = 0x0;
  upd_frm->ctrl = ((anum > 0) ? 0x02 : 0x0);
  upd_frm->upd_id = para->upd_id;
  len += sizeof(upd_frm_t);

  upd_start->upd_type = ((upd_dpara[P_TYPE] & 0x7F) | ((upd_dpara[P_OPT] & 0x1) << 7));
  upd_start->file_type = para->file.file_type;
  upd_start->chn_type = upd_dpara[P_CHNL];
  upd_start->chip_type = para->file.hw_type;
  upd_start->tim_wd = upd_dpara[P_TIM];
  upd_start->seg_len = para->file.blk_len;
  upd_start->file_size = para->file.size;
  upd_start->file_crc = para->file.crc;
  upd_start->addr_len = alen;
  upd_start->addr_num = anum;
  upd_start->addr_type = para->file.addr_type;
  len += (sizeof(upd_start_t));

  if (NULL != dst_addr && alen > 0 && anum > 0)
    {
      len += (alen * anum);
      if ((len + UPD_HDR_LEN + 2) > sizeof(buf))
        return -1;
      memcpy((unsigned char *)(upd_start + 1), dst_addr, alen * anum);
    }

  len = upd_org_hdr(buf, len, 0, 0, NULL, chnl);
  upd_send(buf, len, dst_addr, para->file.pro_type, chnl);

  es_printf(UPD_PRINT_OPT,"upd send start: ID=%08X CRC=%08X SIZE=%d %d \n",
  para->upd_id, para->file.crc, para->file.size, len);

  return 0;
}

int upd_send_stop(unsigned int flag, unsigned char *dst_addr, int alen, int atype, int chnl)
{
  unsigned char buf[128];
  upd_frm_t *upd_frm = (upd_frm_t *)(buf + UPD_HDR_LEN);
  upd_stop_t *upd_stop = (upd_stop_t *)(upd_frm + 1);
  upd_para_t *para = &g_upd_para;
  int len = 0;

  memset(buf, 0x00, sizeof(buf));
  upd_frm->frm_id = 0x1;
  upd_frm->ctrl = 0x0;
//   if (UPD_PARA_VALID == para->valid)
//     upd_frm->upd_id = para->upd_id;
//   else
    upd_frm->upd_id = 0;

  len += sizeof(upd_frm_t);

  upd_stop->flag = flag;
  len += sizeof(upd_stop_t);

  len = upd_org_hdr(buf, len, alen, atype, dst_addr, chnl);
  upd_send(buf, len, dst_addr, para->file.pro_type, chnl);

  es_printf(UPD_PRINT_OPT,"upd send stop: %d %d\n", flag, len);

  return 0;
}

int upd_send_data(unsigned int sn, unsigned char *dst_addr, int alen, int atype, int chnl)
{
  unsigned char buf[512];
  upd_frm_t *upd_frm = (upd_frm_t *)(buf + UPD_HDR_LEN);
  upd_data_t *upd_data = (upd_data_t *)(upd_frm + 1);
  upd_para_t *para = &g_upd_para;
  int len = 0;

  if (UPD_PARA_VALID != para->valid || sn > (para->file.blk_num - 1))
    return -1;

  memset(buf, 0x00, sizeof(buf));
  upd_frm->frm_id = 0x2;
  upd_frm->ctrl = 0x0;
  upd_frm->upd_id = para->upd_id;
  len += sizeof(upd_frm_t);

  upd_data->seg_sn = sn;
  if (sn == (para->file.blk_num - 1))
    upd_data->data_len = para->file.last_len;
  else
    upd_data->data_len = para->file.blk_len;
  len += sizeof(upd_data_t);

  get_upd_file_blk((unsigned char *)(upd_data + 1), (unsigned int)para->file.file, sn * para->file.blk_len, upd_data->data_len);
  len += upd_data->data_len;

  len = upd_org_hdr(buf, len, alen, atype, dst_addr, chnl);
  upd_send(buf, len, dst_addr, para->file.pro_type, chnl);

  es_printf(UPD_PRINT_OPT,"upd send data: %d %d\n", sn, len);

  return 0;
}

int upd_check_state(int num, int sn, unsigned char *dst_addr, int alen, int atype, int chnl)
{
  unsigned char buf[128];
  upd_frm_t *upd_frm = (upd_frm_t *)(buf + UPD_HDR_LEN);
  upd_check_dn_t *upd_check = (upd_check_dn_t *)(upd_frm + 1);
  upd_para_t *para = &g_upd_para;
  int len = 0;

  memset(buf, 0x00, sizeof(buf));
  upd_frm->frm_id = 0x3;
  upd_frm->ctrl = 0x02;
  if (UPD_PARA_VALID == para->valid)
    upd_frm->upd_id = para->upd_id;
  else
    upd_frm->upd_id = 0;
  len += sizeof(upd_frm_t);

  if (UPD_PARA_VALID == para->valid)
    {
      if (num < 0 || (num > para->file.blk_num && num != 0xFFFF)
        || sn < 0 || sn > (para->file.blk_num - 1))
        return -1;
    }
  else
    {
      sn = 0;
      num = 0xFFFF;
    }

  upd_check->start_sn = sn;
  upd_check->check_num = num;
  upd_check->addr_len = alen;
  upd_check->addr_type = atype;
  if (alen > 0)
    memcpy(upd_check->addr, dst_addr, alen);
  len += (sizeof(upd_check_dn_t) - 1 + alen);

  len = upd_org_hdr(buf, len, alen, atype, dst_addr, chnl);
  upd_send(buf, len, dst_addr, para->file.pro_type, chnl);
  es_printf(UPD_PRINT_OPT,"upd send check: %02X%02X%02X%02X%02X%02X alen=%d %d\n",
  dst_addr[5], dst_addr[4], dst_addr[3], dst_addr[2], dst_addr[1], dst_addr[0], alen, len);
  return 0;
}

int upd_send_exec(unsigned char *dst_addr, int alen, int atype, int chnl)
{
  unsigned char buf[128];
  upd_frm_t *upd_frm = (upd_frm_t *)(buf + UPD_HDR_LEN);
  upd_exec_t *upd_exec = (upd_exec_t *)(upd_frm + 1);
  upd_para_t *para = &g_upd_para;
  int len = 0;

  if (UPD_PARA_VALID != para->valid)
    return -1;

  memset(buf, 0x00, sizeof(buf));
  upd_frm->frm_id = 0x4;
  upd_frm->ctrl = 0x0;
  upd_frm->upd_id = para->upd_id;
  len += sizeof(upd_frm_t);

  upd_exec->tim = ((UPD_STA == para->file.ntype) ? upd_dpara[P_DLY] : 0);
  len += sizeof(upd_exec_t);

  len = upd_org_hdr(buf, len, alen, atype, dst_addr, chnl);
  upd_send(buf, len, dst_addr, para->file.pro_type, chnl);
  es_printf(UPD_PRINT_OPT,"upd send exec: %d %d\n", upd_dpara[P_DLY], len);
  return 0;
}

int is_valid_upd(unsigned char *frm, int len)
{
  if (frm[0] != 0x7F)
    return -1;

  unsigned int len_t = UPD_HDR_LEN;

  unsigned int dlen = ((frm[2] + 0x100 * frm[3]) - 0x0A5A) ^ 0x2129;
  unsigned int alen = frm[4];

  len_t += (dlen + alen);

  if (len < (len_t + 2))
    return -1;

  len_t += 2;

  unsigned char buf[MAX_7F_LEN];
  if (len > sizeof(buf))
    return -1;
  memcpy(buf, frm, len_t);
  decode_7F(buf, len_t);

  unsigned int crc16 = (frm[len_t - 2] | (frm[len_t - 1] << 8));

  if (crc16 != upd_crc16((buf + UPD_HDR_LEN), len_t - UPD_HDR_LEN - 2))
    return -1;

  return len_t;
}

int aupd_indication(unsigned char *buf, int len, int chnl)
{
  decode_7F(buf, len);
  upd_hdr_t *upd_hdr = (upd_hdr_t *)buf;
  upd_frm_t *upd_frm = (upd_frm_t *)(upd_hdr + 1);
  unsigned int dlen = upd_hdr->dlen - sizeof(upd_frm_t);
  unsigned int frm_id = upd_frm->frm_id;
  unsigned int dir = upd_frm->ctrl & 0x1;

  if (aupd_frm.sta != AUPD_EMPTY || 0 == dir)
    return -1;

  if (dlen > sizeof(aupd_frm.frm) || upd_hdr->alen > sizeof(aupd_frm.addr))
    return -1;

  memcpy(aupd_frm.frm, (unsigned char *)(upd_frm + 1), dlen);
  memcpy(aupd_frm.addr, (unsigned char *)(upd_hdr + upd_hdr->dlen), upd_hdr->alen);
  aupd_frm.frm_id = frm_id;
  aupd_frm.upd_id = upd_frm->upd_id;
  aupd_frm.dlen = dlen;
  aupd_frm.alen = upd_hdr->alen;
  aupd_frm.sta = AUPD_PENDING;
  aupd_frm.chnl = chnl;

  return 0;
}

int upd_rcv_srslt(unsigned int upd_id, unsigned char *buf, unsigned int len, int chnl)
{
  upd_start_up_t *start_up = (upd_start_up_t *)buf;
  upd_para_t *para = &g_upd_para;

  if (len < (sizeof(upd_start_up_t) - 1 + start_up->addr_len) || upd_id != para->upd_id)
    return -1;

  int rate = 0, info = 0;
  if (UDP_START_SUCES == start_up->result)
    {
      rate = 0;
      info = 1;
    update_node_check_sn(start_up->addr, g_upd_route.check_round - 1, para->file.ntype);
    }
  else if (UDP_START_NO == start_up->result)
    {
      rate = 100;
      info = 2;
    }
  else if (UDP_START_ERR == start_up->result)
    {
      rate = 0;
    info = 5;
    }
  else
	return -1;

  if (UPD_CCO == para->file.ntype)
    {
      if (chnl < UPD_A)
        return -1;
      start_up->addr[0] = (chnl - UPD_A);
    }

  update_node_upd_info(start_up->addr, rate, info, para->file.ntype);

  es_printf(UPD_PRINT_OPT,"upd recv srslt: %02X%02X%02X%02X%02X%02X alen=%d, result=%d\n", start_up->addr[5],start_up->addr[4],
  start_up->addr[3],start_up->addr[2],start_up->addr[1],start_up->addr[0],start_up->addr_len,start_up->result);

  return 0;
}

int cal_node_upd_rate(unsigned char bitmap[], unsigned int max_sn)
{
  unsigned int next = 0, bit_num = 0;

  while (next < max_sn)
    {
      if ((bitmap[next / 8] >> (next % 8)) & 0x1)
        bit_num++;
      next++;
    }

  return ((bit_num * 100) / max_sn);
}

int upd_rcv_state(unsigned int upd_id, unsigned char *buf, unsigned int len, int chnl)
{
  unsigned char *pdata = buf;
  upd_check_up_t *check_up = (upd_check_up_t *)pdata;
  upd_para_t *para = &g_upd_para;
  int len_t = len, tim = 1000;
  int rate = 0, info = 0;

  pdata += (sizeof(upd_check_up_t));
  len_t -= (sizeof(upd_check_up_t));
  upd_check_addr_t *check_addr = (upd_check_addr_t *)pdata;

  if (UPD_CCO == para->file.ntype)
    {
      if (chnl < UPD_A)
        return -1;
      check_addr->addr[0] = (chnl - UPD_A);
    }

  es_printf(UPD_PRINT_OPT,"upd recv state: %02X%02X%02X%02X%02X%02X alen=%d,state=%d\n",check_addr->addr[5],check_addr->addr[4],
  check_addr->addr[3],check_addr->addr[2],check_addr->addr[1],check_addr->addr[0],check_addr->addr_len, check_up->state);
  if (UPD_CCO == para->file.ntype)
  {
    if (chnl < UPD_A)
      return -1;
    check_addr->addr[0] = (chnl - UPD_A);
	es_printf(UPD_PRINT_OPT,"upd coor: %d \n", check_addr->addr[0]);
  }
  if (UPD_STA_RCV == check_up->state)
    {
      unsigned char *dst_map = (unsigned char *)upd_blk_map;
      if (1 != check_addr->addr_num)
        return -1;

      if (upd_id != para->upd_id)
        {
          info = 0x4;
          rate = 0;
          update_node_upd_info(check_addr->addr, rate, info, para->file.ntype);
        }
      else
	    {
          pdata += (sizeof(upd_check_addr_t) - 1 + check_addr->addr_len);
          len_t -= (sizeof(upd_check_addr_t) - 1 + check_addr->addr_len);
          upd_check_map_t *check_map = (upd_check_map_t *)pdata;
          if (((check_map->num + 7) / 8 + sizeof(upd_check_map_t) - 1) < len_t)
			return -1;
          cpy_errmap_by_byte((dst_map + check_map->sn/8), check_map->map, (check_map->num + 7) / 8);
          rate = cal_node_upd_rate(check_map->map, para->file.blk_num);
	      info = 0x1;
          update_node_upd_info(check_addr->addr, rate, info, para->file.ntype);
	    }
    }
  else if (UPD_STA_FNS == check_up->state || UPD_STA_ING == check_up->state || UPD_STA_IDLE == check_up->state)
    {
      if (check_addr->addr_num < 1)
        return -1;
      len_t -= (sizeof(upd_check_addr_t) - 1);
      pdata += (sizeof(upd_check_addr_t) - 1);
      if ((check_addr->addr_len * check_addr->addr_num) < len_t)
        return -1;
      int addr_num = check_addr->addr_num;
      if (check_up->file_crc == para->file.crc && check_up->file_size == para->file.size)
        {
          if (upd_id != para->upd_id)
            info = 4;
		  else
		    info = 2;
          rate = 100;
          do
            {
              update_node_upd_info(pdata, rate, info, para->file.ntype);
              pdata += check_addr->addr_len;
              addr_num--;
            }while (addr_num);
        }
      else
        {
		  info = 0x3;
		  rate = 0;
          if (UPD_STA_IDLE != check_up->state && upd_id == para->upd_id)
            rate = 100;

          if (upd_id != para->upd_id)
            info = 4;

          do
            {
              update_node_upd_info(pdata, rate, info, para->file.ntype);
              pdata += check_addr->addr_len;
              addr_num--;
            }while (addr_num);
        }
    }

  upd_route_t *upd_route = &g_upd_route;
  if (0x4 == info && ROUTE_ACTION_CHECK == upd_route->action
    && ((UPD_STA == para->file.ntype && 0 == memcmp(upd_route->cur_dst, check_addr->addr, check_addr->addr_len)
           || (UPD_CCO == para->file.ntype && chnl >= UPD_A && (upd_route->dst_hop - UPD_A) == check_addr->addr[0]))))
    {
      upd_route->dst_len = check_addr->addr_len;
      upd_route->dst_type = check_addr->addr_type;
      if (UPD_STA_IDLE == check_up->state)
        {
          upd_route->dst_opt = 0x1;
          //upd_send_start(check_addr->addr, check_addr->addr_len, check_addr->addr_type, 1);
        }
      else
        {
          upd_route->dst_opt = 0x2;
          //upd_send_stop(0, check_addr->addr, check_addr->addr_len, check_addr->addr_type);
        }
      //tim = upd_get_wait_tim(para->file.pro_type, 0xF, 70, 50 * 3);
      //upd_put_off_route_check(tim);
      return 0;
	}

  if (0/* PRO_55_3 != para->file.pro_type */)
    upd_route_check_next(check_addr->addr, check_addr->addr_len, tim);

  return 0;
}

int upd_deal_frm()
{
  if (AUPD_PENDING == aupd_frm.sta)
    {
      if (0x0 == aupd_frm.frm_id)
        upd_rcv_srslt(aupd_frm.upd_id, aupd_frm.frm, aupd_frm.dlen, aupd_frm.chnl);
      else if (0x3 == aupd_frm.frm_id)
        upd_rcv_state(aupd_frm.upd_id, aupd_frm.frm, aupd_frm.dlen, aupd_frm.chnl);
      aupd_frm.sta = AUPD_EMPTY;
    }
  return 0;
}

void upd_init()
{
  aupd_frm.sta = AUPD_EMPTY;
}

void upd_send_cmd(int type, int node_type)
{
  int chnl = UPD_APP;
  if (UPD_CCO == node_type)
    chnl = UPD_ABC;

  if (UPD_CMD_START == type)
    upd_send_start(NULL, 0, 0, 0, chnl);
  else if (UPD_CMD_STOP == type)
    upd_send_stop(0, NULL, 0, 0, chnl);
  else if (UPD_CMD_REBOOT == type)
    upd_send_exec(NULL, 0, 0, chnl);
}

