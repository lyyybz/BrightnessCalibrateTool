/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2016 All rights reserved.
 *
 * File name: aupd.h
 *
 * Description:
 *
 * Version: v1.0
 * Time:
 *
 */
#ifndef __AUPD_H
#define __AUPD_H


#define UPD_VER     0
#define UPD_RBT_TIM 30
#define UPD_HDR_LEN (sizeof(upd_hdr_t))

enum
{
  UPD_NET = 0,
  UPD_LOCAL,
};

enum
{
  UPD_CHN_DFT = 0,
};

enum
{
  UPD_GEN = 0,
  UPD_FORCE,
};

enum
{
  UPD_STA_IDLE = 0x00,
  UPD_STA_RCV,
  UPD_STA_FNS,
  UPD_STA_ING,
};

enum
{
  UDP_START_SUCES = 0,
  UDP_START_NO,
  UDP_START_ERR,
};

enum
{
  UPD_APP = 0, /* ��������Ӧ�ò� */
  UPD_PHY,     /* �������������� */
  UPD_A,    /* �������Դ��� */
  UPD_B,
  UPD_C,
  UPD_ABC,
};

enum
{
   UPD_STA = 0,
   UPD_CCO,
};


typedef struct
{
  unsigned char  upd_type;
  unsigned char  file_type;
  unsigned char  chn_type;
  unsigned char  chip_type;
  unsigned short tim_wd;
  unsigned short seg_len;
  unsigned int   file_size;
  unsigned int   file_crc;
  unsigned char  resv[2];
  unsigned char  addr_len;
  unsigned char  addr_num;
  unsigned char  addr_type;
}__attribute__((packed))upd_start_t;

typedef struct
{
  unsigned char  result;
  unsigned char  addr_len;
  unsigned char  addr_type;
  unsigned char  addr[1];
}__attribute__((packed))upd_start_up_t;

typedef struct
{
  unsigned char  flag;
}__attribute__((packed))upd_stop_t;

typedef struct
{
  unsigned int   seg_sn;
  unsigned short data_len;
}__attribute__((packed))upd_data_t;

typedef struct
{
  unsigned short  tim;
}__attribute__((packed))upd_exec_t;

typedef struct
{
  unsigned int   start_sn;
  unsigned short check_num;
  unsigned char  addr_len;
  unsigned char  addr_type;
  unsigned char  addr[1];
}__attribute__((packed))upd_check_dn_t;

typedef struct
{
  unsigned int   file_size;
  unsigned int   file_crc;
  unsigned char  state;
}__attribute__((packed))upd_check_up_t;

typedef struct
{
  unsigned char  addr_len;
  unsigned char  addr_num;
  unsigned char  addr_type;
  unsigned char  addr[1];
}__attribute__((packed))upd_check_addr_t;

typedef struct
{
  unsigned int   sn;
  unsigned short num;
  unsigned char  map[1];
}__attribute__((packed))upd_check_map_t;

typedef struct
{
  unsigned char  frm_id;
  unsigned char  ctrl;
  unsigned char  rsv[2];
  unsigned int   upd_id;
}__attribute__((packed))upd_frm_t;

typedef struct
{
  unsigned char  start;
  unsigned char  ver;
  unsigned short dlen;
  unsigned char  alen;
  unsigned char  rsv[3];
}__attribute__((packed))upd_hdr_t;

void upd_stop_cur(int rbot_flag);
void upd_init();
void upd_run();
int upd_route_start(unsigned char *file, int size, int file_type, int hw_type, int pro_type, int ntype);

#endif
