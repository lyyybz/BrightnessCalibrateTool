#ifndef _TP_H_
#define _TP_H_

#pragma pack(1)

#define CTL_ERROR       0x01
#define CTL_CONFIRM     0x02
#define CTL_ASK_PANID   0x10
#define CTL_SET_PANID   0x11
#define CTL_CHK_APPID   0x12
#define CTL_ASW_APPID   0x13
#define CTL_REG_SUCC    0x14
#define CTL_EXILE_NODE  0x15
#define CTL_NODE_EXIT   0x16
#define CTL_ASK_NETID   0x17
#define CTL_ASW_NETID   0x18
#define CTL_LOCAL_CMD   0x20
#define CTL_REMOTE_CMD  0x21

#define	NL_FRM_HEADER		0x9F
#define	NL_FRM_DEF_LEN	0x04
#define	NL_FRM_MIN_LEN	0x05
#define	NL_FRM_MAX_LEN	0x100

#define MAX_TID_NUM     1000

#define CHN_FAIL_CNT    10//ԭ����20��ʱ�ĳ�10

enum 
{
  SMARTHOME = 0x01,
  METER,
  REPEATER,
  CJQ,
  TQSBY,  /* ̨��ʶ���� */
  UNKNOWN = 0xf, 
};

struct nl_api_info
{
	void (*fun)(unsigned char *, unsigned char len, unsigned char phase);
	unsigned char ctrl;
};

/* �м��� */
struct rid_info
{
  unsigned char eid[5];
  unsigned short sid;
};

struct nl_chkaid_info_up
{
  unsigned char tno[5];
  unsigned char eid[8];
  unsigned short regsid;
  unsigned short relsid;
  unsigned char ver[3];
  unsigned char aidnum;
  unsigned char data[1];
};

struct nl_chkaid_info_down
{
  unsigned char tno[5];
  unsigned char eid[8];
  unsigned short regsid;
  unsigned short gid;
  unsigned char aidnum;
  unsigned char data[1];
};

/* ��ʱ��ַ */
struct tid_info
{
  unsigned char eid[5];
  unsigned short sid;
};

struct chn_info
{
  unsigned char curchn; /* ��ǰ���� */
  struct
  {
    unsigned char chn1;
    unsigned char chn2;
    unsigned char chn3;
  }failcnt; /* ����ʧ�ܴ��� */
};

void nl_start_net();
int chn_init();
int tp_init();
void aid_645_tohash(unsigned char *aid);
void aid_645_tonormal(unsigned char *aid);
#endif

