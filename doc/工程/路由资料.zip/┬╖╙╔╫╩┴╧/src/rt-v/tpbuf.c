/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2015 All rights reserved.
 *
 * File name: tpbuf.c
 *
 * Description: transport layer buffer 
 *
 * Version: v1.0
 * Time:    2015-06-26
 *
 */

//#include "../ague.h"
//#include "../sys/viuart.h"
//#include "uart.h"
//#include "uart_reg.h"
//#include "../dev/uart.h"
#include "tpbuf.h"
//#include "../sys/timer.h"
//#include "../vinets.h"
#include "pib.h"
#include "router.h"
#include "dev_ctrl.h"

static void tp_chn_buf_init();
static void tp_task_buf_init();
static void tp_chn_buf_resend();
static void tp_task_done();

static struct tp_chn_buf
{
  unsigned char frame[255];
  int len;
  int over_tick; 
  int send_count; 
  unsigned char chn;
} chn_buf;

static struct tp_task_buf
{
  unsigned char buf[0x100];
  int len;
  int chn;
  int chn_all;
  tp_func func;
} task_buf;

void tpbuf_init()
{
  tp_chn_buf_init();
  tp_task_buf_init();
}

void tp_chn_buf_write(unsigned char chn, unsigned char *frm, int len, int tick, int times)
{
  if ((0 == len) || (len > sizeof(chn_buf.frame)))
    return;

  sys_uart_write(chn, frm ,len);

  if (times > 1)
  {
    pib_update(RT_WAIT_CHN, pib_find(RT_WAIT_CHN) | (1 << chn));
    memcpy(chn_buf.frame, frm, len);
    chn_buf.len = len;
    chn_buf.over_tick = tick;
    chn_buf.send_count = times;
    chn_buf.chn = chn;

    timers_create(TIMER_WAIT38_ACK, tick, tp_chn_buf_resend);
  }
}

void tp_task_buf_write(unsigned char *buf, int len, int chn, tp_func func)
{

#if 0
  /* ��������������ϴβ�ͬ����ɾ��������������ִ�б������񣬲����汾������ */
  if ((len != task_buf.len) || (func != task_buf.func) || memcmp(task_buf.buf, buf, len))
  {
    tp_task_buf_init();

    task_buf.len = len;
    task_buf.func = func;
    task_buf.chn = chn;
    memcpy(task_buf.buf, buf, len);

    task_buf.func(task_buf.buf, task_buf.len, task_buf.chn);

    timers_create(TIMER_NL_BUF, 100, tp_task_buf_init); /* �ȴ�100ms����ջ��� */
  }
#endif

  if ((len != task_buf.len) || (func != task_buf.func) || memcmp(task_buf.buf, buf, len))
  {
    tp_task_done();
    task_buf.len = len;
    task_buf.func = func;
    task_buf.chn = chn;
    task_buf.chn_all = 0;
    memcpy(task_buf.buf, buf, len);

    timers_create(TIMER_NL_BUF, 70, tp_task_done); /* �ȴ�70ms�󣬴��� */
  }
  task_buf.chn_all |= (1 << chn);

  /* ���3�����ڶ��յ����Ͳ����� */
  if ((task_buf.chn_all & 0x0E) == 0x0E)
    {
      timers_delete(TIMER_NL_BUF);
      tp_task_done();
    }
  
  /* ��������������ϴ���ͬ�������κδ��� */
  return;
}

static void tp_chn_buf_init()
{
  memset(&chn_buf, 0x00, sizeof(struct tp_chn_buf));
  timers_delete(TIMER_WAIT38_ACK);
  pib_update(RT_WAIT_CHN, pib_find(RT_WAIT_CHN) & 0x01);
}

static void tp_task_buf_init()
{
  memset(&task_buf, 0x00, sizeof(struct tp_task_buf));
  timers_delete(TIMER_NL_BUF);
}

static void tp_chn_buf_resend()
{
  chn_buf.send_count--;
  pib_update(RT_WAIT_CHN, pib_find(RT_WAIT_CHN) & ~(1 << chn_buf.chn));

  if (0 == chn_buf.send_count)
  {
    tp_chn_buf_init();
    return;
  }
  sys_uart_write(chn_buf.chn, chn_buf.frame ,chn_buf.len);
  timers_create(TIMER_WAIT38_ACK, chn_buf.over_tick, tp_chn_buf_resend);
  pib_update(RT_WAIT_CHN, pib_find(RT_WAIT_CHN) | (1 << chn_buf.chn));
}

static void tp_task_done()
{
  if ((task_buf.func != NULL) && (task_buf.len > 0) && (task_buf.len < sizeof(task_buf.buf)))
      task_buf.func(task_buf.buf, task_buf.len, task_buf.chn);

  task_buf.len = 0;
  task_buf.chn_all = 0;
}

int tp_get_chn()
{
  static int order = 1;

  if (task_buf.chn_all & ~((1 << CHN_38_1) | (1 << CHN_38_2) | (1 << CHN_38_3)))
    return(task_buf.chn);

  if (order > 3)
    order = 1;

  if (task_buf.chn_all & (1 << order))
    {
      order++;
      return (order - 1);
    }

  order++;
  if (order > 3)
    order = 1;

  if (task_buf.chn_all & (1 << order))
    {
      order++;
      return (order - 1);
    }

  order++;
  if (order > 3)
    order = 1;

  if (task_buf.chn_all & (1 << order))
    {
      order++;
      return (order - 1);
    }

  order++;
  return(task_buf.chn);
}

int tp_get_all_chn()
{
  return task_buf.chn_all;
}
