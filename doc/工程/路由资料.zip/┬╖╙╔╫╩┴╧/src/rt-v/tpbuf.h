/*
 * Copyright by Qingdao EASTSOFT Communication Technology Co.,Ltd. 2015 All rights reserved.
 *
 * File name: tpbuf.h
 *
 * Description: transport layer buffer 
 *
 * Version: v1.0
 * Time:    2015-06-26
 *
 */

#ifndef TPBUF_H
#define TPBUF_H

#pragma pack(1)

typedef void (*tp_func)(unsigned char *, unsigned char, unsigned char);

/*
 * Function:   initialize the transport layer buffer to zero.
 * Parameters: none
 * Return:     none
 *
 */
void tpbuf_init();

/*
 * Function:   put data into tp chn buffer,and wait to send.
 * Parameters: chn - the uart chn which to send 
 *             *pframe - data to send
 *             frame_len - length of data to send
 *             over_tick - time to wait to send again,if no ack
 *             send_times - times to send ,if no ack
 * Return:     none
 *
 */
void tp_chn_buf_write(unsigned char chn, unsigned char *frm, int len, int tick, int times);

/*
 * Function:   put data and function into tp task buffer,and wait to handle.
 * Parameters: buf[] - the data to put into the nl buffer 
 *             len - length of data to put into the nl buffer 
 *             chn - length of data to send
 *             func - function to put into the nl buffer
 * Return:     none
 *
 */
void tp_task_buf_write(unsigned char *buf, int len, int chn, tp_func func);

int tp_get_all_chn();
int tp_get_chn();
void tpbuf_init();
#endif

