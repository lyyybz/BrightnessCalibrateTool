#include "ses.h"
#include "appgb.h"
#include "rtpara.h"
#include "router.h"
#include "../../rtiii/include/db/node.h"
#include "../../rtiii/include/db/hash.h"
#include "../../rtiii/include/tool/toolfun.h"
#include "../../rtiii/include/app/nwtask.h"

static unsigned int search_time;
extern struct rtpara _rtparas;
static unsigned int idle_time;
static unsigned int powerup_time;
static unsigned int broad_time;
extern unsigned char appgb_reg_v;

void ses_task_time_tick()
{
  if (powerup_time)
    powerup_time--;
  
  if (idle_time)
    idle_time--;
  
  if (search_time)
    search_time--;
  
  if (broad_time)
    broad_time--;
}

#define power_up_num 12  /* �����ϱ������� */
extern unsigned char flag_broad_v;
extern struct gbbrd_info_v brdinfo_v;
extern struct task_nw_info nw_task[2];
void ses_task_switch()
{
  struct mtinfo *mt;

  if ((search_time <= 90 * 60) && (appgb_reg_v == 1))  /* �˴���ֵ90 * 60���2.5h��V���ע��ʱ��1Сʱ */
    {
      ses_switch_iiireg();
    }
  
  if (idle_time == 0)
    {
      if (((_rtparas.state & STARMASK) == STAREG) && (appgb_reg_v == 1))
        {
          ses_switch_iiireg();
        }
    }
  
  if ((broad_time == 0) && (flag_broad_v == 1))
    {
      if ((_rtparas.state & STABMASK) == STABROAD)
        {
          if (0 != appgb_broad(brdinfo_v.appdata, brdinfo_v.len, 0))  //���һ��������ʱû����
            {
              id_bintobcd(nw_task[TASK_EXE_HIGH].appid);
              reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
              nw_report_task_state(nw_task[TASK_EXE_HIGH].tid, nw_task[TASK_EXE_HIGH].appid, TASK_STATUS_DATA_ERR);
              ses_del_task(nw_task[TASK_EXE_HIGH].tid);
              init_nw_cur_task(TASK_EXE_HIGH);
            }
            
          flag_broad_v = 0;  /* V��ִ����ִ��IV���㲥 */
        }
    }
  
  if (powerup_time == 0)
    {
      unsigned char buf_power[200], num_power;
      powerup_time = 1 * 10; /* 10s��ѭһ��*/
      
      num_power = 0;
      memset(buf_power, 0x00, 200);
      db_trav_reset(CHAN_TMP);
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if (mt->powmt_on == 1)
            {
              memcpy(&buf_power[num_power * 6],  mt->node.id, 6);
			        mt->powmt_on = 0;  /* �ϱ��ı����¼� */
              num_power++;
			        if (num_power >= power_up_num)
				        break;
            }
        }
      if (num_power > 0)
        app_mtpower_up(num_power, buf_power);  /* ��������ϱ�power_up_numֻ��,ͣ���¼� */
      
      
      num_power = 0;
      memset(buf_power, 0x00, 200);
      db_trav_reset(CHAN_TMP);
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if ((mt->swapmt2 & 0x01) && (num_power < power_up_num))
            {
              memcpy(&buf_power[num_power * 6], mt->node.id, 6);
              num_power++;
              mt->swapmt2 &= 0x0E;  /* ����Ҫ�ϱ���־λ */
            }
        }
      if (num_power > 0)
        app_power_up(3, num_power, buf_power);  /* ��������ϱ�power_up_numֻ��,�β��¼� */
      
      
      num_power = 0;
      memset(buf_power, 0x00, 200);
      db_trav_reset(CHAN_TMP);
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if ((mt->powmt2_on & 0x01) && (num_power < power_up_num))
            {
              memcpy(&buf_power[num_power * 6], mt->node.id, 6);
              num_power++;
              mt->powmt2_on &= 0x0E;  /* ����Ҫ�ϱ���־λ */
            }
        }
      if (num_power > 0)
        app_power_up(2 ,num_power, buf_power);  /* ��������ϱ�power_up_numֻ��,�ϵ��¼� */
      
      
      num_power = 0;
      memset(buf_power, 0x00, 200);
      db_trav_reset(CHAN_TMP);
      while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
        {
          if ((mt->powmt2_off & 0x01) && (num_power < power_up_num))
            {
              memcpy(&buf_power[num_power * 6], mt->node.id, 6);
              num_power++;
              mt->powmt2_off &= 0x0E;  /* ����Ҫ�ϱ���־λ */
            }
        }
      if (num_power > 0)
        app_power_up(1 ,num_power, buf_power);  /* ��������ϱ�power_up_numֻ��,�ϵ��¼� */

    }

}

int ses_searching()
{
  return search_time;
}

int ses_set_search_time(int t)
{
  search_time = t;

  return 0;
}

void ses_reset_idle_time()
{
#ifdef CZZ_DEBUG
  idle_time = 1 * 60; 
#else
  idle_time = 4 * 60; /* 4���� *///czz
#endif
}

void ses_clr_idle_time()
{
  idle_time = 0;
}

int ses_get_node_ver(unsigned char ver, unsigned char *data)
{
  eep_read(e2rom_addr(node_ver) + ver * 3, data, 3);
  return 0;
}

extern unsigned char local_viv_swi;
void set_dc_fail_cnt(unsigned char *aid, unsigned char flag)
{
  unsigned char aid_hash[IDLEN];
  struct mtinfo *mtp;
  unsigned char succ_rate = 0;
  memcpy(aid_hash, aid, IDLEN);
  aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�����
  if (((mtp = hash_find(aid_hash)) != NULL) || ((mtp = hash_find(aid)) != NULL))  /* ��ַ�п�����ת����Ҳ������û��ת���� */
    {
      /*ͳ���³����ɹ���*/
      if (flag == 1)
        {
          
          mtp->dc_succ_rate += ((mtp->dc_cnt - mtp->dc_fail_cnt) / mtp->dc_cnt);
          mtp->dc_succ_rate = (mtp->dc_succ_rate / 2) * 100;
          mtp->dc_cnt = 0;
          mtp->dc_fail_cnt = 0;
        }
      
      if (flag == 2)
        {
          mtp->dc_fail_cnt++;
          if ((local_viv_swi != 1) && (mtp->dc_fail_cnt >= 10))//lyy
            {
              mtp->dc_succ_rate += ((mtp->dc_cnt - mtp->dc_fail_cnt) / mtp->dc_cnt);
              mtp->dc_succ_rate = (mtp->dc_succ_rate / 2);
              mtp->dc_cnt = 0; 
              mtp->dc_fail_cnt = 0;
              
              memset(mtp->node.eid, 0xFF, sizeof( mtp->node.eid));  /* eid��Ϊδ֪ */
              mtp->node.sid = 0xFFFF;          /* sid��Ϊδ֪ */
              mtp->node.viv |= NNDMASK;        /* ���ó�δ֪����3:δ֪,�� */
              mtp->node.viv |= (1 << NNDMASK);  /* ��������Ϣ��� */

              db_write(mtp->addr + offset(struct mtnode, eid), mtp->node.eid, sizeof( mtp->node.eid));
              db_write(mtp->addr + offset(struct mtnode, sid), (unsigned char *)&mtp->node.sid, sizeof( mtp->node.sid));
              db_write(mtp->addr + offset(struct mtnode, viv), &mtp->node.viv, sizeof(mtp->node.viv));
            }

          if (mtp->dc_fail_cnt >= 10)  /*ÿ10һ����һ��*/
          {
            mtp->dc_succ_rate += ((mtp->dc_cnt - mtp->dc_fail_cnt) / mtp->dc_cnt);
            mtp->dc_succ_rate = (mtp->dc_succ_rate / 2) * 100;
            mtp->dc_cnt = 0;
            mtp->dc_fail_cnt = 0;
          }
        }
    }
}
void ses_switch_iiireg()
{
  /* ��V��ע�����֮�󣬽�search_time/60 ��ֵ��_rtreport.left������search_time��0 */
  appgb_reg_v = 0;
  set_iiireg_left(search_time / 60);
  ses_set_search_time(0);
}
void ses_set_broadtime()
{
  broad_time = 60;  //����Ϊ1���ӣ����ⱨ�ĳ�ͻ
}

void ses_debugup(unsigned char *buf, unsigned char len)
{
  app_debugup(buf, len);
}

void ses_debugdn(unsigned char *buf, unsigned char *data, int len, unsigned char ccw)
{
  nl_debugdn(buf, data, len, ccw);
}


