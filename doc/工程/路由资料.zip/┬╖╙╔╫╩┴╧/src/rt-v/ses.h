#ifndef _SES_H_
#define _SES_H_

#pragma pack(1)

struct reg_task_info
{
  unsigned char tno;
  unsigned int  time;
};

//#define RT_STATE_REG        0x01 /*extend way, node register*/

void ses_task_time_tick();
int ses_searching();
void ses_reset_idle_time();
void ses_clr_idle_time();
int ses_get_node_ver(unsigned char ver, unsigned char *data);
void ses_task_switch();
void set_dc_fail_cnt(unsigned char *aid, unsigned char flag);  /* flag��1�����ǳɹ���2����ʧ�� */
void ses_switch_iiireg();
#endif


