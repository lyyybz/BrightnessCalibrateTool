#include "tp.h"
#include "router.h"
#include "dev_ctrl.h"
#include "ses.h"
#include "pib.h"
#include "appgb.h"
#include "../../rtiii/include/db/node.h"
#include "../../include/db/hash.h"
#include "rtpara.h"
#include "../../include/db/db.h"
#include "../../rtiii/include/tool/toolfun.h"

static unsigned char chn38 = 0;
static unsigned char info[2]; /* ֡��Ϣ�� */
static unsigned char reset_id[6];
static struct tid_info tid[MAX_TID_NUM];  /* ���1000 */
unsigned int reset_times;
unsigned char reset_flag;
unsigned char wireless;  /* ·����Ϣ  0x00Ϊ��plc��0x01Ϊ˫ģ */
unsigned char tno_info;
unsigned short pan_id;
extern struct rtpara _rtparas;
struct chn_info chn;
static unsigned char flag_general = 0;  /* 0�ǳ�ʼֵ��1�ǳ���1�Σ�2�ǳ���2�Σ�3�Ƕ������ɹ� */
extern struct rt_test_info rt_test;

struct debug_info
{
  unsigned char id[0x08];
  unsigned int len;
  unsigned int chn;
}debuginfo;
// unsigned char zero_detect_buf[0x20] = {0};
// unsigned char zero_detect_chn = 0;
// unsigned char zero_chn[3] = {CHN_38_1, CHN_38_2, CHN_38_3};//��ֲ�Ը��ã�Ҳ��������{0x0, 0x3, 0x2};

static void nl_ctrl_error(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_confirm(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_ask_panid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_set_panid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_chk_appid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_asw_appid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_reg_succ(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_exile_node(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_node_exit(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_ask_netid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_asw_netid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_local_cmd(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_ctrl_remote_cmd(unsigned char *buf, unsigned char len, unsigned char phase);

static void nl_chk_aid(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_node_exit(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_local_cmd(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_remote_cmd(unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_set_panid();
static void nl_deal_cjqreg(unsigned char *info, unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_deal_p2pup(unsigned char *info, unsigned char *buf, unsigned char len, unsigned char phase);
static void nl_general_info();
unsigned short nl_get_panid();
static unsigned short nl_get_tid(unsigned char *eid);
static int nl_p2p_save_mtdata(unsigned char *info, unsigned char hop, unsigned char *data, int len, unsigned char phase);
static int nl_reg_save_mtdata(struct mtinfo *mtinfo, unsigned char *info, unsigned char *data);
static unsigned char nl_set_node_ver(unsigned char *ver);

static void scan_a_chn(unsigned char chn);
static void scan_chn();
static void nl_save_debug_info(unsigned char *id, unsigned int len, unsigned int chn);
static void nl_debugup(unsigned char *buf, unsigned char len);

struct nl_api_info nl_api[14] =
{
  {nl_ctrl_error, CTL_ERROR},
  {nl_ctrl_confirm, CTL_CONFIRM},
  {nl_ctrl_ask_panid, CTL_ASK_PANID},
  {nl_ctrl_set_panid, CTL_SET_PANID},
  {nl_ctrl_chk_appid, CTL_CHK_APPID},
  {nl_ctrl_asw_appid, CTL_ASW_APPID},
  {nl_ctrl_reg_succ, CTL_REG_SUCC },
  {nl_ctrl_exile_node, CTL_EXILE_NODE},
  {nl_ctrl_node_exit, CTL_NODE_EXIT },
  {nl_ctrl_ask_netid, CTL_ASK_NETID },
  {nl_ctrl_asw_netid, CTL_ASW_NETID },
  {nl_ctrl_local_cmd, CTL_LOCAL_CMD },
  {nl_ctrl_remote_cmd, CTL_REMOTE_CMD},
  {0, 0},
};

int tp_init()
{
  tpbuf_init();
  memset(tid, 0x00, sizeof(tid));
  pan_id = 0;
  timers_create(TIMER_38_INFO, 3000, nl_general_info);
  timers_create(TIMER_SET_PANID, 3500, nl_set_panid);
  chn_init();
//  area_init();
#if 0
  tpbuf_test();
  timers_create(TIMER_DM_DC, 100, tpbuf_test);
#endif
//  ai_init();
  return 0;
}

void nl_reg_over()
{
  ses_switch_iiireg();
  return;
}

extern unsigned int flag_nl_start_net_eeprom;
void nl_start_net()
{
  int len, tno;
  unsigned char buf[0x100];

  buf[0] = 0x01;    /* ������� */
  buf[1] = 0x01;    /* �������� */
  eeprom_read(e2rom_addr(reg_tno), &tno, e2rom_len(reg_tno));
  tno++;

  buf[2] = tno & 0x07;   /* ����� */
  buf[3] = 0x00;
  buf[4] = tno & 0x07;   /* ����� */
  len = nl_fill_frm(CTL_REMOTE_CMD, NULL, &buf[0], 5);

  //pib_update(RT_STATE, pib_find(RT_STATE) | RT_STATE_LOCK);
  switch (chn38) /* �л�38���ͣ��������ȷ�Ϸ�2�� */
  {
      case 0:
        tp_chn_buf_write(CHN_38_1, &buf[0], len, 500, 2);
        chn38++;
        alloc_a_timer(TIMER_REG_TASK, 1000, 1000, nl_start_net);
        break;
      case 1:
        tp_chn_buf_write(CHN_38_2, &buf[0], len, 500, 2);
        chn38++;
        alloc_a_timer(TIMER_REG_TASK, 1000, 1000, nl_start_net);
        break;
      case 2:
        tp_chn_buf_write(CHN_38_3, &buf[0], len, 500, 2);
        chn38++;
        alloc_a_timer(TIMER_REG_TASK, 1000, 1000, nl_start_net);
        break;
      case 3:
        chn38++;
        //��ʱ������  alloc_a_timer(TIMER_REG_TASK, 1000 * reg_task.time, 1000, nl_reg_over); /* ע����ɺ󣬵ȴ�t�� */
        chn38 = 0;
        eeprom_write(e2rom_addr(reg_tno), &tno, e2rom_len(reg_tno));

        flag_nl_start_net_eeprom++;

        //net_start_time = get_sys_tick();

        //if (net_first_start_time == 0)
        //net_first_start_time = get_sys_tick();

        break;
      default:
        return;
  }
  return;
}

void nl_broad(unsigned char ctrl, unsigned char *data, int len)
{
  unsigned char buf[0x100], sno;
  unsigned char buf_zeroA[] = {0x68, 0x99, 0x99, 0x99, 0x99, 0x99, 0x99, 0x68, 0x1F, 0x02, 0xE1, 0x73, 0xDB, 0x16};
  unsigned char buf_zeroB[] = {0x68, 0x99, 0x99, 0x99, 0x99, 0x99, 0x99, 0x68, 0x1F, 0x02, 0xE1, 0xB3, 0x1B, 0x16};
  unsigned char buf_zeroC[] = {0x68, 0x99, 0x99, 0x99, 0x99, 0x99, 0x99, 0x68, 0x1F, 0x02, 0xE1, 0xF3, 0x5B, 0x16};
  int l;

  if ((memcmp(buf_zeroA, data, len) == 0) || (memcmp(buf_zeroB, data, len) == 0)
      || (memcmp(buf_zeroC, data, len) == 0))
    ctrl = 1;  //���㷢��

  buf[0] = 0x10; /* ��ĳ�ڵ㷢����Ϣ */
  buf[1] = 0x02; /* ��ַģʽΪsid */
  buf[2] = 0xff; /* sidΪ0xFFFF��Ϊ�㲥 */
  buf[3] = 0xff;
  buf[4] = 0x00; /* �м̽ڵ�Ϊ0x0000 */
  buf[5] = 0x00;

  sno = get_next_para_sno();
  if (0x00 == sno)  /* ���������⣬ע����� */
    return;

  buf[6] = sno & 0x07;

  memcpy(&buf[7], data, len);

  if (ctrl)
    memcpy(&buf[7], buf_zeroA, len);

  info[0] = 0;
  info[1] = 0;  //��ʼ��
  if (ctrl) //   if (ctrl && (zero_detect_chn <= 2))     /* �������㷢�Ϳ��� */
    info[1] = 0xA0; //     info[1] = (1 << 7) + ((zero_detect_chn + 1) << 5);//���̶ܹ���A��info[1] = 0xA0;
  else //   else
    info[1] = 0x20;

  l = nl_fill_frm(CTL_REMOTE_CMD, info, buf, len + 7);

//   if (ctrl && (zero_detect_chn <= 2))
//     tp_chn_buf_write(zero_chn[zero_detect_chn], buf, l, 500, 2);
//   else
  tp_chn_buf_write(CHN_38_1, buf, l, 500, 2);

  return;
}

static void nl_ctrl_error(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_confirm(unsigned char *buf, unsigned char len, unsigned char phase)
{
  if (len > 1)
    return;

  if (((1 << phase) & pib_find(RT_WAIT_CHN)) == 0) /* ������ǵȴ��Ĵ��ڣ������� */
    return;

  pib_update(RT_WAIT_CHN, pib_find(RT_WAIT_CHN) & ~(1 << phase)); /* ������ڵȴ���־ */
  del_a_timer(TIMER_WAIT38_ACK); /* ���38��ʱ��ʱ�� */
  tpbuf_init();   /* ������� */
  return;
}

static void nl_ctrl_ask_panid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_set_panid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_chk_appid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  /* �����������ģ�ȥ�ظ����� */
  tp_task_buf_write(buf, len, phase, nl_chk_aid);
  return;
}

static void nl_ctrl_asw_appid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_reg_succ(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_exile_node(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_node_exit(unsigned char *buf, unsigned char len, unsigned char phase)
{
  /* �����������ģ�ȥ�ظ����� */
  tp_task_buf_write(buf, len, phase, nl_node_exit);
  return;
}

static void nl_ctrl_ask_netid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}

static void nl_ctrl_asw_netid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  return;
}


static void nl_ctrl_local_cmd(unsigned char *buf, unsigned char len, unsigned char phase)
{
  if (get_upgrd_state() == UPGRD_UPDATING) /* �����У�����Ӧ */
    return;

  printf_s("\n***************local_cmd*******before****************************\n");
  for (int i = 0; i < len; i++)
  {
    printf_s("%02x ", buf[i]);
  }
  /* �����������ģ�ȥ�ظ����� */
  tp_task_buf_write(buf, len, phase, nl_local_cmd);
  return;
}

static void nl_ctrl_remote_cmd(unsigned char *buf, unsigned char len, unsigned char phase)
{
  if (get_upgrd_state() == UPGRD_UPDATING) /* �����У�����Ӧ */
    return;

  /* �����������ģ�ȥ�ظ����� */
  tp_task_buf_write(buf, len, phase, nl_remote_cmd);
  return;
}

static void nl_chk_aid(unsigned char *buf, unsigned char len, unsigned char phase)
{
  switch (buf[21] & 0x0F)
  {
      case METER: /* �ز��� */

#if 0
        nl_deal_mtreg(info, buf, len, phase);

        break;
#endif

      case REPEATER: /* �м��� */
      case CJQ: /* �ɼ��� */
#ifdef TAI_QU
      case TQSBY:    /* ̨��ʶ���� */
#endif
        nl_deal_cjqreg(info, buf, len, phase);

        break;

      default:
        return;
  }
}

static void nl_node_exit(unsigned char *buf, unsigned char len, unsigned char phase)
{
#if 0  //��ʱ����
  int pos;
  struct mtnode mt;
  unsigned short addr;

  if ((buf[0] & 0x03) != 0x00) /* ֻ������������ */
  return;

  if (buf[1] > 16) /* Ӧ�õ�ַ�������ܳ���16 */
  return;

  if ((buf[3] & 0x0F) != IDLEN) /* Ӧ�õ�ַ���Ȳ�Ϊ6������ */
  return;

  if (db_find(AID, &buf[4], &pos) != 0)
  return;

  db_find_flash(&buf[4], &mt, &addr); /* �ɼ����е�ַ��ʽ��δ������� */
  mt.sid = 0xFFFF;
  db_updatemt(addr, &mt);
#endif
  return;

}
extern unsigned char info_v[2]; /* ֡��Ϣ�� */
static void nl_remote_cmd(unsigned char *buf, unsigned char len, unsigned char phase)
{
  switch (buf[0] & 0x7F)
  {
    //�㼯������֧��
//     case 0x23: /* ���ݻ㼯�ϱ� */
//
//       nl_deal_colup(info, buf, len, phase);

//       break;
      case 0x11: /* �㳭�ϱ� */
#if 1
        if (rt_test.time)
        {
          if (0 == ((1 << rt_test.chn) & tp_get_all_chn()))
            return;
        }
#endif
        nl_deal_p2pup(info_v, buf, len, phase);

        break;
      default:
        return;
  }
  return;
}

static void nl_local_cmd(unsigned char *buf, unsigned char len, unsigned char phase)
{
  unsigned char l;

  //timers_delete(TIMER_WAIT38_ACK); /* ���38��ʱ��ʱ�� */
  //tpbuf_init();   /* ������� */

  printf_s("\n***************local_cmd*******after****************************\n");
  for (int i = 0; i < len; i++)
  {
    printf_s("%02x ", buf[i]);
  }

  switch (buf[0] & 0x7F)
  {
      case 0x11: /* ��ȡ�ۺ���Ϣ */
        if ((flag_general == 1) || (flag_general == 2))
          flag_general = 3;

        l = buf[12];
        pan_id = buf[1 + 2 + 5 + 4 + 1 + l] + buf[1 + 2 + 5 + 4 + 1 + l + 1] * 256;
        wireless = buf[1 + 2 + 5 + 4 + 1 + l + 8 + 2 + 2]; /* 0x00Ϊ��plc��0x01Ϊ˫ģ */
        tno_info = buf[1 + 2 + 5]; /* �������ģʽ�汾��Ϊ0x30��Ϊ������ͨ���ԣ��㳭�����Ϊ1�ֽ� */
        break;
      case 0x10: /* ��ȡ����ģʽ */
        unsigned short t;
        unsigned char frame[0x20], c;

        if (len != 2)
          return;

        nl_general_info();
        timers_create(TIMER_SET_PANID, 1000, nl_set_panid);
        break;
#if 0  /* ̨��ʶ����ʱ������ */
      case 0x20: /* ̨��ʶ���ǵ�ַ�ϱ� */
        unsigned char tq_aid[6];

        if (buf[1] != 6)  /* ̨����Ĭ��6�ֽ� */
        return;
        pib_update(TQ_ALIVE, 1);
        eep_read(e2rom_addr(tq_info), tq_aid, 6);

        if (memcmp(tq_aid, &buf[2], 6) == 0)  /* ���ű���һ�£�ͬʱeep���У����ӱ� */
        ;
        else
        eep_write(e2rom_addr(tq_info), &buf[2], 6);  /* �ӵ��� */

        /* ����̨��ʶ������ */
        area_start();
        break;
#endif
      default:
        return;
  }
  return;
}

static void nl_set_panid()
{
  unsigned short len, t;
  unsigned char frame[0x20], c, jzq_address[IDLEN], sinkid[2];
  int datalen = IDLEN;

  printf_s("\nnl_set_panid\n");

  frame[0] = chn38 + 1;
  frame[1] = 0x06;

  rf_get_jzqid_nw(jzq_address, &datalen);
  memcpy(&frame[2], &jzq_address[0], 6);

  t = nl_get_panid();
  sinkid[0] = (t & 0xFF) % 0x63;
  sinkid[1] = ((t >> 8) & 0xFF) % 0x63;
  rf_set_sinkid_v(sinkid);
#if 1
  frame[8] = (unsigned char)t;
  frame[9] = (unsigned char)(t >> 8);
#else
  frame[8] = 0x28;
  frame[9] = 0x07;
#endif

  frame[8] %= 0x63;  /* ����43 */
  frame[9] %= 0x63;

  eep_read(e2rom_addr(reg_tno), &c, e2rom_len(reg_tno));
  t = c & 0x07;

  frame[10] = t;
  memset(&frame[11], 0x00, 4);

  len = nl_fill_frm(CTL_SET_PANID, NULL, &frame[0], 15);

  switch (chn38)   /* �л�38���ͣ��������ȷ�Ϸ�2�� */
  {
      case 0:
        tp_chn_buf_write(CHN_38_1, &frame[0], len, 500, 2);
        chn38++;
        timers_create(TIMER_SET_PANID, 100, nl_set_panid);
        break;
      case 1:
        tp_chn_buf_write(CHN_38_2, &frame[0], len, 500, 2);
        chn38++;
        timers_create(TIMER_SET_PANID, 100, nl_set_panid);
        break;
      case 2:
        tp_chn_buf_write(CHN_38_3, &frame[0], len, 500, 2);
        chn38++;
        timers_create(TIMER_SET_PANID, 100, nl_set_panid);
        break;
      default:
        chn38 = 0;
  }
}

void nl_p2p(unsigned char *aid, unsigned char *frm, unsigned char len, unsigned char seq, unsigned char upd_flg)
{
  int pos = 0, l, t = 0;
  unsigned char buf[0x100], info[2], aid_hash[IDLEN];
  struct mtinfo *mtp;

  buf[0] = 0x10; /* ��ĳ�ڵ㷢����Ϣ */

  memcpy(aid_hash, aid, IDLEN);
  aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������

  /* ��ѯ����aid_hash */
  if (((mtp = hash_find(aid_hash)) != NULL)) //if (db_find(AID, aid, &pos) == 0) /* AID����DB�У������� */
  {
    t = 1;
  }
#if 0
  dbpara_read(dbpara_addr(chn), &c, 1);

  if ((c == 0xFF) || (c == 0x01)) /* �Զ��ŵ� */
  info[0] = 0x00;
  if (c == 0x02)  /* ָ��plc */
  info[0] = 0x40;
  if (c == 0x03) /* ָ������ */
  info[0] = 0x60;
  info[1] = 0x00;
#else
  info[0] = 0x00;
  info[1] = 0x00;
#endif
#if 0
  info[0] &= 0xF8;  /* ���3bit */
  info[0] |= 0x1;   /* 001-Robust(5.6kbps,�㳭�̶�) */
#endif
  if (t == 0) /* �ڵ㲻�ڵ�������AID�㳭 */
  {
#ifdef UPDATE_STA
    if (upd_flg)
    {
      buf[1] = 0x02;
      buf[2] = 0xFF; /* �м̽ڵ�Ϊ0 */
      buf[3] = 0xFF;
      buf[4] = 0x0;
      buf[5] = 0x0;
      if (tno_info == 0x30)
        buf[6] = seq;
      else
        buf[6] = seq & 0x07;
      memcpy(&buf[7], frm, len);
      l = nl_fill_frm(CTL_REMOTE_CMD, info, buf, len + 7);
    }
    else
#endif
    {
      buf[1] = 0x03;
      buf[2] = 0x00; /* �м̽ڵ�Ϊ0 */
      buf[3] = 0x00;

      if (tno_info == 0x30)
        buf[4] = seq;
      else
        buf[4] = seq & 0x07;
      memcpy(&buf[5], frm, len);
      l = nl_fill_frm(CTL_REMOTE_CMD, info, buf, len + 5);
    }
  }
  else      /* �ڵ��ڵ���,��SID�㳭 */
  {
    buf[1] = 0x02;
    if (t == 1)
    {
      if (mtp->node.sid == 0xFFFF)
      {
        buf[2] = 0x00;
        buf[3] = 0x00;
      }
      else
      {
        buf[2] = (unsigned char)(mtp->node.sid & 0xFF);
        buf[3] = (unsigned char)(mtp->node.sid >> 8);
      }
      if (mtp->nexthop != 0xFFFF) /* �м̽ڵ� */
      {
        buf[4] = (unsigned char)(mtp->nexthop & 0xFF);
        buf[5] = (unsigned char)(mtp->nexthop >> 8);
      }
      else
      {
        buf[4] = 0x00;
        buf[5] = 0x00;
      }
    }
    if (tno_info == 0x30)
      buf[6] = seq;
    else
      buf[6] = seq & 0x07;

    memcpy(&buf[7], frm, len);
    mtp->dc_cnt++;
    l = nl_fill_frm(CTL_REMOTE_CMD, info, buf, len + 7);
  }
#ifdef SZH_DEBUG
  unsigned char test_char[3] = {0x66, 0x88, 0x66};
  sys_uart_write(UART_CHN_DM, test_char, 3);
//���ֽڷ���ס  if (pos != 0x68)
//    sys_uart_write(UART_CHN_DM, (unsigned char *)&pos, 4);

#endif

  if (rt_test.time)
  {
    tp_chn_buf_write(rt_test.chn, buf, l, 5000, 2);
  }
  else
  {
    unsigned char chan;

    if (chn_valid(mtp->chn) == 0)
    {
      chn.curchn = mtp->chn;
      chan = mtp->chn;
    }
    else
      chan = chn_getchn();
    tp_chn_buf_write(chan, buf, l, 5000, 2);
  }

  return;
}

extern unsigned int flag_nl_deal_cjqreg_eeprom;
static void nl_deal_cjqreg(unsigned char *info, unsigned char *buf, unsigned char len, unsigned char phase)
{
  int pos = 0, l, num = 0, aidindb = 0, eidindb = 0, cjqindb = 0;
  struct rid_info rid;
#ifdef TAI_QU
  struct tqid_info tqid;
  int tqindb = 0;
  unsigned char depth; //, tq_state = 1, flag_istq = 0, flag_no_support = 0;  /* tq_state = 1��ʾ�ӽڵ�̨���������쳣 */
#endif
  unsigned char t[0x100] = {0}, bitmap[0x400] = {0}, aid[96] = {0}, jzq_address1[6] = {0}, said[112] = {0};
  struct nl_chkaid_info_up *fup = (struct nl_chkaid_info_up *)buf;
  struct nl_chkaid_info_down *fdn = (struct nl_chkaid_info_down *)t;
  struct mtinfo *mtp;
  unsigned char aid_hash[IDLEN];

  if ((fup->data[1] & 0x0F) == 0x04) /* Ӧ�õ�ַ����4λ�������� */
    return;
  if ((fup->data[0] & 0x0F) == 0x03) /* �м��� */
  {
    memcpy(aid_hash, &fup->data[10], IDLEN);
    aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
    if ((mtp = hash_find(aid_hash)) != NULL) //if (db_find(AID, &fup->data[10], &pos) == 0)
    {
      for (int i = e2rom_addr(rpt); i < e2rom_len(rpt); i += sizeof(struct rid_info))
      {
        eep_read(i, (unsigned char *)&rid, sizeof(struct rid_info));
        if ((rid.eid[0] == fup->eid[0]) && (rid.eid[1] == fup->eid[1]) && (rid.eid[2] == fup->eid[2]) && (rid.eid[3] == fup->eid[3]) && (rid.eid[4] == fup->eid[4]))
        {
          if (rid.sid != 0xFFFF)
          {
            fdn->regsid = rid.sid;
            break;
          }
        }
        if ((rid.eid[0] == 0xFF) && (rid.eid[1] == 0xFF) && (rid.eid[2] == 0xFF) && (rid.eid[3] == 0xFF) && (rid.eid[4] == 0xFF))
        {
          fdn->regsid = 0xE000 + ((i - e2rom_addr(rpt)) / sizeof(struct rid_info)) + 1;
          memcpy(rid.eid, fup->eid, 5);
          rid.sid = fdn->regsid;
          eep_write(i, (unsigned char *)&rid, sizeof(struct rid_info));

          flag_nl_deal_cjqreg_eeprom++;
          break;
        }
      }
      for (int j = 0; j < 2; j++)
      {
        if ((fup->regsid != 0x0000) && (fup->regsid != rid.sid))      /* sid��֤ʧ�� */
          fdn->data[j * 8 + 1] = 0x40;
        else
          fdn->data[j * 8 + 1] = 0x00;    /* ��֤�ɹ� */
      }
    }
    else
    {
      for (int j = 0; j < 2; j++)
        fdn->data[j * 8 + 1] = 0x20; /* AID��֤ʧ�� */
    }
    for (int j = 0; j < 2; j++)
    {
      fdn->data[j * 8 + 1] |= fup->data[j * 8 + 1] & 0x1F;
      fdn->data[j * 8] = fup->data[j * 8];
      memcpy(&fdn->data[j * 8 + 2], &fup->data[j * 8 + 2], IDLEN);
    }
  }
  else
  { /* ����flash�����Ƿ�����ͬ��EID���Ѿ�������sid��ͬʱ��һ��δ�õ�sid���� */
    //for (int i = 0; i < (pib_find(MT_NUM) + pib_find(MAP_MT_NUM)); i++)
    db_trav_reset(CHAN_TMP);
    while ((mtp = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if (memcmp(mtp->node.eid, fup->eid, EIDLEN) == 0) //if (memcmp(rnode[i].node.eid, fup->eid, EIDLEN) == 0)
      {
        if (mtp->node.sid != 0xFFFF)
        {
          eidindb = 1;
          fdn->regsid = mtp->node.sid;
          break;
        }
      }
      if (mtp->node.sid != 0xFFFF)
        bitmap[mtp->node.sid / 8] |= (1 << (mtp->node.sid % 8));
    }
    if (fdn->regsid == 0x0000) /* ���û�ҵ���Ӧ��EID, �����ҵ�EID��SIDû��(������ܰɣ�), ����һ��δ�õ�SID */
    {
      num = 0;
      for (int i = 0; i < 0x400; i++)
      {
        for (int j = 0; j < 8; j++)
        {
          if ((bitmap[i] & (1 << (j % 8))) == 0)
          {
            if ((0 == i) && (0 == j)) /* sid����Ϊ0 */
              continue;

            fdn->regsid = i * 8 + j;
            num++;
            break;
          }
        }
        if (num > 0)
          break;
      }
    }
    for (int i = 0; i < fup->aidnum; i++)
    {
      memcpy(aid_hash, &fup->data[i * 8 + 2], IDLEN);
      aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
      if ((mtp = hash_find(aid_hash)) != NULL) //if (db_find(AID, &fup->data[i * 8 + 2], &pos) == 0)/* AID���������ݿ��� */
      {
        aidindb = 1;

        if ((_rtparas.state & STARMASK) == STAREG) //if ((pib_find(RT_STATE) & 0x0F) == RT_STATE_REG) //( || ((pib_find(RT_STATE) & 0x0F) == RT_STATE_COL))
          ses_reset_idle_time();
        else
        {
          if ((fup->ver[0] == 0x00) && (fup->ver[2] >= 0x16))
          {
            if ((fup->data[0] >> 4) & 0x01) /* ˫ģ */
            {
              if (is_data_all_same(reset_id, 6, 0x00))
                memcpy(reset_id, &fup->data[i * 8 + 2], 6);
              if (memcmp(reset_id, &fup->data[i * 8 + 2], 6) == 0)
                reset_times++;
            }
          }
        }
        /* Ӧ����ȷ����ʷ������ϵ���п��ܱ���������ͬ�Ĳɼ����� */
        mtp->node.sid = fdn->regsid; /* ���±���SID, ��ֹ�ӵ���Ĳɼ�����, ԭ������EIDΪ׼ */

        if ((fup->regsid != 0x0000) && (fup->regsid != fdn->regsid))      /* sid��֤ʧ�� */
          fdn->data[i * 8 + 1] = 0x40;
        else
          fdn->data[i * 8 + 1] = 0x00;    /* ��֤�ɹ� */
        if (nl_reg_save_mtdata(mtp, info, buf) < 0) /* ����ڵ���Ϣ */
          return;
      }
      else
      {
        if (ses_searching())
          fdn->data[i * 8 + 1] = 0x00;
        else
          fdn->data[i * 8 + 1] = 0x20; /* AID��֤ʧ�� */
      }
      /* �����Э����Ϣ��97,07,698.45 */
      said[i * (IDLEN + 1)] = fup->data[i * 8] >> 5;
      memcpy(&said[i * (IDLEN + 1) + 1], &fup->data[i * 8 + 2], IDLEN);
      fdn->data[i * 8 + 1] |= fup->data[i * 8 + 1] & 0x1F;
      fdn->data[i * 8] = fup->data[i * 8];
      memcpy(&fdn->data[i * 8 + 2], &fup->data[i * 8 + 2], IDLEN);
      memcpy(&aid[i * IDLEN], &fup->data[i * 8 + 2], IDLEN);
    }
  }

  if (!ses_searching())
  {
    if ((aidindb == 0) && (eidindb == 0) && (cjqindb == 0)) /* �ɼ���ȫ��AID��֤ʧ�� */
#ifdef TAI_QU
      if (tqindb == 0)
#endif
        fdn->regsid = 0x0000;
  }

  if (ses_searching() && (aidindb == 0) && (cjqindb == 0) && (eidindb == 0))
  {
#ifdef TAI_QU
    if (tqindb == 0)
#endif
    {
      fdn->regsid = nl_get_tid(fup->eid);
      if (fdn->regsid == 0)
        return;
    }
  }
  memcpy(fdn->tno, fup->tno, 13); /* tno + eid */
  fdn->gid = 0x0000;
  fdn->aidnum = fup->aidnum;

  fdn->data[fdn->aidnum * 8] = 0x01;
  fdn->data[fup->aidnum * 8 + 1] = 0x00;

  if (reset_flag)
  {
    fdn->data[fdn->aidnum * 8] = 0x21;
    fdn->data[fup->aidnum * 8 + 1] = 0x01;
  }
  if (!ses_searching())
  {
    if ((db_regnum_53() == _rtparas.mtnum)
        && ((_rtparas.state & STARMASK) == STAREG)) //((pib_find(RT_STATE) & 0x0F) == RT_STATE_REG))
      ses_clr_idle_time();
  }
  if (ses_searching()) // && (flag_istq != 1) && ((pib_find(RT_STATE) & 0x0F) != RT_STATE_AREA_IDENTIFY))  /* ̨��ʶ���ǲ��ϱ� */
  {
    app_mt_up(fup->aidnum, aid); //ses_mt_up(fup->aidnum, aid);
  }
  if (ses_searching())
    ses_reset_idle_time();

  l = nl_fill_frm(CTL_ASW_APPID, NULL, (unsigned char *)fdn, len - 3 - fup->data[fup->aidnum * 8] + 1);

  tp_chn_buf_write(phase, (unsigned char *)fdn, l, 0, 0);
}

static void nl_deal_p2pup(unsigned char *info, unsigned char *buf, unsigned char len, unsigned char phase)
{
  unsigned char m, t;

  m = buf[1] & 0x07; /* ��ַģʽ */

  if (1 == m) /* EID */
    t = 8;
  if (2 == m) /* SID */
    t = 2;

  nl_save_debug_info(&buf[2], t, phase);


#ifndef HUTONG
  if ((buf[3 + t] & 0x80) && (0xFF != buf[3 + t]))
  {
    /* ̨��ʶ���ǵ��¼������� */
    if (m == 2 && buf[2] == 0xFF && buf[3] == 0x0F)
      return;

    nl_p2p_save_mtdata(info, buf[2 + t], &buf[4 + t], len - t - 4, phase);

    if ((buf[3 + t] & 0x40) && (buf[3 + t] & 0x80))  /* �㳭���к���bit6��bit7ͬʱ��1��ʾͣ���¼� */
    {
      if (2 == m) /* SID */
      {
        unsigned short tmp_sid = (buf[3] << 8) + buf[2];
        app_power_eventup((buf[2 + t] & 0x0F) - 1, (info[1] >> 5) & 0x03, &buf[4 + t], len - t - 4, 0, tmp_sid, (buf[3 + t] & 0x07));
      }
    }
    else
    {
      app_eventup(&buf[4 + t], len - t - 4); //nl_eventup((buf[2 + t]& 0x0F) - 1, (info[1] >> 5) & 0x03, &buf[4 + t], len - t - 4);
    }

    return;
  }
  else
  {
    nl_p2p_save_mtdata(info, buf[2 + t], &buf[4 + t], len - t - 4, phase);
  }

  if (buf[3 + t] == 0xFF)
  {
    printf_s("nl_debug\n");
    nl_debugup(&buf[4 + t], len - t - 4);
    return;
  }
#endif

  if (buf[2] == 0xFF && buf[3] == 0x0F)
    return;

  if ((_task.flag & TSMASK) != TSRUN)
    return;
  /* ����Ŵ�, ������ */
  if ((buf[3 + t] & 0x07) != (_task.dcseq & 0x07))
    return;

  int start, prot = 0;
  unsigned char aid[IDLEN];
  memset(aid, 0x00, sizeof(aid));

  if ((start = get_645_frame(&buf[4 + t], len - t - 4)) < 0)
  {
    if ((start = get_69845_frame(&buf[4 + t], len - t - 4)) < 0)
      prot = 0;
    else
      prot = 2;
  }
  else
    prot = 1;
  if (prot == 1)
    memcpy(aid, &buf[4 + t] + start + 1, 6);
  else
    if (prot == 2)
      memcpy(aid, &buf[4 + t] + start + 5, 6);

  /* ���صı��Ÿ�Ҫ���ı��Ų�һ�� ��Ҫ���� */
  if (memcmp(_task.minfo.id, aid, IDLEN) != 0 && (prot != 0))
    return;



#ifdef UPDATE_STA
  if ((is_valid_upd(&buf[4 + t], len - t - 4)) > 0)
  {
    aupd_indication(&buf[4 + t], len - t - 4);
    len = 0; //len - t - 4 = 0;
    return;
  }
#endif
  /* ��3���ĵ㳭���� */
  _task.flag &= ~TSMASK;
  _task.flag |= TSSUCC;
  _task.dcsucc = 2;
  _task.appd.datalen = len - t - 4;
  memcpy(_task.appd.data, &buf[4 + t], len - t - 4);

  return;
}

void soft_dog()
{
  timers_delete(TIMER_SOFT_DOG);
  if (flag_general == 2)  /* ˵��2�ζ�û�г�������λ�ز�оƬ */
  {
    gipo_out_low(RST_38);
    delay_ms(50);
    gipo_out_high(RST_38);
    return;
  }

  if (flag_general == 3)
    flag_general = 0;

}

static void nl_general_info()
{
  int len;
  unsigned char buf[0x10];

  if (flag_general == 1)
    flag_general = 2;
  else
    flag_general = 1;

  buf[0] = 0x11;

  printf_s("\nnl_general_info\n");

  len = nl_fill_frm(CTL_LOCAL_CMD, NULL, buf, 1);

  tp_chn_buf_write(CHN_38_1, buf, len, 500, 2);

  timers_create(TIMER_38_INFO, 30 * 60 * 1000, nl_general_info);  /* ��ʱ30���� */
  timers_create(TIMER_SOFT_DOG, 3 * 1000, soft_dog);      /* ��ʱ3s */

  return;
}

extern unsigned int flag_nl_get_panid_eeprom;
unsigned short nl_get_panid()
{
  unsigned short t;
  unsigned int a, b, c;
  unsigned int uid1, uid2, uid3, uid4, u;
  unsigned char pan[2];

#ifdef HUTONG
  t = crc16(jzq_address, 6);
  t = t & 0XFCFF;
  return t;
#else
  if (pan_id != 0)
  {
    return ((pan_id & 0x3FFF) | 0x2000);
  }
  eep_read(e2rom_addr(panid), (unsigned char *)&t, e2rom_len(panid));
/*
    get_rand_info((unsigned int *)&buf[0]);
    
    pan[0] = buf[0];
    pan[1] = 0;

    for(i = 0; i < sizeof(buf); i++)
    {
      pan[1] ^= buf[i];
      pan[0] += buf[i];
    }
    pan[1] &= 0x1f;
*/
  uid1 = *(unsigned int *)(0x40048054); /* unique device ID */
  uid2 = *(unsigned int *)(0x40048058);
  uid3 = *(unsigned int *)(0x4004805c);
  uid4 = *(unsigned int *)(0x40048060);
  u = uid1 + uid2 + uid3 + uid4;
  u ^= uid1;
  u ^= uid2;
  u ^= uid3;
  u ^= uid4;
  srand(u);

  a = rand();
  b = a;
  c = (unsigned char)a;
  for (int i = 0; i < 3; i++)
  {
    a >>= 8;
    c ^= (unsigned char)a;
  }
  pan[0] = c;
  c = (unsigned char)b;
  for (int i = 0; i < 3; i++)
  {
    b >>= 8;
    c += (unsigned char)b;
  }
  pan[1] = (unsigned char)c;

  for (int i = 0; i < 3; i++)
  {
    if ((pan[0] == 0x00) && (pan[1] == 0x00))
    {
      pan[0] = rand();
      pan[1] = rand();
    }
    else
      break;
  }

  if (t != *(unsigned short *)pan)
  {
    t = *(unsigned short *)pan;
    eep_write(e2rom_addr(panid), (unsigned char *)&t, e2rom_len(panid));


    flag_nl_get_panid_eeprom++;
  }
  if (0 == t)
  {
    t = 0x1111;
    eep_write(e2rom_addr(panid), pan, e2rom_len(panid));

    flag_nl_get_panid_eeprom++;
  }
  return ((t & 0x3FFF) | 0x2000);
#endif
}

static unsigned short nl_get_tid(unsigned char *eid)
{
  struct tid_info *ptid = (struct tid_info *)tid;

  for (unsigned short i = 0; i < MAX_TID_NUM; i++)
  {
    if (memcmp(ptid[i].eid, eid, EIDLEN) == 0)
      return ptid[i].sid;
    if (is_data_all_same(ptid[i].eid, EIDLEN, 0x00))
    {
      memcpy(ptid[i].eid, eid, EIDLEN);
      ptid[i].sid = 0xE000 | (i + 1);
      return (ptid[i].sid); /* ��ʱ��ַ����λΪȫ1 */
    }
  }
  return 0;
}

static int nl_p2p_save_mtdata(unsigned char *info, unsigned char hop, unsigned char *data, int len, unsigned char phase)
{
  int c, i = 0, end = 0;  // pos = 0,
  struct mtinfo *mtinfo;
  unsigned char aid_hash[IDLEN];

  while (1)  /* ���ܶ������ģ����Բ�� */
  {
    if ((c = sep_645_frame(data + i, len - i, (unsigned char *)&end)) >= 0)
    {
      memcpy(aid_hash, &data[c + i + 1], IDLEN);
      aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
      if ((mtinfo = hash_find(aid_hash)) != NULL) //if (db_find(AID, &data[c + i + 1], &pos) == 0)
      {
#if 1
        //��λ��Ҫʵʱ����  if (rnode[pos].node.phase == 3)
        {
          unsigned char phase = mtinfo->phase; //rnode[pos].node.phase;
          if (((info[1] >> 5) & 0x03) != 0x00)  /* ��λδ֪�� ����flash */
          {
            mtinfo->phase = ((info[1] >> 5) & 0x03);
            mtinfo->node.phase = 0;
            mtinfo->node.phase |= (((info[1] >> 5) & 0x03) << 6);
//��ʱ����flash                       if (db_save_flash(pos) < 0)
//                         return -1;  
                    }
//                   if (phase != mtinfo->phase)
//                     topology_change = 1;
                }
#endif              
              mtinfo->chn = phase & 0x03;
              mtinfo->signal = info[1] & 0x1F;  /* signal�㶫�� / 2�������� */
              
              unsigned char node_state_bak = 0;
              node_state_bak = mtinfo->node_sta;
              mtinfo->node_sta = info[0] >> 7;  /* ���λ��ʾ������0����1�쳣 */
//               if (node_state_bak != mtinfo->node_sta)
//                 topology_change = 1;
                
              mtinfo->hop = hop;
              i += end;
              if (i >= len)
                return 0;
            }
          else
            break;
        }
      else
        return 0;
    }
  return 0;
}

extern unsigned int flag_nl_reg_save_mtdata_eeprom;
extern unsigned int flag_nl_reg_save_mtdata_succ;
static int nl_reg_save_mtdata(struct mtinfo *mtinfo, unsigned char *info, unsigned char *data)
{
  unsigned char ver, sinkid[2];
  unsigned short t = 0;
  struct nl_chkaid_info_up *p = (struct nl_chkaid_info_up *)data;

  /* ��λ, �ź���������Ϣ���л��, �ŵ����ȼ��͵��Ʒ�ʽ�ݲ����� */
  //��λҪ����ʱ�仯  if (rnode[pos].node.phase == 3)
  unsigned char phase = mtinfo->phase;
    {
      if (((info[1] >> 5) & 0x03) != 0x00)  /* ��λδ֪�� ����flash */
      {
        mtinfo->phase = ((info[1] >> 5) & 0x03);
        mtinfo->node.phase = 0;
        mtinfo->node.phase |= (((info[1] >> 5) & 0x03) << 6);
      }
    }
//   if (phase != mtinfo->phase)
//     topology_change = 1;

  mtinfo->signal = info[1] & 0x1F;  /* signal�㶫�� / 2�������� */
  
  unsigned char node_state_bak = 0;
  node_state_bak = mtinfo->node_sta;
  mtinfo->node_sta = info[0] >> 7;  /* ���λ��ʾ������0����1�쳣 */
//   if (node_state_bak != rnode[pos].node.node_sta)
//     topology_change = 1;
    
  /* EID, �汾��, ����, ���ڵ����������� */
  memcpy(mtinfo->node.eid, p->eid, EIDLEN);
  ver = nl_set_node_ver(p->ver);
  mtinfo->attr = (mtinfo->attr & 0xCF) | (ver << 4);
  
  mtinfo->hop = p->tno[0] & 0x0F; /* ���� */
  if (p->tno[1] || p->tno[2])
    {
      mtinfo->hop++;
      mtinfo->fsid = p->tno[1] + p->tno[2] * 256;
    }
   else
     {
       t = nl_get_panid();
       sinkid[0] = (t&0xFF) % 0x63;
       sinkid[1] = ((t>>8)&0xFF) % 0x63;
       mtinfo->fsid = sinkid[1] * 256 + sinkid[0];
     }
    
  if (p->relsid != 0x0FFF)//����̨��ʶ����
    mtinfo->nexthop = p->relsid;
  mtinfo->type = (p->data[0] & 0x0F) - 1; /* flash��0x00-0x11 */
  mtinfo->chn_node = (p->data[0] >> 4) & 0x01;

  mtinfo->node.viv &= ~NNDMASK;
  if ((p->ver[0] & 0x0F) == 3) /* 3�����ں�ϵͳ */
  {
    mtinfo->node.viv |= NND55;
    printf_s("v �� innet������������������\n");
    mtinfo->node.viv |= (1 << 2);  /*����Ϊ55������Ĭ��Ҳ�ǰ���55��������Ϊֻ����55ģ�飬�����������*/
  }
  else
    mtinfo->node.viv |= NND53;

  db_write(mtinfo->addr + offset(struct mtnode, eid), mtinfo->node.eid, sizeof( mtinfo->node.eid));
  db_write(mtinfo->addr + offset(struct mtnode, sid), (unsigned char *)&mtinfo->node.sid, sizeof( mtinfo->node.sid));
  db_write(mtinfo->addr + offset(struct mtnode, viv), &mtinfo->node.viv, sizeof( mtinfo->node.viv));
  set_dc_fail_cnt(mtinfo->node.id, 1);  //�ɹ������־
  flag_nl_reg_save_mtdata_succ++;
  
  flag_nl_reg_save_mtdata_eeprom++;
  
  return 0;
}

extern unsigned int flag_nl_set_node_ver_eeprom;
static unsigned char nl_set_node_ver(unsigned char *ver)
{
  unsigned char v[12];
  int i, j = 0xFF;

  eep_read(e2rom_addr(node_ver), v, e2rom_len(node_ver));
  for(i = 0; i < 4; i ++)
  {
    if(memcmp(&v[i * 3], ver, 3) == 0)
      return i;

    if((v[i * 3] == 0xFF) && (v[i * 3 + 1] == 0xFF) && (v[i * 3 + 2] == 0xFF))
      j = i;
  }
  if(j != 0xFF)
  {
    memcpy(&v[j * 3], ver, 3);
    eep_write(e2rom_addr(node_ver) + j * 3, ver, 3);

    flag_nl_set_node_ver_eeprom++;
    
    return j;
  }
  return 0;
}

int chn_init()
{
  memset(&chn, 0x00, sizeof(chn));

  return 0;
}

int chn_fail()
{
  if (chn.curchn == CHN_38_1)
    chn.failcnt.chn1++;
  if (chn.curchn == CHN_38_2)
    chn.failcnt.chn2++;
  if (chn.curchn == CHN_38_3)
    chn.failcnt.chn3++;

  return 0;
}

int chn_getchn()
{
  if (chn_valid(CHN_38_1) == 0)
    {
      chn.curchn = CHN_38_1;
      return CHN_38_1;
    }
  if (chn_valid(CHN_38_2) == 0)
    {
      chn.curchn = CHN_38_2;
      return CHN_38_2;
    }
  if (chn_valid(CHN_38_3) == 0)
    {
      chn.curchn = CHN_38_3;
      return CHN_38_3;
    }
  chn_init();
  chn.curchn = CHN_38_1;
  return CHN_38_1;
}

int chn_clrfail()
{
  if (chn.curchn == CHN_38_1)
    chn.failcnt.chn1 = 0;
  if (chn.curchn == CHN_38_2)
    chn.failcnt.chn2 = 0;
  if (chn.curchn == CHN_38_3)
    chn.failcnt.chn3 = 0;

  return 0;
}

static int chn_valid(unsigned char c)
{
  if (c == CHN_38_1)
    {
      if (wireless == 1)
        {
          if (chn.failcnt.chn1 < CHN_FAIL_CNT * 2)
            return 0;
        }
      else
        {
          if (chn.failcnt.chn1 < CHN_FAIL_CNT)
            return 0;
        }
    }
  if (c == CHN_38_2)
    {
      if (chn.failcnt.chn2 < CHN_FAIL_CNT)
        return 0;
    }
  if (c == CHN_38_3)
    {
      if (chn.failcnt.chn3 < CHN_FAIL_CNT)
        return 0;
    }
  return -1;
}

/* 645�����еı��ţ�ת����hash��ѯ�õı��� */
void aid_645_tohash(unsigned char *aid)
{
  unsigned char aid_hash[IDLEN];
  
  memcpy(aid_hash, aid, IDLEN);
  id_bcdtobin(aid_hash);
  for (int i = 0; i < IDLEN; i++)
    {
      aid[i] = aid_hash[IDLEN - 1 - i];
    }
}

/* hash��ѯ�õı��ţ�ת����645�����еı��� */
void aid_645_tonormal(unsigned char *aid)
{
  unsigned char aid_hash[IDLEN];
  
  memcpy(aid_hash, aid, IDLEN);
  id_bintobcd(aid_hash);
  for (int i = 0; i < IDLEN; i++)
    {
      aid[i] = aid_hash[IDLEN - 1 - i];
    }
}
//�������������
void nl_debugdn(unsigned char *buf, unsigned char *data, int len, unsigned char ccw)
{
  int l;
	int jzq_len = 0;
  unsigned char jzq_address[6];
  rf_get_jzqid_nw(&jzq_address[0], &jzq_len); 
  buf[0] = 0x10;  //��ڵ㷢����Ϣ
  
  if ((2 != debuginfo.len) && (8 != debuginfo.len))
    return;
  
  if (2 == debuginfo.len)
    buf[1] = 0x02;
  else
    buf[1] = 0x01;
  
  memcpy(&buf[2], &debuginfo.id[0], debuginfo.len);
  
  l = debuginfo.len + 2;
  
  buf[l++] = 0;
  buf[l++] = 0;
  buf[l++] = 0xff;
  
  buf[l++] = 0x02;
  memcpy(&buf[l], jzq_address, 6);
  l += 6;
  
  buf[l++] = ccw;
  
  memcpy(&buf[l], &data[0], len);
  l += len;
  
  l = nl_fill_frm(CTL_REMOTE_CMD, NULL, &buf[0], l);
  
  tp_chn_buf_write(debuginfo.chn, &buf[0], l, 500, 2);
  return;
}

static void nl_debugup(unsigned char *buf, unsigned char len)
{
  ses_debugup(buf, len);
}


static void nl_save_debug_info(unsigned char *id, unsigned int len, unsigned int chn)
{
  if (len > 0x08)
    return;

  memcpy(debuginfo.id, id, len);
  debuginfo.len = len;
  debuginfo.chn = chn;
}
