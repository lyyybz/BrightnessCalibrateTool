#ifndef _DEV_CTRL_H_
#define _DEV_CTRL_H_

#pragma pack(1)

#define DEV_VER    0x0001

#define		PARITY_NO		0x01
#define		PARITY_ODD		0x02
#define		PARITY_EVEN		0x04

#define DM_OVER_TICK        6000
#define DEFAULT_LIFE_SPAN	55000
#define SYS_TICK_INTERVAL    10  //ϵͳ��ʱ���(ms)

#define CHN_DM     (1)  /* ��ʵ�����ӵ��豸��Ӧ */
#define CHN_38_1      (0)
#define CHN_38_2      (3)
#define CHN_38_3      (2)
//#define CHN_DBG  0x01  //���Դ���ͨ��

#define CHN_PLC_DBG  0x05  //���Դ���ͨ��


//���Ź�ʱ�䣬��λ��s�����Ϊ6.5��
#define WDG_MAX_TIME  5.0

typedef void(*pfunc)(void);


#define MAIN_PROGRAM_START  0x00000000

#define USER_OFFSET   0x4000

/* �����Ƿֲ㺯����������ʱ���ֲ��� */
void flash_sector_erase(int addr, int to_wait);
void flash_wait_over(void);
//void flash_write(int addr, unsigned char  buffer[],  int len);
//int flash_read( int addr ,unsigned char  buffer[], int len);
void flash_erase_all(void);
int is_flash_waiting(void);


//void udelay(int x);
void mdelay(unsigned int m);
int alloc_a_timer(unsigned int timer_id, unsigned int over_time, unsigned int interval, pfunc func);
void del_a_timer(unsigned int time_id);
void deal_event_timer(void);
void set_rts_value(unsigned int chn, unsigned int value);
unsigned int get_cts_value(unsigned int chn);
void enable_plc38(void);
void disable_plc38(void);
void modules_init(void);
unsigned int get_sys_tick();
void sys_tick_hook(void);
void eep_write(int addr, unsigned char  buffer[],  int len);
int eep_read( int addr ,unsigned char  buffer[], int len);
void eep_set(int addr, unsigned char v,  int len);
unsigned char eep_get(int addr);
void get_current_bcd_time(unsigned char t[]);
void set_current_bcd_time(unsigned char t[]);
void hard_reset(void);
//int get_uart_status(int chn);
void port_reinit(void);
void set_a_timer_done(unsigned int timer_id);
void adjust_a_timer_overtime(unsigned int timer_id, unsigned int time);
int sys_uart_read(int chn, unsigned char buffer[],int len);
int sys_uart_write(int chn,unsigned char buffer[],int len);
int sys_uart_peek_data(int chn,unsigned char buffer[],int len);
int sys_uart_clr_rx_data(int chn);
int dbg_putdev(char buf[], int len);
void watchdog(void);
void config_uart_info(int chn, int baud, int bits, int parity);
void uart_init_for_38_3(int plc_38_3, int baud);
//void set_to_jump_to_update(void);
void send_uart_data_blocking(unsigned int chn, unsigned char buf[], int len);
void modules_init2(void);
void set_memory_no_bakcup();
//void save_fault_info(void);
void reset_to_main(void);
unsigned int get_random_data(void);
void set_to_add_ee_idle_time(void);
void rtc_second_tick_hook(void);
void uart_tick_hook( int chn);
void scan_to_recycle_flash(void);
//void disable_uart_rcv(void);
void set_led_out(int v);
void enable_irq(void);
void disable_irq(void);
int is_memory_eep(void);
//void heck_to_erase_all(void);

void get_rand_info(unsigned int buf[]);
int is_hard_new(void);
unsigned int get_set_value(void);

void msys_init(void);

void init_timer_event(void);

#endif

