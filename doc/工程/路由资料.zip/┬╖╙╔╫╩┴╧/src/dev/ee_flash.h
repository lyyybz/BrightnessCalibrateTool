#ifndef _EE_FLASH_H_
#define _EE_FLASH_H_

#pragma pack(1)


struct _flash_blk{
    unsigned char  valid;
    unsigned short ee_no;   //���ֽڣ���ֹ������ʹ�÷�Χ0-65525
    unsigned char state;
    unsigned char sum[0x08];
    unsigned char xor[0x08];
    unsigned char sum_bit; //λi�����ʾʹ�õ�У��Ϊi��
    unsigned short bk_no;
    unsigned char res[9];

    unsigned char data[224];
};

#define SECTOR_VALID  0x04
#define PAGE_VALID    0x02
#define BLK_VALID     0x01

#define PAGE_USED     0x80

#define DATA_SIZE   224
#define PAGE_SIZE   0x100

#define SECTOR_SIZE   0x2000 //8K
//#define BLOCK_SIZE    0x10000 //64K

//#define BLK_SHIFT   0x05
//#define BLK_MASK    (~((1<<BLK_SHIFT) - 1))
#define BLK_SIZE    sizeof(struct _flash_blk)

#define STATE_SIZE  0x04

#define MAX_EE_NO   ((0x10000 + DATA_SIZE - 1) / DATA_SIZE)//293

#define MAX_FLASH_NO   (FLASH_DATA_SIZE / BLK_SIZE)//2048


#define FLASH_END  0x100000

#define FLASH_DATA_START  0xA4000
#define FLASH_DATA_SIZE   0x38000

#define FLASH_BK_START  0xE0000
#define FLASH_BK_END    0xF8000

#define FLASH_BK_P_START  0xF8000
#define FLASH_BK_P_END    0xFC000


#define SECTOR_BK_INFO   (FLASH_END - 0x4000)
#define PAGE_BK_INFO     (FLASH_END - 0x2000)


#define FLASH_BACKING   0xeeeeeeee
#define FLASH_BACKED    0xcccccccc
#define FLASH_DATA_BK   0x44444444
#define FLASH_NOUSE     0x00000000

#define PAGE_MASK       0xffffff00

#define SECTOR_MASK   0xffffe000
#define SECTOR_OFFSET 13
#define INFOLEN 0x1FFFF
#define BITMAP 0x1FFF

#define DBFLASHEND 0x10000  /* �����������ַ������С�������ַ */

struct flash_bk_info {
    unsigned int sec_no; //sector num??ʵ��Ҫд�������
    unsigned int bk_sec; //��������
    unsigned int len;
    unsigned int state;
};
#pragma pack()

void init_ee_flash_map(void);
int ee_read_flash(int addr, unsigned char buf[], int len);//addr is ee addr 0~224*MAX_EE_NO
void ee_write_flash(int addr, unsigned char buf[], int len);

typedef struct
{
	unsigned char write_data[512];
	unsigned char read_data[512];
	unsigned int ee_map;
  unsigned int ee_map_bk;
	unsigned int ee_map_a;
  unsigned int ee_map_bk_a;
	int try_cnt;
	int len;
	int addr;

}S_EE_FLASH_INFO;

#endif
