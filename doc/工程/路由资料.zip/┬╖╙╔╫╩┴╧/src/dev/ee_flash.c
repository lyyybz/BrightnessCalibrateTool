//#include "dev_ctrl.h"
#include "string.h"
#include "stdio.h"
#include "ee_flash.h"
//#include "comfunc.h"
#include "flash.h"
// #include "trios.h"
#include "visys.h"

//�ڴ˼ٶ�ee�Ĵ�С��224*MAX_EE_NO
unsigned int ee_map[MAX_EE_NO];  //eeprom��flash��ӳ�����224�ֽ�Ϊһ����Ԫ
unsigned int ee_map_bk[MAX_EE_NO];   //ӳ����ı�����

#define flash_valid(addr) (((unsigned int)(addr) < (FLASH_DATA_SIZE+FLASH_DATA_START))&&((unsigned int)(addr) >= FLASH_DATA_START))
#define bk_valid(addr) (((unsigned int)(addr) >= FLASH_BK_START) && ((unsigned int)(addr) < FLASH_BK_P_END))

#define EE_BK(i)     ((i * 133) + 0x55)


//int cur_scan_sector = 0;
//int cur_scan_part = 0;
//int last_recycle_page;
//int cur_recyle_page = 0;

//extern int ee_idle_time;


struct {
    int recycle_cycle;
    int recycle_sector;
} flash_info;

int sector_bk_pos = 0;
int page_bk_pos = 0;

unsigned int map_flag=0x55;

unsigned int last_valid_page = -1;//???
//unsigned int last_valid_page =FLASH_DATA_START;

#if 1
struct {
    unsigned int addr;
    unsigned int map;
    unsigned char buf[0x100];

    unsigned char sum;
}page_group[5];
#endif

void check_to_recycle_flash(void);
unsigned int get_free_flash_page(int p_cnt);
void set_setcor_bk_info(struct flash_bk_info *pbk, int start, int *cur_pos);
int init_sector_bk_info(void);
int init_page_bk_info(void);
void check_to_write_group_data(void);
int secure_flash_write(int addr, unsigned char buf[], int len);

void recycle_a_sector(unsigned int addr);//
int secure_flash_read(int addr, unsigned char buf[], int len, int to_reset);
void _ee_write_flash(int addr, unsigned char buf[], int len, int back_up);

int check_flash_data_valid(struct _flash_blk *blk);
unsigned char _checkxor( unsigned char buf[], int len );
unsigned char _checksum( unsigned char buf[], int len );
int check_data_to_replace(struct _flash_blk *blk, unsigned char buf[], int start, int len);
void set_a_flash_blk(struct _flash_blk *blk, int ee_no);
int _is_data_all_same(unsigned char data[],int len , unsigned char same);
int get_next_free_flash_addr(void);
int get_flash_data(int addr, unsigned char buf[], int len);
void init_flash_page_info(void);
int set_data_in_page_group(int addr, unsigned char buf[], int len);
int is_flash_empty(unsigned int addr, unsigned int page_map);
int is_flash_bk_info_valid(struct flash_bk_info *blk);
unsigned get_len_bit_map(int st, int len);
int get_data_from_page_group(int addr, unsigned char buf[], int len);
int check_to_back_write_data(struct flash_bk_info *bk_info);
void check_to_clr_back_data(struct flash_bk_info *bk_info);
unsigned int get_free_flash_sector(void);
void _flash_sector_erase(int addr, int to_wait);

unsigned int  ee_f_get_BASEPRI(void)
{
  register unsigned int __regBasePri         __ASM("basepri");
  return(__regBasePri);
}

void ee_f_set_BASEPRI(unsigned int basePri)
{
  register unsigned int __regBasePri         __ASM("basepri");
  __regBasePri = (basePri & 0xff);
}

void init_ee_flash_map(void)
{
    unsigned char buf[BLK_SIZE];
    int addr =FLASH_DATA_START;
    int i;
    struct _flash_blk *blk = (struct _flash_blk *)&buf[0];

    //mutex_pend(ee_write_mutex,0);

    memset((unsigned char *)ee_map, 0xff, MAX_EE_NO * 4);

    for(i = 0; i < MAX_EE_NO; i++)
    {
        ee_map_bk[i] = EE_BK(0xffffffff);
    }


    last_valid_page = -1;//???
    //last_valid_page = FLASH_DATA_START;

    init_sector_bk_info();

    while(flash_valid(addr))
    {
        //addr=FLASH_DATA_START|addr;
        flash_read(addr, &buf[0], 3);//flash_read

        if((0 == (addr & (SECTOR_SIZE-1))) && (0 == (buf[0] & SECTOR_VALID)))
        {
            addr += SECTOR_SIZE;
            continue;
        }

        if((0 == (addr & 0xff)) && (0 == (buf[0] & PAGE_VALID)))
        {
            addr += 0x100;
            continue;
        }

        if((buf[0] & BLK_VALID) && (blk->ee_no < MAX_EE_NO))
        {
            flash_read(addr, &buf[0], BLK_SIZE);
            if(check_flash_data_valid(&blk[0]) >= 0)
            {
                ee_map[blk->ee_no] = addr;   //��Ӧ��
                ee_map_bk[blk->ee_no] = EE_BK(addr);   //ͬ���޸ı�������
                if(last_valid_page < ee_map[blk->ee_no])
                {
                    last_valid_page = ee_map[blk->ee_no];
                }
            }

           // watchdog();
        }

        addr += sizeof(buf);
    }

    init_page_bk_info();
    flash_info.recycle_cycle = 0;
    flash_info.recycle_sector = 0;
    map_flag = 0xaa;

    //mutex_post(ee_write_mutex);
}


int ee_read_flash(int addr, unsigned char buf[], int len)
{
    int k, t = 0, s, b_addr, b_len, b_cnt = 0;
    unsigned int n;
    unsigned char temp[256];
    struct _flash_blk *blk = (struct _flash_blk *)&temp[0];

    if(addr < 0 || (addr + len) > DBFLASHEND)
    {
        return -1;
    }

   // _flash_wait_over();  //�ȴ��ϴβ�����ɣ������ж�flash����������δ���
    b_addr = addr;
    b_len = len;

read_start_again:
    t = 0;
    while(len > 0)
    {
        s = addr % DATA_SIZE; //����ƫ���ֽ���
        k = DATA_SIZE - s;  //�����ݿ�ʣ���ֽ�

        if(k > len)
        {
            k = len;
        }

        n = ee_map[addr / DATA_SIZE];//

        if(flash_valid(n))
        {
            if(n & 0xFF)
            {
                //reset_to_main();   //��256�ֽڶ��룬��ʼ��
            }

            //n=FLASH_DATA_START|n;
            flash_read(n, &temp[0], BLK_SIZE);

            if(check_flash_data_valid(blk) < 0)
            {
                if(0 == b_cnt)
                {
                    init_ee_flash_map();//!!!!!!!!!!!!
                    b_cnt++;
                    addr = b_addr;
                    len = b_len;
                    goto read_start_again;
                }
            }

            memcpy(&buf[t], &temp[BLK_SIZE - DATA_SIZE + s], k);
        }
        else
        {
            memset(&buf[t], 0xff, k);
        }

        t += k;
        len -= k;
        addr += k;
    }

    return(t);
}

// S_EE_FLASH_INFO ee_flash_info[4];

// void record_flash_data(int addr, unsigned char w_buf[], unsigned char r_buf[], int len, int cnt, int opt)
// {
// 	static int i = 0;

// 	if(i > 3)
// 	{
// 		i = 0;
// 	}

// 	if(opt)
// 	{
// 		ee_flash_info[i].ee_map = ee_map[0];
// 		ee_flash_info[i].ee_map_bk = ee_map_bk[0];

// 		return;
// 	}

// 	ee_flash_info[i].len = len;
// 	ee_flash_info[i].addr = addr;
// 	ee_flash_info[i].try_cnt = cnt;
// 	ee_flash_info[i].ee_map_a = ee_map[0];
// 	ee_flash_info[i].ee_map_bk_a = ee_map_bk[0];


// 	if(addr > 0 && addr < 0x120)
// 	{
// 		if(len < 0 || len > 0x120)
// 		{
// 			printf_d(0," ee_flash: write len error \n");
// 			//return;
// 		}

// 		//if(opt)
// 		{
// 			memcpy(ee_flash_info[i].write_data,w_buf,len);
// 		}
// 		//else
// 		{
// 			memcpy(ee_flash_info[i].read_data,r_buf,len);
// 		}

// 	}

// 	i++;
// }

void ee_write_flash(int addr, unsigned char buf[], int len)
{
    unsigned char temp[0x200];

    int cnt = 3;

    unsigned int cpu_sr;

    if(addr < 0 || (addr + len) > DBFLASHEND)
    {
        return;
    }

    if(map_flag != 0xaa)
    {
        return;
    }

    //mutex_pend(ee_write_mutex,0);

    while(cnt-- >= 0)//4�Σ���
    {
    	//record_flash_data(addr,buf,temp,len,cnt,1);

    	cpu_sr = ee_f_get_BASEPRI();
        ee_f_set_BASEPRI(0x20);
        _ee_write_flash(addr, &buf[0], len, 0);
        ee_f_set_BASEPRI(cpu_sr);

      int len_t = len;
        if(len > sizeof(temp))
        {
        	//mutex_post(ee_write_mutex);
           // return;
          len_t = sizeof(temp);
        }

        ee_read_flash(addr, &temp[0], len_t);//

        //record_flash_data(addr,buf,temp,len,cnt,0);

        if(0 == memcmp(&buf[0], &temp[0], len_t))
        {
        	//mutex_post(ee_write_mutex);
            return;
        }
    }
   // mutex_post(ee_write_mutex);
}


void _ee_write_flash(int addr, unsigned char buf[], int len, int back_up)
{
    int k, t = 0, a, s, ee_no, cur_page;
    int n;
    unsigned char temp[BLK_SIZE], temp2[DATA_SIZE];
    struct _flash_blk *blk = (struct _flash_blk *)&temp[0];
    struct flash_bk_info bk_info;

    //_flash_wait_over();

    init_flash_page_info();

    while(len > 0)
    {
        ee_no = addr / DATA_SIZE;
        s = addr % DATA_SIZE;
        k = DATA_SIZE - s;

        if(k > len)
        {
            k = len;
        }

        n = ee_map[ee_no];


        memset(&temp[0], 0xff, sizeof(temp));

        if(flash_valid(n))
        {
            if(n & 0xFF)
            {
                //reset_to_main();   //��256�ֽڶ��룬��ʼ��
            }

            get_flash_data(n, &temp[0], sizeof(temp));

            a = check_data_to_replace((struct _flash_blk *)&temp[0], &buf[t], s, k);

            if(0 == a)
            {
                goto continue_write;
            }

            cur_page = n;

            memcpy(&blk->data[s], &buf[t], k);  //ʵ������ blk=temp

            if(a > 0)
            {
                set_a_flash_blk(blk, ee_no);//����У�����Ϣ
            }
            else
            {
                blk->valid &= (~0x01);//����Ч��־
                n = 0xFFFFFFFF; //���ݲ�ͬ����Ϊ��Ч


                ee_map[ee_no] = n;  //��Ϊ��Ч
                ee_map_bk[ee_no] = EE_BK(n);
            }

           set_data_in_page_group(cur_page, &temp[0], BLK_SIZE);///////temp�Ǵ�flash�ж���������+��д����
           //viflash_write(cur_page, &temp[0], BLK_SIZE);
        }

        if(!flash_valid(n))
        {
            a = s + k;
            memcpy(&temp2[0], &temp[BLK_SIZE - DATA_SIZE], s);  //ǰ�������
            memcpy(&temp2[a], &temp[BLK_SIZE - DATA_SIZE + a], DATA_SIZE - a);  //��������
            memcpy(&temp2[s], &buf[t], k);
            //��д������λȫ0x�Ƿ�����ֻɾ���������·���
            if(1 == _is_data_all_same(&temp2[0], sizeof(temp2), 0xff))
            {
                goto continue_write;  //ȫΪ0xff��ֻ����������·���//goto
            }

            while((n = get_next_free_flash_addr()) < 0)
            {
                last_valid_page = (unsigned int)-1;//???
                //last_valid_page = FLASH_DATA_START;
                check_to_write_group_data();  //���գ���֤flash��������ڻ���ʱ��Ҫ��ȡ
                check_to_recycle_flash();
                //watchdog();
            }

            last_valid_page = n;

            memset(&temp[0], 0xff, BLK_SIZE - DATA_SIZE);    //??
            memcpy(&blk->data[0], &temp2[0], DATA_SIZE);  //����

            set_a_flash_blk(blk, ee_no);

           set_data_in_page_group(n, &temp[0], BLK_SIZE);//////////����temp�п������Ϣ�Ѹ���
           //viflash_write(n, &temp[0], BLK_SIZE);

            ee_map[ee_no] = n;
            ee_map_bk[ee_no] = EE_BK(n);
        }
continue_write:
        t += k;
        len -= k;
        addr += k;
    }


    if(back_up)
    {
        if(check_to_back_write_data(&bk_info) < 0)
        {
            back_up = 0;
        }
    }

    check_to_write_group_data();

    if(back_up)
    {
        check_to_clr_back_data(&bk_info);
    }

}


//���flash���ݵĺϷ��ԣ����мӺͼ����У��
int check_flash_data_valid(struct _flash_blk *blk)
{
    unsigned char sum, xor,t;
    int i;

    blk->res[sizeof(blk->res) - 1] = 0x55;
    sum = _checksum(&blk->data[0], sizeof(blk->data));
    xor = _checkxor(&blk->res[sizeof(blk->res) - 1], sizeof(blk->data) + 1);

    if((blk->bk_no != 0xffff) && (blk->bk_no != blk->ee_no))//0xffff???
    {
        return(-1);
    }

   t=~blk->sum_bit;
   if(t&(t+1))
       return(-1);//��ֹ����101֮�����

    for(i=0;i<8;i++)
    {
         if(0 == (blk->sum_bit & (0x80>>i)))
         {
             if((sum == blk->sum[7-i]) && (xor == blk->xor[7-i]))
               {
                    return(blk->ee_no);
               }
         }
    }

    return(-1);
}


unsigned char _checksum( unsigned char buf[], int len )
{
    int i=0;
    unsigned char sum=0;

    for(i=0;i<len;i++)
    {
        sum=sum+buf[i++];
    }

    return sum;
}

unsigned char _checkxor( unsigned char buf[], int len )
{
    int i=0;
    unsigned char xor=buf[0];

    for(i=1;i<len;i++)
    {
        xor=xor^buf[i++];
    }

    return xor;
}

int check_data_to_replace(struct _flash_blk *blk, unsigned char buf[], int start, int len)
{
    int i;
    //��flash�д�д���������ԭ������ͬ��������д��
    if(0 == memcmp(&blk->data[start], &buf[0], len))
    {
        return(0);
    }

    if(0 == (blk->sum_bit & 0x80))
    {
        return(-1);
    }

    for(i = 0; i < len; i++)
    {
        if(buf[i] != (buf[i] & blk->data[start + i]))
        {
            return(-1);
        }
    }
    //����д��������ԭ�������룬��д������ͬ������Խ�ԭ���ݸ���
    return(1);
}

void set_a_flash_blk(struct _flash_blk *blk, int ee_no)
{
    unsigned char data[DATA_SIZE + 1], sum, xor;
    int i;

    blk->ee_no = ee_no;
    blk->bk_no = ee_no;

    data[0] = 0x55;
    memcpy(&data[1], &blk->data[0], DATA_SIZE);

    sum = _checksum(&data[1], DATA_SIZE);
    xor = _checkxor(&data[0], DATA_SIZE + 1);


    for(i=0;i<8;i++)
     {
         if(0 == (blk->sum_bit & (0x01<<i)))
         {
             if((blk->sum_bit & (0x01<<(i+1))))//!!!
             {
                 blk->sum[i+1] = sum;
                 blk->xor[i+1] = xor;
                 break;
             }
         }
     }
    if(i>=8)
    {
        blk->sum[0] = sum;
        blk->xor[0] = xor;
    }

    blk->sum_bit <<= 1;//����˸�У�鶼��������ô��
}


int _is_data_all_same(unsigned char data[],int len , unsigned char same)
{
    int i;
    for( i = 0x00 ; i < len ; i++)
    {
        if(data[i] != same) break;
    }
    if( i >= len) return(0x01);//same
    return(0x00);
}

int get_next_free_flash_addr(void)
{
    unsigned int p = FLASH_DATA_START;
    unsigned char buf[BLK_SIZE];

    p = last_valid_page;//
    p &= 0xFFFFFF00;//��ҳ����??

    if(flash_valid(p))
    {
        p += BLK_SIZE;
    }

    if(!flash_valid(p) || !flash_valid(p + 0x100))
    {
        p = FLASH_DATA_START;
    }

    while(flash_valid(p))
    {
        get_flash_data(p, &buf[0], 0x02);
        //���ǰ���ֽ�
        if((0 == (p & (SECTOR_SIZE-1))) && (0 == (buf[0] & SECTOR_VALID)))
        {
            p += SECTOR_SIZE;
        }

        if((0 == (p & 0xff)) && (0 == (buf[0] & PAGE_VALID)))
        {
            p += 0x100;
        }

        if((0xff == buf[0]) && (0xff == buf[1]))
        {
            get_flash_data(p, &buf[0], sizeof(buf));

            if(1 == _is_data_all_same(&buf[0], sizeof(buf), 0xff))
            {
                return(p);
            }
        }

        p += sizeof(buf);
    }

    return(-1);
}

void check_to_recycle_flash(void)
{
    unsigned int i, t, cycle = 0, least;
    unsigned char sector_cnt[(FLASH_DATA_START+FLASH_DATA_SIZE) / SECTOR_SIZE];//  ????  shoud be FLASH_SIZE/SECTOR_SIZE? NO!!!
    unsigned int blk_num=SECTOR_SIZE/BLK_SIZE, num_t;

    memset(&sector_cnt[0], 0x00, sizeof(sector_cnt));

    for(i = 0; i < MAX_EE_NO; i++)    //initial value of i should be FLASH_DATA_START >> SECTOR_OFFSET?? NO!!!
    {
        t = ee_map[i];//t>0x100000

        if(flash_valid(t))
        {
            t >>= SECTOR_OFFSET; //sector mask
            if(sector_cnt[t] < blk_num)//0x80������һ��������0x80��32�ֽڿ飬��Ϊ����???0x08 0x10��0x100
            {
                sector_cnt[t]++;  //ԭ����ֻ����С��һ���
            }
        }
    }

    t = 0;
search_sector:
    t = flash_info.recycle_sector>>SECTOR_OFFSET;

    if(t < (FLASH_DATA_START/SECTOR_SIZE))    //sector_cnt[t] will awlays be zero!!
    {
    	t = FLASH_DATA_START >> SECTOR_OFFSET;
    }

    num_t = ((blk_num / 8) > 0) ? (blk_num / 8) : 1;
    for(i = t, least = t; i < sizeof(sector_cnt); i++)
    {
#ifdef FPGA_VERSION
        if(flash_info.recycle_cycle < 4)
        {
            if(sector_cnt[i] < 0x04)
            {
                goto recycle_flash;
            }
        }
        else
        {
            if((sector_cnt[i] >= 0x04) && (sector_cnt[i] < 0x80))
            {
                goto recycle_flash;
            }
        }
#else

        if(flash_info.recycle_cycle < 4)
            {
                if(sector_cnt[i] < num_t)
                {
                    goto recycle_flash;
                }
            }
            else
            {
                if((sector_cnt[i] >= num_t) && (sector_cnt[i] < (4 * num_t)))
                {
                    goto recycle_flash;
                }
            }
#endif
        if (sector_cnt[i] < sector_cnt[least])
          least = i;
    }

    if(++flash_info.recycle_cycle >= 6)
    {
        flash_info.recycle_cycle = 0;
    }

    flash_info.recycle_sector = 0; //may be FLASH_DATA_START??

    cycle++;
    if(cycle > 8)
    {
      if (sector_cnt[least] < blk_num)
      {
        i = least;
        goto recycle_flash;
      }
        //ȫ�����
        return;
    }

    goto search_sector;

recycle_flash:
    t = ((unsigned int)i)<<SECTOR_OFFSET;
    flash_info.recycle_sector = t + SECTOR_SIZE; //record next sector

   recycle_a_sector(t);
}

int get_flash_data(int addr, unsigned char buf[], int len)
{
#if 1
    if(get_data_from_page_group(addr, &buf[0], len) >= 0)
    {
        return(len);
    }
#endif
    return(secure_flash_read(addr, &buf[0], len, 1));

}

#if 1
//����������д��flash
void check_to_write_group_data(void)
{
    int i = 0, j = 0;
    unsigned char buf[0x100]__attribute__((aligned(4))), temp[0x100];

    for(i = 0; i < (sizeof(page_group) / sizeof(page_group[0])); i++)
    {
        if(flash_valid(page_group[i].addr) && (0 == (page_group[i].addr & 0xff)))
        {
            memcpy(&buf[0], &page_group[i].buf[0], 0x100);   //�ȸ������ڴ棬���ڴ��м���У�飬���ڴ���д��flash
            if(page_group[i].sum != _checksum(&buf[0], 0x100))
            {
                //reset_to_main();
            }

            secure_flash_read(page_group[i].addr, &temp[0], sizeof(temp), 1);

            for(j = 0; j < 0x100; j++)
            {
                temp[j] = temp[j] & page_group[i].buf[j];//???������д��flash���ֵ
            }
            //page_group[i].addr=FLASH_DATA_START|page_group[i].addr;
            flash_write(page_group[i].addr, &buf[0], 0x100, (~(page_group[i].addr)), 0);

            secure_flash_read(page_group[i].addr, &buf[0], sizeof(buf), 1);

            if(memcmp(&temp[0], &buf[0], 0x100))
            {
                //reset_to_main();
            	return;//??
            }
        }
    }

    init_flash_page_info();  //д���������
}
#endif

int secure_flash_read(int addr, unsigned char buf[], int len, int to_reset)
{
   // unsigned char temp[0x80];
    //addr=FLASH_DATA_START|addr;
    return(flash_read(addr, &buf[0], len));

}

#if 1
void init_flash_page_info(void)
{
    int i = 0;
    for(i = 0; i < (sizeof(page_group) / sizeof(page_group[0])); i++)
    {
        page_group[i].addr = FLASH_SIZE;
        page_group[i].map = 0;

    }
}
#endif

#if 1
int set_data_in_page_group(int addr, unsigned char buf[], int len)
{
    int i = 0, t = -1, p;
    unsigned char sum_t, sum;

    if(!flash_valid(addr))
    {
        return(-2);
    }

    p = addr & PAGE_MASK;
    for(i = 0; i < (sizeof(page_group) / sizeof(page_group[0])); i++)
    {
        if((page_group[i].addr & PAGE_MASK) == p)//�õ�ַ����ҳ�Ƿ���page_group
        {
            //page_group[i].map |= (1<<((addr & 0xff)>>BLK_SHIFT));//BLK_SHIFT
            sum_t = _checksum(&page_group[i].buf[addr & 0xff], len);
            sum = _checksum(&buf[0], len);
            memcpy(&page_group[i].buf[addr & 0xff], &buf[0], len);  //������ֿ�ҳ�����

            page_group[i].sum = page_group[i].sum + sum - sum_t;   //ֻ����ı�Ĳ���
            return(0);
        }

        if((t < 0) && (!flash_valid(page_group[i].addr)))
        {
            t = i;
        }
    }

    if(t < 0)
    {
        check_to_write_group_data();
        t = 0;  //ȫ��д������ݷ����һ����
    }

    page_group[t].addr = p;
    //page_group[t].map |= (1<<((addr & 0xff)>>BLK_SHIFT));BLK_SHIFT
    memset(&page_group[t].buf[0], 0xff, 0x100);
    page_group[t].sum = 0x00;   //ȫ0xffʱУ��Ϊ00

    sum_t = _checksum(&page_group[t].buf[addr & 0xff], len);
    sum = _checksum(&buf[0], len);

    memcpy(&page_group[t].buf[addr & 0xff], &buf[0], len);

    page_group[t].sum = page_group[t].sum + sum - sum_t;

    return(0);
}
#endif


int init_sector_bk_info(void)
{
    int addr = 0, i = 0, page_dst, page_src;
    struct flash_bk_info info;
    unsigned char buf[0x100]__attribute__((aligned(4)));

    sector_bk_pos = -1;

    while(addr < SECTOR_SIZE)
    {
        secure_flash_read(SECTOR_BK_INFO + addr, (unsigned char *)&info, sizeof(info), 1);

        if(is_flash_bk_info_valid(&info) >= 0)
        {
            info.len &= INFOLEN;//???? 4K-0xFFFF 64K-0xFFFFF

            if((SECTOR_SIZE == info.len) && (FLASH_BACKED == info.state))
            {
                if(sector_bk_pos < 0)
                {
                    sector_bk_pos = addr;  //ֻ����һ�������ڱ���״̬��
                }
                else
                {
                   _flash_sector_erase(SECTOR_BK_INFO, 1);
                    sector_bk_pos = 0;
                    return(-1);
                }
            }
        }

        addr += sizeof(info);
    }

    if(sector_bk_pos >= 0)
    {
        secure_flash_read(SECTOR_BK_INFO + sector_bk_pos, (unsigned char *)&info, sizeof(info), 1);
        info.len &= INFOLEN;

        if(!flash_valid(info.sec_no) || !bk_valid(info.bk_sec))
        {
            _flash_sector_erase(SECTOR_BK_INFO, 1);
            sector_bk_pos = 0;  //ȫ�����֮���ϴ��д���
            return(-1);
        }

        if((info.sec_no & (SECTOR_SIZE-1)) || (info.bk_sec & (SECTOR_SIZE-1)))
        {
           _flash_sector_erase(SECTOR_BK_INFO, 1);
            sector_bk_pos = 0;  //ȫ�����֮���ϴ��д���
            return(-1);
        }

        page_src = info.bk_sec & SECTOR_MASK;

        page_dst = info.sec_no & SECTOR_MASK;

        _flash_sector_erase(page_dst, 1);

        for(i = 0; i < (SECTOR_SIZE / PAGE_SIZE); i++)//�������ݻָ�
        {
            memset(&buf[0], 0xff, PAGE_SIZE);
            secure_flash_read(page_src + (i * PAGE_SIZE), &buf[0], PAGE_SIZE, 1);
            ((struct _flash_blk *)&buf[0])->state = 0xff;
            //page_dst=FLASH_DATA_START|page_dst;
            flash_write(page_dst + (i * PAGE_SIZE), &buf[0], PAGE_SIZE, (~(page_dst + (i * PAGE_SIZE))), 0);
        }

        info.state = FLASH_NOUSE;
        set_setcor_bk_info(&info, SECTOR_BK_INFO, &sector_bk_pos);

        _flash_sector_erase(page_src, 1);  //�������������
    }

    if(is_flash_empty(SECTOR_BK_INFO, 0xffff) < 0)//check all page
    {
    //
    }

    sector_bk_pos = 0;  //ȫ�����֮���ϴ��д���
    return(0);
}

int is_flash_empty(unsigned int addr, unsigned int page_map)
{
    int i = 0;
    unsigned char buf[PAGE_SIZE];

#ifdef FPGA_VERSION
    if(page_map==0x01)//check the first page
    {
        secure_flash_read(addr + (i * PAGE_SIZE), &buf[0], PAGE_SIZE, 1);
        if(_is_data_all_same(&buf[0], PAGE_SIZE, 0xff) == 0)
          {
             return(-1);
          }
    }

    while(i < (SECTOR_SIZE / PAGE_SIZE))// 4k-16  64k-256 check all
    {
            secure_flash_read(addr + (i * PAGE_SIZE), &buf[0], PAGE_SIZE, 1);
            if(_is_data_all_same(&buf[0], PAGE_SIZE, 0xff) == 0)
            {
                return(-1);
            }
        i++;
    }
#else
    while(i < (SECTOR_SIZE / PAGE_SIZE))// sector/page=16
    {
        if(page_map & (1<<i))   //page_map:check which page
        {
            secure_flash_read(addr + (i * PAGE_SIZE), &buf[0], PAGE_SIZE, 1);
            if(_is_data_all_same(&buf[0], PAGE_SIZE, 0xff) == 0)
            {
                return(-1);
            }
        }

        i++;
    }
#endif
    return(0);
}

void set_setcor_bk_info(struct flash_bk_info *pbk, int bk_start, int *cur_pos)
{
    int cnt = 3;
    unsigned int t;
    unsigned char buf[0x100]__attribute__((aligned(4))), temp[0x40], bk_info[0x20];
    struct flash_bk_info *pinfo = (struct flash_bk_info *)&buf[0];

    struct flash_bk_info *pbk_info = (struct flash_bk_info *)&bk_info[0];

    memcpy(&bk_info[0], (unsigned char *)pbk, sizeof(struct flash_bk_info));

    if(pbk_info->state)
    {
        t = _checksum(&bk_info[0], sizeof(struct flash_bk_info));
        pbk_info->len |= (t<<24);////24 ???
    }

    if(*cur_pos < 0)
    {
        *cur_pos = 0;
    }

set_sector_info_again:
    while(*cur_pos < SECTOR_SIZE)
    {
        secure_flash_read(bk_start + *cur_pos, &buf[0], sizeof(struct flash_bk_info), 1);

        if((pbk_info->bk_sec == (pbk_info->bk_sec & pinfo[0].bk_sec)) && (pbk_info->sec_no == (pbk_info->sec_no & pinfo[0].sec_no)) &&
           (pbk_info->state == (pbk_info->state & pinfo[0].state)) && (pbk_info->len == (pbk_info->len & pinfo[0].len)))
        {
            break;
        }

        *cur_pos += sizeof(struct flash_bk_info);
    }

    if(*cur_pos >= SECTOR_SIZE)
    {
       _flash_sector_erase(bk_start, 1);
        *cur_pos = 0;  //ȫ�����֮���ϴ��д���
    }

    memset(&buf[0], 0xff, sizeof(buf));

    memcpy((unsigned char *)&pinfo[((*cur_pos) & 0xff)>>4], (unsigned char *)pbk_info, sizeof(struct flash_bk_info));///>>4????
    							//��ǰλ�����ƫ��16�ֽڣ���sizeof(struct flash_bk_info)��
    //bk_start=FLASH_DATA_START|bk_start;
    flash_write(bk_start + ((*cur_pos) & 0xff00), &buf[0], sizeof(buf), (~(bk_start + ((*cur_pos) & 0xff00))), 0);//����������!!!!!!!!!!!4K->0xff00 64K->0xfff00
    secure_flash_read(bk_start + *cur_pos, &temp[0], sizeof(struct flash_bk_info), 0);

    if(memcmp(&temp[0], (unsigned char *)pbk_info, sizeof(struct flash_bk_info)))
    {
        if(cnt-- >= 0)
        {
            goto set_sector_info_again;
        }
    }
}

int is_flash_bk_info_valid(struct flash_bk_info *blk)
{
    unsigned char t, s;

    s = _checksum((unsigned char *)blk, sizeof(struct flash_bk_info));
    t = (unsigned char)(blk->len>>24); //???

    if((0 == t) || (s = (t + t)))//??
    {
        return(0);
    }

    return(-1);
}

int init_page_bk_info(void)
{
    int addr = 0, i = 0;
    struct flash_bk_info info;
    unsigned char buf[0x100]__attribute__((aligned(4))), temp[0x100];//0x20-->0x100
    struct _flash_blk *blk = (struct _flash_blk *)&temp[0];

    page_bk_pos = -1;

    while(addr < SECTOR_SIZE)
    {
        secure_flash_read(PAGE_BK_INFO + addr, (unsigned char *)&info, sizeof(info), 1);

        if(is_flash_bk_info_valid(&info) >= 0)
        {
            info.len &= INFOLEN;//????

            if((0 == (info.len & 0xFF)) && ((FLASH_BACKED == info.state) || (FLASH_DATA_BK == info.state)))//0x1f--->0xff????
            {
                if(page_bk_pos < 0)
                {
                    page_bk_pos = addr;  //ֻ����һ�������ڱ���״̬��
                }
                else
                {
                    _flash_sector_erase(PAGE_BK_INFO, 1);
                    page_bk_pos = 0;
                    return(-1);
                }
            }
        }

        addr += sizeof(info);
    }

    if(page_bk_pos >= 0)
    {
        secure_flash_read(PAGE_BK_INFO + page_bk_pos, (unsigned char *)&info, sizeof(info), 1);

        info.len &= INFOLEN;//???

        if((0 != info.sec_no) || !bk_valid(info.bk_sec) || (info.bk_sec & 0xff))//0 != info.sec_no????
        {
           _flash_sector_erase(PAGE_BK_INFO, 1);
            page_bk_pos = 0;  //ȫ�����֮���ϴ��д���
            return(-1);
        }

        secure_flash_read(info.bk_sec, &buf[0], sizeof(buf), 1);

       if(FLASH_DATA_BK == info.state)
        {
            while(i < info.len)
            {
                secure_flash_read(info.bk_sec + i, &temp[0], BLK_SIZE, 1);
                blk->state = 0xff;
                //������Ч
                if((0 == (blk->valid & BLK_VALID)) && (blk->ee_no < MAX_FLASH_NO))
                {
                    addr = blk->ee_no * BLK_SIZE;///???? ��Ҫ+FLASH_DATA_START
                    memset(&buf[0], 0xff, sizeof(buf));
                    memcpy(&buf[0], &temp[0], BLK_SIZE);
                    //addr=FLASH_DATA_START|addr;
                    flash_write(addr & 0xFFFF00, &buf[0], PAGE_SIZE, (~(addr & 0xFFFF00)), 0);
                }

                i += BLK_SIZE;
            }

            i = 0;

            while(i < info.len)
            {
                secure_flash_read(info.bk_sec + i, &temp[0], BLK_SIZE, 1);

                if((blk->valid & BLK_VALID) && (blk->ee_no < MAX_EE_NO))
                {
                    if(check_flash_data_valid(blk) >= 0)
                    {
                        ee_write_flash(blk->ee_no * DATA_SIZE, &blk->data[0], DATA_SIZE);////����Ҫ+FLASH_DATA_START?????
                    }
                }

                i += BLK_SIZE;
            }
        }

        info.state = FLASH_NOUSE;
        set_setcor_bk_info(&info, PAGE_BK_INFO, &page_bk_pos);
    }

    if(is_flash_empty(PAGE_BK_INFO, 0xffff) < 0)//check all page
    {

    }

    page_bk_pos = 0;  //ȫ�����֮���ϴ��д���

    return(0);
}

#if 1
//�ӻ����ж������ݣ�flash�е����ݿ��ܻ�δ�õ����£�
int get_data_from_page_group(int addr, unsigned char buf[], int len)
{
    int i, p;
    unsigned char temp[0x100];

    if((addr & PAGE_MASK) != ((addr + len) & PAGE_MASK))//��ҳ
    {
        return(-1);
    }

    p = addr & PAGE_MASK;
    //t = get_len_bit_map(addr, len);

    for(i = 0; i < (sizeof(page_group) / sizeof(page_group[0])); i++)
    {
        if(p == page_group[i].addr)
        {
            memcpy(&temp[0], &page_group[i].buf[0], 0x100);   //���Ƶ��ڴ棬�ڴ���У�飬�ڴ����⿽��

            if(page_group[i].sum != _checksum(&temp[0], 0x100))
            {
               // reset_to_main();
            }

            memcpy(&buf[0], &temp[addr & 0xff], len);
            return(len);
        }
    }

    return(-1);
}
#endif


#if 0
//��st��ʼ�ĳ���Ϊlen��ռ�õĿ�
unsigned get_len_bit_map(int st, int len)
{
    unsigned int t = 0, i = 0;

    st &= 0xff;
    len = len + (st & 0x1f) + BLK_SIZE - 1;
    //len &= BLK_MASK;
    //st &= BLK_MASK;  //����

    while(i < (PAGE_SIZE / BLK_SIZE))
    {
        if(st)
        {
            st -= BLK_SIZE;;
        }
        else
        {
            if(len)
            {
                len -= BLK_SIZE;
                t |= (1<<i);
            }
            else
            {
                break;
            }
        }

        i++;
    }

    return(t);
}
#endif

int check_to_back_write_data(struct flash_bk_info *bk_info)
{
    int i = 0, addr,  len = 0, to_write = 0, cnt = 3;
    unsigned char buf[0x400]__attribute__((aligned(4))), temp[0x100];//local variable more than 1K...
    struct _flash_blk *blk;

    memset(&buf[0], 0xff, sizeof(buf));

    for(i = 0; i < (sizeof(page_group) / sizeof(page_group[0])); i++)
    {
        if(flash_valid(page_group[i].addr) && (0 == (page_group[i].addr & 0xff)))
        {

            if(len >= sizeof(buf))
            {
                return(-1);
            }

            secure_flash_read(page_group[i].addr, &temp[0], 0x100, 1);

                blk = (struct _flash_blk *)&temp[0];//
                to_write = 0;

                memcpy(&temp[0], &page_group[i].buf[0], BLK_SIZE);//

                    if(0 == (blk->valid & BLK_VALID))
                    {
                        blk->valid = ~BLK_VALID;
                        blk->ee_no = (page_group[i].addr ) / BLK_SIZE;////page_group[i].addr-FLASH_DATA_START?????? ʹ��BLK_SIZE����Ҫ
                        to_write = 1;
                    }


                if(((blk->valid & BLK_VALID) && (check_flash_data_valid(blk) >= 0)) || to_write)// to_write = 1;��ִ��
                {
                    blk->state = 0xfe;
                    if(len >=  sizeof(buf))
                    {
                        return(-1);
                    }

                    memcpy(&buf[len], &temp[0], BLK_SIZE);//page_group�����ݸ��Ƶ�buf
                    len += BLK_SIZE;
                }

        }
    }

    if(0 == len)
    {
        return(-1);
    }
back_again:
    addr = get_free_flash_page((len + PAGE_SIZE - 1)/ PAGE_SIZE);//addr
    bk_info->sec_no = 0;  // 0 ?????????
    bk_info->bk_sec = addr;
    bk_info->len = len;
    bk_info->state = FLASH_DATA_BK;

    if(secure_flash_write(addr, &buf[0], (len + PAGE_SIZE - 1) & 0xffff00) < 0)
    {
        if(cnt-- > 0)
        {
            goto back_again;
        }
    }

    set_setcor_bk_info(bk_info, PAGE_BK_INFO, &page_bk_pos);

    return(0);
}


void check_to_clr_back_data(struct flash_bk_info *bk_info)
{
    bk_info->state = FLASH_NOUSE; //no use
    set_setcor_bk_info(bk_info, PAGE_BK_INFO, &page_bk_pos);
}

int secure_flash_write(int addr, unsigned char buf[], int len)
{
    unsigned char temp[0x100];
    int t = 0;

    //addr=FLASH_DATA_START|addr;

    if(addr & 0xff)
    {
        flash_write(addr, &buf[0], len, (~addr), 0);
        return(len);
    }

    while(t < len)
    {
        flash_write(addr + t, &buf[t], PAGE_SIZE, (~(addr + t)), 0);
        secure_flash_read(addr + t, &temp[0], PAGE_SIZE, 1);
#if 1
        if(memcmp(&buf[t], &temp[0], PAGE_SIZE))
        {
            return(-1);
        }
#endif
        t += PAGE_SIZE;
    }

    return(len);
}


int cur_flash_page = FLASH_BK_P_START;
int last_flash_page = FLASH_BK_P_START;

unsigned int get_free_flash_page(int p_cnt)
{
    unsigned char buf[BLK_SIZE], t = 2, cnt;
    struct _flash_blk *blk = (struct _flash_blk *)&buf[0];

    if((cur_flash_page < FLASH_BK_P_START) || (cur_flash_page >= FLASH_BK_P_END))
    {
        cur_flash_page = FLASH_BK_P_START;
    }

    cnt = p_cnt;

    while(t--)
    {
        while(cur_flash_page < FLASH_BK_P_END)
        {
            if(secure_flash_read(cur_flash_page, &buf[0], STATE_SIZE, 0) >= 0)
            {
                if(0xff == blk->state)
                {
                    if(is_flash_empty(cur_flash_page, 0x01) >= 0)////check page one
                    {
                        cnt--;

                        if(cnt <= 0)
                        {
                            return(cur_flash_page - ((p_cnt - 1) * PAGE_SIZE));
                        }
                    }
                    else
                    {
                        cnt = p_cnt;
                    }
                }
                else
                {
                    cnt = p_cnt;
                }
            }

            cur_flash_page += PAGE_SIZE;
        }

        cur_flash_page = FLASH_BK_P_START;
        cnt = p_cnt;
    }

    if(last_flash_page >= (FLASH_BK_P_END - SECTOR_SIZE))///0x1000???
    {
        cur_flash_page = FLASH_BK_P_START;////////////////////////??
    }
    else
    {
        cur_flash_page = (last_flash_page + SECTOR_SIZE) & SECTOR_MASK;
    }

    _flash_sector_erase(cur_flash_page, 1);

    last_flash_page = cur_flash_page;
    return(cur_flash_page);
}

void recycle_a_sector(unsigned int addr)
{
    int cnt = 3;
    unsigned int bk_addr, i, t, bit_map[SECTOR_SIZE/PAGE_SIZE];//һ������16*16ҳ
    struct flash_bk_info info;
    unsigned char temp[0x100]__attribute__((aligned(4)));

    //addr |= FLASH_DATA_START;

    if(!flash_valid(addr))
    {
        return;
    }

    addr &= SECTOR_MASK;

    memset(&bit_map[0], 0x00, sizeof(bit_map));

    for(i = 0; i < MAX_EE_NO; i++)
    {
        t = ee_map[i];

        if(addr == (t & SECTOR_MASK))
        {

           // bit_map[(t & 0xfff)>>8] |= (1<<((t & 0xff)>>5));//???  (t & 0xfff)>>8 which page    1<<((t & 0xff)>>5)offset within page?
             bit_map[(t & BITMAP)>>8]=1;// 4k-0xfff  64k-0xffff   (t & 0xfff)>>8: means which page...
        }
    }

recycle_sector_1:
    bk_addr = get_free_flash_sector();
    t = 0;
    while(t < (SECTOR_SIZE / PAGE_SIZE))
    {
        if(bit_map[t])   //bit_map[t] always 0
        {
            memset(&temp[0], 0xff, sizeof(temp));

            //for(i = 0; i < (PAGE_SIZE / BLK_SIZE); i++)

               // if(bit_map[t] & (1<<i))
                    // PAGE_SIZE?? BLK_SIZE???
                    secure_flash_read(addr + (t * PAGE_SIZE) , &temp[0], BLK_SIZE, 1);



            ((struct _flash_blk *)&temp[0])->state = 0xfe;

            if(secure_flash_write(bk_addr + (t * PAGE_SIZE), &temp[0], PAGE_SIZE) < 0)//��ҳ����
            {
                if(cnt-- >= 0)
                {
                    _flash_sector_erase(bk_addr, 1);
                    goto recycle_sector_1;
                }
            }

            ((struct _flash_blk *)&temp[0])->state = 0xff;

        }
        t++;
    }

    info.bk_sec = bk_addr;
    info.sec_no = addr;
    info.len = SECTOR_SIZE;//???
    info.state = FLASH_BACKED;
    set_setcor_bk_info(&info, SECTOR_BK_INFO, &sector_bk_pos);   //�������

recycle_sector_2:
    _flash_sector_erase(addr, 1);  //�ȴ�Դ����������

    t = 0;
    while(t < (SECTOR_SIZE / PAGE_SIZE))
    {
        if(bit_map[t])
        {
            secure_flash_read(bk_addr + (t * PAGE_SIZE), &temp[0], PAGE_SIZE, 1);
            ((struct _flash_blk *)&temp[0])->state = 0xff;

            if(secure_flash_write(addr + (t * PAGE_SIZE), &temp[0], PAGE_SIZE) < 0)//���ݻָ�
            {
                if(cnt-- >= 0)
                {
                    goto recycle_sector_2;
                }
            }


        }

        t++;
    }

    info.state = FLASH_NOUSE;
    set_setcor_bk_info(&info, SECTOR_BK_INFO, &sector_bk_pos);   //�������
}

int cur_flash_sector = FLASH_BK_START;
int last_flash_sector = FLASH_BK_START;
unsigned int get_free_flash_sector(void)
{
    unsigned char buf[PAGE_SIZE]__attribute__((aligned(4))), t = 2;
    struct _flash_blk *blk = (struct _flash_blk *)&blk;    //should point to buf????????????????

    if((cur_flash_sector < FLASH_BK_START) || (cur_flash_sector >= FLASH_BK_END))
    {
        cur_flash_sector = FLASH_BK_START;
    }

    while(t--)
    {
        while(cur_flash_sector < FLASH_BK_END)
        {
            if(secure_flash_read(cur_flash_sector, &buf[0], STATE_SIZE, 0) >= 0)
            {
                if(0xff == blk->state)
                {
                    if(is_flash_empty(cur_flash_sector, 0xffff) >= 0)//all
                    {
                        return(cur_flash_sector);
                    }
                    else
                    {
                        blk->state = 0xfe;
                        //cur_flash_sector=FLASH_DATA_START|cur_flash_sector;
                        flash_write(cur_flash_sector, &buf[0], PAGE_SIZE, (~cur_flash_sector), 0);    //��Ϊ�Ƿ����ȴ�����
                    }
                }
            }

            cur_flash_sector += SECTOR_SIZE;
        }

        cur_flash_sector = FLASH_BK_START;//
    }

//ȫ�ǿգ�ÿ�ζ�����ͬһ������???
    if(last_flash_sector >= (FLASH_BK_END - SECTOR_SIZE))
    {
        cur_flash_sector = FLASH_BK_START;
    }
    else
    {
        cur_flash_sector = (last_flash_sector + SECTOR_SIZE) & SECTOR_MASK;
    }

    _flash_sector_erase(cur_flash_sector, 1);
    last_flash_sector = cur_flash_sector;
    return(cur_flash_sector);
}

void _flash_sector_erase(int addr, int to_wait)
{
    //addr=FLASH_DATA_START|addr;
    flash_page_erase(SECTOR_MASK & addr, (~(SECTOR_MASK & addr)), 0);
}



