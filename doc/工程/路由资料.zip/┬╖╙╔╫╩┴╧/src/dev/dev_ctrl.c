#include "stdio.h"
#include "stdlib.h"
#include <string.h>
//#include <stm32f10x_lib.h>
#include "dev_ctrl.h"
#include "../sys/visys.h" 
#include "uart_67.h"
#include "ssc1667.h"
#include "scu.h"
#include "gpio.h"
#include "nvic.h"
#include "flash.h"
#include "toolfun.h"

#define SYSTICK (CPU_CLK / 100)

int memory_eep = 0, ee_idle_time = 0, dm_status = 0, rt_hard_new = 0, plc_38_new = 0;  /* 43��Ҫʹ�õ� */
unsigned char current_bin_time[6]={0,0,0,1,6,11};
static int sys_time_valid = 0x00;		//> is ok
static unsigned int sys_second_ticks = 0x00;

//void uart_tx_hook(int chn){}
//void uart_rx_hook(int chn){}
//int uart_chn_tx_bytes(int chn,unsigned char buffer[] ,int len){}
//int uart_chn_rx_bytes(int chn,unsigned char buffer[] ,int len){}

/* �����Ƿֲ㺯����������ʱ���ֲ��� */
void flash_sector_erase(int addr, int to_wait)
{
  //����flash֧�ֲ��ˣ��ȷ����˴�������flash�Ŀռ���������ʼ��
  
}

void flash_wait_over(void)
{
  //����flash֧�ֲ��ˣ��ȷ����˴�������flash�Ŀռ���������ʼ��
  
}
//��falsh�����ж���  void flash_write(int addr, unsigned char  buffer[],  int len){}
//��falsh�����ж���  int flash_read( int addr ,unsigned char  buffer[], int len){}
void flash_erase_all(void)
{
  //����flash֧�ֲ��ˣ��ȷ����˴�������flash�Ŀռ���������ʼ��

}
int is_flash_waiting(void)
{
  //����flash֧�ֲ��ˣ��ȷ����˴�������flash�Ŀռ���������ʼ��
  
}


//void udelay(int x){}
void mdelay(unsigned int m)
{
  delay_ms(m);  /* ����67����ĺ��� */
}

int alloc_a_timer(unsigned int timer_id, unsigned int over_time, unsigned int interval, pfunc func)
{
  timers_create(timer_id, over_time, func);
}

void del_a_timer(unsigned int time_id)
{
  timers_delete(time_id);
}

/*
�������ƣ� set_rts_value
��������������rtsֵ
���룺chn ����ͨ����value 1��0
*/
void set_rts_value(unsigned int chn, unsigned int value)
{
  //GPIO_InitTypeDef GPIO_InitStructure;

  if(CHN_DM == chn)
  {
    if(value)
    {
      dm_status = 1;
    }
    else
    {
      dm_status = 0;
    }
  }
  else if(CHN_38_1 == chn)
  {
    #if 0
    if(rt_hard_new && (0 == plc_38_new))
    {
      if(value)
      {
        GPIO_SetBits(GPIOC, GPIO_Pin_10);
      }
      else
      {
        GPIO_ResetBits(GPIOC, GPIO_Pin_10);
      }
    }
    else
    {
      if(value)
      {
        GPIO_SetBits(GPIOB, GPIO_Pin_15);
      }
      else
      {
        GPIO_ResetBits(GPIOB, GPIO_Pin_15);
      }
    }
    #else
    if(value)
      {
        gipo_out_high(TX_A_SEL);//GPIO_SetBits(GPIOC, GPIO_Pin_10);
      }
    else
      {
        gipo_out_low(TX_A_SEL);//GPIO_ResetBits(GPIOC, GPIO_Pin_10);
      }
    #endif
  }
}

/* 
�������ƣ� get_cts_value 
������������ȡctsֵ
���룺chn ����ͨ�� 
�����1 ctsΪ�ߵ�ƽ�� 0 ctsΪ�͵�ƽ
*/ 
unsigned int get_cts_value(unsigned int chn)
{
  unsigned int v = 0;
  if(CHN_DM == chn)
  {
    if(dm_status)
    {
      v = 1;
    }
  }
  else if(CHN_38_1 == chn)
  {
    #if 0
    if(rt_hard_new && (0 == plc_38_new))
    {
      v = GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_11);
    }
    else
    {
      v = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14);
    }
    #endif
    gpio_input(RX_A_SEL);
  }
    
  return v;
}

void enable_plc38(void)
{
  set_rts_value(CHN_38_1, 0);
}

void disable_plc38(void)
{
  set_rts_value(CHN_38_1, 1);
}

//visys.c�����ж��� void modules_init(void){}
//visys.c�����ж��� unsigned int get_sys_tick(){}
//dev_adapter.c�����ж��� void sys_tick_hook(void){}
void eep_write(int addr, unsigned char  buffer[],  int len)
{
  ee_write_flash(addr, buffer, len);
}

int eep_read( int addr ,unsigned char  buffer[], int len)
{
  ee_read_flash(addr, buffer, len);
}

void eep_set(int addr, unsigned char v,  int len)
{
  ee_write_flash(addr, &v, len);
}

unsigned char eep_get(int addr)
{
  unsigned char v;
  ee_read_flash(addr, &v, 1);  //_eep_read(addr, &v, 1);
  return(v);
}

void get_current_bcd_time(unsigned char t[])
{
  memcpy(&t[0], &current_bin_time[0], 6);
  bin_to_bcd(&t[0], 6);
}

void set_current_bcd_time(unsigned char t[])
{
  int i;
  unsigned char s[6];

  for(i = 0; i < 6; i++)
  {
    s[i] = BCD2BIN(t[i]);
  }
  memcpy(&current_bin_time[0], &s[0], 6);
}
  
void hard_reset(void)
{
    NVIC_SystemReset();
}
#if 0
int get_uart_status(int chn)
{
  
}
#endif
void port_reinit(void)
{
  //ԭ�����ǿպ���
}

//viuart.c�����ж��� int sys_uart_read(int chn, unsigned char buffer[],int len){}
//viuart.c�����ж��� int sys_uart_write(int chn,unsigned char buffer[],int len){}
//viuart.c�����ж��� int sys_uart_peek_data(int chn,unsigned char buffer[],int len){}
//viuart.c�����ж��� int sys_uart_clr_rx_data(int chn){}
int dbg_putdev(char buf[], int len)
{
  printf_s("dbg_putdev:  \n");
  for (int i = 0; i < len; i++)
    {
      printf_s("%02x ", buf[i]);
    }
}

void watchdog(void)
{
  wdog_fed();
}

void config_uart_info(int chn, int baud, int bits, int parity)
{
  //��ʱ������̽�ˣ�ֻ�ڳ�ʼ������һ�� uart_config(chn, baud, UART_DataMode_8);//UART_DataMode_8Even);  //Ŀǰ���õĶ���  8, PARITY_EVEN
}

void uart_init_for_38_3(int plc_38_3, int baud)
{
  //GPIO_InitTypeDef GPIO_InitStructure; 
//��ʱ������̽�ˣ�ֻ�ڳ�ʼ������һ��  
#if 0
  if(plc_38_3)
  {
    uart_config(CHN_38_3, 115200, UART_DataMode_8);//_config_uart_info(CHN_38_3, 115200, 8, PARITY_NO);
    plc_38_new = 0;

    return;
  }

  plc_38_new = 1;
#if 0
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOC, &GPIO_InitStructure); 

  /* Configure USART4 Rx (PC.11) as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  _config_uart_info(CHN_38_2, baud, 8, PARITY_EVEN);

  UART_CHN_ReInit(CHN_38_2); 
  UART_IT_Ctrl(CHN_38_2, DISABLE,ENABLE);
#else
  /* ��ʱ���ӣ�����ǰ����  */
#endif
    if(rt_hard_new)
    {
        uart_config(CHN_38_3, baud, UART_DataMode_8Even);//_config_uart_info(CHN_38_3, baud, 8, PARITY_EVEN);
    }
#endif
}
#if 0
void set_to_jump_to_update(void)
{
  
}
#endif

void send_uart_data_blocking(unsigned int chn, unsigned char buf[], int len)
{
  sys_uart_write(chn, buf, len);
}
void modules_init2(void)
{
  //���治ȷ���Ƿ��
  plc_38_new = 0;
  //gpio_init();//port_init();
  //init_timer_event();
}

int flash_backup = 1;
void set_memory_no_bakcup()
{
  flash_backup = 0;
}
#if 0
void save_fault_info(void)
{
  
}
#endif
//visys.c�����ж��� void reset_to_main(void){}
unsigned int get_random_data(void)
{
  return(SysTick->VAL);
}

void set_to_add_ee_idle_time(void)
{
  ee_idle_time += SYS_TICK_INTERVAL;
}

void sys_advance_a_second(unsigned char currnet_bin_time[])
{
  const unsigned char day_of_month[2][12] =
  {
    {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
    {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
  };

  currnet_bin_time[0]++;
  if(currnet_bin_time[0] < 60)
    goto bin_time_adjust_exit;

  currnet_bin_time[0] -= 60;
  currnet_bin_time[1]++;
  if(currnet_bin_time[1] < 60)
    goto bin_time_adjust_exit;

  currnet_bin_time[1] -= 60;
  currnet_bin_time[2]++;
  if(currnet_bin_time[2] < 24)
    goto bin_time_adjust_exit;

  currnet_bin_time[2] -= 24;
  currnet_bin_time[3]++;
  if(currnet_bin_time[3] <= day_of_month[0x00 != (currnet_bin_time[5] & 0x03)][currnet_bin_time[4] - 1])
    goto bin_time_adjust_exit;

  currnet_bin_time[3] = 1;
  currnet_bin_time[4] ++;
  if(currnet_bin_time[4] <= 12)
    goto bin_time_adjust_exit;

  currnet_bin_time[4] = 1;
  currnet_bin_time[5]++;

bin_time_adjust_exit:
  return;
}

void rtc_second_tick_hook(void)
{
  sys_advance_a_second(current_bin_time);
  sys_second_ticks++;
  sys_time_valid --;
}

//void uart_tick_hook( int chn){}
void scan_to_recycle_flash(void)
{
  //��ʱ����Ҫ
}

//void disable_uart_rcv(void){}
//void set_led_out(int v){}
#if 0  /* ����2����������Ҫ */
void disable_irq(void)
{
  __disable_irq();
}

void enable_irq(void)
{
  __enable_irq();
}
#endif
int is_memory_eep(void)
{
  if(memory_eep)
  {
    return(0);
  }

  return(-1);
}

//void heck_to_erase_all(void){}

void get_rand_info(unsigned int buf[])
{
  buf[0] = *(unsigned int*)(0x40048054);//(0x1FFFF7E8);	// ��ȡоƬUnique Device ID
	buf[1] = *(unsigned int*)(0x40048058);//(0x1FFFF7EC);
	buf[2] = *(unsigned int*)(0x4004805c);//(0x1FFFF7F0);
  
  #if 0
  uid1 = *(unsigned int *)(0x40048054); /* unique device ID */
  uid2 = *(unsigned int *)(0x40048058);
  uid3 = *(unsigned int *)(0x4004805c);
  uid4 = *(unsigned int *)(0x40048060);
  #endif
}

int is_hard_new(void)
{
  return(rt_hard_new);
}
#if 0
unsigned int get_set_value(void)
{
  
}
#endif
void msys_init(void)
{
  scu_init();               /*FCLK = 150MHz, PLCK = 75M*/
  systick_config(CPU_CLK / 100);           /* 150M, 10ms */   
  flash_protect_init();	
  //EN25QXX_Init();
}



