#ifndef _INODE_H_
#define _INODE_H_

#define BLK_NO_SHIFT  5
#define BLK_SZ     (0x01 << BLK_NO_SHIFT)
/*BUFFER_SIZE is the power of the BUFFER_SHIFT*/
#define INVALID_BLK_NO  0xFF  

#define INVALID_PTR     (INVALID_BLK_NO << BLK_NO_SHIFT)

#define BUFFER_LEN 0x08


typedef unsigned int   OS_CPU_SR;
#define  OS_CRITICAL_METHOD   3

//�����ж�
#if OS_CRITICAL_METHOD == 3
#define  OS_ENTER_CRITICAL()  disable_irq()//{cpu_sr = OS_CPU_SR_Save();}
#define  OS_EXIT_CRITICAL()   enable_irq()//{OS_CPU_SR_Restore(cpu_sr);}
#endif



struct _CHN_SLOT
{
  unsigned short rx;                  //���ݵĵ�ǰλ��
  unsigned short tx;                  //���ݵ���ʼλ��
  unsigned short data_cnt;            //��Ч���ݸ���
  unsigned short data_max;            //������������ݸ���
  unsigned char  buffer[BUFFER_LEN];
  unsigned char  t_index;
  unsigned char  r_index;
  //uint16 idle_tick;
};

struct _CHN_POOL_MGR
{
  unsigned char buffer[0x400];  //������
  unsigned int  free_bitmap;    //λ��־����ʾÿ�黺���ʹ�������1Ϊ���п�
};

void init_chn_pool_mgr(void);
int put_chn_bytes(struct _CHN_SLOT *pCHN_SLOT,unsigned char buffer[] ,int len);
int put_chn_byte(struct _CHN_SLOT *pCHN_SLOT,unsigned char c);
int get_chn_bytes(struct _CHN_SLOT *pCHN_SLOT,unsigned char buffer[] ,int len);
int get_chn_byte(struct _CHN_SLOT *pCHN_SLOT ,unsigned char buffer[]);
int peek_chn_byte(struct _CHN_SLOT *pCHN_SLOT,unsigned char data[],int len);
#endif
