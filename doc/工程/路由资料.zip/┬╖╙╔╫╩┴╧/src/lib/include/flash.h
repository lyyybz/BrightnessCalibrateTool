#ifndef __FLASH_H__
#define __FLASH_H__

#ifndef REG32
    #define REG32(x)                    (*(volatile unsigned int *)(x))
#endif

#ifndef _REG_FLD_OP_
    #define _REG_FLD_OP_

    // Register Field Mask
    #define FLD_MASK(s,e)              ((0xffffffff >> (31-(e)+(s))) << (s))

    // Register Field Mask Write-Data
    // s -- Start of Bit  e -- End   of Bit
    // v -- Value
    #define FLD_MWD(s,e,v)              (((v) << (s)) & FLD_MASK((s),(e)))

    // Register Field Mask Read-Data
    // s -- Start of Bit  e -- End   of Bit
    // v -- Value
    #define FLD_MRD(s,e,v)              (((v) & FLD_MASK((s),(e))) >> (s))

    // Register Field Write operation
    // a -- Address   s -- Start of Bit
    // v -- Value     e -- End   of Bit
    #define OP_FLD_WR(a,s,e,v)          (REG32((a)) = (((v) << (s)) & FLD_MASK((s),(e))) | (REG32((a)) & ~FLD_MASK((s),(e))))
    #define OP_FLD_WR_EXC(a,s,e,v)      (REG32((a)) = (((v) << (s)) & FLD_MASK((s),(e))))

    // Register Field Read operation
    #define OP_FLD_RD(a,s,e)            ((REG32((a)) & FLD_MASK((s),(e))) >> (s))

#endif

#define CACHE_BASE_ADDR   (0x40080000)
#define CACHE_CCR_ADDR    (CACHE_BASE_ADDR)
#define CACHE_SR_ADDR     (CACHE_BASE_ADDR + 0x4)

#define SET_CACHE_MODE(v)    OP_FLD_WR(CACHE_CCR_ADDR, 3, 4, v)
#define SET_CACHE_ENABLE(v)  OP_FLD_WR(CACHE_CCR_ADDR, 0, 0, v)
#define GET_CACHE_STATE()    OP_FLD_RD(CACHE_SR_ADDR, 0, 1)

#define CACHE_ENABLE()   SET_CACHE_MODE(0);\
                         SET_CACHE_ENABLE(1);\
												 while(0x2 != GET_CACHE_STATE())
													 
#define CACHE_DISABLE()  SET_CACHE_ENABLE(0)
												 
#define IAP_BASE_ADDR     (0x40000800)
#define IAP_CON_ADDR      (IAP_BASE_ADDR)
#define IAP_UL_ADDR       (IAP_BASE_ADDR + 0x10)
												 
#define IAP_ENABLE()        OP_FLD_WR(IAP_CON_ADDR, 0, 0, 1)
#define IAP_DISABLE()       OP_FLD_WR(IAP_CON_ADDR, 0, 0, 0)

#define SET_IAP_CKS(v)      OP_FLD_WR(IAP_CON_ADDR, 4, 6, v)
												 
#define GET_IAP_FLASH_ACK() OP_FLD_RD(CACHE_SR_ADDR, 2, 2)

#define IAP_UNLOCK()        OP_FLD_WR(IAP_UL_ADDR, 0, 31, 0xA5)
#define IAP_LOCK()          OP_FLD_WR(IAP_UL_ADDR, 0, 31, 0x0)
												 
#define BYTE_PROGRAM_ERASE_NO 0x0
#define BYTE_PROGRAM_ERASE    0x1

typedef unsigned int (*page_erase_fun)(unsigned int, unsigned int);
typedef unsigned int (*word_program_fun)(unsigned int, unsigned int, unsigned int);
typedef unsigned int (*byte_program_fun)(unsigned int, unsigned int, unsigned int, unsigned int);

#define IAP_PAGE_ERASE         ((page_erase_fun)(*(unsigned int *)0x10000004))
#define IAP_WORD_PROGRAM       ((word_program_fun)(*(unsigned int *)0x10000008))
#define IAP_BYTE_PROGRAM       ((byte_program_fun)(*(unsigned int *)0x10000000))

#define FLASH_VECTOR_ADDR  0x00014000
#define SRAM_VECTOR_ADDR   0x200FE000

#define FLASH_SIZE        0x100000
#define FLASH_START_ADDR  0x0
#define FLASH_END_ADDR    (FLASH_SIZE - 0x1)
#define FLASH_PAGE_SIZE   0x2000
#define FLASH_PAGE_MASK   0x1FFF

#define F_DATA_START 0xA4000
#define F_DATA_END   0xFFFFF
#define HPRI_FLAG 0x5555AAAA

int flash_page_erase(unsigned int page_addr, unsigned int rpage_addr, unsigned int flag);
int flash_erase(unsigned int addr, unsigned int len, unsigned int raddr, unsigned int flag);
//�ĳ��ʺ�43�Ľṹ  int flash_write(unsigned int dst, unsigned char src[], unsigned int len, unsigned int rdst, unsigned int flag);
//�ĳ��ʺ�43�Ľṹ  int flash_read(unsigned int addr, unsigned char buf[], unsigned int len);
int flash_erase_write(unsigned int dst, unsigned char src[], unsigned int len, unsigned int rdst, unsigned int flag);

void flash_protect_init(void);
void lvd_irq_handler(void);

#endif /* end of flash.h */
