/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      crc.h
Description:    the crc interface control
Author:         ch
Version:        v1.0
Date:           2017/08/04
History:
*/
/************************************************************************************************/
#include "ssc1667.h"
#include "type.h"

typedef enum
{
    CRC_OUT_NOMAL       = 0x00,         /* CRC���������ȡ�� */
    CRC_OUT_NOT         = 0x01,         /* CRC�������ȡ�� */
} CRC_XOROUT;

typedef enum
{
    CRC_WITH_BYTE       = 0x00,         /* CRC���ȣ��ֽ� */
    CRC_WITH_HLWORD     = 0x01,         /* CRC���ȣ����� */
    CRC_WITH_WORD       = 0x02,         /* CRC���ȣ��ֽ� */
} CRC_WITH;

typedef enum
{
    CRC_MOD_CRC32       = 0x00,         /* CRC32 */
    CRC_MOD_CRC24       = 0x01,         /* CRC24 */
    CRC_MOD_CRC16       = 0x02,         /* CRC16 */
} CRC_MOD;

typedef enum
{
    CRC_DS_0            = 0x00,         /* ��ʼȫΪ0 */
    CRC_DS_1            = 0x01,         /* ��ʼȫΪ1 */
} CRC_DS;

typedef uint32_t(*API_CRC_EmptyCheck)(uint32_t, uint32_t);
typedef uint32_t(*API_CRC_FlashVerify)(uint32_t, uint32_t, uint32_t);
typedef uint32_t(*API_CRC_UserCal)(uint32_t, uint32_t, uint32_t);
typedef uint32_t(*API_CRC_CheckReset)(void);

#define CRC_EmptyCheck      ((API_CRC_EmptyCheck)(*((uint32_t *)0x10008000)))
#define CRC_FlashVerify     ((API_CRC_FlashVerify)(*((uint32_t *)0x10008004)))
#define CRC_UserCal         ((API_CRC_UserCal)(*((uint32_t *)0x10008008)))
#define CRC_CheckReset      ((API_CRC_CheckReset)(*((uint32_t *)0x1000800C)))

/*****************************************************************************************************/
/*
    Function    : crc24
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
extern int crc24(CRC_DS ds, unsigned char *data, unsigned int len, void *out);

/*****************************************************************************************************/
/*
    Function    : crc16
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
extern int crc16(CRC_DS ds, unsigned char *data, unsigned int len, void *out);

/*****************************************************************************************************/
/*
    Function    : crc32
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFFFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
extern int crc32(CRC_DS ds, unsigned char *data, unsigned int len, void *out);

/*****************************************************************************************************/
/*
    Function    : crc_get_config
    Description : get config word
    Input       : oxor - ��������Ƿ�ȡ��
                  with - ���ݿ���
                  md   - crc ģʽ
                  ds   - CRC�����ֵ 
    Output      : none
    Return      : �����ϳɵ������֣�32bit������
    Notes       : �������ڵ��ù̻���������У����ʱ���������������
*/
/*****************************************************************************************************/
extern unsigned int crc_get_config(CRC_XOROUT oxor, CRC_WITH with, CRC_MOD mod, CRC_DS ds);

unsigned short crc16_soft1(unsigned char *buf, int len);  /* 0x9FУ��ר��CRC */

