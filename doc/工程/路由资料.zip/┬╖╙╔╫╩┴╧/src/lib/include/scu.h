/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      scu.h
Description:    the scu control
Author:         ch
Version:        v1.0
Date:           2017/07/28
History:
*/
/************************************************************************************************/


#ifndef __SCU_H
#define __SCU_H

typedef enum
{
  SCU_GPIO = 0,
  SCU_FLASH = 1,
  SCU_ADC = 2,
  SCU_IWDT = 3,
  SCU_T16N0 = 4,
  SCU_T16N1 = 5,
  SCU_T16N2 = 6,
  SCU_T16N3 = 7,
  SCU_T32N0 = 8,
  SCU_T32N1 = 9,
  SCU_T32N2 = 10,
  SCU_T32N3 = 11,
  SCU_UART0 = 12,
  SCU_UART1 = 13,
  SCU_UART2 = 14,
  SCU_UART3 = 15,
  SCU_SPI0 = 16,
  SCU_SPI1 = 17,
  SCU_I2C0 = 18,
  SCU_I2C1 = 19,
  SCU_TENSOR = 20,
  SCU_ECC = 23,
  SCU_CRC = 24,
  SCU_WWDT = 25,
  SCU_OPAMP = 26,
  SCU_COMP = 27,
  SCU_RNG = 29,
  SCU_SPI2 = 30,
  SCU_SPI3 = 31,
}SCU_APB1PERI_Typedef;

typedef enum
{
  SCU_AES = 0,
  SCU_BPLC = 1,
  SCU_150M = 2,
  SCU_TIMER = 3,
}SCU_APB2PERI_Typedef;

void scu_init(void);

void scu_clk_en(unsigned int periph);

#endif /* __LIB_SCU_H */
