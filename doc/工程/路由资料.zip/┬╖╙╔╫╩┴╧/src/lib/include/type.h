/*********************************************************
*Copyright (C), 2016~2020, �ൺ�����ز��Ƽ��ɷ����޹�˾��
*�ļ���:  type.h
*��  ��:  ES Application Team
*��  ��:  V1.0
*��  ��:  2017/06/30
*��  ��:  type���塣
*��  ע:  ������SSC1667&68��
**********************************************************/


#ifndef __TYPE_H
#define __TYPE_H


#ifndef TRUE
#define TRUE            (1 == 1)
#endif
#ifndef FALSE
#define FALSE           (!TRUE)
#endif

#ifndef OK
#define OK              0
#endif
#ifndef ERROR
#define ERROR           -1
#endif

#define __isr__

typedef enum {Disable = 0x0, Enable = 0x1} TYPE_FUNCEN;
typedef enum {DISABLE = 0, ENABLE = !DISABLE} FuncState;
typedef enum {RESET = 0, SET = !RESET} FlagStatus, ITStatus, PinStatus;

typedef unsigned long       ulong_t;
typedef unsigned long long  uint64_t;
typedef unsigned int        uint32_t;
typedef unsigned short      uint16_t;
typedef unsigned char       uint8_t;

typedef long           long_t;
typedef long long      int64_t;
typedef int            int32_t;
typedef short          int16_t;
typedef signed char    int8_t;

typedef unsigned char  BOOLEAN;
typedef unsigned char  INT8U;                    /* Unsigned  8 bit quantity                           */
typedef signed char    INT8S;                    /* Signed    8 bit quantity                           */
typedef unsigned short INT16U;                   /* Unsigned 16 bit quantity                           */
typedef signed short   INT16S;                   /* Signed   16 bit quantity                           */
typedef unsigned int   INT32U;                   /* Unsigned 32 bit quantity                           */
typedef signed int     INT32S;                   /* Signed   32 bit quantity                           */

typedef INT32U         OS_STK;                   /* Each stack entry is 32-bit wide                    */
typedef INT32U         OS_CPU_SR;                /* Define size of CPU status register (PSW = 32 bits) */

typedef unsigned long int   ULONG;
#endif /* __TYPE_H */
