/*********************************************************
*Copyright (C), 2016~2020, �ൺ�����ز��Ƽ��ɷ����޹�˾��
*�ļ���:  lib_nvic.h
*��  ��:  ES Application Team
*��  ��:  V1.0
*��  ��:  2017/06/30
*��  ��:  NVICģ��⺯��ͷ�ļ���
*��  ע:  ������SSC1667&68��
**********************************************************/


#ifndef __NVIC_H
#define __NVIC_H


#include "ssc1667.h"
//#include "types.h"


typedef struct
{
  uint8_t NVIC_IRQChannel;                    /*!< Specifies the IRQ channel to be enabled or disabled.
                                                   This parameter can be an enumerator of @ref IRQn_Type
                                                   enumeration (For the complete STM32 Devices IRQ Channels
                                                   list, please refer to stm32f2xx.h file) */

  uint8_t NVIC_IRQChannelPreemptionPriority;  /*!< Specifies the pre-emption priority for the IRQ channel
                                                   specified in NVIC_IRQChannel. This parameter can be a value
                                                   between 0 and 15 as described in the table @ref MISC_NVIC_Priority_Table
                                                   A lower priority value indicates a higher priority */

  uint8_t NVIC_IRQChannelSubPriority;         /*!< Specifies the subpriority level for the IRQ channel specified
                                                   in NVIC_IRQChannel. This parameter can be a value
                                                   between 0 and 15 as described in the table @ref MISC_NVIC_Priority_Table
                                                   A lower priority value indicates a higher priority */

  FuncState NVIC_IRQChannelCmd;         /*!< Specifies whether the IRQ channel defined in NVIC_IRQChannel
                                                   will be enabled or disabled.
                                                   This parameter can be set either to ENABLE or DISABLE */
} NVIC_InitTypeDef;

void NVIC_Init(NVIC_InitTypeDef* NVIC_InitStruct);
void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset);
unsigned int systick_config(unsigned int ticks);

#endif /* __LIB_NVIC_H */
