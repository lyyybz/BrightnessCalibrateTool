/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      t32n_reg.h
Description:    the t32n interface
Author:         ch
Version:        v1.0
Date:           2017/08/01
History:
*/
/************************************************************************************************/

#ifndef __T32N_H
#define __T32N_H

/*t32n��ƥ����ֵ���üĴ���*/
typedef enum
{
    T32N_MAT0 = 0,
    T32N_MAT1 = 1,
    T32N_MAT2 = 2,
    T32N_MAT3 = 3,
}T32N_TYPE_MAT;

#define TIMER32_0   (0)
#define TIMER32_1   (1)
#define TIMER32_2   (2)
#define TIMER32_3   (3)

#define PT_TMR      (TIMER32_0)

#define T32N_CLK                 (1000000)          /* 1M */
#define T32N_S_PERTICK           (float)(1.0 / (T32N_CLK))
#define T32N_MS_PERTICK          (float)(T32N_S_PERTICK * 1000)
#define T32N_US_PERTICK          (float)(T32N_MS_PERTICK * 1000)
#define T32N_NS_PERTICK          (float)(T32N_US_PERTICK * 1000)

#define T32N_TICK_PERS           (T32N_CLK)
#define T32N_TICK_PERMS          (T32N_TICK_PERS / 1000)
#define T32N_TICK_PERUS          (T32N_TICK_PERMS / 1000)

typedef void (*T32N_MAT_HANDLE)(void);

/*****************************************************************************************************/
/*
    Function    : t32n_init
    Description : config t32nx as system timer
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_init(unsigned int tmr);

/*****************************************************************************************************/
/*
    Function    : t32n_set_mat
    Description : config T32Nx_Matx
    Input       : tmr - T32N idx  [0,3]
                  mat - MAT idx  [0,3]
                  us  - timer interval (us)
                  isr - call back fun when timeout
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_set_mat(unsigned int tmr, unsigned char mat, unsigned int us, T32N_MAT_HANDLE isr);

/*****************************************************************************************************/
/*
    Function    : t32n_clear_mat
    Description : stop mat timing and disable interrupt
    Input       : tmr - T32N idx  [0,3]
                  mat - MAT idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_clear_mat(unsigned int tmr, unsigned char mat);

/*****************************************************************************************************/
/*
    Function    : t32n_set_overflow
    Description : config T32Nx overflow
    Input       : tmr - T32N idx [0,3]
                  isr - call back fun when timer is overflow
    Output      : none
    Return      : none
    Notes       : overflow timer = 4294967295 us = 4294967.295ms = 4294.967295s = 71.583min = 1.193h
*/
/*****************************************************************************************************/
extern void t32n_set_overflow(unsigned int tmr, T32N_MAT_HANDLE isr);

/*****************************************************************************************************/
/*
    Function    : t32n_get_cnt
    Description : get cur cnt
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern unsigned int t32n_get_cnt(unsigned char tmr);
/*****************************************************************************************************/
/*
    Function    : t32n_set_cnt
    Description : set current cnt
    Input       : tmr - T32N idx  [0,3]
                  cnt - init cnt to be set
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_set_cnt(unsigned char tmr, unsigned int cnt);

/*****************************************************************************************************/
/*
    Function    : t32n_tmr_start
    Description : start a timer for mat0
    Input       : tmr - T32N idx  [0,3]
                  inicnt - start cnt
                  endcnt - end cnt
                  isr    - call back func for timerout
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_tmr_start(unsigned int tmr, unsigned int inicnt, unsigned int endcnt, T32N_MAT_HANDLE isr);

/*****************************************************************************************************/
/*
    Function    : t32n_start
    Description : start counting
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_start(unsigned int tmr);

/*****************************************************************************************************/
/*
    Function    : t32n_stop
    Description : stop a timer
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
extern void t32n_stop(unsigned int tmr);

#endif

