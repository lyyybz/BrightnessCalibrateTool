/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      t32n_reg.h
Description:    the t32n control
Author:         ch
Version:        v1.0
Date:           2017/08/01
History:
*/
/************************************************************************************************/

#ifndef __T32N_REG_H
#define __T32N_REG_H


#include "ssc1667.h"

/*t32nƥ��mat��Ĺ���ģʽ*/
typedef enum
{
    T32N_COUNT_INT0 = 0x00,
    T32N_HOLD_INT1  = 0x01,
    T32N_CLEAR_INT1 = 0x02,
    T32N_COUNT_INT1 = 0x03,
}T32N_TYPE_MAT_MODE;

/*t32n����ģʽ*/
typedef enum
{
    T32N_TIMING_MOD  = 0x00,
    T32N_CAPTURE_MOD = 0x02,
    T32N_MODIFY_MOD  = 0X03,
}T32N_TYPE_MOD;

/*t32n�ⲿʱ�Ӽ�������ѡ��*/
typedef enum
{
    T32N_UP_EDGE    = 0x00,
    T32N_DOWN_EDGE  = 0x01,
    T32N_UP_DOWN    = 0x02,
}T32N_TYPE_EDGE;

/*t32nʱ��Դ*/
typedef enum
{
    T32N_PCLK   =   0x00,
    T32N_CK0    =   0x01,
    T32N_CK1    =   0x02,
}T32N_TYPE_CS;

/*t32nƥ��mat��Ķ˿ڶ���*/
typedef enum
{
    T32N_PORT_HOLD   =   0x00,
    T32N_PORT_CLEAR  =   0x01,
    T32N_PORT_HIGH   =   0x02,
    T32N_PORT_REVS   =   0x03,
}T32N_TYPE_MOM;

/*t32n�ж�ʹ��λ*/
typedef enum
{
    T32N_MAT0IE = (0X01 << 0),
    T32N_MAT1IE = (0X01 << 1),
    T32N_MAT2IE = (0X01 << 2),
    T32N_MAT3IE = (0X01 << 3),
    T32N_FFFFIE = (0X01 << 4),
    T32N_CAP0IE = (0X01 << 5),
    T32N_CAP1IE = (0X01 << 6),
}T32N_TYPE_IE;

/*T32N�жϱ�־λ*/
typedef enum
{
    T32N_MAT0IF = (0X01 << 0),
    T32N_MAT1IF = (0X01 << 1),
    T32N_MAT2IF = (0X01 << 2),
    T32N_MAT3IF = (0X01 << 3),
    T32N_FFFFIF = (0X01 << 4),
    T32N_CAP0IF = (0X01 << 5),
    T32N_CAP1IF = (0X01 << 6),
}T32N_TYPE_IF;

typedef enum
{
    MATS_0    = 8,
    MATS_1    = 10,
    MATS_2    = 12,
    MATS_3    = 14,
} T32N_MATS_OFF;

#if 1
typedef enum
{
    MATS0_MOD0 = T32N_COUNT_INT0 << MATS_0,
    MATS0_MOD1 = T32N_HOLD_INT1  << MATS_0,
    MATS0_MOD2 = T32N_CLEAR_INT1 << MATS_0,
    MATS0_MOD3 = T32N_COUNT_INT1 << MATS_0,

    MATS1_MOD0 = T32N_COUNT_INT0  << MATS_1,
    MATS1_MOD1 = T32N_HOLD_INT1   << MATS_1,
    MATS1_MOD2 = T32N_CLEAR_INT1  << MATS_1,
    MATS1_MOD3 = T32N_COUNT_INT1  << MATS_1,

    MATS2_MOD0 = T32N_COUNT_INT0 << MATS_2,
    MATS2_MOD1 = T32N_HOLD_INT1  << MATS_2,
    MATS2_MOD2 = T32N_CLEAR_INT1 << MATS_2,
    MATS2_MOD3 = T32N_COUNT_INT1 << MATS_2,

    MATS3_MOD0 = T32N_COUNT_INT0 << MATS_3,
    MATS3_MOD1 = T32N_HOLD_INT1  << MATS_3,
    MATS3_MOD2 = T32N_CLEAR_INT1 << MATS_3,
    MATS3_MOD3 = T32N_COUNT_INT1 << MATS_3,
} T32N_MATSx_MODx;
#endif

typedef enum
{
    MOM_0 = 24,
    MOM_1 = 26,
    MOM_2 = 28,
    MOM_3 = 30,
} T32N_MOM_OFF;

#define _T32Nx(tmr)        ((T32N0_BASE) + (0x400 * (tmr)))
#define T32N_CNT           (4)
#define T32N_MAT_CNT       (4)

#define T32N_GetIF(T32Nx, flag) (((T32Nx)->IF.Word) & (flag))
#define T32N_CLRIF(T32Nx, flag) (((T32Nx)->IF.Word) = (flag))

typedef void (*T32N_CONFIG)(void);

#endif

