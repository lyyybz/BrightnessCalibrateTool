/*************************************************************************************************/
/*
Copyright:		QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:		irq.c
Description:	the irq control
Author:			ch
Version:		v1.0
Date:			2017/06/09
History:
*/
/************************************************************************************************/
#include <stdio.h>
#include "nvic.h"

#include "irq.h"

ext_irq_t ext_irq[IRQn_DEF];

void irq_release(IRQn_Type irqn)
{
  if (irqn >= IRQn_DEF)
    return;
  ext_irq[irqn].ext_irq = NULL;
}

void irq_request(IRQn_Type irqn, irq_priority_t pri, EXT_IRQ_HANDLE irq_handle)
{
    if ((irqn >= IRQn_DEF) || (pri >= PRI_DEF) || (NULL == irq_handle))
    {
        return;
    }

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = irqn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = pri;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    ext_irq[irqn].EIRQ_n = irqn;
    ext_irq[irqn].ext_irq = irq_handle;
}



