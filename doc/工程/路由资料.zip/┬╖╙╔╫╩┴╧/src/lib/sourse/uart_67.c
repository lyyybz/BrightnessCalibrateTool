/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      uart.c
Description:    the uart control
Author:         ch
Version:        v1.0
Date:           2017/07/26
History:
*/
/************************************************************************************************/
#include "stdio.h"
#include "uart_67.h"
#include "uart_reg.h"
#include "gpio.h"
#include "scu.h"
#include "irq.h"
#include "nvic.h"
#include "../../rtiii/include/dev/uart.h"

static void uart_config_0(UART_RX_ISR rx, UART_TX_ISR tx);
static void uart_config_1(UART_RX_ISR rx, UART_TX_ISR tx);
static void uart_config_2(UART_RX_ISR rx, UART_TX_ISR tx);
static void uart_config_3(UART_RX_ISR rx, UART_TX_ISR tx);

static void UART_OutLfToCrLf(char c);

static void uart_reset(unsigned char chn);

static void uart_config_ctrl(UART_TypeDef *UARTx, UART_InitStruType *UART_InitStruct);

static void uart_cmd(UART_TypeDef *UARTx, FuncState NewState);

static void  uart_0_isr(void);
static void  uart_1_isr(void);
static void  uart_2_isr(void);
static void  uart_3_isr(void);

static UART_RX_ISR uart_rx_isr[UART_MAX_INX] = {NULL};

static UART_TX_ISR uart_tx_isr[UART_MAX_INX] = {NULL};

/*****************************************************************************************************/
/*
    Function    : uart_init
    Description : uart init
    Input       : chn - uart chan idx [0,3]
                  rx - user rx isr
                  tx - user tx isr
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void uart_init(unsigned int chn, UART_RX_ISR rx, UART_TX_ISR tx)
{
    UART_CONFIG_FUNC config[] = {uart_config_0, uart_config_1, uart_config_2, uart_config_3};
    
    if (chn > sizeof(config) / sizeof(config[0]))
    {
        return;
    }
    config[chn](rx, tx);
}

/*****************************************************************************************************/
/*
    Function    : uart_config_0
    Description : config uart0 as A
    Input       : rx - user rx isr
                  tx - user tx isr
    Output      : none
    Return      : none
    Notes       : 115200, 8, 1, n start rx
*/
/*****************************************************************************************************/
static void uart_config_0(UART_RX_ISR rx, UART_TX_ISR tx)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    uart_reset(0);

    gpio_set_map(GPIO_9, UART0_TXD);
    gpio_set_map(GPIO_8, UART0_RXD);
    gpio_set_dir(GPIO_9, GPIO_DIR_OUT);
    gpio_set_dir(GPIO_8, GPIO_DIR_IN);

    irq_release(UART0_IRQn);
    irq_request(UART0_IRQn, PRI_UART0, uart_0_isr);
    
    uart_rx_isr[0] = rx;
    uart_tx_isr[0] = tx;


    uart_cmd(UART0, DISABLE);
    uart_config(CHN_38_1, UART_BAUD_115200, UART_DataMode_8);

    UART0->CON1.IDM    = UART_IDM_Idle_3;
    UART0->CON0.IDEN   = 1;
    UART0->IE.RBIE     = 1;    /* enable RB&ID */
    UART0->IE.IDIE     = 1;

    NVIC_InitStructure.NVIC_IRQChannel = UART0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    uart_cmd(UART0, ENABLE);
}

/*****************************************************************************************************/
/*
    Function    : uart_config_1
    Description : config uart1 as DM
    Input       : rx - user rx isr
                  tx - user tx isr
    Output      : none
    Return      : none
    Notes       : 9600, 8, 1, EVEN start rx
*/
/*****************************************************************************************************/
static void uart_config_1(UART_RX_ISR rx, UART_TX_ISR tx)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    uart_reset(1);

    gpio_set_map(GPIO_23, UART1_TXD);
    gpio_set_map(GPIO_22, UART1_RXD);
    gpio_set_dir(GPIO_23, GPIO_DIR_OUT);
    gpio_set_dir(GPIO_22, GPIO_DIR_IN);

    irq_release(UART1_IRQn);
    irq_request(UART1_IRQn, PRI_UART1, uart_1_isr);
    
    uart_rx_isr[1] = rx;
    uart_tx_isr[1] = tx;


    uart_cmd(UART1, DISABLE);
    uart_config(CHN_DM, UART_BAUD_9600, UART_DataMode_8Even);

    UART1->CON1.IDM    = UART_IDM_Idle_3;
    UART1->CON0.IDEN   = 1;
    UART1->IE.RBIE     = 1;    /* enable RB&ID */
    UART1->IE.IDIE     = 1;

    NVIC_InitStructure.NVIC_IRQChannel = UART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    uart_cmd(UART1, ENABLE);
}

/*****************************************************************************************************/
/*
    Function    : uart_config_2
    Description : config uart2 as C
    Input       : rx - user rx isr
                  tx - user tx isr
    Output      : none
    Return      : none
    Notes       : 115200, 8, 1, n start rx
*/
/*****************************************************************************************************/
static void uart_config_2(UART_RX_ISR rx, UART_TX_ISR tx)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    uart_reset(2);

    gpio_set_map(GPIO_17, UART2_TXD);
    gpio_set_map(GPIO_16, UART2_RXD);
    gpio_set_dir(GPIO_17, GPIO_DIR_OUT);
    gpio_set_dir(GPIO_16, GPIO_DIR_IN);

    irq_release(UART2_IRQn);
    irq_request(UART2_IRQn, PRI_UART2 ,uart_2_isr);
    
    uart_rx_isr[2] = rx;
    uart_tx_isr[2] = tx;


    uart_cmd(UART2, DISABLE);
    uart_config(CHN_38_3, UART_BAUD_115200, UART_DataMode_8);

    UART2->CON1.IDM    = UART_IDM_Idle_3;
    UART2->CON0.IDEN   = 1;
    UART2->IE.RBIE     = 1;    /* enable RB&ID */
    UART2->IE.IDIE     = 1;

    NVIC_InitStructure.NVIC_IRQChannel = UART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    uart_cmd(UART2, ENABLE);
}

/*****************************************************************************************************/
/*
    Function    : uart_config_3
    Description : config uart3 as B
    Input       : rx - user rx isr
                  tx - user tx isr
    Output      : none
    Return      : none
    Notes       : 115200, 8, 1, n start rx
*/
/*****************************************************************************************************/
static void uart_config_3(UART_RX_ISR rx, UART_TX_ISR tx)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    uart_reset(3);

    gpio_set_map(GPIO_19, UART3_TXD);
    gpio_set_map(GPIO_18, UART3_RXD);
    gpio_set_dir(GPIO_19, GPIO_DIR_OUT);
    gpio_set_dir(GPIO_18, GPIO_DIR_IN);

    irq_release(UART3_IRQn);
    irq_request(UART3_IRQn, PRI_UART3, uart_3_isr);
    
    uart_rx_isr[3] = rx;
    uart_tx_isr[3] = tx;


    uart_cmd(UART3, DISABLE);
    uart_config(CHN_38_2, UART_BAUD_115200, UART_DataMode_8);

    UART3->CON1.IDM    = UART_IDM_Idle_3;
    UART3->CON0.IDEN   = 1;
    UART3->IE.RBIE     = 1;    /* enable RB&ID */
    UART3->IE.IDIE     = 1;

    NVIC_InitStructure.NVIC_IRQChannel = UART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    uart_cmd(UART3, ENABLE);
}

/*****************************************************************************************************/
/*
    Function    : uart_config
    Description : config uartx parameter
    Input       : chn  - uart chan idx [0,3]
                  baud - baud rate
                  mod  - data mod-> UART_TYPE_DATAMOD
    Output      : 0  - config success
                  -1 - config failed
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
int uart_config(unsigned int chn, UART_BAUD baud, UART_TYPE_DATAMOD mod)
{
    UART_TypeDef *UARTx = (UART_TypeDef * )(_UARTx(chn));
    unsigned char dmod = (unsigned char)(mod & 0x0F);
    UART_InitStruType config;

    if ((chn > UART_MAX_INX) || (INVAL_DMODE_CHK(dmod)))
    {
        return -1;
    }

    config.UART_BaudRate   = baud;
    config.UART_ClockSet   = UART_Clock_1;
    config.UART_RxMode     = mod;
    config.UART_TxMode     = mod;
    config.UART_RxPolar    = UART_Polar_Normal;
    config.UART_TxPolar    = UART_Polar_Normal;
    config.UART_StopBits   = UART_StopBits_1;

    uart_config_ctrl(UARTx, &config);

    return 0;
}

/*****************************************************************************************************/
/*
    Function    : uart_put_char
    Description : send 1-Byte data
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void uart_put_char(UART_TypeDef *UARTx, char c)
{
    __OS_ENTER_CRITICAL();
    UART_SendData(UARTx, (unsigned char)c);
    while (UART_GetIF(UARTx, UART_FLAG_TB) == RESET);
    while(UART_GetITStatus(UARTx, UART_STA_TXBUSY) != RESET)
    __OS_EXIT_CRITICAL();
}

/*****************************************************************************************************/
/*
    Function    : uart_send_data
    Description : uart send data
    Input       : chn  - uart chn idx
                  data - data need to be send
                  len  - data len
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void uart_send_data(unsigned char chn, unsigned char *data, unsigned int len)
{
    UART_TypeDef *UARTx = (UART_TypeDef * )(_UARTx(chn));
    unsigned int i = 0;
    for (i = 0; i < len; i++)
    {
        uart_put_char(UARTx, data[i]);
    }
}

/*****************************************************************************************************/
/*
    Function    : uart_ITsend_start
    Description : uart send data IT enable
    Input       : chn  - uart chn idx
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void uart_ITsend_start(unsigned int chn)
{
    UART_TypeDef *UARTx = (UART_TypeDef * )(_UARTx(chn));

   // UARTx->IE.TBIE = 0;    /* ������ͻ����� */
   // UARTx->IE.TCIE = 0;    /* ������ͻ����� */

    //UARTx->CON0.TBCLR = 1;
 
    UARTx->IE.TBIE    = 1;
}

/*****************************************************************************************************/
/*
    Function    : uart_ITsend_stop
    Description : uart send data IT disable
    Input       : chn  - uart chn idx
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void uart_ITsend_stop(unsigned int chn)
{
    UART_TypeDef *UARTx = (UART_TypeDef * )(_UARTx(chn));

    UARTx->IE.TBIE = 0;    /* ������ͻ����� */

    UARTx->CON0.TBCLR = 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void  uart_0_isr(void)
{
    char c;
    unsigned int num = 0, ret = 0;

    __OS_ENTER_CRITICAL();
    if (UART_GetIF(UART0, UART_FLAG_RB) != RESET)
    {
        num = UAER_GetRXCnt(UART0);
        while (num > 0)
        {
            c = UART_ReceiveData(UART0);
            if (uart_rx_isr[0] != NULL)
            {
                uart_rx_isr[0](0, &c, 0x01);
            }
            --num;
        }
    }
    if (UART_GetIF(UART0, UART_FLAG_TB) != RESET)
    {
        //while(UART_GetITStatus(UART0, UART_STA_TXBUSY) != RESET);
        //UART0->IE.TBIE    = 0;
        while (UAER_GetTXCnt(UART0) < 8)
        {
            if (uart_tx_isr[0] != NULL)
            {
                ret = uart_tx_isr[0](0, &c, 0x01);
            }
            if (ret > 0)
            {
                UART_SendData(UART0, c);
            }
            else
            {
               UART0->IE.TBIE  = 0;
               break;
            }

//            num += ret;
        }
//        if (num > 0)
//        {
//            UART0->IE.TBIE    = 1;
//        }        
    }
    __OS_EXIT_CRITICAL();

}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void  uart_1_isr(void)
{
char c;
    unsigned int num = 0, ret = 0;

    __OS_ENTER_CRITICAL();
    if (UART_GetIF(UART1, UART_FLAG_RB) != RESET)
    {
        num = UAER_GetRXCnt(UART1);
        while (num > 0)
        {
            c = UART_ReceiveData(UART1);
            if (uart_rx_isr[1] != NULL)
            {
                uart_rx_isr[1](1, &c, 0x01);
            }
            --num;
        }
    }
    if (UART_GetIF(UART1, UART_FLAG_TB) != RESET)
    {
        //while(UART_GetITStatus(UART1, UART_STA_TXBUSY) != RESET);
        //UART1->IE.TBIE    = 0;
        while (UAER_GetTXCnt(UART1) < 8)
        {
            if (uart_tx_isr[1] != NULL)
            {
                ret = uart_tx_isr[1](1, &c, 0x01);
            }
            if (ret > 0)
            {
                UART_SendData(UART1, c);
            }
            else
            {
               UART1->IE.TBIE  = 0;
               break;
            }

//            num += ret;
        }
//        if (num > 0)
//        {
//            UART1->IE.TBIE    = 1;
//        }        
    }
    __OS_EXIT_CRITICAL();

}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void  uart_2_isr(void)
{
    char c;
    unsigned int num = 0, ret = 0;

    __OS_ENTER_CRITICAL();
    if (UART_GetIF(UART2, UART_FLAG_RB) != RESET)
    {
        num = UAER_GetRXCnt(UART2);
        while (num > 0)
        {
            c = UART_ReceiveData(UART2);
            if (uart_rx_isr[2] != NULL)
            {
                uart_rx_isr[2](2, &c, 0x01);
            }
            --num;
        }
    }
    if (UART_GetIF(UART2, UART_FLAG_TB) != RESET)
    {
        //while(UART_GetITStatus(UART2, UART_STA_TXBUSY) != RESET);
        //UART2->IE.TBIE    = 2;
        while (UAER_GetTXCnt(UART2) < 8)
        {
            if (uart_tx_isr[2] != NULL)
            {
                ret = uart_tx_isr[2](2, &c, 0x01);
            }
            if (ret > 0)
            {
                UART_SendData(UART2, c);
            }
            else
            {
               UART2->IE.TBIE  = 0;
               break;
            }

//            num += ret;
        }
//        if (num > 0)
//        {
//            UART2->IE.TBIE    = 1;
//        }        
    }
    __OS_EXIT_CRITICAL();

}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void  uart_3_isr(void)
{
char c;
    unsigned int num = 0, ret = 0;

    __OS_ENTER_CRITICAL();
    if (UART_GetIF(UART3, UART_FLAG_RB) != RESET)
    {
        num = UAER_GetRXCnt(UART3);
        while (num > 0)
        {
            c = UART_ReceiveData(UART3);
            if (uart_rx_isr[3] != NULL)
            {
                uart_rx_isr[3](3, &c, 0x01);
            }
            --num;
        }
    }
    if (UART_GetIF(UART3, UART_FLAG_TB) != RESET)
    {
        //while(UART_GetITStatus(UART3, UART_STA_TXBUSY) != RESET);
        //UART3->IE.TBIE    = 0;
        while (UAER_GetTXCnt(UART3) < 8)
        {
            if (uart_tx_isr[3] != NULL)
            {
                ret = uart_tx_isr[3](3, &c, 0x01);
            }
            if (ret > 0)
            {
                UART_SendData(UART3, c);
            }
            else
            {
               UART3->IE.TBIE  = 0;
               break;
            }

//            num += ret;
        }
//        if (num > 0)
//        {
//            UART3->IE.TBIE    = 1;
//        }        
    }
    __OS_EXIT_CRITICAL();

}

/*****************************************************************************************************/
/*
    Function    : inbyte
    Description : uart1 read a char
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
char inbyte(void)
{
#if 0
    while (UART_GetITStatus(UART1, UART_STA_RXBUSY) != RESET);

    if (UAER_GetRXCnt(UART1) == 0)
    {
        return 128;
    }

    return (char)UART_ReceiveData(UART1);
#else
    return simuart_getchar();
#endif
}

/*****************************************************************************************************/
/*
    Function    : inbyte_wait
    Description : uart1 read a char for delay
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static unsigned int wait_tmout = 0;
char inbyte_wait(void)
{
#if 0
    wait_tmout = 0;
    while (UART_GetITStatus(UART1, UART_STA_RXBUSY) != RESET);

    while (UAER_GetRXCnt(UART1) == 0)
    {
        if (wait_tmout++ > 1000)        /* timeout  defend */
        {
            return 128;
        }
    }

    return (char)UART_ReceiveData(UART1);
#else
  return simuart_getchar();
#endif
}

/*****************************************************************************************************/
/*
    Function    : uart_putc
    Description : uart1 output char
    Input       : 
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void uart_putc(char c)
{
#if 0
    //UART_ClearIF(UART1, UART_CLR_TC);
    __OS_ENTER_CRITICAL();
    UART_SendData(UART1, (unsigned char)c);
    __OS_EXIT_CRITICAL();

    //while (UART_GetITStatus(UART1, UART_STA_TXBUSY) != RESET);

    while (UART_GetIF(UART1, UART_FLAG_TB) == RESET);
    while(UART_GetITStatus(UART1, UART_STA_TXBUSY) != RESET);
#else
  simuart_send_char(c);
#endif
}

/*****************************************************************************************************/
/*
    Function    : uart_puts
    Description : uart1 output string
    Input       :
    Output      :
    Return      :
    Notes       : pcOut must end with a '\0'
*/
/*****************************************************************************************************/
void uart_puts(char *pcOut)
{
    while(*pcOut != 0)
    {
        UART_OutLfToCrLf(*pcOut++);
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void UART_OutLfToCrLf(char c)
{
    /*  Do LF to CR-LF conversion here:  */
    if (c == '\n')         /* LF? */
    {
        uart_putc('\r'); /* output CR first */
    }
    uart_putc(c);

    return;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void uart_reset(unsigned char chn)
{
    UART_TypeDef *UARTx = (UART_TypeDef * )(_UARTx(chn));

    uart_cmd(UARTx, DISABLE);
    UART_ClearIF(UARTx, UART_CLR_ALL);
    UARTx->CON0.RBCLR = 1;
    UARTx->CON0.TBCLR = 1;
    uart_cmd(UART0, ENABLE);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void uart_config_ctrl(UART_TypeDef *UARTx, UART_InitStruType *UART_InitStruct)
{
    float div = 0;
    unsigned int clk;


    UARTx->CON1.BCS = UART_InitStruct->UART_ClockSet;

    if ((UART_InitStruct->UART_ClockSet > UART_Clock_4)
        || (UART_InitStruct->UART_ClockSet == UART_Clock_0))
    {
        UART_InitStruct->UART_ClockSet = UART_Clock_4;
    }

    clk = PCLK;
    div = (float)clk / (16.0 * (0x01 << (UART_InitStruct->UART_ClockSet - 1))
                        * UART_InitStruct->UART_BaudRate);


    div = (div < 1.0) ? 1.0 : div;
    UARTx->BRR.Word   = (unsigned int)(div * 16);
    UARTx->CON0.TXFS  = UART_InitStruct->UART_StopBits;
    UARTx->CON0.TXMOD = UART_InitStruct->UART_TxMode;
    UARTx->CON0.TXP   = UART_InitStruct->UART_TxPolar;
    UARTx->CON0.RXMOD = UART_InitStruct->UART_RxMode;
    UARTx->CON0.RXP   = UART_InitStruct->UART_RxPolar;
    UARTx->CON1.RBIM  = UART_TRBIM_Byte;
    UARTx->CON1.TBIM  = UART_TBIM_EMPTY;
    //UARTx->CON1.IDM   = UART_IDM_Idle_1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void uart_cmd(UART_TypeDef *UARTx, FuncState NewState)
{
    if (NewState != DISABLE)
    {
        UARTx->CON0.TXEN = 1;
        UARTx->CON0.RXEN = 1;
    }
    else
    {
        UARTx->CON0.TXEN = 0;
        UARTx->CON0.RXEN = 0;
    }
}

void dm_uart_reinit(int t)  /* ���� */
{
  uart_cmd(UART1, DISABLE);//UARTDisable(UART0_BASE_PTR);
  uart_config(CHN_DM, t, UART_DataMode_8Even);
  //UARTConfigSetExpClk(UART0_BASE_PTR, SYS_CLOCK, t, UART_WLEN_9|UART_PAR_EVEN); 
  
  //UART_IT_Ctrl(CHN_DM,DISABLE,ENABLE);
  uart_cmd(UART1, ENABLE);//UARTEnable(UART0_BASE_PTR); 
}

