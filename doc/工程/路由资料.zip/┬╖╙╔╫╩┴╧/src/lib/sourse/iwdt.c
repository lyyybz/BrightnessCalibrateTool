/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      iwdt.c
Description:    the dma control
Author:         ch
Version:        v1.0
Date:           2017/08/10
History:
*/
/************************************************************************************************/
#include "nvic.h"
#include "scu.h"
#include "irq.h"
#include "iwdt_reg.h"
#include "iwdt.h"

/*****************************************************************************************************/
/*
    Function    : iwdt_init
    Description : init iwdt for hard mod
    Input       : interval - ���Ź�������λʱ�䣬��λs
    Output      :
    Return      :
    Notes       : 1.���оƬ������ʹ��Ӳ�����Ź����ú����������ã���λʱ��Ϊ32s
                  2.���������û�п����Ź���ι������Ϊinterval*2 s��
                  �������ι����оƬ����interval*2s�������λ�ź�
                  3.�������ʱ��Ϊ37h
*/
/*****************************************************************************************************/
void iwdt_init(uint32_t  interval)
{
#ifdef IWDT_ON

    IWDT_UNLOCK();

    IWDT_DIS();

    IWDT->CON.CLKS = IWDT_LRC;

    IWDT_EN();
    IWDT->LOAD.Word = interval * IWDT_CLK;
    IWDT_CLRIF();
    IWDT_RSTEN();
    IWDT_LOCK();
#endif
}

/*****************************************************************************************************/
/*
    Function    : iwdt_watchdog
    Description : wathc dog
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void iwdt_watchdog(void)
{
	static unsigned int last_value = 0xFFFFFFFF;
	unsigned int cur_value = IWDT->VALUE.Word;
	unsigned int load = IWDT->LOAD.Word;
	if (load > 0)
	  {
			if (last_value < cur_value)
				{
					if ((load - cur_value) < 30)
						return;
				}
			else if (last_value > cur_value)
				{
					if ((last_value - cur_value) < 30)
						return;
				}
			else
				return;
    }
	else
		return;
    IWDT_UNLOCK();

    IWDT_CLRIF();
	  if (0 == GET_IWDT_IE())
		  IWDT_IEEN();

    IWDT_LOCK();
		last_value = IWDT->VALUE.Word;
}


void diable_wdog()
{
  IWDT_UNLOCK();
  IWDT_DIS();	
	IWDT_LOCK();
}


