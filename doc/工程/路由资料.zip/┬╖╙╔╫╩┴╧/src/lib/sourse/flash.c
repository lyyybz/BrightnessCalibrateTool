
#include "ssc1667.h"
#include "core_cm3.h"
#include "core_cmFunc.h"
#include "flash.h"
//#include "sys.h"
#include "nvic.h"
#include "scu_reg.h"
#include <string.h>
#define FLASH_OPTING_FLAG  0x55AA

unsigned char first_page_buf[FLASH_PAGE_SIZE];
unsigned char last_page_buf[FLASH_PAGE_SIZE];

unsigned int g_flash_opt = 0x0;

#pragma arm section code = "SRAM_FUN"

unsigned int  _f_get_BASEPRI(void)
{
  register unsigned int __regBasePri         __ASM("basepri");
  return(__regBasePri);
}

void _f_set_BASEPRI(unsigned int basePri)
{
  register unsigned int __regBasePri         __ASM("basepri");
  __regBasePri = (basePri & 0xff);
}


int static _flash_page_erase(unsigned int page_addr, unsigned int rpage_addr, unsigned int flag)
{
  if (page_addr >= FLASH_SIZE)
    return -1;

  if ((HPRI_FLAG != flag) && (page_addr  > F_DATA_END || page_addr < F_DATA_START))
    return -1;

	if ((page_addr | rpage_addr) != 0xFFFFFFFF)
      return -1;
  
	unsigned char iap_clk[] = {0x6, 0x6, 0x5, 0x4}; /* only 150M!!! */

	if (page_addr & FLASH_PAGE_MASK)
	  return -1;
	
  if (0x1 != IAP_PAGE_ERASE(page_addr, iap_clk[SCU->AHBEN.APB1_PRE1]))
	  return -1;
	
	return 0;
}

int static _flash_write(unsigned int dst, unsigned int src, unsigned int len, unsigned int rdst, unsigned int flag)
{
  if (dst >= FLASH_SIZE)
    return -1;

  if ((HPRI_FLAG != flag) && (dst  > F_DATA_END || dst < F_DATA_START))
    return -1;

	if ((dst | rdst) != 0xFFFFFFFF)
      return -1;
    
	unsigned int i, _dst, _src;
	unsigned char iap_clk[] = {0x6, 0x6, 0x5, 0x4}; /* only 150M!!! */
	
  if (0x1 != IAP_BYTE_PROGRAM(dst, src, len, ((BYTE_PROGRAM_ERASE_NO << 31) | iap_clk[SCU->AHBEN.APB1_PRE1])))
	  return -1;
	
	_dst = dst;
	_src = src;
	for (i = 0; i < len; i++, _dst++, _src++)
	  {
		  if ((*((unsigned char *)_dst)) != (*((unsigned char *)_src)))
			  {
// 					printf_s("WRITE ERR: addr = %08X, %02X %02X\n",
// 					  _dst, (*((unsigned char *)_dst)), (*((unsigned char *)_src)));
				  return -1;
			  }
	  }

	return 0;
}

int static _flash_read(unsigned int addr ,unsigned char buf[], unsigned int len)
{
	int i;
	
	if (NULL == buf || len > FLASH_SIZE)
	  return -1;

  for (i = 0; i < len; ++i, addr+=1)
    buf[i] = *(unsigned char*)addr;
	
	return 0;
}

int static _flash_erase(unsigned int addr, unsigned int len, unsigned int raddr, unsigned int flag)
{
	if ((addr | raddr) != 0xFFFFFFFF)
      return -1;

	unsigned int first_start, first_len, last_start, last_len;
	unsigned int i;
	
  if (0 == len || (addr + len) > (FLASH_START_ADDR + FLASH_SIZE))
	  return -1;
	
	first_start = addr & (~((unsigned int)FLASH_PAGE_MASK));
	first_len = addr & ((unsigned int)FLASH_PAGE_MASK);
	if (first_len)
	  flash_read(first_start, first_page_buf, first_len);

	last_start = addr + len;
	last_len = last_start & ((unsigned int)FLASH_PAGE_MASK);
	if (last_len) 
	  {
		  last_len  = FLASH_PAGE_SIZE - last_len;
		  flash_read(last_start, last_page_buf, last_len);

			if (flash_page_erase((last_start & (~FLASH_PAGE_MASK)), (~(last_start & (~FLASH_PAGE_MASK))), flag) != 0)
				{
					//printf_s("ERASE ERROR\n");
					return -1;
				}
	  }

	for (i = first_start; i < (last_start & (~FLASH_PAGE_MASK)); i += FLASH_PAGE_SIZE) 
	  {
			if (flash_page_erase((i & (~FLASH_PAGE_MASK)), (~(i & (~FLASH_PAGE_MASK))), flag) != 0) 
				{
					//printf_s("ERASE ERROR\n");
					return -1;
				}
    }

	if (first_len) 
		flash_write(first_start, first_page_buf, first_len, (~first_start), flag);

	if (last_len)
	  flash_write(last_start, last_page_buf, last_len, (~last_start), flag);
    
	return 0;
}

int _flash_erase_write(unsigned int dst, unsigned char src[], unsigned int len, unsigned int rdst, unsigned int flag)
{
  if ((dst | rdst) != 0xFFFFFFFF)
  return -1;

	unsigned int cnt = 2;
	
	while (cnt--)
	  {
		  if (0 != flash_erase(dst, len, rdst, flag))
	      continue;
	
	    if (0 != flash_write(dst, src, len, rdst, flag))
	      continue;
			
			return 0;
	  }
		
	return -1;
}

/* ��ַ��Ҫ8K���� */
int flash_page_erase(unsigned int page_addr, unsigned rpage_addr, unsigned int flag)
{ 
  if ((page_addr | rpage_addr) != 0xFFFFFFFF)
    return -1;
    
	unsigned int rslt, opt_bk = g_flash_opt;
	//unsigned int primask = __get_PRIMASK(), 
	unsigned int basepri = _f_get_BASEPRI();
	
  //__set_PRIMASK(1);
	_f_set_BASEPRI(0x20); /* �������ȼ���1�ʹ���1�� */
	g_flash_opt = FLASH_OPTING_FLAG;
	
	rslt = _flash_page_erase(page_addr, rpage_addr, flag);
	
	g_flash_opt = opt_bk;
	_f_set_BASEPRI(basepri);
	//__set_PRIMASK(primask);
	
	return rslt;
}

int flash_erase(unsigned int addr, unsigned int len, unsigned int raddr, unsigned int flag)
{ 
  if ((addr | raddr) != 0xFFFFFFFF)
    return -1;
   
	unsigned int rslt, opt_bk = g_flash_opt;
	//unsigned int primask = __get_PRIMASK();
	unsigned int basepri = _f_get_BASEPRI();
	
  //__set_PRIMASK(1);
	_f_set_BASEPRI(0x20);
	g_flash_opt = FLASH_OPTING_FLAG;
	
	rslt = _flash_erase(addr, len, raddr, flag);
	
	g_flash_opt = opt_bk;
	_f_set_BASEPRI(basepri);
	//__set_PRIMASK(primask);
	
	return rslt;
}

int flash_write(unsigned int dst, unsigned char src[], unsigned int len, unsigned int rdst, unsigned int flag)
{
  if ((dst | rdst) != 0xFFFFFFFF)
    return -1;
    
	unsigned int rslt, opt_bk = g_flash_opt;
	//unsigned int primask = __get_PRIMASK();
	unsigned int basepri = _f_get_BASEPRI();
	
  //__set_PRIMASK(1);
	_f_set_BASEPRI(0x20);
	g_flash_opt = FLASH_OPTING_FLAG;
	
	rslt = _flash_write(dst, (unsigned int)src, len, rdst, flag);
	
  g_flash_opt = opt_bk;	
	_f_set_BASEPRI(basepri);
	//__set_PRIMASK(primask);
	
	return rslt;	
}

int flash_read(unsigned int addr, unsigned char buf[], unsigned int len)
{
	unsigned int rslt, opt_bk = g_flash_opt;
	//unsigned int primask = __get_PRIMASK();
	unsigned int basepri = _f_get_BASEPRI();
	
  //__set_PRIMASK(1);
	_f_set_BASEPRI(0x20);
	g_flash_opt = FLASH_OPTING_FLAG;
	
	rslt = _flash_read(addr, buf, len);
	
	g_flash_opt = opt_bk;	
	_f_set_BASEPRI(basepri);
	//__set_PRIMASK(primask);
	
	return rslt;	
}

int flash_erase_write(unsigned int dst, unsigned char src[], unsigned int len, unsigned int rdst, unsigned int flag)
{
  if ((dst | rdst) != 0xFFFFFFFF)
    return -1;
     
	unsigned int rslt, opt_bk = g_flash_opt;
	//unsigned int primask = __get_PRIMASK();
	unsigned int basepri = _f_get_BASEPRI();
	
  //__set_PRIMASK(1);
	_f_set_BASEPRI(0x20);
	g_flash_opt = FLASH_OPTING_FLAG;
	
	rslt = _flash_erase_write(dst, src, len, rdst, flag);

  g_flash_opt = opt_bk;		
	_f_set_BASEPRI(basepri);
	//__set_PRIMASK(primask);
	
	return rslt;		
}

int is_flash_opting()
{
  return (g_flash_opt == FLASH_OPTING_FLAG);
}

void __delay_us(unsigned int time)
{
 time = time * 16;
 while(time)time--;
}

/* LVD��ش��붼��SRAM */
void lvd_irq_handler()
{
	unsigned int i = 0;
	unsigned int primask = __get_PRIMASK();
	
	__set_PRIMASK(1);
	
	SCU_RegUnLock();
	SCU->LVDCON.IF = 0x01;
	SCU_RegLock();
	
	GPIO->DATABCR.Word = (1 << 17);  //RX LED OFF
  GPIO->DATABSR.Word = (1 << 16);  //TX LED OFF
	
	/* �жϵ�ǰ�Ƿ����flash?�������reset */
	if (is_flash_opting())
	  {
			SCU_RegUnLock();
			SCU->PWRC.CHIPRST = 0x01;
			SCU_RegLock();
			
			while(1);
    }
		
  while(1)
	  {
		  if (0x1 == SCU->LVDCON.LVD)
			  {
				  GPIO->DATABCR.Word = (1 << 16);  //RX LED ON
          GPIO->DATABSR.Word = (1 << 17);  //TX LED ON
					
					i++;
					
					if (i >= 30)
						{
							SCU_RegUnLock();
							SCU->PWRC.CHIPRST = 0x01;
							SCU_RegLock();
						}
						
				  __delay_us(10);
			  }
			else
				break;
    }
		
  __set_PRIMASK(primask);	
}

#pragma arm section code

void enable_lvd()
{
	NVIC_InitTypeDef NVIC_InitStructure;
	
  SCU_RegUnLock();
	SCU->LVDCON.IFS = 0x00; /* ������������? */
	SCU->LVDCON.VS = 0xD;
	SCU->LVDCON.IF = 0x01;
	SCU->LVDCON.IE = 0x01;
	SCU->LVDCON.EN = 0x01;
	SCU_RegLock();
	
	NVIC_InitStructure.NVIC_IRQChannel = LVD_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void cpy_vtab_to_sram(unsigned int addr)
{
  memcpy((unsigned char *)addr, (unsigned char *)FLASH_VECTOR_ADDR, 66*4);
	NVIC_SetVectorTable(0x20000000, addr);
}

void flash_protect_init()
{
  unsigned int primask = __get_PRIMASK();
	
	__set_PRIMASK(1);
  cpy_vtab_to_sram(SRAM_VECTOR_ADDR);
	enable_lvd();
	__set_PRIMASK(primask);
}

#if 0
unsigned int rslt;
unsigned int addr;
unsigned char buf[0x2000];
void flash_test()
{
// 	__set_BASEPRI(0x20);
// 	g_flash_opt = 0x55AA;
// 	while(1);
	
#if 0 // ��д����
	memset(buf, 0xA5, sizeof(buf));
	
	for (addr = 0x80000; addr < 0x100000; addr+=0x2000)
	{
		if (0 != flash_page_erase(addr))
		{
			printf_s("\n  flash_page_erase err \n");
			delay_ms(1);
		}
		
		delay_ms(1);
		
		if (0 != flash_write(addr, buf, 0x2000))
		{
			printf_s("\n  flash_write err \n");
			delay_ms(1);
		}
	}
#endif	

#if 0 //һ����д���������
	for (addr = 0x40000; addr < 0x100000; addr+=0x2000)
	  {
			if (0 != flash_page_erase(addr))
			{
				printf_s("\n  flash_page_erase err \n");
				delay_ms(100);
		  }
		}
		
	memset(buf, 0x55, sizeof(buf));
	
	rslt = flash_write(0x80000, (unsigned int)buf, sizeof(buf));
		
	for (addr = 0x40000; addr < 0x100000; addr+=0x2000)
	  {
			if (0 != flash_page_erase(addr))
			{
				printf_s("\n  flash_page_erase err \n");
				delay_ms(100);
		  }
		}
	
	memset(buf, 0xAA, sizeof(buf));
	
  rslt = flash_write(0x80000, (unsigned int)buf, sizeof(buf));
#endif


#if 0 //�Ƕ������	
	for (int i = 0; i < sizeof(buf); i++)
	  buf[i] = i;
	
	for (int i = 0; i < 32; i++)
	{
		for (int j = 0; j < 32; j++)
		{
			flash_page_erase(0x80000);
		  rslt = flash_write(0x80000 + i, (unsigned int)buf, j);
		}
	}
	
	rslt = flash_write(0x80080, (unsigned int)buf, 32);
	rslt = flash_write(0x800A0, (unsigned int)(buf + 1), 32);
	rslt = flash_write(0x800C0, (unsigned int)(buf + 2), 32);
	rslt = flash_write(0x800E0, (unsigned int)(buf + 3), 32);
#endif	
	
#if 0
	
	for (addr = 0x40000; addr < 0x100000; addr+=0x2000)
	  {
			if (0 != flash_page_erase(addr))
			{
				printf_s("\n  flash_page_erase err \n");
				delay_ms(100);
		  }
		}
  memset(buf, 0x55, sizeof(buf));
	
	flash_erase_write(0x80000, (unsigned int)buf, 0x2000 * 5);
	
	flash_erase_write(0x90000, (unsigned int)buf, 0x2000 * 5 - 1);
	
	flash_erase_write(0xA0000, (unsigned int)buf, 0x2000 * 5 + 1);
		
		
	for (addr = 0x40000; addr < 0x100000; addr+=0x2000)
	  {
			if (0 != flash_page_erase(addr))
			{
				printf_s("\n  flash_page_erase err \n");
				delay_ms(100);
		  }
		}
  memset(buf, 0xAA, sizeof(buf));
	
	flash_erase_write(0x80000 - 1, (unsigned int)buf, 0x2000 * 5);
	
	flash_erase_write(0x90000 + 1, (unsigned int)buf, 0x2000 * 5);
		
	flash_erase_write(0xa0000 + 345, (unsigned int)buf, 0x2000 * 5 - 678);
	
#endif
	
}

#endif
