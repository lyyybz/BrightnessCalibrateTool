/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      ssc1667_it.c
Description:    interrupt service subroutine
Author:         ch
Version:        v1.0
Date:           2017/07/26
History:
*/
/************************************************************************************************/
#include "stdio.h"
#include "ssc1667.h"
#include "irq.h"
#include "flash.h"

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/*****************************************************************************************************/
/*
    Function    : 
    Description : call app irq function
    Input       : handle - irq_handle requested by user
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void ASM_IRQ_HANDLE(EXT_IRQ_HANDLE handle)
{
    (handle)();
}

/*****************************************************************************************************/
/*
    Function    : ASM_IRQ_HANDLE
    Description : call app irq function
    Input       : handle - irq_handle requested by user
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
#ifndef DEF_ETOS
void _tx_irq_systick_processing_handle(void)
{
}

void _tx_irq_processing_handle(EXT_IRQ_HANDLE handle)
{
    if (NULL == handle)
    {
        return;
    }
    
    handle();
}

void SVC_Handler(void)
{
}

#else
void _tx_irq_systick_processing_handle(void);
void _tx_irq_processing_handle(EXT_IRQ_HANDLE handle);
#endif

/*****************************************************************************************************/
/*
    Function    : HardFault_Trace
    Description : user for hardfault trace back
    Input       : hard_lr - EXCE_RETURN for get into hardfault
    Output      : none
    Return      : none
    Notes       : HardFault = 3
                  refor to uart1 output
*/
/*****************************************************************************************************/
void HardFault_Trace(unsigned int hard_lr)
{
    char hardstr[300] = {'\0'};
    volatile unsigned int stacked_r0;
    volatile unsigned int stacked_r1;
    volatile unsigned int stacked_r2;
    volatile unsigned int stacked_r3;
    volatile unsigned int stacked_r12;
    volatile unsigned int stacked_lr;
    volatile unsigned int stacked_pc;
    volatile unsigned int stacked_psr;
    uint32_t *hardfault_args;
    int idx = 0;

    if (hard_lr & 0x04)
    {
        hardfault_args = (uint32_t * )__get_PSP();
    }
    else
    {
        hardfault_args = (uint32_t * )__get_MSP();
    }
    //unsigned long cc;
    stacked_r0 = ((unsigned long)hardfault_args[0]);
    stacked_r1 = ((unsigned long)hardfault_args[1]);
    stacked_r2 = ((unsigned long)hardfault_args[2]);
    stacked_r3 = ((unsigned long)hardfault_args[3]);

    stacked_r12 = ((unsigned long)hardfault_args[4]);
    stacked_lr = ((unsigned long)hardfault_args[5]);
    stacked_pc = ((unsigned long)hardfault_args[6]);
    stacked_psr = ((unsigned long)hardfault_args[7]);

    idx += sprintf(hardstr + idx, "\r\n%s", "[Hard fault handler]\n");
    idx += sprintf(hardstr + idx, "%s", "lr=");
    idx += sprintf(hardstr + idx, "0x%.8x\n", (uint32_t)hard_lr);
    idx += sprintf(hardstr + idx, "%s", "sp=");
    idx += sprintf(hardstr + idx, "0x%.8x\n", (uint32_t)hardfault_args);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_r0);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_r1);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_r2);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_r3);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_r12);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_lr);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_pc);
    idx += sprintf(hardstr + idx, "0x%.8x\n", stacked_psr);
    idx += sprintf(hardstr + idx, "%s", "BFSR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED28))));
    idx += sprintf(hardstr + idx, "%s", "HFSR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED2C))));
    idx += sprintf(hardstr + idx, "%s", "DFSR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED30))));
    idx += sprintf(hardstr + idx, "%s", "MMAR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED34))));
    idx += sprintf(hardstr + idx, "%s", "BFAR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED38))));
    idx += sprintf(hardstr + idx, "%s", "AFSR = ");
    idx += sprintf(hardstr + idx, "0x%8x\n", (*((volatile unsigned int *)(0xE000ED3C))));
    /* Go to infinite loop when Hard Fault exception occurs */
    hardstr[idx++] = '\0';

    while (1)
    {
     print_s(hardstr);
        mdelay(1500);
			  hard_reset();
    }

}

/*****************************************************************************************************/
/*
    Function    : NMI_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       : NonMaskableInt_IRQn = -14->2
*/
/*****************************************************************************************************/
void NMI_Handler(void)
{
}

/*****************************************************************************************************/
/*
    Function    : MemManage_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       : MemoryManagement_IRQn = -12->4
*/
/*****************************************************************************************************/
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/*****************************************************************************************************/
/*
    Function    : BusFault_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :  BusFault_IRQn = -11->5
*/
/*****************************************************************************************************/
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}

/*****************************************************************************************************/
/*
    Function    : UsageFault_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       : UsageFault_IRQn = -10->6
*/
/*****************************************************************************************************/
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/*****************************************************************************************************/
/*
    Function    : DebugMon_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       : DebugMonitor_IRQn = -4->12
*/
/*****************************************************************************************************/
void DebugMon_Handler(void)
{
}

/*****************************************************************************************************/
/*
    Function    : SysTick_Handler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       : SysTick_IRQn = -1->15
*/
/*****************************************************************************************************/
#if 0
void SysTick_Handler(void)
{
    _tx_irq_systick_processing_handle();
}
#endif
/*****************************************************************************************************/
/*
    Function    : GPIO0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO0_IRQn = 0->16
*/
/*****************************************************************************************************/
void GPIO0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO1_IRQn = 1->17
*/
/*****************************************************************************************************/
void GPIO1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO2_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO2_IRQn = 2->18
*/
/*****************************************************************************************************/
void GPIO2_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO2_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO3_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO3_IRQn = 3->19
*/
/*****************************************************************************************************/
void GPIO3_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO3_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO4_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO4_IRQn = 4->20
*/
/*****************************************************************************************************/
void GPIO4_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO4_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO5_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO5_IRQn = 5->21
*/
/*****************************************************************************************************/
void GPIO5_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO5_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO6_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO6_IRQn = 6->22
*/
/*****************************************************************************************************/
void GPIO6_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO6_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : GPIO7_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   GPIO7_IRQn = 7->23
*/
/*****************************************************************************************************/
void GPIO7_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[GPIO7_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T16N0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T16N0_IRQn = 8->24
*/
/*****************************************************************************************************/
void T16N0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T16N0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T16N1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T16N1_IRQn = 9->25
*/
/*****************************************************************************************************/
void T16N1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T16N1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T16N2_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T16N2_IRQn = 10->26
*/
/*****************************************************************************************************/
void T16N2_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T16N2_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T16N3_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T16N3_IRQn = 11->27
*/
/*****************************************************************************************************/
void T16N3_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T16N3_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T32N0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T32N0_IRQn = 12->28
*/
/*****************************************************************************************************/
void T32N0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T32N0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T32N1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T32N1_IRQn = 13->29
*/
/*****************************************************************************************************/
void T32N1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T32N1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T32N2_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T32N2_IRQn = 14->30
*/
/*****************************************************************************************************/
void T32N2_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T32N2_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : T32N3_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   T32N3_IRQn = 15->31
*/
/*****************************************************************************************************/
void T32N3_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[T32N3_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : IWDT_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   IWDT_IRQn = 16->32
*/
/*****************************************************************************************************/
void IWDT_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[IWDT_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : WWDT_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   WWDT_IRQn = 17->33
*/
/*****************************************************************************************************/
void WWDT_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[WWDT_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : SPI2_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   SPI2_IRQn = 18->34
*/
/*****************************************************************************************************/
void SPI2_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[SPI2_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : SPI3_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   SPI3_IRQn = 19->35
*/
/*****************************************************************************************************/
void SPI3_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[SPI3_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : UART0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   UART0_IRQn = 20->36
*/
/*****************************************************************************************************/
void UART0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[UART0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : UART1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   UART1_IRQn = 21->37
*/
/*****************************************************************************************************/
void UART1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[UART1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : UART2_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   UART2_IRQn = 22->38
*/
/*****************************************************************************************************/
void UART2_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[UART2_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : UART3_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   UART3_IRQn = 23->39
*/
/*****************************************************************************************************/
void UART3_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[UART3_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : SPI0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   SPI0_IRQn = 24->40
*/
/*****************************************************************************************************/
void SPI0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[SPI0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : SPI1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   SPI1_IRQn = 25->41
*/
/*****************************************************************************************************/
void SPI1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[SPI1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : I2C0_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   I2C0_IRQn = 26->42
*/
/*****************************************************************************************************/
void I2C0_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[I2C0_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : I2C1_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   I2C1_IRQn = 27->43
*/
/*****************************************************************************************************/
void I2C1_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[I2C1_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : AES_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   AES_IRQn = 28->44
*/
/*****************************************************************************************************/
void AES_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[AES_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : ADC_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   ADC_IRQn = 29->45
*/
/*****************************************************************************************************/
void ADC_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[ADC_IRQn].ext_irq);
}


/*****************************************************************************************************/
/*
    Function    : Tsensor_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   Tsensor_IRQn = 30->46
*/
/*****************************************************************************************************/
void Tsensor_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[Tsensor_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : KINT_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   KINT_IRQn = 31->47;����оƬ��֧��
*/
/*****************************************************************************************************/
void KINT_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[KINT_IRQn].ext_irq);
}


/*****************************************************************************************************/
/*
    Function    : PLCRX_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   PLCRX_IRQn = 32->48
*/
/*****************************************************************************************************/
#if 0
void PLCRX_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[PLCRX_IRQn].ext_irq);
}
#endif
/*****************************************************************************************************/
/*
    Function    : PLCTX_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   PLCTX_IRQn = 33->49
*/
/*****************************************************************************************************/
#if 0
void PLCTX_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[PLCTX_IRQn].ext_irq);
}
#endif
/*****************************************************************************************************/
/*
    Function    : PLCTIMERINT_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   PLCTIMERINT_IRQn = 34->50
*/
/*****************************************************************************************************/
#if 0
void PLCTIMERINT_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[PLCTIMERINT_IRQn].ext_irq);
}
#endif
/*****************************************************************************************************/
/*
    Function    : DMADONE_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   DMADONE_IRQn= 36->52
*/
/*****************************************************************************************************/
void DMADONE_IRQHandler(void)
{
//    _tx_irq_processing_handle(ext_irq[DMADONE_IRQn].ext_irq);
#if 1
    if (SCU->DMADONE.CH9_DONE)
        {
            SCU->DMADONE.CH9_DONE = 1; /* ��0*/
//            plc_tx_dma_done();
        }

    if (SCU->DMADONE.CH10_DONE)
        {
            SCU->DMADONE.CH10_DONE = 1; /* ��0*/
//            plc_rx_dma_done();
        }

#if 0
    if (BPLC->CTRL0.RXE == 1) // �ȶԸ�һ�£��������зֿ���
    plc_rx_dma_done();

    if (BPLC->CTRL0.TXE == 1)
    plc_tx_dma_done();

    if (DMA->DONESET.plc_rx)
        {
            while ( 1 )
                {

                }
        }
    if (DMA->DONESET.plc_tx)
        {
            while ( 1 )
                {

                }
        }
#endif

#endif
}

/*****************************************************************************************************/
/*
    Function    : DMAERR_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   DMAERR_IRQn= 37->53
*/
/*****************************************************************************************************/
void DMAERR_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[DMAERR_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : ECC_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   ECC_IRQn = 38->54
*/
/*****************************************************************************************************/
void ECC_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[ECC_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : TRNG_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   TRNG_IRQn = 39->55
*/
/*****************************************************************************************************/
void TRNG_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[TRNG_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : Cache_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   Cache_IRQn = 40->56
*/
/*****************************************************************************************************/
void Cache_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[Cache_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : USB_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   USB_IRQn = 41->57 ��֧��
*/
/*****************************************************************************************************/
void USB_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[USB_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : USB_BWERR_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   USB_BWERR_IRQn = 42->58
*/
/*****************************************************************************************************/
void USB_BWERR_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[USB_BWERR_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : ETHERNETINT_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   ETHERNETINT_IRQn = 43->59
*/
/*****************************************************************************************************/
void ETHERNETINT_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[ETHERNETINT_IRQn].ext_irq);
}

/*****************************************************************************************************/
/*
    Function    : LVD_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   LVD_IRQn = 44->60
*/
/*****************************************************************************************************/
void __attribute__((section("SRAM_FUN")))LVD_IRQHandler(void)
{  
	lvd_irq_handler();
}

/*****************************************************************************************************/
/*
    Function    : COMP_IRQHandler
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :   COMP_IRQn = 45->61
*/
/*****************************************************************************************************/
void COMP_IRQHandler(void)
{
    _tx_irq_processing_handle(ext_irq[COMP_IRQn].ext_irq);
}

