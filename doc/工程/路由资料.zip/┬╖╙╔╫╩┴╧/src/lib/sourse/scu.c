/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      scu.c
Description:    the scu control
Author:         ch
Version:        v1.0
Date:           2017/07/28
History:
*/
/************************************************************************************************/

#include "scu_reg.h"
#include "scu.h"

static void scu_set_dpll(void);

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/

void scu_clk_en(unsigned int periph)
{
  APB1PERI_CLK_EN(periph);
}

void scu_init(void)
{
    //scu_set_hrc();
    scu_set_dpll();

    //scu_enabl_alldev();
    AHBPERI_CLK_EN(SCU_APB1);
    AHBPERI_CLK_EN(SCU_APB2);

    APB1PERI_CLK_EN(SCU_GPIO);
#if 0  /* ��clock_init�����ж�Ӧ��ʼ�� */
    APB1PERI_CLK_EN(SCU_UART0);
    APB1PERI_CLK_EN(SCU_UART1);
    APB1PERI_CLK_EN(SCU_UART2);
    APB1PERI_CLK_EN(SCU_UART3);
#endif
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_set_dpll(void)
{
    SCU_RegUnLock();

    SCU->SCLKEN0.MOSC_EN     = 1;      //���˯��ʱ���رվ����·��Ƶ��·
    SCU->SCLKEN0.CLKFLT_EN   = 1;      //���˯��ʱ���رվ����˲�

    //XTAL CONFIG
    SCU->SCLKEN0.XO_BUF_EN = 1;
    SCU->SCLKEN0.XO_EN = 1;

    SCU->SCLKEN1.OSCCLK_SEL = 1;   //select xtal as DPLL2 input clock

    //DPLL2 CONFIG
    SCU->DPLL2CON0.PREDIV = 5;
    SCU->DPLL2CON0.OFFSET_EN = 0;
    SCU->DPLL2CON0.DNOFFSET = 3;
    SCU->DPLL2CON0.UPOFFSET = 3;

    //SCU->DPLL2CON0.CPI = 6;
    //SCU->DPLL2CON0.CPI = 12;
    //SCU->DPLL2CON0.CPI = 24;
    SCU->DPLL2CON0.CPI = 36;

    SCU->DPLL2CON0.LPFRES = 4;

    SCU->DPLL2CON1.NDIV = 0x90;
    SCU->DPLL2CON1.POSTDIV_ADC = 3;

    SCU->SCLKEN1.DPLL2_EN = 1;
    SCU->SCLKEN1.DPLL2_LDTEN = 1;
    while (SCU->DPLL2CON0.LOCKED == 0)
    {
    }

    //select DPLL used as system clock
    SCU->SCLKEN1.DPLL2CLK_SEL = 1; //select DPLL2_150M to Mcu
    SCU->SCLKEN1.DPLL_OSC_SEL = 1; //select DPLL2 as system clock

    SCU->APB2EN.CLKEN_150M = 1; //Modem clk150m enable
    SCU->APB2EN.CLKEN_BPLC = 1;
	
	SCU->SCLKEN0.XO_LP_SEL = 1; /* XOSC����ģʽѡ��͹��� */
    SCU->AHBEN.APB1_PRE1 = SCU_AHBEN_ABP1_PRE1_HCLK_2_1; /* APB1ʱ��ΪCPU��Ƶ�Ķ���Ƶ����75M */

    SCU_RegLock();
}

#if 0
/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_set_hrc(void)
{
    SCU_RegUnLock();
    SCU->SCLKEN0.MOSC_EN     = 1;      //���˯��ʱ���رվ����·��Ƶ��·
    SCU->SCLKEN0.CLKFLT_EN   = 1;      //���˯��ʱ���رվ����˲�

    //XTAL CONFIG
    SCU->SCLKEN0.XO_BUF_EN   = 1;
    SCU->SCLKEN0.XO_EN       = 1;

    SCU->SCLKEN1.OSCCLK_SEL   = 0;   //select HRC as DPLL2 input clock
    SCU->SCLKEN1.DPLL_OSC_SEL = 0; //select xtal/hrc as system clock

    SCU_RegLock();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_set_xtal(void)
{
    SCU_RegUnLock();
    SCU->SCLKEN0.MOSC_EN     = 1;      //���˯��ʱ���رվ����·��Ƶ��·
    SCU->SCLKEN0.CLKFLT_EN   = 1;      //���˯��ʱ���رվ����˲�

    //XTAL CONFIG
    SCU->SCLKEN0.XO_BUF_EN = 1;
    SCU->SCLKEN0.XO_EN = 1;

    SCU->SCLKEN1.OSCCLK_SEL = 1;   //select xtal as DPLL2 input clock
    SCU->SCLKEN1.DPLL_OSC_SEL = 0; //select xtal/hrc as system clock

    SCU_RegLock();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_set_dpll2(void)
{
    SCU_RegUnLock();
    SCU->SCLKEN0.HRC_EN = 1;
    SCU->SCLKEN1.OSCCLK_SEL = 1;
    SCU->SCLKEN0.HRC_EN = 0;
    SCU->SCLKEN1.DPLL2_EN = 1;
    SCU->SCLKEN1.DPLL2_LDTEN = 1;
    SCU->SCLKEN1.DPLL_OSC_SEL = 1;
    SCU_RegLock();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static uint8_t scu_get_sysclk(void)
{
    uint32_t clk_tmp;

    SCU_RegUnLock();
    if (SCU->SCLKEN1.SYSCLK_SEL != 0)
    {
        clk_tmp = SCU_SYSCLK_LRC;
    }
    else if (SCU->SCLKEN1.DPLL_OSC_SEL != 1)
    {
        if ((SCU->SCLKEN1.OSCCLK_SEL = 0) & (SCU->SCLKEN0.HRC_EN = 1))
        {
            clk_tmp = SCU_SYSCLK_HRC;
        }
        else if ((SCU->SCLKEN1.OSCCLK_SEL = 1) & (SCU->SCLKEN0.XO_EN = 1))
        {
            clk_tmp = SCU_SYSCLK_XTAL;
        }
        else
        {
            clk_tmp = WRONG_SET;
        }
    }
    else if (SCU->SCLKEN1.DPLL_OSC_SEL == 1)
    {
        clk_tmp = SCU_SYSCLK_DPLL2;
    }
    SCU_RegLock();

    return (clk_tmp);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_enabl_alldev(void)
{
  SCU_RegUnLock();
  SCU->AHBEN.CLKEN_APB1 = 1;
  SCU->AHBEN.CLKEN_APB2 = 1;
  SCU->AHBEN.CLKEN_DMA = 1;
  SCU->AHBEN.CLKEN_SRAM = 1;
  SCU->AHBEN.CLKEN_USB = 1;
  SCU->AHBEN.APB1_PRE1 = SCU_AHBEN_ABP1_PRE1_HCLK_2_1;/* 150m 2  75m*/
  SCU->APB1EN.Word = 0XFFFFFFFF;
  SCU->APB2EN.Word = 0XFFFFFFFF;
  SCU_RegLock();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void scu_dis_alldev(void)
{
    SCU_RegUnLock();
    SCU->AHBEN.CLKEN_APB1  = 0;
    SCU->AHBEN.CLKEN_APB2  = 0;
    SCU->AHBEN.CLKEN_DMA   = 0;
    SCU->AHBEN.CLKEN_SRAM  = 0;
    SCU->AHBEN.CLKEN_USB   = 0;
    SCU->APB1EN.Word       = 0X0;
    SCU->APB2EN.Word       = 0X0;
    SCU_RegLock();
}
#endif
