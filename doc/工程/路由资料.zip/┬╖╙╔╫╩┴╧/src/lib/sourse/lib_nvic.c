/*********************************************************
*Copyright (C), 2016~2020, �ൺ�����ز��Ƽ��ɷ����޹�˾��
*�ļ���:  lib_nvic.c
*��  ��:  ES Application Team
*��  ��:  V1.0
*��  ��:  2017/06/30
*��  ��:  NVICģ��⺯�����塣
*��  ע:  ������SSC1667&68��
**********************************************************/

#include "ssc1667.h"
#include "lib_nvic.h"

void NVIC_SetPriorityGrouping(uint32_t PriorityGroup)
{
  uint32_t reg_value;
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07);               /* only values 0..7 are used          */

  reg_value  =  SCB->AIRCR;                                                   /* read old register configuration    */
  reg_value &= ~(SCB_AIRCR_VECTKEY_Msk | SCB_AIRCR_PRIGROUP_Msk);             /* clear bits to change               */
  reg_value  =  (reg_value                                 |
                ((uint32_t)0x5FA << SCB_AIRCR_VECTKEY_Pos) |
                (PriorityGroupTmp << 8));                                     /* Insert write key and priorty group */
  SCB->AIRCR =  reg_value;
}

uint32_t SysTick_Config(uint32_t ticks)
{
  if (ticks > SysTick_LOAD_RELOAD_Msk)  return (1);            /* Reload value impossible */

  SysTick->LOAD  = (ticks & SysTick_LOAD_RELOAD_Msk) - 1;      /* set reload register */
  NVIC_SetPriority (SysTick_IRQn, (1<<__NVIC_PRIO_BITS) - 1);  /* set Priority for Systick Interrupt */
  SysTick->VAL   = 0;                                          /* Load the SysTick Counter Value */
  SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk |
                   SysTick_CTRL_TICKINT_Msk   |
                   SysTick_CTRL_ENABLE_Msk;                    /* Enable SysTick IRQ and SysTick Timer */
  return (0);                                                  /* Function successful */
}

/** \brief  System Reset

    The function initiates a system reset request to reset the MCU.
 */
 void NVIC_SystemReset(void)
{
  __DSB();                                                     /* Ensure all outstanding memory accesses included
                                                                  buffered write are completed before reset */
  SCB->AIRCR  = ((0x5FA << SCB_AIRCR_VECTKEY_Pos)      |
                 (SCB->AIRCR & SCB_AIRCR_PRIGROUP_Msk) |
                 SCB_AIRCR_SYSRESETREQ_Msk);                   /* Keep priority group unchanged */
  __DSB();                                                     /* Ensure completion of memory access */
  while(1);                                                    /* wait until reset */
}

void NVIC_Init(NVIC_InitTypeDef *NVIC_InitStruct)
{
	uint8_t tmppriority = 0x00, tmppre = 0x00, tmpsub = 0x0F;

	if (NVIC_InitStruct->NVIC_IRQChannelCmd != DISABLE)
		{
			/* Compute the Corresponding IRQ Priority --------------------------------*/
			tmppriority = (0x700 - ((SCB->AIRCR) & (uint32_t)0x700)) >> 0x08;
			tmppre = (0x4 - tmppriority);
			tmpsub = tmpsub >> tmppriority;

			tmppriority = NVIC_InitStruct->NVIC_IRQChannelPreemptionPriority << tmppre;
			tmppriority |=  (uint8_t)(NVIC_InitStruct->NVIC_IRQChannelSubPriority & tmpsub);

			tmppriority = tmppriority << 0x04;

			NVIC->IP[NVIC_InitStruct->NVIC_IRQChannel] = tmppriority;

			/* Enable the Selected IRQ Channels --------------------------------------*/
			NVIC->ISER[NVIC_InitStruct->NVIC_IRQChannel >> 0x05] =
				(uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
		}
	else
		{
			/* Disable the Selected IRQ Channels -------------------------------------*/
			NVIC->ICER[NVIC_InitStruct->NVIC_IRQChannel >> 0x05] =
			 (uint32_t)0x01 << (NVIC_InitStruct->NVIC_IRQChannel & (uint8_t)0x1F);
		}
}

void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset)
{
	SCB->VTOR = NVIC_VectTab | (Offset & (uint32_t)0x1FFFFF80);
}



