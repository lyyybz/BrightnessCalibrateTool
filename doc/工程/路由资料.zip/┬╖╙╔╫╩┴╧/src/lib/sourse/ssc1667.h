/*********************************************************
*Copyright (C), 2016~2020, �ൺ�����ز��Ƽ��ɷ����޹�˾��
*�ļ���:  ssc1667.h
*��  ��:  ES Application Team
*��  ��:  V1.0
*��  ��:  2017/06/30
*��  ��:  ssc1667оƬ�Ĵ������塢����ַ�����ļ���
*��  ע:  ������SSC1667&68��
**********************************************************/


#ifndef __SSC1667_H
#define __SSC1667_H


#define __I volatile const       /* defines 'read only' permissions */
#define __O volatile             /* defines 'write only' permissions */
#define __IO volatile            /* defines 'read / write' permissions */

#define __CM0_REV 0              /* Core Revision r0p0 */
#define __NVIC_PRIO_BITS 3       /* HR8P506 uses 2 Bits for the Priority Levels */
#define __Vendor_SysTickConfig 0 /* Set to 1 if different SysTick Config is used */


#define CPU_CORE_CLOCK_MHZ        150

typedef enum IRQn
{
  /****** Cortex-M3 Processor Exceptions Numbers ******************************************************/
  RST_IRQn = -15,
  NonMaskableInt_IRQn = -14,
  HardFault_IRQn = -13,
  MemoryManagement_IRQn = -12,
  BusFault_IRQn = -11,
  UsageFault_IRQn = -10,
  SVC_IRQn = -5,
  PendSV_IRQn = -2,
  SysTick_IRQn = -1,

  GPIO0_IRQn                 = 0,
  GPIO1_IRQn                 = 1,
  GPIO2_IRQn                 = 2,
  GPIO3_IRQn                 = 3,
  GPIO4_IRQn                 = 4,
  GPIO5_IRQn                 = 5,
  GPIO6_IRQn                 = 6,
  GPIO7_IRQn                 = 7,
  T16N0_IRQn                 = 8,
  T16N1_IRQn                 = 9,
  T16N2_IRQn                 = 10,
  T16N3_IRQn                 = 11,
  T32N0_IRQn                 = 12,
  T32N1_IRQn                 = 13,
  T32N2_IRQn                 = 14,
  T32N3_IRQn                 = 15,
  IWDT_IRQn                  = 16,
  WWDT_IRQn                  = 17,
  SPI2_IRQn                  = 18,
  SPI3_IRQn                  = 19,
  UART0_IRQn                 = 20,
  UART1_IRQn                 = 21,
  UART2_IRQn                 = 22,
  UART3_IRQn                 = 23,
  SPI0_IRQn                  = 24,
  SPI1_IRQn                  = 25,
  I2C0_IRQn                  = 26,
  I2C1_IRQn                  = 27,
  AES_IRQn                   = 28,
  ADC_IRQn                   = 29,
  Tsensor_IRQn               = 30,
  KINT_IRQn                  = 31,
  PLCRX_IRQn                 = 32,
  PLCTX_IRQn                 = 33,
  PLCTIMERINT_IRQn           = 34,
  Reserved1_IRQn             = 35,
  DMADONE_IRQn               = 36,
  DMAERR_IRQn                = 37,
  ECC_IRQn                   = 38,
  TRNG_IRQn                  = 39,
  Cache_IRQn                 = 40,
  USB_IRQn                   = 41,
  USB_BWERR_IRQn             = 42,
  ETHERNETINT_IRQn           = 43,
  LVD_IRQn                   = 44,
  COMP_IRQn                  = 45,

  IRQn_DEF
} IRQn_Type;


#include <stdint.h>
#include <type.h>
#include "core_cm3.h"


////////////////////////////////////*�豸����Ĵ����ṹ����*////////////////////////
#pragma anon_unions /* ���������ṹ���������� */

/******************************************************************************/
/************************************* SCU ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t PROT: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} SCU_PROT_Typedef;

typedef union
{
  struct
  {
    uint32_t NMICS: 8;
    uint32_t EN: 1;
    uint32_t RESERVED0: 23;
  };
  uint32_t Word;
} SCU_NMICON_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 1;
    uint32_t CHIPRSTF: 1;
    uint32_t PORF_3: 1;
    uint32_t RC_PORF: 1;
    uint32_t BORF: 1;
    uint32_t IWDTRSTF: 1;
    uint32_t MRSTF: 1;
    uint32_t SOFT_RSTF: 1;
    uint32_t POR_LOST: 1;
    uint32_t LOCKUP_RSTF: 1;
    uint32_t WWDT_RSTF: 1;
    uint32_t RESERVED1: 5;
    uint32_t LOCKUPRST: 1;
    uint32_t CHIPRST: 1;
    uint32_t RESERVED2: 14;
  };
  uint32_t Word;
} SCU_PWRC_Typedef;

typedef union
{
  struct
  {
    uint32_t ACCT: 4;
    uint32_t RESERVED0: 12;
    uint32_t SE_WIDTH: 2;
    uint32_t RESERVED1: 14;
  };
  uint32_t Word;
} SCU_FLASHWAIT_Typedef;

typedef union
{
  struct
  {
    uint32_t FT_FLAG0: 1;
    uint32_t FT_FLAG1: 1;
    uint32_t FT_FLAG2: 1;
    uint32_t RESERVED0: 29;
  };
  uint32_t Word;
} SCU_FAULTFLAG_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t FLT: 1;
    uint32_t RESERVED0: 2;
    uint32_t VS: 4;
    uint32_t IF: 1;
    uint32_t IE: 1;
    uint32_t IFS: 3;
    uint32_t RESERVED1: 2;
    uint32_t LVD: 1;
    uint32_t RESERVED2: 16;
  };
  uint32_t Word;
} SCU_LVDCON_Typedef;

typedef union
{
  struct
  {
    uint32_t TBLREMAPEN: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} SCU_TBLREMAPEN_Typedef;

typedef union
{
  struct
  {
    uint32_t BTFREMAP: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} SCU_BFREGION_Typedef;

typedef union
{
  struct
  {
    uint32_t T16N0EN: 1;
    uint32_t T16N1EN: 1;
    uint32_t T16N2EN: 1;
    uint32_t RESERVED0: 5;
    uint32_t T32N0EN: 1;
    uint32_t T32N1EN: 1;
    uint32_t T32N2EN: 1;
    uint32_t T32N3EN: 1;
    uint32_t RESERVED1: 20;
  };
  uint32_t Word;
} SCU_TIMEREN_Typedef;

typedef union
{
  struct
  {
    uint32_t T16N0DIS: 1;
    uint32_t T16N1DIS: 1;
    uint32_t T16N2DIS: 1;
    uint32_t RESERVED0: 5;
    uint32_t T32N0DIS: 1;
    uint32_t T32N1DIS: 1;
    uint32_t T32N2DIS: 1;
    uint32_t T32N3DIS: 1;
    uint32_t RESERVED1: 20;
  };
  uint32_t Word;
} SCU_TIMERDIS_Typedef;

typedef union
{
  struct
  {
    uint32_t WAKEUPTIME: 14;
    uint32_t RESERVED0: 18;
  };
  uint32_t Word;
} SCU_WAKEUPTIME_Typedef;

typedef union
{
  struct
  {
    uint32_t MOSC_EN: 1;
    uint32_t CLKFLT_EN: 1;
    uint32_t MCU_DIV: 2;
    uint32_t HRC_EN: 1;
    uint32_t HRC_SEL_2M: 1;
    uint32_t WDT_LP: 1;
    uint32_t RESERVED0: 1;
    uint32_t XO_LP_SEL: 1;
    uint32_t XO_BUF_EN: 1;
    uint32_t XO_EN: 1;
    uint32_t RESERVED1: 21;
  };
  uint32_t Word;
} SCU_SCLKEN0_Typedef;

typedef union
{
  struct
  {
    uint32_t OSCCLK_SEL: 1;
    uint32_t RESERVED0: 1;
    uint32_t DPLL_OSC_SEL: 1;
    uint32_t RESERVED1: 1;
    uint32_t DPLL2CLK_SEL: 1;
    uint32_t SYSCLK_SEL: 1;
    uint32_t RESERVED2: 12;
    uint32_t DPLL2_EN: 1;
    uint32_t DPLL2_LDTEN: 1;
    uint32_t RESERVED3: 12;
  };
  uint32_t Word;
} SCU_SCLKEN1_Typedef;


typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_SCLKEN2_Typedef;

typedef union
{
  struct
  {
    uint32_t CLKEN_DMA: 1;
    uint32_t CLKEN_USB: 1;
    uint32_t CLKEN_SRAM: 1;
    uint32_t CLKEN_APB1: 1;
    uint32_t CLKEN_APB2: 1;
    uint32_t CLKEN_ETH:  1;
    uint32_t RESERVED0: 10;
    uint32_t APB1_PRE1: 2;
    uint32_t RESERVED1: 2;
    uint32_t APB2_PRE1: 2;
    uint32_t RESERVED2: 10;
  };
  uint32_t Word;
} SCU_AHBEN_Typedef;

typedef union
{
  struct
  {
    uint32_t CLKEN_GPIO: 1;
    uint32_t CLKEN_FLASH: 1;
    uint32_t CLKEN_ADC: 1;
    uint32_t CLKEN_IWDT: 1;
    uint32_t CLKEN_T16N0: 1;
    uint32_t CLKEN_T16N1: 1;
    uint32_t CLKEN_T16N2: 1;
    uint32_t CLKEN_T16N3: 1;
    uint32_t CLKEN_T32N0: 1;
    uint32_t CLKEN_T32N1: 1;
    uint32_t CLKEN_T32N2: 1;
    uint32_t CLKEN_T32N3: 1;
    uint32_t CLKEN_UART0: 1;
    uint32_t CLKEN_UART1: 1;
    uint32_t CLKEN_UART2: 1;
    uint32_t CLKEN_UART3: 1;
    uint32_t CLKEN_SPI0: 1;
    uint32_t CLKEN_SPI1: 1;
    uint32_t CLKEN_I2C0: 1;
    uint32_t CLKEN_I2C1: 1;
    uint32_t CLKEN_TENSOR: 1;
    uint32_t RESERVED0: 2;
    uint32_t CLKEN_ECC: 1;
    uint32_t CLKEN_CRC: 1;
    uint32_t CLKEN_WWDT: 1;
    uint32_t CLKEN_OPAMP: 1;
    uint32_t CLKEN_COMP: 1;
    uint32_t RESERVED1: 1;
    uint32_t CLKEN_RNG: 1;
    uint32_t CLKEN_SPI2: 1;
    uint32_t CLKEN_SPI3: 1;
  };
  uint32_t Word;
} SCU_APB1EN_Typedef;

typedef union
{
  struct
  {
    uint32_t CLKEN_AES: 1;
    uint32_t CLKEN_BPLC: 1;
    uint32_t CLKEN_150M: 1;
    uint32_t CLKEN_TIMER: 1;
    uint32_t RESERVED0: 28;
  };
  uint32_t Word;
} SCU_APB2EN_Typedef;

typedef union
{
  struct
  {
    uint32_t TPIU_CLK_SEL: 1;
    uint32_t RESERVED0: 15;
    uint32_t BGR0_EN: 1;
    uint32_t BGR0_BUF_EN: 1;
    uint32_t BGR1_EN: 1;
    uint32_t BGR1_BUF_EN: 1;
    uint32_t RESERVED1: 12;
  };
  uint32_t Word;
} SCU_MCUCTR_Typedef;

typedef union
{
  struct
  {
    uint32_t CH0_DONE: 1;
    uint32_t CH1_DONE: 1;
    uint32_t CH2_DONE: 1;
    uint32_t CH3_DONE: 1;
    uint32_t CH4_DONE: 1;
    uint32_t CH5_DONE: 1;
    uint32_t CH6_DONE: 1;
    uint32_t CH7_DONE: 1;
    uint32_t CH8_DONE: 1;
    uint32_t CH9_DONE: 1;
    uint32_t CH10_DONE: 1;
    uint32_t CH11_DONE: 1;
    uint32_t CH12_DONE: 1;
    uint32_t CH13_DONE: 1;
    uint32_t CH14_DONE: 1;
    uint32_t CH15_DONE: 1;
    uint32_t CH16_DONE: 1;
    uint32_t CH17_DONE: 1;
    uint32_t CH18_DONE: 1;
    uint32_t CH19_DONE: 1;
    uint32_t CH20_DONE: 1;
    uint32_t CH21_DONE: 1;
    uint32_t CH22_DONE: 1;
    uint32_t CH23_DONE: 1;
    uint32_t CH24_DONE: 1;
    uint32_t CH25_DONE: 1;
    uint32_t CH26_DONE: 1;
    uint32_t CH27_DONE: 1;
    uint32_t CH28_DONE: 1;
    uint32_t CH29_DONE: 1;
    uint32_t CH30_DONE: 1;
    uint32_t CH31_DONE: 1;
  };
  uint32_t Word;
} SCU_DMADONE_Typedef;

typedef union
{
  struct
  {
    uint32_t CLKSEL: 1;
    uint32_t RATE: 1;
    uint32_t RESERVED0: 6;
    uint32_t FDIV: 6;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} SCU_ETHCON_Typedef;

typedef union
{
  struct
  {
    uint32_t PREDIV: 3;
    uint32_t OFFSET_EN: 1;
    uint32_t DNOFFSET: 2;
    uint32_t UPOFFSET: 2;
    uint32_t CPI: 6;
    uint32_t RESERVED0: 2;
    uint32_t LPFRES: 3;
    uint32_t RESERVED1: 1;
    uint32_t KVCOI: 3;
    uint32_t RESERVED2: 1;
    uint32_t VCOI: 3;
    uint32_t RESERVED3: 1;
    uint32_t LOCKED: 1;
    uint32_t DPLL2_FLAG1: 1;
    uint32_t DPLL2_FLAG0: 1;
    uint32_t RESERVED4: 1;
  };
  uint32_t Word;
} SCU_DPLL2CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t NDIV: 8;
    uint32_t POSTDIV: 4;
    uint32_t SEL_400_300: 1;
    uint32_t POSTDIV_ADC: 3;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} SCU_DPLL2CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t SRT: 1;
    uint32_t B33: 1;
    uint32_t PWR: 1;
    uint32_t B12: 1;
    uint32_t IWD: 1;
    uint32_t WWD: 1;
    uint32_t B33_VS: 3;
    uint32_t B12_VS: 3;
    uint32_t RESERVED0: 1;
    uint32_t FCS: 1;
    uint32_t DBG: 2;
    uint32_t RESERVED1:16;
  };
  uint32_t Word;
} SCU_CFGWORD0_Typedef;

typedef union
{
  struct
  {
    uint32_t CTM: 1;
    uint32_t MDCK_FLT: 3;
    uint32_t MCCK_FLG: 3;
    uint32_t FWP: 1;
    uint32_t FWPS: 6;
    uint32_t RESERVED0: 18;
  };
  uint32_t Word;
} SCU_CFGWORD1_Typedef;

typedef union
{
  struct
  {
    uint32_t ENC: 32;
  };
  uint32_t Word;
} SCU_CFGENCRY_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_CFGCAL_RESV0_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_CFGCAL_RESV1_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_CFGCAL_RESV2_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_XO_CAP: 8;
    uint32_t CFG_XO_IB_TUNE: 2;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} SCU_CFGOSCCAL0_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_OSCRC_CAP: 2;
    uint32_t CFG_OSCRC_IB_ISEL: 2;
    uint32_t CFG_OSCRC_CAL: 10;
    uint32_t RESERVED0: 18;
  };
  uint32_t Word;
} SCU_CFGOSCCAL1_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_OSC_ISEL: 4;
    uint32_t CFG_OSC_BUF_ISEL: 2;
    uint32_t RESERVED0: 2;
    uint32_t CFG_OSC_CAP_SEL: 8;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} SCU_CFGOSCCAL2_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_CFGOSCCAL3_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_BGR0TCAL: 4;
    uint32_t CFG_BGR0VCAL: 4;
    uint32_t CFG_BGR1TCAL: 4;
    uint32_t CFG_BGR1VCAL: 4;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} SCU_CFGVR0_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_VCTL_DCDC: 4;
    uint32_t RESERVED0: 28;
  };
  uint32_t Word;
} SCU_CFGVR1_Typedef;

typedef union
{
  struct
  {
    uint32_t CFG_AFEBGR_TCAL: 4;
    uint32_t CFG_AFEBGR_ICAL: 4;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} SCU_CFGAFE0_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} SCU_CFGAFE1_Typedef;
typedef union
{
  struct
  {
    uint32_t PROT: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} SCU_TST_PROT_Typedef;

typedef union
{
  struct
  {
    uint32_t SYS_TSTMD: 4;
    uint32_t RESERVED0: 4;
    uint32_t SRAM_TM: 4;
    uint32_t FLASH_TM: 4;
    uint32_t XOSC_FLAG1: 1;
    uint32_t XOSC_FLAG0: 1;
    uint32_t RESERVED1: 2;
    uint32_t CTL_TST_DCDC: 1;
    uint32_t RESERVED2: 3;
    uint32_t BGR0_TSTSEL: 1;
    uint32_t BGR0_CHOP: 1;
    uint32_t RESERVED3: 6;
  };
  uint32_t Word;
} SCU_TST_SYS_Typedef;
typedef struct
{
  __IO SCU_PROT_Typedef PROT;
  __IO SCU_NMICON_Typedef NMICON;
  __IO SCU_PWRC_Typedef PWRC;
  __IO SCU_FLASHWAIT_Typedef FLASHWAIT;
  __IO SCU_FAULTFLAG_Typedef FAULTFLAG;
  __IO SCU_LVDCON_Typedef LVDCON;
  __IO SCU_TBLREMAPEN_Typedef TBLREMAPEN;
  __IO SCU_BFREGION_Typedef BFREGION;
  __IO SCU_TIMEREN_Typedef TIMEREN;
  __IO SCU_TIMERDIS_Typedef TIMERDIS;
  __IO SCU_WAKEUPTIME_Typedef WAKEUPTIME;
  uint32_t RESERVED0[5];
  __IO SCU_SCLKEN0_Typedef SCLKEN0;
  __IO SCU_SCLKEN1_Typedef SCLKEN1;
  __IO SCU_SCLKEN2_Typedef SCLKEN2;
  __IO SCU_AHBEN_Typedef AHBEN;
  __IO SCU_APB1EN_Typedef APB1EN;
  __IO SCU_APB2EN_Typedef APB2EN;
  uint32_t RESERVED1[1];
  __IO SCU_MCUCTR_Typedef MCUCTP;
  uint32_t RESERVED2[1];
  __IO SCU_DMADONE_Typedef DMADONE;
  __IO SCU_ETHCON_Typedef ETHCON;
  uint32_t RESERVED3[5];
  __IO SCU_DPLL2CON0_Typedef DPLL2CON0;
  __IO SCU_DPLL2CON1_Typedef DPLL2CON1;
  uint32_t RESERVED4[14];
  __IO SCU_CFGWORD0_Typedef CFGWORD0;
  __IO SCU_CFGWORD1_Typedef CFGWORD1;
  uint32_t RESERVED5[4];
  __IO SCU_CFGENCRY_Typedef CFGENCRY;
  uint32_t RESERVED6[9];
  __IO SCU_CFGCAL_RESV0_Typedef CFGCAL_RESV0;
  __IO SCU_CFGCAL_RESV1_Typedef CFGCAL_RESV1;
  __IO SCU_CFGCAL_RESV2_Typedef CFGCAL_RESV2;
  uint32_t RESERVED7[3];
  __IO SCU_CFGOSCCAL0_Typedef CFGOSCCAL0;
  __IO SCU_CFGOSCCAL1_Typedef CFGOSCCAL1;
  __IO SCU_CFGOSCCAL2_Typedef CFGOSCCAL2;
  __IO SCU_CFGOSCCAL3_Typedef CFGOSCCAL3;
  uint32_t RESERVED8[2];
  __IO SCU_CFGVR0_Typedef CFGVR0;
  __IO SCU_CFGVR1_Typedef CFGVR1;
  __IO SCU_CFGAFE0_Typedef CFGAFE0;
  __IO SCU_CFGAFE1_Typedef CFGAFE1;

  uint32_t RESERVED12[48] ;
  __IO SCU_TST_PROT_Typedef TST_PROT;
  __IO SCU_TST_SYS_Typedef TST_SYS;
} SCU_TypeDef;

/******************************************************************************/
/************************************* GPIO ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t PORT_0: 1;
    uint32_t PORT_1: 1;
    uint32_t PORT_2: 1;
    uint32_t PORT_3: 1;
    uint32_t PORT_4: 1;
    uint32_t PORT_5: 1;
    uint32_t PORT_6: 1;
    uint32_t PORT_7: 1;
    uint32_t PORT_8: 1;
    uint32_t PORT_9: 1;
    uint32_t PORT_10: 1;
    uint32_t PORT_11: 1;
    uint32_t PORT_12: 1;
    uint32_t PORT_13: 1;
    uint32_t PORT_14: 1;
    uint32_t PORT_15: 1;
    uint32_t PORT_16: 1;
    uint32_t PORT_17: 1;
    uint32_t PORT_18: 1;
    uint32_t PORT_19: 1;
    uint32_t PORT_20: 1;
    uint32_t PORT_21: 1;
    uint32_t PORT_22: 1;
    uint32_t PORT_23: 1;
    uint32_t PORT_24: 1;
    uint32_t PORT_25: 1;
    uint32_t PORT_26: 1;
    uint32_t PORT_27: 1;
    uint32_t PORT_28: 1;
    uint32_t PORT_29: 1;
    uint32_t PORT_30: 1;
    uint32_t PORT_31: 1;
  };
  uint32_t Word;
} GPIO_PORT_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA_0: 1;
    uint32_t DATA_1: 1;
    uint32_t DATA_2: 1;
    uint32_t DATA_3: 1;
    uint32_t DATA_4: 1;
    uint32_t DATA_5: 1;
    uint32_t DATA_6: 1;
    uint32_t DATA_7: 1;
    uint32_t DATA_8: 1;
    uint32_t DATA_9: 1;
    uint32_t DATA_10: 1;
    uint32_t DATA_11: 1;
    uint32_t DATA_12: 1;
    uint32_t DATA_13: 1;
    uint32_t DATA_14: 1;
    uint32_t DATA_15: 1;
    uint32_t DATA_16: 1;
    uint32_t DATA_17: 1;
    uint32_t DATA_18: 1;
    uint32_t DATA_19: 1;
    uint32_t DATA_20: 1;
    uint32_t DATA_21: 1;
    uint32_t DATA_22: 1;
    uint32_t DATA_23: 1;
    uint32_t DATA_24: 1;
    uint32_t DATA_25: 1;
    uint32_t DATA_26: 1;
    uint32_t DATA_27: 1;
    uint32_t DATA_28: 1;
    uint32_t DATA_29: 1;
    uint32_t DATA_30: 1;
    uint32_t DATA_31: 1;
  };
  uint32_t Word;
} GPIO_DATA_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DATABSR_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DATABCR_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DATABRR_Typedef;

typedef union
{
  struct
  {
    uint32_t DIR_0: 1;
    uint32_t DIR_1: 1;
    uint32_t DIR_2: 1;
    uint32_t DIR_3: 1;
    uint32_t DIR_4: 1;
    uint32_t DIR_5: 1;
    uint32_t DIR_6: 1;
    uint32_t DIR_7: 1;
    uint32_t DIR_8: 1;
    uint32_t DIR_9: 1;
    uint32_t DIR_10: 1;
    uint32_t DIR_11: 1;
    uint32_t DIR_12: 1;
    uint32_t DIR_13: 1;
    uint32_t DIR_14: 1;
    uint32_t DIR_15: 1;
    uint32_t DIR_16: 1;
    uint32_t DIR_17: 1;
    uint32_t DIR_18: 1;
    uint32_t DIR_19: 1;
    uint32_t DIR_20: 1;
    uint32_t DIR_21: 1;
    uint32_t DIR_22: 1;
    uint32_t DIR_23: 1;
    uint32_t DIR_24: 1;
    uint32_t DIR_25: 1;
    uint32_t DIR_26: 1;
    uint32_t DIR_27: 1;
    uint32_t DIR_28: 1;
    uint32_t DIR_29: 1;
    uint32_t DIR_30: 1;
    uint32_t DIR_31: 1;
  };
  uint32_t Word;
} GPIO_DIR_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DIRBSR_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DIRBCR_Typedef;

typedef struct
{
  uint32_t Word;
} GPIO_DIRBRR_Typedef;

typedef union
{
  struct
  {
    uint32_t GPIO0FUNC: 2;
    uint32_t RESERVED0: 2;
    uint32_t GPIO1FUNC: 2;
    uint32_t RESERVED1: 2;
    uint32_t GPIO2FUNC: 2;
    uint32_t RESERVED2: 2;
    uint32_t GPIO3FUNC: 2;
    uint32_t RESERVED3: 2;
    uint32_t GPIO4FUNC: 2;
    uint32_t RESERVED4: 2;
    uint32_t GPIO5FUNC: 2;
    uint32_t RESERVED5: 2;
    uint32_t GPIO6FUNC: 2;
    uint32_t RESERVED6: 2;
    uint32_t GPIO7FUNC: 2;
    uint32_t RESERVED7: 2;
  };
  uint32_t Word;
} GPIO_FUNC0_Typedef;

typedef union
{
  struct
  {
    uint32_t GPIO8FUNC: 2;
    uint32_t RESERVED0: 2;
    uint32_t GPIO9FUNC: 2;
    uint32_t RESERVED1: 2;
    uint32_t GPIO10FUNC: 2;
    uint32_t RESERVED2: 2;
    uint32_t GPIO11FUNC: 2;
    uint32_t RESERVED3: 2;
    uint32_t GPIO12FUNC: 2;
    uint32_t RESERVED4: 2;
    uint32_t GPIO13FUNC: 2;
    uint32_t RESERVED5: 2;
    uint32_t GPIO14FUNC: 2;
    uint32_t RESERVED6: 2;
    uint32_t GPIO15FUNC: 2;
    uint32_t RESERVED7: 2;
  };
  uint32_t Word;
} GPIO_FUNC1_Typedef;

typedef union
{
  struct
  {
    uint32_t GPIO16FUNC: 2;
    uint32_t RESERVED0: 2;
    uint32_t GPIO17FUNC: 2;
    uint32_t RESERVED1: 2;
    uint32_t GPIO18FUNC: 2;
    uint32_t RESERVED2: 2;
    uint32_t GPIO19FUNC: 2;
    uint32_t RESERVED3: 2;
    uint32_t GPIO20FUNC: 2;
    uint32_t RESERVED4: 2;
    uint32_t GPIO21FUNC: 2;
    uint32_t RESERVED5: 2;
    uint32_t GPIO22FUNC: 2;
    uint32_t RESERVED6: 2;
    uint32_t GPIO23FUNC: 2;
    uint32_t RESERVED7: 2;
  };
  uint32_t Word;
} GPIO_FUNC2_Typedef;

typedef union
{
  struct
  {
    uint32_t GPIO24FUNC: 2;
    uint32_t RESERVED0: 2;
    uint32_t GPIO25FUNC: 2;
    uint32_t RESERVED1: 2;
    uint32_t GPIO26FUNC: 2;
    uint32_t RESERVED2: 2;
    uint32_t GPIO27FUNC: 2;
    uint32_t RESERVED3: 2;
    uint32_t GPIO28FUNC: 2;
    uint32_t RESERVED4: 2;
    uint32_t GPIO29FUNC: 2;
    uint32_t RESERVED5: 2;
    uint32_t GPIO30FUNC: 2;
    uint32_t RESERVED6: 2;
    uint32_t GPIO31FUNC: 2;
    uint32_t RESERVED7: 2;
  };
  uint32_t Word;
} GPIO_FUNC3_Typedef;

typedef union
{
  struct
  {
    uint32_t INEB_0: 1;
    uint32_t INEB_1: 1;
    uint32_t INEB_2: 1;
    uint32_t INEB_3: 1;
    uint32_t INEB_4: 1;
    uint32_t INEB_5: 1;
    uint32_t INEB_6: 1;
    uint32_t INEB_7: 1;
    uint32_t INEB_8: 1;
    uint32_t INEB_9: 1;
    uint32_t INEB_10: 1;
    uint32_t INEB_11: 1;
    uint32_t INEB_12: 1;
    uint32_t INEB_13: 1;
    uint32_t INEB_14: 1;
    uint32_t INEB_15: 1;
    uint32_t INEB_16: 1;
    uint32_t INEB_17: 1;
    uint32_t INEB_18: 1;
    uint32_t INEB_19: 1;
    uint32_t INEB_20: 1;
    uint32_t INEB_21: 1;
    uint32_t INEB_22: 1;
    uint32_t INEB_23: 1;
    uint32_t INEB_24: 1;
    uint32_t INEB_25: 1;
    uint32_t INEB_26: 1;
    uint32_t INEB_27: 1;
    uint32_t INEB_28: 1;
    uint32_t INEB_29: 1;
    uint32_t INEB_30: 1;
    uint32_t INEB_31: 1;
  };
  uint32_t Word;
} GPIO_INEB_Typedef;

typedef union
{
  struct
  {
    uint32_t ODE_0: 1;
    uint32_t ODE_1: 1;
    uint32_t ODE_2: 1;
    uint32_t ODE_3: 1;
    uint32_t ODE_4: 1;
    uint32_t ODE_5: 1;
    uint32_t ODE_6: 1;
    uint32_t ODE_7: 1;
    uint32_t ODE_8: 1;
    uint32_t ODE_9: 1;
    uint32_t ODE_10: 1;
    uint32_t ODE_11: 1;
    uint32_t ODE_12: 1;
    uint32_t ODE_13: 1;
    uint32_t ODE_14: 1;
    uint32_t ODE_15: 1;
    uint32_t ODE_16: 1;
    uint32_t ODE_17: 1;
    uint32_t ODE_18: 1;
    uint32_t ODE_19: 1;
    uint32_t ODE_20: 1;
    uint32_t ODE_21: 1;
    uint32_t ODE_22: 1;
    uint32_t ODE_23: 1;
    uint32_t ODE_24: 1;
    uint32_t ODE_25: 1;
    uint32_t ODE_26: 1;
    uint32_t ODE_27: 1;
    uint32_t ODE_28: 1;
    uint32_t ODE_29: 1;
    uint32_t ODE_30: 1;
    uint32_t ODE_31: 1;
  };
  uint32_t Word;
} GPIO_ODE_Typedef;

typedef union
{
  struct
  {
    uint32_t PUE_0: 1;
    uint32_t PUE_1: 1;
    uint32_t PUE_2: 1;
    uint32_t PUE_3: 1;
    uint32_t PUE_4: 1;
    uint32_t PUE_5: 1;
    uint32_t PUE_6: 1;
    uint32_t PUE_7: 1;
    uint32_t PUE_8: 1;
    uint32_t PUE_9: 1;
    uint32_t PUE_10: 1;
    uint32_t PUE_11: 1;
    uint32_t PUE_12: 1;
    uint32_t PUE_13: 1;
    uint32_t PUE_14: 1;
    uint32_t PUE_15: 1;
    uint32_t PUE_16: 1;
    uint32_t PUE_17: 1;
    uint32_t PUE_18: 1;
    uint32_t PUE_19: 1;
    uint32_t PUE_20: 1;
    uint32_t PUE_21: 1;
    uint32_t PUE_22: 1;
    uint32_t PUE_23: 1;
    uint32_t PUE_24: 1;
    uint32_t PUE_25: 1;
    uint32_t PUE_26: 1;
    uint32_t PUE_27: 1;
    uint32_t PUE_28: 1;
    uint32_t PUE_29: 1;
    uint32_t PUE_30: 1;
    uint32_t PUE_31: 1;
  };
  uint32_t Word;
} GPIO_PUE_Typedef;

typedef union
{
  struct
  {
    uint32_t PDE_0: 1;
    uint32_t PDE_1: 1;
    uint32_t PDE_2: 1;
    uint32_t PDE_3: 1;
    uint32_t PDE_4: 1;
    uint32_t PDE_5: 1;
    uint32_t PDE_6: 1;
    uint32_t PDE_7: 1;
    uint32_t PDE_8: 1;
    uint32_t PDE_9: 1;
    uint32_t PDE_10: 1;
    uint32_t PDE_11: 1;
    uint32_t PDE_12: 1;
    uint32_t PDE_13: 1;
    uint32_t PDE_14: 1;
    uint32_t PDE_15: 1;
    uint32_t PDE_16: 1;
    uint32_t PDE_17: 1;
    uint32_t PDE_18: 1;
    uint32_t PDE_19: 1;
    uint32_t PDE_20: 1;
    uint32_t PDE_21: 1;
    uint32_t PDE_22: 1;
    uint32_t PDE_23: 1;
    uint32_t PDE_24: 1;
    uint32_t PDE_25: 1;
    uint32_t PDE_26: 1;
    uint32_t PDE_27: 1;
    uint32_t PDE_28: 1;
    uint32_t PDE_29: 1;
    uint32_t PDE_30: 1;
    uint32_t PDE_31: 1;
  };
  uint32_t Word;
} GPIO_PDE_Typedef;

typedef union
{
  struct
  {
    uint32_t DS_0: 1;
    uint32_t DS_1: 1;
    uint32_t DS_2: 1;
    uint32_t DS_3: 1;
    uint32_t DS_4: 1;
    uint32_t DS_5: 1;
    uint32_t DS_6: 1;
    uint32_t DS_7: 1;
    uint32_t DS_8: 1;
    uint32_t DS_9: 1;
    uint32_t DS_10: 1;
    uint32_t DS_11: 1;
    uint32_t DS_12: 1;
    uint32_t DS_13: 1;
    uint32_t DS_14: 1;
    uint32_t DS_15: 1;
    uint32_t DS_16: 1;
    uint32_t DS_17: 1;
    uint32_t DS_18: 1;
    uint32_t DS_19: 1;
    uint32_t DS_20: 1;
    uint32_t DS_21: 1;
    uint32_t DS_22: 1;
    uint32_t DS_23: 1;
    uint32_t DS_24: 1;
    uint32_t DS_25: 1;
    uint32_t DS_26: 1;
    uint32_t DS_27: 1;
    uint32_t DS_28: 1;
    uint32_t DS_29: 1;
    uint32_t DS_30: 1;
    uint32_t DS_31: 1;
  };
  uint32_t Word;
} GPIO_DS_Typedef;

typedef union
{
  struct
  {
    uint32_t PINTIE_V: 8;
    uint32_t PMASK_V: 8;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} GPIO_PINTIE_Typedef;

typedef union
{
  struct
  {
    uint32_t PINTIF_0: 1;
    uint32_t PINTIF_1: 1;
    uint32_t PINTIF_2: 1;
    uint32_t PINTIF_3: 1;
    uint32_t PINTIF_4: 1;
    uint32_t PINTIF_5: 1;
    uint32_t PINTIF_6: 1;
    uint32_t PINTIF_7: 1;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} GPIO_PINTIF_Typedef;

typedef union
{
  struct
  {
    uint32_t PINT0_SEL: 3;
    uint32_t RESERVED0: 1;
    uint32_t PINT1_SEL: 3;
    uint32_t RESERVED1: 1;
    uint32_t PINT2_SEL: 3;
    uint32_t RESERVED2: 1;
    uint32_t PINT3_SEL: 3;
    uint32_t RESERVED3: 1;
    uint32_t PINT4_SEL: 3;
    uint32_t RESERVED4: 1;
    uint32_t PINT5_SEL: 3;
    uint32_t RESERVED5: 1;
    uint32_t PINT6_SEL: 3;
    uint32_t RESERVED6: 1;
    uint32_t PINT7_SEL: 3;
    uint32_t RESERVED7: 1;
  };
  uint32_t Word;
} GPIO_PINTSEL_Typedef;

typedef union
{
  struct
  {
    uint32_t PINT0_CFG: 3;
    uint32_t RESERVED0: 1;
    uint32_t PINT1_CFG: 3;
    uint32_t RESERVED1: 1;
    uint32_t PINT2_CFG: 3;
    uint32_t RESERVED2: 1;
    uint32_t PINT3_CFG: 3;
    uint32_t RESERVED3: 1;
    uint32_t PINT4_CFG: 3;
    uint32_t RESERVED4: 1;
    uint32_t PINT5_CFG: 3;
    uint32_t RESERVED5: 1;
    uint32_t PINT6_CFG: 3;
    uint32_t RESERVED6: 1;
    uint32_t PINT7_CFG: 3;
    uint32_t RESERVED7: 1;
  };
  uint32_t Word;
} GPIO_PINTCFG_Typedef;

typedef union
{
  struct
  {
    uint32_t KINTIE: 8;
    uint32_t KMASK: 8;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} GPIO_KINTIE_Typedef;

typedef union
{
  struct
  {
    uint32_t KINTIF_0: 1;
    uint32_t KINTIF_1: 1;
    uint32_t KINTIF_2: 1;
    uint32_t KINTIF_3: 1;
    uint32_t KINTIF_4: 1;
    uint32_t KINTIF_5: 1;
    uint32_t KINTIF_6: 1;
    uint32_t KINTIF_7: 1;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} GPIO_KINTIF_Typedef;

typedef union
{
  struct
  {
    uint32_t KINT0_SEL: 3;
    uint32_t RESERVED0: 1;
    uint32_t KINT1_SEL: 3;
    uint32_t RESERVED1: 1;
    uint32_t KINT2_SEL: 3;
    uint32_t RESERVED2: 1;
    uint32_t KINT3_SEL: 3;
    uint32_t RESERVED3: 1;
    uint32_t KINT4_SEL: 3;
    uint32_t RESERVED4: 1;
    uint32_t KINT5_SEL: 3;
    uint32_t RESERVED5: 1;
    uint32_t KINT6_SEL: 3;
    uint32_t RESERVED6: 1;
    uint32_t KINT7_SEL: 3;
    uint32_t RESERVED7: 1;
  };
  uint32_t Word;
} GPIO_KINTSEL_Typedef;

typedef union
{
  struct
  {
    uint32_t KINT0_CFG: 3;
    uint32_t RESERVED0: 1;
    uint32_t KINT1_CFG: 3;
    uint32_t RESERVED1: 1;
    uint32_t KINT2_CFG: 3;
    uint32_t RESERVED2: 1;
    uint32_t KINT3_CFG: 3;
    uint32_t RESERVED3: 1;
    uint32_t KINT4_CFG: 3;
    uint32_t RESERVED4: 1;
    uint32_t KINT5_CFG: 3;
    uint32_t RESERVED5: 1;
    uint32_t KINT6_CFG: 3;
    uint32_t RESERVED6: 1;
    uint32_t KINT7_CFG: 3;
    uint32_t RESERVED7: 1;
  };
  uint32_t Word;
} GPIO_KINTCFG_Typedef;

typedef union
{
  uint32_t Word;
} GPIO_IOFLTSEL_Typedef;

typedef union
{
  struct
  {
    uint32_t TX0PS: 2;
    uint32_t TX0PLV: 1;
    uint32_t RESERVED0: 1;
    uint32_t TX0_S0: 1;
    uint32_t TX0_S1: 1;
    uint32_t TX0_S2: 1;
    uint32_t TX0_S3: 1;
    uint32_t TX1PS: 2;
    uint32_t TX1PLV: 1;
    uint32_t RESERVED1: 1;
    uint32_t TX1_S0: 1;
    uint32_t TX1_S1: 1;
    uint32_t TX1_S2: 1;
    uint32_t TX1_S3: 1;
    uint32_t RESERVED2: 16;
  };
  uint32_t Word;
} GPIO_TXPWM_Typedef;

typedef union
{
  struct
  {
    uint32_t BUZEN: 1;
    uint32_t RESERVED0: 7;
    uint32_t BUZ_LOAD: 20;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} GPIO_BUZC_Typedef;

typedef struct
{
  __I GPIO_PORT_Typedef PORT;
  __IO GPIO_DATA_Typedef DATA;
  __O GPIO_DATABSR_Typedef DATABSR;
  __O GPIO_DATABCR_Typedef DATABCR;
  __O GPIO_DATABRR_Typedef DATABRR;
  __IO GPIO_DIR_Typedef DIR;
  __O GPIO_DIRBSR_Typedef DIRBSR;
  __O GPIO_DIRBCR_Typedef DIRBCR;
  __O GPIO_DIRBRR_Typedef DIRBRR;
  __IO GPIO_FUNC0_Typedef FUNC0;
  __IO GPIO_FUNC1_Typedef FUNC1;
  __IO GPIO_FUNC2_Typedef FUNC2;
  __IO GPIO_FUNC3_Typedef FUNC3;
  __IO GPIO_INEB_Typedef INEB;
  __IO GPIO_ODE_Typedef ODE;
  __IO GPIO_PUE_Typedef PUE;
  __IO GPIO_PDE_Typedef PDE;
  __IO GPIO_DS_Typedef PDS;
  uint32_t RESERVED0[174];
  __IO GPIO_PINTIE_Typedef PINTIE;
  __IO GPIO_PINTIF_Typedef PINTIF;
  __IO GPIO_PINTSEL_Typedef PINTSEL;
  __IO GPIO_PINTCFG_Typedef PINTCFG;
  __IO GPIO_KINTIE_Typedef KINTIE;
  __IO GPIO_KINTIF_Typedef KINTIF;
  __IO GPIO_KINTSEL_Typedef KINTSEL;
  __IO GPIO_KINTCFG_Typedef KINTCFG;
  uint32_t RESERVED1[4];
  __IO GPIO_IOFLTSEL_Typedef IOFLTSEL;
  uint32_t RESERVED2[19];
  __IO GPIO_TXPWM_Typedef TXPWM;
  __IO GPIO_BUZC_Typedef BUZC;
} GPIO_TypeDef;

/******************************************************************************/
/************************************* IAP ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RST: 1;
    uint32_t FLASH_ACK: 1;
    uint32_t FLASH_FALL: 1;
    uint32_t IAPCKS: 3;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} IAP_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t IAPCA: 14;
    uint32_t IAPPA: 6;
    uint32_t IFREN: 1;
    uint32_t RESERVED0: 11;
  };
  uint32_t Word;
} IAP_ADDR_Typedef;

typedef union
{
  struct
  {
    uint32_t TRIG: 32;
  };
  uint32_t Word;
} IAP_TRIG_Typedef;

typedef union
{
  struct
  {
    uint32_t IAPUL: 32;
  };
  uint32_t Word;
} IAP_UL_Typedef;

typedef union
{
  struct
  {
    uint32_t BSY: 1;
    uint32_t PERASE_END: 1;
    uint32_t WPROG_END: 1;
    uint32_t PPROGS_END: 1;
    uint32_t PPROGD_END: 1;
    uint32_t PPROGE_END: 1;
    uint32_t MERASE_END: 1;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} IAP_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA: 32;
  };
  uint32_t Word;
} IAP_DATA0_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA: 32;
  };
  uint32_t Word;
} IAP_DATA1_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA: 32;
  };
  uint32_t Word;
} IAP_DATA3_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA: 32;
  };
  uint32_t Word;
} IAP_DATA4_Typedef;

typedef struct
{
  __IO IAP_CON_Typedef CON;
  __IO IAP_ADDR_Typedef ADDR;
  __IO IAP_TRIG_Typedef TRIG;
  __IO IAP_UL_Typedef UL;
  __I IAP_STA_Typedef STA;
  __IO IAP_DATA0_Typedef DATA0;
  __IO IAP_DATA1_Typedef DATA1;
  __IO IAP_DATA3_Typedef DATA3;
  __IO IAP_DATA4_Typedef DATA4;
} IAP_TypeDef;

/******************************************************************************/
/************************************* ADC ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t DR: 12;
    uint32_t RESERVED0: 20;
  };
  uint32_t Word;
} ADC_DR_Typedef;

typedef union
{
  struct
  {
    uint32_t ADC_EN: 1;
    uint32_t ADC_TRIG: 1;
    uint32_t ADC_BIT_SEL: 1;
    uint32_t RESERVED0: 29;
  };
  uint32_t Word;
} ADC_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t CLKDIV: 3;
    uint32_t CLKS: 1;
    uint32_t AD_DIFFMODE: 1;
    uint32_t AD_STIME: 2;
    uint32_t RESERVED0: 1;
    uint32_t ADR_LP: 1;
    uint32_t ADR_VCM_EN: 1;
    uint32_t ADR_VREF_EN: 1;
    uint32_t ADR_BP: 1;
    uint32_t ADR_VRSEL: 4;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} ADC_CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t ADCHS: 12;
    uint32_t RESERVED0: 20;
  };
  uint32_t Word;
} ADC_CHS_Typedef;

typedef union
{
  struct
  {
    uint32_t ADIF: 1;
    uint32_t ADIE: 1;
    uint32_t RESERVED0: 30;
  };
  uint32_t Word;
} ADC_INT_Typedef;

typedef struct
{
  __I ADC_DR_Typedef DR;
  __IO ADC_CON0_Typedef CON0;
  __IO ADC_CON1_Typedef CON1;
  __IO ADC_CHS_Typedef CHS;
  __IO ADC_INT_Typedef INT;
} ADC_TypeDef;

/******************************************************************************/
/************************************* WWDT ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t LOAD: 32;
  };
  uint32_t Word;
} WWDT_LOAD_Typedef;

typedef union
{
  struct
  {
    uint32_t VALUE: 32;
  };
  uint32_t Word;
} WWDT_VALUE_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t IE: 1;
    uint32_t RSTEN: 1;
    uint32_t CLKS: 1;
    uint32_t WWDTWIN: 2;
    uint32_t RESERVED0: 26;
  };
  uint32_t Word;
} WWDT_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t INTCLR: 32;
  };
  uint32_t Word;
} WWDT_INTCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t WDTIF: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} WWDT_RIS_Typedef;

typedef union
{
  struct
  {
    uint32_t LOCK: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} WWDT_LOCK_Typedef;

typedef struct
{
  __IO WWDT_LOAD_Typedef LOAD;
  __I WWDT_VALUE_Typedef VALUE;
  __IO WWDT_CON_Typedef CON;
  __IO WWDT_INTCLR_Typedef INTCLR;
  __I WWDT_RIS_Typedef RIS;
  uint32_t RESERVED0[59];
  __IO WWDT_LOCK_Typedef LOCK;
} WWDT_TypeDef;

/******************************************************************************/
/************************************* IWDT ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t LOAD: 32;
  };
  uint32_t Word;
} IWDT_LOAD_Typedef;

typedef union
{
  struct
  {
    uint32_t VALUE: 32;
  };
  uint32_t Word;
} IWDT_VALUE_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t IE: 1;
    uint32_t RSTEN: 1;
    uint32_t CLKS: 1;
    uint32_t RESERVED0: 28;
  };
  uint32_t Word;
} IWDT_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t INTCLR: 32;
  };
  uint32_t Word;
} IWDT_INTCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t WDTIF: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} IWDT_RIS_Typedef;

typedef union
{
  struct
  {
    uint32_t LOCK: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} IWDT_LOCK_Typedef;

typedef struct
{
  __IO IWDT_LOAD_Typedef LOAD;
  __I IWDT_VALUE_Typedef VALUE;
  __IO IWDT_CON_Typedef CON;
  __IO IWDT_INTCLR_Typedef INTCLR;
  __I IWDT_RIS_Typedef RIS;
  uint32_t RESERVED0[59];
  __IO IWDT_LOCK_Typedef LOCK;
} IWDT_TypeDef;

/******************************************************************************/
/************************************* T16N ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t CNT0: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_CNT0_Typedef;

typedef union
{
  struct
  {
    uint32_t CNT1: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_CNT1_Typedef;

typedef union
{
  struct
  {
    uint32_t PRECNT: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} T16N_PRECNT_Typedef;

typedef union
{
  struct
  {
    uint32_t PREMAT: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} T16N_PREMAT_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t CS: 2;
    uint32_t SYNC: 1;
    uint32_t EDGE: 2;
    uint32_t MOD: 2;
    uint32_t MAT0S: 2;
    uint32_t MAT1S: 2;
    uint32_t MAT2S: 2;
    uint32_t MAT3S: 2;
    uint32_t ASYWEN: 1;
    uint32_t RESERVED0: 15;
  };
  uint32_t Word;
} T16N_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t CAPPE: 1;
    uint32_t CAPNE: 1;
    uint32_t CAPIS0: 1;
    uint32_t CAPIS1: 1;
    uint32_t CAPT: 4;
    uint32_t CAPL0: 1;
    uint32_t CAPL1: 1;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} T16N_CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t MOE0: 1;
    uint32_t MOE1: 1;
    uint32_t POL0: 1;
    uint32_t POL1: 1;
    uint32_t PWMMOD: 2;
    uint32_t PWMDZE: 1;
    uint32_t RESERVED0: 1;
    uint32_t MOM0: 2;
    uint32_t MOM1: 2;
    uint32_t MOM2: 2;
    uint32_t MOM3: 2;
    uint32_t PWMBKE0: 1;
    uint32_t PWMBKE1: 1;
    uint32_t PWMBKL0: 1;
    uint32_t PWMBKL1: 1;
    uint32_t RESERVED1: 2;
    uint32_t PWMBKP0: 1;
    uint32_t PWMBKP1: 1;
    uint32_t PWMBKF: 1;
    uint32_t RESERVED2: 7;
  };
  uint32_t Word;
} T16N_CON2_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IE: 1;
    uint32_t MAT1IE: 1;
    uint32_t MAT2IE: 1;
    uint32_t MAT3IE: 1;
    uint32_t TOP0IE: 1;
    uint32_t TOP1IE: 1;
    uint32_t CAP0IE: 1;
    uint32_t CAP1IE: 1;
    uint32_t PBK0IE: 1;
    uint32_t PBK1IE: 1;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} T16N_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IF: 1;
    uint32_t MAT1IF: 1;
    uint32_t MAT2IF: 1;
    uint32_t MAT3IF: 1;
    uint32_t TOP0IF: 1;
    uint32_t TOP1IF: 1;
    uint32_t CAP0IF: 1;
    uint32_t CAP1IF: 1;
    uint32_t PBK0IF: 1;
    uint32_t PBK1IF: 1;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} T16N_IF_Typedef;

typedef union
{
  struct
  {
    uint32_t PDZ: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} T16N_PDZ_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 1;
    uint32_t P0MAT0TRE: 1;
    uint32_t P0MAT1TRE: 1;
    uint32_t P0TOP0TRE: 1;
    uint32_t RESERVED1: 1;
    uint32_t P1MAT2TRE: 1;
    uint32_t P1MAT3TRE: 1;
    uint32_t P1TOP1TRE: 1;
    uint32_t RESERVED2: 24;
  };
  uint32_t Word;
} T16N_PTR_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_MAT0_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT1: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_MAT1_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT2: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_MAT2_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT3: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_MAT3_Typedef;

typedef union
{
  struct
  {
    uint32_t TOP0: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_TOP0_Typedef;

typedef union
{
  struct
  {
    uint32_t TOP1: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} T16N_TOP1_Typedef;

typedef struct
{
  __IO T16N_CNT0_Typedef CNT0;
  __IO T16N_CNT1_Typedef CNT1;
  __IO T16N_PRECNT_Typedef PRECNT;
  __IO T16N_PREMAT_Typedef PREMAT;
  __IO T16N_CON0_Typedef CON0;
  __IO T16N_CON1_Typedef CON1;
  __IO T16N_CON2_Typedef CON2;
  uint32_t RESERVED0;
  __IO T16N_IE_Typedef IE;
  __IO T16N_IF_Typedef IF;
  __IO T16N_PDZ_Typedef PDZ;
  __IO T16N_PTR_Typedef PTR;
  __IO T16N_MAT0_Typedef MAT0;
  __IO T16N_MAT1_Typedef MAT1;
  __IO T16N_MAT2_Typedef MAT2;
  __IO T16N_MAT3_Typedef MAT3;
  __IO T16N_TOP0_Typedef TOP0;
  __IO T16N_TOP1_Typedef TOP1;
} T16N_TypeDef;

/******************************************************************************/
/************************************* T32N ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t CNT0: 32;
  };
  uint32_t Word;
} T32N_CNT_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t CS: 2;
    uint32_t SYNC: 1;
    uint32_t EDGE: 2;
    uint32_t MOD: 2;
    uint32_t MAT0S: 2;
    uint32_t MAT1S: 2;
    uint32_t MAT2S: 2;
    uint32_t MAT3S: 2;
    uint32_t ASYNC_WREN: 1;
    uint32_t RESERVED0: 15;
  };
  uint32_t Word;
} T32N_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t CAPPE: 1;
    uint32_t CAPNE: 1;
    uint32_t CAPIS0: 1;
    uint32_t CAPIS1: 1;
    uint32_t CAPT: 4;
    uint32_t CAPL0: 1;
    uint32_t CAPL1: 1;
    uint32_t RESERVED0: 6;
    uint32_t MOE0: 1;
    uint32_t MOE1: 1;
    uint32_t RESERVED1: 6;
    uint32_t MOM0: 2;
    uint32_t MOM1: 2;
    uint32_t MOM2: 2;
    uint32_t MOM3: 2;
  };
  uint32_t Word;
} T32N_CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t PRECNT: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} T32N_PRECNT_Typedef;

typedef union
{
  struct
  {
    uint32_t PREMAT: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} T32N_PREMAT_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IE: 1;
    uint32_t MAT1IE: 1;
    uint32_t MAT2IE: 1;
    uint32_t MAT3IE: 1;
    uint32_t IE: 1;
    uint32_t CAP0IE: 1;
    uint32_t CAP1IE: 1;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} T32N_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IF: 1;
    uint32_t MAT1IF: 1;
    uint32_t MAT2IF: 1;
    uint32_t MAT3IF: 1;
    uint32_t IF: 1;
    uint32_t CAP0IF: 1;
    uint32_t CAP1IF: 1;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} T32N_IF_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0: 32;
  };
  uint32_t Word;
} T32N_MAT0_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT1: 32;
  };
  uint32_t Word;
} T32N_MAT1_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT2: 32;
  };
  uint32_t Word;
} T32N_MAT2_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT3: 32;
  };
  uint32_t Word;
} T32N_MAT3_Typedef;

typedef struct
{
  __IO T32N_CNT_Typedef CNT;
  __IO T32N_CON0_Typedef CON0;
  __IO T32N_CON1_Typedef CON1;
  uint32_t RESERVED0;
  __IO T32N_PRECNT_Typedef PRECNT;
  __IO T32N_PREMAT_Typedef PREMAT;
  __IO T32N_IE_Typedef IE;
  __IO T32N_IF_Typedef IF;
  __IO T32N_MAT0_Typedef MAT0;
  __IO T32N_MAT1_Typedef MAT1;
  __IO T32N_MAT2_Typedef MAT2;
  __IO T32N_MAT3_Typedef MAT3;
} T32N_TypeDef;

/******************************************************************************/
/************************************* UART ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t TXEN: 1;
    uint32_t TRST: 1;
    uint32_t TBCLR: 1;
    uint32_t TXI: 1;
    uint32_t RESERVED0: 4;
    uint32_t TXMOD: 4;
    uint32_t TXP: 1;
    uint32_t TXFS: 1;
    uint32_t RESERVED1: 2;
    uint32_t RXEN: 1;
    uint32_t RRST: 1;
    uint32_t RBCLR: 1;
    uint32_t RXI: 1;
    uint32_t BDEN: 1;
    uint32_t IDEN: 1;
    uint32_t RESERVED2: 2;
    uint32_t RXMOD: 4;
    uint32_t RXP: 1;
    uint32_t RESERVED3: 3;
  };
  uint32_t Word;
} UART_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t TBIM: 2;
    uint32_t RESERVED0: 2;
    uint32_t RBIM: 2;
    uint32_t RESERVED1: 2;
    uint32_t BCS: 3;
    uint32_t RESERVED2: 1;
    uint32_t BDM: 2;
    uint32_t RESERVED3: 2;
    uint32_t IDM: 2;
    uint32_t RESERVED4: 14;
  };
  uint32_t Word;
} UART_CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t TXDMAEN: 1;
    uint32_t RXDMAEN: 1;
    uint32_t DMAONERR: 1;
    uint32_t RESERVED0: 29;
  };
  uint32_t Word;
} UART_DMACR_Typedef;

typedef union
{
  struct
  {
    uint32_t BRFRA: 4;
    uint32_t BRINT: 12;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} UART_BRR_Typedef;

typedef union
{
  struct
  {
    uint32_t TBPTR: 4;
    uint32_t TBOV: 1;
    uint32_t TXBUSY: 1;
    uint32_t RESERVED0: 2;
    uint32_t RBPTR: 4;
    uint32_t RBOV: 1;
    uint32_t RXBUSY: 1;
    uint32_t RESERVED1: 2;
    uint32_t FER0: 1;
    uint32_t PER0: 1;
    uint32_t FER1: 1;
    uint32_t PER1: 1;
    uint32_t FER2: 1;
    uint32_t PER2: 1;
    uint32_t FER3: 1;
    uint32_t PER3: 1;
    uint32_t RESERVED2: 8;
  };
  uint32_t Word;
} UART_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t TBIE: 1;
    uint32_t TCIE: 1;
    uint32_t RESERVED0: 6;
    uint32_t TBWEIE: 1;
    uint32_t TBWOIE: 1;
    uint32_t RESERVED1: 6;
    uint32_t RBIE: 1;
    uint32_t IDIE: 1;
    uint32_t RESERVED2: 6;
    uint32_t ROIE: 1;
    uint32_t FEIE: 1;
    uint32_t PEIE: 1;
    uint32_t BDEIE: 1;
    uint32_t RBREIE: 1;
    uint32_t RBROIE: 1;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} UART_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t TBIF: 1;
    uint32_t TCIF: 1;
    uint32_t RESERVED0: 6;
    uint32_t TBWEIF: 1;
    uint32_t TBWOIF: 1;
    uint32_t RESERVED1: 6;
    uint32_t RBIF: 1;
    uint32_t IDIF: 1;
    uint32_t RESERVED2: 6;
    uint32_t ROIF: 1;
    uint32_t FEIF: 1;
    uint32_t PEIF: 1;
    uint32_t BDEIF: 1;
    uint32_t RBREIF: 1;
    uint32_t RBROIF: 1;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} UART_IF_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} UART_TBW_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} UART_RBR_Typedef;

typedef union
{
  struct
  {
    uint32_t TB0: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP0: 1;
    uint32_t TBFF0: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB0_Typedef;

typedef union
{
  struct
  {
    uint32_t TB1: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP1: 1;
    uint32_t TBFF1: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB1_Typedef;

typedef union
{
  struct
  {
    uint32_t TB2: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP2: 1;
    uint32_t TBFF2: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB2_Typedef;

typedef union
{
  struct
  {
    uint32_t TB3: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP3: 1;
    uint32_t TBFF3: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB3_Typedef;

typedef union
{
  struct
  {
    uint32_t TB4: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP4: 1;
    uint32_t TBFF4: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB4_Typedef;

typedef union
{
  struct
  {
    uint32_t TB5: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP5: 1;
    uint32_t TBFF5: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB5_Typedef;

typedef union
{
  struct
  {
    uint32_t TB6: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP6: 1;
    uint32_t TBFF6: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB6_Typedef;

typedef union
{
  struct
  {
    uint32_t TB7: 9;
    uint32_t RESERVED0: 3;
    uint32_t TP7: 1;
    uint32_t TBFF7: 1;
    uint32_t RESERVED1: 18;
  };
  uint32_t Word;
} UART_TB7_Typedef;

typedef union
{
  struct
  {
    uint32_t RB0: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP0: 1;
    uint32_t RBFF0: 1;
    uint32_t FE0: 1;
    uint32_t PE0: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB0_Typedef;

typedef union
{
  struct
  {
    uint32_t RB1: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP1: 1;
    uint32_t RBFF1: 1;
    uint32_t FE1: 1;
    uint32_t PE1: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB1_Typedef;

typedef union
{
  struct
  {
    uint32_t RB2: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP2: 1;
    uint32_t RBFF2: 1;
    uint32_t FE2: 1;
    uint32_t PE2: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB2_Typedef;

typedef union
{
  struct
  {
    uint32_t RB3: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP3: 1;
    uint32_t RBFF3: 1;
    uint32_t FE3: 1;
    uint32_t PE3: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB3_Typedef;

typedef union
{
  struct
  {
    uint32_t RB4: 5;
    uint32_t RESERVED0: 3;
    uint32_t RP4: 1;
    uint32_t RBFF4: 1;
    uint32_t FE4: 1;
    uint32_t PE4: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB4_Typedef;

typedef union
{
  struct
  {
    uint32_t RB5: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP5: 1;
    uint32_t RBFF5: 1;
    uint32_t FE5: 1;
    uint32_t PE5: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB5_Typedef;

typedef union
{
  struct
  {
    uint32_t RB6: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP6: 1;
    uint32_t RBFF6: 1;
    uint32_t FE6: 1;
    uint32_t PE6: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB6_Typedef;

typedef union
{
  struct
  {
    uint32_t RB7: 9;
    uint32_t RESERVED0: 3;
    uint32_t RP7: 1;
    uint32_t RBFF7: 1;
    uint32_t FE7: 1;
    uint32_t PE7: 1;
    uint32_t RESERVED1: 16;
  };
  uint32_t Word;
} UART_RB7_Typedef;

typedef struct
{
  __IO UART_CON0_Typedef CON0;
  __IO UART_CON1_Typedef CON1;
  __IO UART_DMACR_Typedef DMACR;
  uint32_t RESERVED0[1];
  __IO UART_BRR_Typedef BRR;
  __I UART_STA_Typedef STA;
  __IO UART_IE_Typedef IE;
  __IO UART_IF_Typedef IF;
  __O UART_TBW_Typedef TBW;
  __I UART_RBR_Typedef RBR;
  uint32_t RESERVED1[6];
  __I UART_TB0_Typedef TB0;
  __I UART_TB1_Typedef TB1;
  __I UART_TB2_Typedef TB2;
  __I UART_TB3_Typedef TB3;
  __I UART_TB4_Typedef TB4;
  __I UART_TB5_Typedef TB5;
  __I UART_TB6_Typedef TB6;
  __I UART_TB7_Typedef TB7;
  __I UART_RB0_Typedef RB0;
  __I UART_RB1_Typedef RB1;
  __I UART_RB2_Typedef RB2;
  __I UART_RB3_Typedef RB3;
  __I UART_RB4_Typedef RB4;
  __I UART_RB5_Typedef RB5;
  __I UART_RB6_Typedef RB6;
  __I UART_RB7_Typedef RB7;
} UART_TypeDef;

/******************************************************************************/
/************************************* SPI ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RST: 1;
    uint32_t MS: 1;
    uint32_t REN: 1;
    uint32_t RESERVED0: 1;
    uint32_t DRE: 1;
    uint32_t DFS: 2;
    uint32_t TXDMAEN: 1;
    uint32_t RXDMAEN: 1;
    uint32_t RESERVED1: 6;
    uint32_t TME: 1;
    uint32_t TMS: 1;
    uint32_t TMP: 6;
    uint32_t DW: 3;
    uint32_t RESERVED2: 3;
    uint32_t TXCLR: 1;
    uint32_t RXCLR: 1;
  };
  uint32_t Word;
} SPI_CON_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} SPI_TBW_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} SPI_RBR_Typedef;

typedef union
{
  struct
  {
    uint32_t TBIE: 1;
    uint32_t RBIE: 1;
    uint32_t TEIE: 1;
    uint32_t ROIE: 1;
    uint32_t IDIE: 1;
    uint32_t NSSIE: 1;
    uint32_t TBWEIE: 1;
    uint32_t RESERVED0: 1;
    uint32_t TBIM: 2;
    uint32_t RBIM: 2;
    uint32_t RESERVED1: 20;
  };
  uint32_t Word;
} SPI_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t TBIF: 1;
    uint32_t RBIF: 1;
    uint32_t TEIF: 1;
    uint32_t ROIF: 1;
    uint32_t IDIF: 1;
    uint32_t NSSIF: 1;
    uint32_t TBWEIF: 1;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} SPI_IF_Typedef;

typedef union
{
  struct
  {
    uint32_t TB0: 8;
    uint32_t TB1: 8;
    uint32_t TB2: 8;
    uint32_t TB3: 8;
  };
  uint32_t Word;
} SPI_TB_Typedef;

typedef union
{
  struct
  {
    uint32_t RB0: 8;
    uint32_t RB1: 8;
    uint32_t RB2: 8;
    uint32_t RB3: 8;
  };
  uint32_t Word;
} SPI_RB_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 7;
    uint32_t NSS: 1;
    uint32_t TBEF0: 1;
    uint32_t TBEF1: 1;
    uint32_t TBEF2: 1;
    uint32_t TBEF3: 1;
    uint32_t RBFF0: 1;
    uint32_t RBFF1: 1;
    uint32_t RBFF2: 1;
    uint32_t RBFF3: 1;
    uint32_t IDLE: 1;
    uint32_t RESERVED1: 15;
  };
  uint32_t Word;
} SPI_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t CKS: 10;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} SPI_CKS_Typedef;

typedef struct
{
  __O SPI_CON_Typedef CON;
  uint32_t RESERVED0;
  __O SPI_TBW_Typedef TBW;
  __I SPI_RBR_Typedef RBR;
  __IO SPI_IE_Typedef IE;
  __IO SPI_IF_Typedef IF;
  __I SPI_TB_Typedef TB;
  __I SPI_RB_Typedef RB;
  __I SPI_STA_Typedef STA;
  __IO SPI_CKS_Typedef CKS;
} SPI_TypeDef;

/******************************************************************************/
/************************************* I2C ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RST: 1;
    uint32_t SCLOD: 1;
    uint32_t SDAOD: 1;
    uint32_t SCLSE: 1;
    uint32_t SDASE: 1;
    uint32_t RESERVED0: 1;
    uint32_t TJE: 1;
    uint32_t TJP: 8;
    uint32_t RW: 1;
    uint32_t SA: 7;
    uint32_t TXDMAEN: 1;
    uint32_t RXDMAEN: 1;
    uint32_t RESERVED1: 6;
  };
  uint32_t Word;
} I2C_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t MS: 1;
    uint32_t RDM: 3;
    uint32_t CSE: 1;
    uint32_t ANAE: 1;
    uint32_t SRAE: 1;
    uint32_t SPAE: 1;
    uint32_t ADLY: 3;
    uint32_t ADE: 1;
    uint32_t TIS: 4;
    uint32_t SRT: 1;
    uint32_t SPT: 1;
    uint32_t RDT: 1;
    uint32_t BLD: 1;
    uint32_t RESERVED0: 4;
    uint32_t TAS: 1;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} I2C_MOD_Typedef;

typedef union
{
  struct
  {
    uint32_t SRIE: 1;
    uint32_t SPIE: 1;
    uint32_t TBIE: 1;
    uint32_t RBIE: 1;
    uint32_t TEIE: 1;
    uint32_t ROIE: 1;
    uint32_t NAIE: 1;
    uint32_t TBWEIE: 1;
    uint32_t TBIM: 2;
    uint32_t RBIM: 2;
    uint32_t TIDLEIE: 1;
    uint32_t RESERVED0: 19;
  };
  uint32_t Word;
} I2C_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t SRIF: 1;
    uint32_t SPIF: 1;
    uint32_t TBIF: 1;
    uint32_t RBIF: 1;
    uint32_t TEIF: 1;
    uint32_t ROIF: 1;
    uint32_t NAIF: 1;
    uint32_t TBWEIF: 1;
    uint32_t RESERVED0: 4;
    uint32_t TIDLEIF: 1;
    uint32_t RESERVED1: 19;
  };
  uint32_t Word;
} I2C_IF_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} I2C_TBW_Typedef;

typedef union
{
  uint8_t Byte[4];
  uint16_t HalfWord[2];
  uint32_t Word;
} I2C_RBR_Typedef;

typedef union
{
  struct
  {
    uint32_t TB0: 8;
    uint32_t TB1: 8;
    uint32_t TB2: 8;
    uint32_t TB3: 8;
  };
  uint32_t Word;
} I2C_TB_Typedef;

typedef union
{
  struct
  {
    uint32_t RB0: 8;
    uint32_t RB1: 8;
    uint32_t RB2: 8;
    uint32_t RB3: 8;
  };
  uint32_t Word;
} I2C_RB_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 8;
    uint32_t TBEF0: 1;
    uint32_t TBEF1: 1;
    uint32_t TBEF2: 1;
    uint32_t TBEF3: 1;
    uint32_t RBFF0: 1;
    uint32_t RBFF1: 1;
    uint32_t RBFF2: 1;
    uint32_t RBFF3: 1;
    uint32_t ACK: 1;
    uint32_t IDLE: 1;
    uint32_t RESERVED1: 14;
  };
  uint32_t Word;
} I2C_STA_Typedef;

typedef struct
{
  __IO I2C_CON_Typedef CON;
  __IO I2C_MOD_Typedef MOD;
  __IO I2C_IE_Typedef IE;
  __IO I2C_IF_Typedef IF;
  __O I2C_TBW_Typedef TBW;
  __I I2C_RBR_Typedef RBR;
  __I I2C_TB_Typedef TB;
  __I I2C_RB_Typedef RB;
  __I I2C_STA_Typedef STA;
} I2C_TypeDef;

/******************************************************************************/
/************************************* TRNG ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t PD: 1;
    uint32_t SEED: 1;
    uint32_t DATA_MODE: 1;
    uint32_t RESERVED0: 5;
    uint32_t RNG_VALID: 1;
    uint32_t RESERVED1: 7;
    uint32_t RNG_IE: 1;
    uint32_t RNG_IF: 1;
    uint32_t RESERVED2: 2;
    uint32_t DMA_EN: 1;
    uint32_t RESERVED3: 3;
  };
  uint32_t Word;
} TRNG_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t START_TIME: 24;
    uint32_t RESERVED0: 8;
  };
  uint32_t Word;
} TRNG_CON1_Typedef;

typedef union
{
  struct
  {
    uint32_t TRNG_DATA: 32;
  };
  uint32_t Word;
} TRNG_DATA_Typedef;

typedef struct
{
  __IO TRNG_CON0_Typedef LOAD;
  __IO TRNG_CON1_Typedef VALUE;
  __I TRNG_DATA_Typedef CON;
} TRNG_TypeDef;

/******************************************************************************/
/************************************* ECC ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t RST: 1;
    uint32_t MODE: 3;
    uint32_t RES: 3;
    uint32_t OPR: 3;
    uint32_t OPL: 3;
    uint32_t RESERVED0: 14;
    uint32_t ComMod: 2;
    uint32_t Remap: 1;
    uint32_t Comb: 1;
    uint32_t RUN: 1;
  };
  uint32_t Word;
} ECC_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t WK: 1;
    uint32_t DONE: 1;
    uint32_t ERR: 1;
    uint32_t RESERVED: 29;
  };
  uint32_t Word;
} ECC_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t DMA_EN: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} ECC_DMACTR_Typedef;

typedef struct
{
  __IO ECC_CON_Typedef CON;
  __IO ECC_STA_Typedef STA;
  __IO ECC_DMACTR_Typedef DMACTR;
} ECC_TypeDef;

/******************************************************************************/
/************************************* CRC ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t UL: 32;
  };
  uint32_t Word;
} CRC_UL_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RST: 1;
    uint32_t HS: 1;
    uint32_t DS: 1;
    uint32_t REQ: 1;
    uint32_t ACK: 1;
    uint32_t RESERVED0: 2;
    uint32_t MOD: 2;
    uint32_t BYTE: 2;
    uint32_t REFIN: 1;
    uint32_t REFOUT: 1;
    uint32_t XOROUT: 1;
    uint32_t RESERVED1: 1;
    uint32_t DMAEN: 1;
    uint32_t RESERVED2: 15;
  };
  uint32_t Word;
} CRC_CON_Typedef;

typedef union
{
  struct
  {
    uint32_t TRIG: 32;
  };
  uint32_t Word;
}CRC_TRIG_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 4;
    uint32_t ADDR: 17;
    uint32_t IFREN: 1;
    uint32_t RESERVED1: 10;
  };
  uint32_t Word;
} CRC_ADDR_Typedef;

typedef union
{
  struct
  {
    uint32_t CRC_SIZE: 17;
    uint32_t RESERVED0: 15;
  };
  uint32_t Word;
} CRC_SIZE_Typedef;

typedef union
{
  struct
  {
    uint32_t DI: 32;
  };
  uint32_t Word;
} CRC_DI_Typedef;

typedef union
{
  struct
  {
    uint32_t DO: 32;
  };
  uint32_t Word;
} CRC_DO_Typedef;

typedef union
{
  struct
  {
    uint32_t BUSY: 1;
    uint32_t RSTF: 1;
    uint32_t EMPTY_ERR: 1;
    uint32_t RESERVED0: 29;
  };
  uint32_t Word;
} CRC_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 4;
    uint32_t FADR: 17;
    uint32_t IFREN: 1;
    uint32_t RESERVED1: 10;
  };
  uint32_t Word;
} CRC_FA_Typedef;

typedef union
{
  struct
  {
    uint32_t FS: 10;
    uint32_t RESERVED0: 22;
  };
  uint32_t Word;
} CRC_FS_Typedef;

typedef struct
{
  __IO CRC_UL_Typedef UL;
  __IO CRC_CON_Typedef CON;
  __IO CRC_TRIG_Typedef TRIG;
  __IO CRC_ADDR_Typedef ADDR;
  __IO CRC_SIZE_Typedef SIZE;
  __IO CRC_DI_Typedef DI;
  __IO CRC_DO_Typedef DO;
  __IO CRC_STA_Typedef STA;
  __I CRC_FA_Typedef FA;
  __I CRC_FS_Typedef FS;
} CRC_TypeDef;

/******************************************************************************/
/************************************* AES ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t DATA0: 32;
  };
  uint32_t Word;
} AES_DATA0_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA1: 32;
  };
  uint32_t Word;
} AES_DATA1_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA2: 32;
  };
  uint32_t Word;
} AES_DATA2_Typedef;

typedef union
{
  struct
  {
    uint32_t DATA3: 32;
  };
  uint32_t Word;
} AES_DATA3_Typedef;

typedef union
{
  struct
  {
    uint32_t KEY0: 32;
  };
  uint32_t Word;
} AES_KEY0_Typedef;

typedef union
{
  struct
  {
    uint32_t KEY1: 32;
  };
  uint32_t Word;
} AES_KEY1_Typedef;

typedef union
{
  struct
  {
    uint32_t KEY2: 32;
  };
  uint32_t Word;
} AES_KEY2_Typedef;

typedef union
{
  struct
  {
    uint32_t KEY3: 32;
  };
  uint32_t Word;
} AES_KEY3_Typedef;

typedef union
{
  struct
  {
    uint32_t GODONE: 1;
    uint32_t ENCRYPT: 1;
    uint32_t RESERVED0: 4;
    uint32_t IE: 1;
    uint32_t IF: 1;
    uint32_t DMA_EN: 1;
    uint32_t RESERVED1: 23;
  };
  uint32_t Word;
} AES_CON_Typedef;

typedef struct
{
  __IO AES_DATA0_Typedef DATA0;
  __IO AES_DATA1_Typedef DATA1;
  __IO AES_DATA2_Typedef DATA2;
  __IO AES_DATA3_Typedef DATA3;
  __IO AES_KEY0_Typedef KEY0;
  __IO AES_KEY1_Typedef KEY1;
  __IO AES_KEY2_Typedef KEY2;
  __IO AES_KEY3_Typedef KEY3;
  __IO AES_CON_Typedef CON;
} AES_TypeDef;

/******************************************************************************/
/************************************* NTB ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t CNT: 32;
  };
  uint32_t Word;
} NTB_CNT_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RESERVED0: 7;
    uint32_t MAT0S: 2;
    uint32_t MAT1S: 2;
    uint32_t MAT2S: 2;
    uint32_t MAT3S: 2;
    uint32_t MAT4S: 2;
    uint32_t MAT5S: 2;
    uint32_t MAT6S: 2;
    uint32_t MAT7S: 2;
    uint32_t RESERVED1:8;
  };
  uint32_t Word;
} NTB_CON0_Typedef;

typedef union
{
  struct
  {
    uint32_t val: 32;
  };
  uint32_t Word;
} NTB_ADJ_Typedef;

typedef union
{
  struct
  {
    uint32_t PRECNT: 32;
  };
  uint32_t Word;
} NTB_PRECNT_Typedef;

typedef union
{
  struct
  {
    uint32_t PREMAT: 32;
  };
  uint32_t Word;
} NTB_PREMAT_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IE: 1;
    uint32_t MAT1IE: 1;
    uint32_t MAT2IE: 1;
    uint32_t MAT3IE: 1;
    uint32_t MAT4IE: 1;
    uint32_t MAT5IE: 1;
    uint32_t MAT6IE: 1;
    uint32_t MAT7IE: 1;
    uint32_t IE: 1;
    uint32_t RESERVED0: 23;
  };
  uint32_t Word;
} NTB_IE_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0IF: 1;
    uint32_t MAT1IF: 1;
    uint32_t MAT2IF: 1;
    uint32_t MAT3IF: 1;
    uint32_t MAT4IF: 1;
    uint32_t MAT5IF: 1;
    uint32_t MAT6IF: 1;
    uint32_t MAT7IF: 1;
    uint32_t IF: 1;
    uint32_t RESERVED0: 23;
  };
  uint32_t Word;
} NTB_IF_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT0: 32;
  };
  uint32_t Word;
} NTB_MAT0_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT1: 32;
  };
  uint32_t Word;
} NTB_MAT1_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT2: 32;
  };
  uint32_t Word;
} NTB_MAT2_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT3: 32;
  };
  uint32_t Word;
} NTB_MAT3_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT4: 32;
  };
  uint32_t Word;
} NTB_MAT4_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT5: 32;
  };
  uint32_t Word;
} NTB_MAT5_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT6: 32;
  };
  uint32_t Word;
} NTB_MAT6_Typedef;

typedef union
{
  struct
  {
    uint32_t MAT7: 32;
  };
  uint32_t Word;
} NTB_MAT7_Typedef;

typedef struct
{
  __IO NTB_CNT_Typedef CNT;
  __IO NTB_CON0_Typedef CON0;
  __IO NTB_ADJ_Typedef ADJ;
  uint32_t RESERVED0;
  __IO NTB_PRECNT_Typedef PRECNT;
  __IO NTB_PREMAT_Typedef PREMAT;
  __IO NTB_IE_Typedef IE;
  __IO NTB_IF_Typedef IF;
  __IO NTB_MAT0_Typedef MAT0;
  __IO NTB_MAT1_Typedef MAT1;
  __IO NTB_MAT2_Typedef MAT2;
  __IO NTB_MAT3_Typedef MAT3;
  __IO NTB_MAT4_Typedef MAT4;
  __IO NTB_MAT5_Typedef MAT5;
  __IO NTB_MAT6_Typedef MAT6;
  __IO NTB_MAT7_Typedef MAT7;
} NTB_TypeDef;

/******************************************************************************/
/************************************* BPLC ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t DAC: 1;
    uint32_t RSSI: 1;
    uint32_t RESERVED0: 2;
    uint32_t ADC_E: 1;
    uint32_t LPE: 1;
    uint32_t RESERVED1: 10;

    uint32_t RSSI_TLCTL: 3;
    uint32_t RESERVED3: 1;
    uint32_t RSSI_THCTL: 3;
    uint32_t RESERVED4: 1;
    uint32_t DAC_ICTL: 4;
    uint32_t RESERVED5: 4;
  };
  uint32_t Word;
} BPLC_AFE00_Typedef;

typedef union
{
  struct
  {
    uint32_t LPF: 1;
    uint32_t CSE: 1;
    uint32_t BSE: 1;
    //uint32_t RESERVED0: 13;
    uint32_t RESERVED0: 5;
    uint32_t LPF_GAIN: 5;
    uint32_t RESERVED01: 3;

    uint32_t LPF_EXCAL: 6;
    uint32_t RESERVED1: 2;
    uint32_t LPF_CTL: 6;
    uint32_t RESERVED2: 2;
  };
  uint32_t Word;
} BPLC_AFE01_Typedef;

typedef union
{
  struct
  {
    uint32_t PG1: 1;
    uint32_t PG2: 1;
    uint32_t PG3: 1;
    uint32_t RESERVED0: 1;
    uint32_t PG1_IC: 2;
    uint32_t PG2_IC: 2;
    uint32_t PG3_IC: 2;
    uint32_t RESERVED1: 6;
    uint32_t PG2_SW: 7;
    uint32_t CMCTL: 1;
    uint32_t RESERVED2: 3;
    uint32_t REF: 1;
    uint32_t VCM: 1;
    uint32_t RESERVED3: 3;
  };
  uint32_t Word;
} BPLC_AFE02_Typedef;

typedef union
{
  struct
  {
    uint32_t PA: 1;
    uint32_t RCC: 1;
    uint32_t STA: 1;
    uint32_t PAS: 1;
    uint32_t PA_GAIN: 4;
    uint32_t PA_CTRL1: 4;
    uint32_t PA_CTRL2: 4;
    uint32_t TESTN_SEL: 3;
    uint32_t RESERVED0: 1;
    uint32_t TESTP_SEL: 3;
    uint32_t RESERVED1: 1;
    uint32_t PA_IBIAS_CTL: 2;
    uint32_t RESERVED2: 6;
  };
  uint32_t Word;
} BPLC_AFE03_Typedef;

typedef union
{
  uint32_t Word;
} BPLC_AFE04_Typedef;

typedef union
{
  uint32_t Word;
} BPLC_AFE05_Typedef;

typedef union
{
  uint32_t Word;
} BPLC_AFE06_Typedef;

typedef union
{
  uint32_t Word;
} BPLC_AFE07_Typedef;

typedef union
{
  struct
  {
    uint32_t TXE: 1;
    uint32_t RXE: 1;
    uint32_t RESERVED0: 1;
    uint32_t TXG: 1;
    uint32_t SYNCP_NUM: 4;
    uint32_t SYNCM_NUM: 4;
    uint32_t TME: 1;
    uint32_t RME: 1;
    uint32_t CGS: 1;
    uint32_t PLS: 1;
    uint32_t PB_NUM: 8;
    uint32_t RESERVED1: 8;
  };
  uint32_t Word;
} BPLC_CTRL0_Typedef;

typedef union
{
  struct
  {
    uint32_t FBS: 1;
    uint32_t FBC: 1;
    uint32_t FB: 1;
    uint32_t FRC: 1;
    uint32_t DBS: 1;
    uint32_t DBC: 1;
    uint32_t DB: 1;
    uint32_t DRC: 1;
    uint32_t FCH_RNUM: 4;
    uint32_t DAT_RNUM: 4;
    uint32_t PLD_SYMBOL: 15;
    uint32_t SCF: 1;
  };
  uint32_t Word;
} BPLC_CTRL1_Typedef;

typedef union
{
  struct
  {
    uint32_t FCB: 1;
    uint32_t FCC: 1;
    uint32_t FCS: 1;
    uint32_t FCI: 1;
    uint32_t FCG: 2;
    uint32_t FCR: 2;
    uint32_t FC_SYMBOL: 4;
    uint32_t RESERVED0: 4;
    uint32_t FC_CARRIER: 9;
    uint32_t FC_PB: 3;
    uint32_t FC_BPC: 3;
    uint32_t RESERVED1: 1;
  };
  uint32_t Word;
} BPLC_CFG00_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_CRC_INIT;
  };
  uint32_t Word;
} BPLC_CFG01_Typedef;

typedef union
{
  struct
  {
    uint32_t DC_SYMBOL: 11;
    uint32_t DCC: 1;
    uint32_t DCS: 1;
    uint32_t DCI: 1;
    uint32_t DCR: 2;
    uint32_t DC_CARRIER: 9;
    uint32_t DC_PB: 3;
    uint32_t DC_BPC: 3;
    uint32_t DCB: 1;
  };
  uint32_t Word;
} BPLC_CFG02_Typedef;

typedef union
{
  struct
  {
    uint32_t DC_PAD_NUM: 14;
    uint32_t SCR: 1;
    uint32_t STR: 1;
    uint32_t SCR_INIT: 10;
    uint32_t SCRI1: 1;
    uint32_t SCRI2: 1;
    uint32_t SMD: 1;
    uint32_t RESERVED0: 3;
  };
  uint32_t Word;
} BPLC_CFG03_Typedef;

typedef union
{
  struct
  {
    uint32_t DC_CRC_INIT: 24;
    uint32_t RESERVED0: 8;
  };
  uint32_t Word;
} BPLC_CFG04_Typedef;

typedef union
{
  struct
  {
    uint32_t PREMBLE_LC: 6;
    uint32_t DCG: 2;
    uint32_t DC_RNUM: 4;
    uint32_t LCS: 1;
    uint32_t AEE: 1;
    uint32_t TMF: 1;
    uint32_t RESERVED0: 1;
    uint32_t TX_DLY: 16;
  };
  uint32_t Word;
} BPLC_CFG05_Typedef;

typedef union
{
  struct
  {
    uint32_t ADP: 1;
    uint32_t RESERVED0: 1;
    uint32_t AGC: 1;
    uint32_t RESERVED1: 1;
    uint32_t HPF: 1;
    uint32_t DPG: 1;
    uint32_t MF: 1;
    uint32_t FLT1: 1;
    uint32_t PGA_INIT: 8;
    uint32_t PGA_MIN: 8;
    uint32_t PGA_MAX: 8;
  };
  uint32_t Word;
} BPLC_CFG06_Typedef;

typedef union
{
  struct
  {
    uint32_t RSSI: 1;
    uint32_t RESERVED0: 1;
    uint32_t RSI_N: 2;
    uint32_t AVE_N: 2;
    uint32_t RESERVED1: 2;
    uint32_t AGC_LEN: 6;
    uint32_t RESERVED2: 2;
    uint32_t GAIN_OFFSET: 8;
    uint32_t CPS_H: 2;
    uint32_t CPS: 1;
    uint32_t RESERVED3: 1;
    uint32_t AVE_SEL: 4;
  };
  uint32_t Word;
} BPLC_CFG07_Typedef;

typedef union
{
  struct
  {
    uint32_t AGC_TH11: 16;
    uint32_t AGC_TH12: 16;
  };
  uint32_t Word;
} BPLC_CFG08_Typedef;

typedef union
{
  struct
  {
    uint32_t AGC_TH21: 16;
    uint32_t AGC_TH22: 16;
  };
  uint32_t Word;
} BPLC_CFG09_Typedef;

typedef union
{
  struct
  {
    uint32_t TX_SAMPLE_NUM: 15;
    uint32_t RESERVED0: 1;
    uint32_t RX_SAMPLE_NUM: 15;
    uint32_t RESERVED1: 1;
  };
  uint32_t Word;
} BPLC_CFG10_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 11;
    uint32_t RSF: 1;
    uint32_t TSF: 1;
    uint32_t SFE: 1;
    uint32_t DAG: 2;
    uint32_t ADP_A1_CFG: 14;
    uint32_t AAS: 1;
    uint32_t RESERVED1: 1;
  };
  uint32_t Word;
} BPLC_CFG11_Typedef;

typedef union
{
  struct
  {
    uint32_t BTX_IF_0: 1;
    uint32_t BTX_IF_1: 1;
    uint32_t BTX_IF_2: 1;
    uint32_t BTX_IF_3: 1;
    uint32_t BTX_IF_4: 1;
    uint32_t BTX_IF_5: 1;
    uint32_t MER_IF: 1;
    uint32_t BRX_IF_0: 1;
    uint32_t BRX_IF_1: 1;
    uint32_t BRX_IF_2: 1;
    uint32_t BRX_IF_3: 1;
    uint32_t BRX_IF_4: 1;
    uint32_t BRX_IF_5: 1;
    uint32_t BRX_IF_6: 1;
    uint32_t BRX_IF_7: 1;
    uint32_t BRX_IF_8: 1;
    uint32_t BTX_IE_0: 1;
    uint32_t BTX_IE_1: 1;
    uint32_t BTX_IE_2: 1;
    uint32_t BTX_IE_3: 1;
    uint32_t BTX_IE_4: 1;
    uint32_t BTX_IE_5: 1;
    uint32_t MER_IE: 1;
    uint32_t BRX_IE_0: 1;
    uint32_t BRX_IE_1: 1;
    uint32_t BRX_IE_2: 1;
    uint32_t BRX_IE_3: 1;
    uint32_t BRX_IE_4: 1;
    uint32_t BRX_IE_5: 1;
    uint32_t BRX_IE_6: 1;
    uint32_t BRX_IE_7: 1;
    uint32_t BRX_IE_8: 1;
  };
  uint32_t Word;
} BPLC_CFG12_Typedef;

typedef union
{
  struct
  {
    uint32_t BTX_IF_0: 1;
    uint32_t BTX_IF_1: 1;
    uint32_t BTX_IF_2: 1;
    uint32_t BTX_IF_3: 1;
    uint32_t BTX_IF_4: 1;
    uint32_t BTX_IF_5: 1;
    uint32_t IF_MER: 1;
    uint32_t BRX_IF_0: 1;
    uint32_t BRX_IF_1: 1;
    uint32_t BRX_IF_2: 1;
    uint32_t BRX_IF_3: 1;
    uint32_t BRX_IF_4: 1;
    uint32_t BRX_IF_5: 1;
    uint32_t BRX_IF_6: 1;
    uint32_t BRX_IF_7: 1;
    uint32_t BRX_IF_8: 1;
    uint32_t RESERVED: 16;
  };
  uint32_t Word;
} BPLC_CLRIF_Typedef;

typedef union
{
  struct
  {
    uint32_t GNUM1: 9;
    uint32_t RESERVED0: 7;
    uint32_t GNUM2: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG13_Typedef;

typedef union
{
  struct
  {
    uint32_t GNUM3: 9;
    uint32_t RESERVED0: 7;
    uint32_t BNUM: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG14_Typedef;

typedef union
{
  struct
  {
    uint32_t CTH1: 8;
    uint32_t CTH2: 8;
    uint32_t RPW: 8;
    uint32_t SMP_CNT_I: 8;
  };
  uint32_t Word;
} BPLC_CFG15_Typedef;

typedef union
{
  struct
  {
    uint32_t INIT_VAL: 23;
    uint32_t RESERVED0: 9;
  };
  uint32_t Word;
} BPLC_CFG16_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET10: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET11: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG17_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET12: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET13: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG18_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET14: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET15: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG19_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET16: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET17: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG20_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET18: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET19: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG21_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET1A: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET1B: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG22_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET1C: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET1D: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG23_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET1E: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET1F: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG24_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET20: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET21: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG25_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET22: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET23: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG26_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET24: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET25: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG27_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET26: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET27: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG28_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET28: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET29: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG29_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET2A: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET2B: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG30_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET2C: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET2D: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG31_Typedef;

typedef union
{
  struct
  {
    uint32_t FC_OFFSET2E: 9;
    uint32_t RESERVED0: 7;
    uint32_t FC_OFFSET2F: 9;
    uint32_t RESERVED1: 7;
  };
  uint32_t Word;
} BPLC_CFG32_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET00: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET01: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG33_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET02: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET03: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG34_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET04: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET05: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG35_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET06: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET07: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG36_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET08: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET09: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG37_Typedef;

typedef union
{
  struct
  {
    uint32_t PB_OFFSET10: 14;
    uint32_t RESERVED0: 2;
    uint32_t PB_OFFSET11: 14;
    uint32_t RESERVED1: 2;
  };
  uint32_t Word;
} BPLC_CFG38_Typedef;

typedef union
{
  struct
  {
    uint32_t CARRIER_N: 11;
    uint32_t RESERVED0: 5;
    uint32_t ADP_TH: 4;
    uint32_t ADP_GAIN: 3;
    uint32_t DC_MASK: 9;
  };
  uint32_t Word;
} BPLC_CFG39_Typedef;

typedef union
{
  struct
  {
    uint32_t RSSI_V: 8;
    uint32_t RSSI_INT: 8;
    uint32_t AGC_GAIN: 8;
    uint32_t CH_SNR: 8;
  };
  uint32_t Word;
} BPLC_RSSI_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} BPLC_GAIN_Typedef;

typedef union
{
  struct
  {
    uint32_t BPLC_DBG: 4;
    uint32_t ACS: 1;
    uint32_t DCS: 1;
    uint32_t PCS: 1;
    uint32_t APS: 1;
    uint32_t SYMBOL_DLY: 3;
    uint32_t RESERVED1: 1;
    uint32_t CEX: 1;
    uint32_t PEX: 1;
    uint32_t ECF: 1;
    uint32_t PCE: 1;
    uint32_t PCT: 2;
    uint32_t RESERVED2: 2;
    uint32_t AVS: 4;
    uint32_t RESERVED3: 8;
  };
  uint32_t Word;
} BPLC_DBG00_Typedef;
typedef union
{
  struct
  {
    uint32_t PBE_GAIN: 8;
    uint32_t FCH_GAIN: 8;
    uint32_t PLD_GAIN: 8;
    uint32_t RESERVED0: 8;
  };
  uint32_t Word;
} BPLC_CFG40_Typedef;

typedef union
{
  struct
  {
    uint32_t NTB_VSEL: 4;
    uint32_t PINT_SEL: 3;
    uint32_t RESERVED0: 25;
  };
  uint32_t Word;
} BPLC_NTB_CFG_Typedef;

typedef union
{
  uint32_t VALUE;
  uint32_t Word;
} BPLC_TX_BTT_OFFSET_Typedef;

typedef union
{
  uint32_t VALUE;
  uint32_t Word;
} BPLC_RX_BTT_OFFSET_Typedef;

typedef union
{
  uint32_t VALUE;
  uint32_t Word;
} BPLC_NTB_VALUE_Typedef;

typedef union
{
  uint32_t VALUE;
  uint32_t Word;
} BPLC_BTT_VALUE_Typedef;

typedef union
{
  struct
  {
    uint32_t CGRP: 8;
    uint32_t RP_NUM: 4;
    uint32_t ROB: 1;
    uint32_t ILV: 1;
    uint32_t TUB: 1;
    uint32_t PTS: 1;
    uint32_t BTS: 1;
    uint32_t BTO: 1;
    uint32_t BSP: 5;
    uint32_t BIO: 1;
    uint32_t RAE: 1;
    uint32_t RESERVED0: 7;
  };
  uint32_t Word;
} BPLC_CFG50_Typedef;

typedef union
{
  struct
  {
    uint32_t TMSK_0: 1;
    uint32_t TMSK_1: 1;
    uint32_t TMSK_2: 1;
    uint32_t TMSK_3: 1;
    uint32_t TMSK_4: 1;
    uint32_t TMSK_5: 1;
    uint32_t TMSK_6: 1;
    uint32_t TMSK_7: 1;
    uint32_t TMSK_8: 1;
    uint32_t TMSK_9: 1;
    uint32_t TMSK_10: 1;
    uint32_t TMSK_11: 1;
    uint32_t TMSK_12: 1;
    uint32_t TMSK_13: 1;
    uint32_t TMSK_14: 1;
    uint32_t TMSK_15: 1;
    uint32_t TMSK_16: 1;
    uint32_t TMSK_17: 1;
    uint32_t TMSK_18: 1;
    uint32_t TMSK_19: 1;
    uint32_t TMSK_20: 1;
    uint32_t TMSK_21: 1;
    uint32_t TMSK_22: 1;
    uint32_t TMSK_23: 1;
    uint32_t TMSK_24: 1;
    uint32_t TMSK_25: 1;
    uint32_t TMSK_26: 1;
    uint32_t TMSK_27: 1;
    uint32_t TMSK_28: 1;
    uint32_t TMSK_29: 1;
    uint32_t TMSK_30: 1;
    uint32_t TMSK_31: 1;
  };
  uint32_t Word;
} BPLC_TMSK_CFG_Typedef;

typedef union
{
  struct
  {
    uint32_t FLT_COEF: 8;
    uint32_t RESERVED0: 24;
  };
  uint32_t Word;
} BPLC_FLT_COEF_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB00: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB01: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG00_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB02: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB03: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG01_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB04: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB05: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG02_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB06: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB07: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG03_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB08: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB09: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG04_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB10: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB11: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG05_Typedef;


typedef union
{
  struct
  {
    uint32_t PGA_GC_TB12: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB13: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG06_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB14: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB15: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG07_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB16: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB17: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG08_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB18: 12;
    uint32_t RESERVED0: 4;
    uint32_t PGA_GC_TB19: 12;
    uint32_t RESERVED1: 4;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG09_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_GC_TB20: 12;
    uint32_t RESERVED0: 20;
  };
  uint32_t Word;
} BPLC_PGA_GC_CFG10_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S00: 6;
    uint32_t RESERVED0: 2;
    uint32_t PGA_OFFSET_S01: 6;
    uint32_t RESERVED1: 2;
    uint32_t PGA_OFFSET_S02: 6;
    uint32_t RESERVED2: 2;
    uint32_t PGA_OFFSET_S03: 6;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG00_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S04: 6;
    uint32_t RESERVED0: 2;
    uint32_t PGA_OFFSET_S05: 6;
    uint32_t RESERVED1: 2;
    uint32_t PGA_OFFSET_S06: 6;
    uint32_t RESERVED2: 2;
    uint32_t PGA_OFFSET_S07: 6;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG01_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S08: 6;
    uint32_t RESERVED0: 2;
    uint32_t PGA_OFFSET_S09: 6;
    uint32_t RESERVED1: 2;
    uint32_t PGA_OFFSET_S10: 6;
    uint32_t RESERVED2: 2;
    uint32_t PGA_OFFSET_S11: 6;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG02_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S12: 6;
    uint32_t RESERVED0: 2;
    uint32_t PGA_OFFSET_S13: 6;
    uint32_t RESERVED1: 2;
    uint32_t PGA_OFFSET_S14: 6;
    uint32_t RESERVED2: 2;
    uint32_t PGA_OFFSET_S15: 6;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG03_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S16: 6;
    uint32_t RESERVED0: 2;
    uint32_t PGA_OFFSET_S17: 6;
    uint32_t RESERVED1: 2;
    uint32_t PGA_OFFSET_S18: 6;
    uint32_t RESERVED2: 2;
    uint32_t PGA_OFFSET_S19: 6;
    uint32_t RESERVED3: 2;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG04_Typedef;

typedef union
{
  struct
  {
    uint32_t PGA_OFFSET_S16: 6;
    uint32_t RESERVED0: 26;
  };
  uint32_t Word;
} BPLC_PGA_OFFSET_CFG05_Typedef;

typedef union
{
  struct
  {
    uint32_t REF0001: 3;
    uint32_t RESERVED0: 1;
    uint32_t REF0002: 3;
    uint32_t RESERVED1: 1;
    uint32_t REF0003: 3;
    uint32_t RESERVED2: 1;
    uint32_t REF0004: 3;
    uint32_t RESERVED3: 1;
    uint32_t REF0005: 3;
    uint32_t RESERVED4: 1;
    uint32_t REF0006: 3;
    uint32_t RESERVED5: 1;
    uint32_t REF0007: 3;
    uint32_t RESERVED6: 1;
    uint32_t REF0008: 3;
    uint32_t RESERVED7: 1;
  };
  uint32_t Word;
} BPLC_REF_CFG_Typedef;

typedef struct
{
  __IO BPLC_AFE00_Typedef AFE00;
  __IO BPLC_AFE01_Typedef AFE01;
  __IO BPLC_AFE02_Typedef AFE02;
  __IO BPLC_AFE03_Typedef AFE03;
  __IO BPLC_AFE04_Typedef AFE04;
  __IO BPLC_AFE05_Typedef AFE05;
  __IO BPLC_AFE06_Typedef AFE06;
  __IO BPLC_AFE07_Typedef AFE07;

  __IO BPLC_CTRL0_Typedef CTRL0;
  __IO BPLC_CTRL1_Typedef CTRL1;

  __IO BPLC_CFG00_Typedef CFG00;
  __IO BPLC_CFG01_Typedef CFG01;
  __IO BPLC_CFG02_Typedef CFG02;
  __IO BPLC_CFG03_Typedef CFG03;
  __IO BPLC_CFG04_Typedef CFG04;
  __IO BPLC_CFG05_Typedef CFG05;
  __IO BPLC_CFG06_Typedef CFG06;
  __IO BPLC_CFG07_Typedef CFG07;
  __IO BPLC_CFG08_Typedef CFG08;
  __IO BPLC_CFG09_Typedef CFG09;
  __IO BPLC_CFG10_Typedef CFG10;
  __IO BPLC_CFG11_Typedef CFG11;
  __IO BPLC_CFG12_Typedef CFG12;
  __IO BPLC_CFG13_Typedef CFG13;
  __IO BPLC_CFG14_Typedef CFG14;
  __IO BPLC_CFG15_Typedef CFG15;
  __IO BPLC_CFG16_Typedef CFG16;
  __IO BPLC_CFG17_Typedef CFG17;
  __IO BPLC_CFG18_Typedef CFG18;
  __IO BPLC_CFG19_Typedef CFG19;
  __IO BPLC_CFG20_Typedef CFG20;
  __IO BPLC_CFG21_Typedef CFG21;
  __IO BPLC_CFG22_Typedef CFG22;
  __IO BPLC_CFG23_Typedef CFG23;
  __IO BPLC_CFG24_Typedef CFG24;
  __IO BPLC_CFG25_Typedef CFG25;
  __IO BPLC_CFG26_Typedef CFG26;
  __IO BPLC_CFG27_Typedef CFG27;
  __IO BPLC_CFG28_Typedef CFG28;
  __IO BPLC_CFG29_Typedef CFG29;
  __IO BPLC_CFG30_Typedef CFG30;
  __IO BPLC_CFG31_Typedef CFG31;
  __IO BPLC_CFG32_Typedef CFG32;
  __IO BPLC_CFG33_Typedef CFG33;
  __IO BPLC_CFG34_Typedef CFG34;
  __IO BPLC_CFG35_Typedef CFG35;
  __IO BPLC_CFG36_Typedef CFG36;
  __IO BPLC_CFG37_Typedef CFG37;
  __IO BPLC_CFG38_Typedef CFG38;
  __IO BPLC_CFG39_Typedef CFG39;

  __IO BPLC_RSSI_Typedef BPLC_RSSI;
  __IO BPLC_CLRIF_Typedef CLRIF;
  __IO BPLC_DBG00_Typedef DBG00;
  __IO BPLC_CFG40_Typedef CFG40;

  uint32_t RESERVED0[3];

  __IO BPLC_NTB_CFG_Typedef NTB_CFG;
  __IO BPLC_TX_BTT_OFFSET_Typedef TX_BTT_OFFSET;
  __IO BPLC_RX_BTT_OFFSET_Typedef RX_BTT_OFFSET;
  __IO BPLC_NTB_VALUE_Typedef NTB_VALUE;
  __IO BPLC_BTT_VALUE_Typedef BTT_VALUE;

  __IO BPLC_CFG50_Typedef CFG50;

  uint32_t RESERVED1;

  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG00;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG01;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG02;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG03;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG04;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG05;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG06;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG07;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG08;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG09;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG10;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG11;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG12;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG13;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG14;
  __IO BPLC_TMSK_CFG_Typedef TMSK_CFG15;

  __IO BPLC_FLT_COEF_Typedef FLT_COEF00;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF01;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF02;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF03;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF04;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF05;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF06;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF07;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF08;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF09;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF10;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF11;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF12;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF13;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF14;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF15;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF16;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF17;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF18;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF19;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF20;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF21;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF22;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF23;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF24;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF25;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF26;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF27;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF28;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF29;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF30;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF31;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF32;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF33;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF34;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF35;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF36;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF37;
  __IO BPLC_FLT_COEF_Typedef FLT_COEF38;

  __IO BPLC_PGA_GC_CFG00_Typedef PGA_GC_CFG00;
  __IO BPLC_PGA_GC_CFG01_Typedef PGA_GC_CFG01;
  __IO BPLC_PGA_GC_CFG02_Typedef PGA_GC_CFG02;
  __IO BPLC_PGA_GC_CFG03_Typedef PGA_GC_CFG03;
  __IO BPLC_PGA_GC_CFG04_Typedef PGA_GC_CFG04;
  __IO BPLC_PGA_GC_CFG05_Typedef PGA_GC_CFG05;
  __IO BPLC_PGA_GC_CFG06_Typedef PGA_GC_CFG06;
  __IO BPLC_PGA_GC_CFG07_Typedef PGA_GC_CFG07;
  __IO BPLC_PGA_GC_CFG08_Typedef PGA_GC_CFG08;
  __IO BPLC_PGA_GC_CFG09_Typedef PGA_GC_CFG09;
  __IO BPLC_PGA_GC_CFG10_Typedef PGA_GC_CFG10;

  uint32_t RESERVED2[2];

  __IO BPLC_PGA_OFFSET_CFG00_Typedef PGA_OFFSET_CFG00;
  __IO BPLC_PGA_OFFSET_CFG01_Typedef PGA_OFFSET_CFG01;
  __IO BPLC_PGA_OFFSET_CFG02_Typedef PGA_OFFSET_CFG02;
  __IO BPLC_PGA_OFFSET_CFG03_Typedef PGA_OFFSET_CFG03;
  __IO BPLC_PGA_OFFSET_CFG04_Typedef PGA_OFFSET_CFG04;
  __IO BPLC_PGA_OFFSET_CFG05_Typedef PGA_OFFSET_CFG05;

  uint32_t RESERVED3[118];

  __IO BPLC_REF_CFG_Typedef REF_CFG000;
  __IO BPLC_REF_CFG_Typedef REF_CFG001;
  __IO BPLC_REF_CFG_Typedef REF_CFG002;
  __IO BPLC_REF_CFG_Typedef REF_CFG003;
  __IO BPLC_REF_CFG_Typedef REF_CFG004;
  __IO BPLC_REF_CFG_Typedef REF_CFG005;
  __IO BPLC_REF_CFG_Typedef REF_CFG006;
  __IO BPLC_REF_CFG_Typedef REF_CFG007;
  __IO BPLC_REF_CFG_Typedef REF_CFG008;
  __IO BPLC_REF_CFG_Typedef REF_CFG009;
  __IO BPLC_REF_CFG_Typedef REF_CFG010;
  __IO BPLC_REF_CFG_Typedef REF_CFG011;
  __IO BPLC_REF_CFG_Typedef REF_CFG012;
  __IO BPLC_REF_CFG_Typedef REF_CFG013;
  __IO BPLC_REF_CFG_Typedef REF_CFG014;
  __IO BPLC_REF_CFG_Typedef REF_CFG015;
  __IO BPLC_REF_CFG_Typedef REF_CFG016;
  __IO BPLC_REF_CFG_Typedef REF_CFG017;
  __IO BPLC_REF_CFG_Typedef REF_CFG018;
  __IO BPLC_REF_CFG_Typedef REF_CFG019;
  __IO BPLC_REF_CFG_Typedef REF_CFG020;
  __IO BPLC_REF_CFG_Typedef REF_CFG021;
  __IO BPLC_REF_CFG_Typedef REF_CFG022;
  __IO BPLC_REF_CFG_Typedef REF_CFG023;
  __IO BPLC_REF_CFG_Typedef REF_CFG024;
  __IO BPLC_REF_CFG_Typedef REF_CFG025;
  __IO BPLC_REF_CFG_Typedef REF_CFG026;
  __IO BPLC_REF_CFG_Typedef REF_CFG027;
  __IO BPLC_REF_CFG_Typedef REF_CFG028;
  __IO BPLC_REF_CFG_Typedef REF_CFG029;
  __IO BPLC_REF_CFG_Typedef REF_CFG030;
  __IO BPLC_REF_CFG_Typedef REF_CFG031;
  __IO BPLC_REF_CFG_Typedef REF_CFG032;
  __IO BPLC_REF_CFG_Typedef REF_CFG033;
  __IO BPLC_REF_CFG_Typedef REF_CFG034;
  __IO BPLC_REF_CFG_Typedef REF_CFG035;
  __IO BPLC_REF_CFG_Typedef REF_CFG036;
  __IO BPLC_REF_CFG_Typedef REF_CFG037;
  __IO BPLC_REF_CFG_Typedef REF_CFG038;
  __IO BPLC_REF_CFG_Typedef REF_CFG039;
  __IO BPLC_REF_CFG_Typedef REF_CFG040;
  __IO BPLC_REF_CFG_Typedef REF_CFG041;
  __IO BPLC_REF_CFG_Typedef REF_CFG042;
  __IO BPLC_REF_CFG_Typedef REF_CFG043;
  __IO BPLC_REF_CFG_Typedef REF_CFG044;
  __IO BPLC_REF_CFG_Typedef REF_CFG045;
  __IO BPLC_REF_CFG_Typedef REF_CFG046;
  __IO BPLC_REF_CFG_Typedef REF_CFG047;
  __IO BPLC_REF_CFG_Typedef REF_CFG048;
  __IO BPLC_REF_CFG_Typedef REF_CFG049;
  __IO BPLC_REF_CFG_Typedef REF_CFG050;
  __IO BPLC_REF_CFG_Typedef REF_CFG051;
  __IO BPLC_REF_CFG_Typedef REF_CFG052;
  __IO BPLC_REF_CFG_Typedef REF_CFG053;
  __IO BPLC_REF_CFG_Typedef REF_CFG054;
  __IO BPLC_REF_CFG_Typedef REF_CFG055;
  __IO BPLC_REF_CFG_Typedef REF_CFG056;
  __IO BPLC_REF_CFG_Typedef REF_CFG057;
  __IO BPLC_REF_CFG_Typedef REF_CFG058;
  __IO BPLC_REF_CFG_Typedef REF_CFG059;
  __IO BPLC_REF_CFG_Typedef REF_CFG060;
  __IO BPLC_REF_CFG_Typedef REF_CFG061;
  __IO BPLC_REF_CFG_Typedef REF_CFG062;
  __IO BPLC_REF_CFG_Typedef REF_CFG063;
  __IO BPLC_REF_CFG_Typedef REF_CFG064;
  __IO BPLC_REF_CFG_Typedef REF_CFG065;
  __IO BPLC_REF_CFG_Typedef REF_CFG066;
  __IO BPLC_REF_CFG_Typedef REF_CFG067;
  __IO BPLC_REF_CFG_Typedef REF_CFG068;
  __IO BPLC_REF_CFG_Typedef REF_CFG069;
  __IO BPLC_REF_CFG_Typedef REF_CFG070;
  __IO BPLC_REF_CFG_Typedef REF_CFG071;
  __IO BPLC_REF_CFG_Typedef REF_CFG072;
  __IO BPLC_REF_CFG_Typedef REF_CFG073;
  __IO BPLC_REF_CFG_Typedef REF_CFG074;
  __IO BPLC_REF_CFG_Typedef REF_CFG075;
  __IO BPLC_REF_CFG_Typedef REF_CFG076;
  __IO BPLC_REF_CFG_Typedef REF_CFG077;
  __IO BPLC_REF_CFG_Typedef REF_CFG078;
  __IO BPLC_REF_CFG_Typedef REF_CFG079;
  __IO BPLC_REF_CFG_Typedef REF_CFG080;
  __IO BPLC_REF_CFG_Typedef REF_CFG081;
  __IO BPLC_REF_CFG_Typedef REF_CFG082;
  __IO BPLC_REF_CFG_Typedef REF_CFG083;
  __IO BPLC_REF_CFG_Typedef REF_CFG084;
  __IO BPLC_REF_CFG_Typedef REF_CFG085;
  __IO BPLC_REF_CFG_Typedef REF_CFG086;
  __IO BPLC_REF_CFG_Typedef REF_CFG087;
  __IO BPLC_REF_CFG_Typedef REF_CFG088;
  __IO BPLC_REF_CFG_Typedef REF_CFG089;
  __IO BPLC_REF_CFG_Typedef REF_CFG090;
  __IO BPLC_REF_CFG_Typedef REF_CFG091;
  __IO BPLC_REF_CFG_Typedef REF_CFG092;
  __IO BPLC_REF_CFG_Typedef REF_CFG093;
  __IO BPLC_REF_CFG_Typedef REF_CFG094;
  __IO BPLC_REF_CFG_Typedef REF_CFG095;
  __IO BPLC_REF_CFG_Typedef REF_CFG096;
  __IO BPLC_REF_CFG_Typedef REF_CFG097;
  __IO BPLC_REF_CFG_Typedef REF_CFG098;
  __IO BPLC_REF_CFG_Typedef REF_CFG099;
  __IO BPLC_REF_CFG_Typedef REF_CFG100;
  __IO BPLC_REF_CFG_Typedef REF_CFG101;
  __IO BPLC_REF_CFG_Typedef REF_CFG102;
  __IO BPLC_REF_CFG_Typedef REF_CFG103;
  __IO BPLC_REF_CFG_Typedef REF_CFG104;
  __IO BPLC_REF_CFG_Typedef REF_CFG105;
  __IO BPLC_REF_CFG_Typedef REF_CFG106;
  __IO BPLC_REF_CFG_Typedef REF_CFG107;
  __IO BPLC_REF_CFG_Typedef REF_CFG108;
  __IO BPLC_REF_CFG_Typedef REF_CFG109;
  __IO BPLC_REF_CFG_Typedef REF_CFG110;
  __IO BPLC_REF_CFG_Typedef REF_CFG111;
  __IO BPLC_REF_CFG_Typedef REF_CFG112;
  __IO BPLC_REF_CFG_Typedef REF_CFG113;
  __IO BPLC_REF_CFG_Typedef REF_CFG114;
  __IO BPLC_REF_CFG_Typedef REF_CFG115;
  __IO BPLC_REF_CFG_Typedef REF_CFG116;
  __IO BPLC_REF_CFG_Typedef REF_CFG117;
  __IO BPLC_REF_CFG_Typedef REF_CFG118;
  __IO BPLC_REF_CFG_Typedef REF_CFG119;
  __IO BPLC_REF_CFG_Typedef REF_CFG120;
  __IO BPLC_REF_CFG_Typedef REF_CFG121;
  __IO BPLC_REF_CFG_Typedef REF_CFG122;
  __IO BPLC_REF_CFG_Typedef REF_CFG123;
  __IO BPLC_REF_CFG_Typedef REF_CFG124;
  __IO BPLC_REF_CFG_Typedef REF_CFG125;
  __IO BPLC_REF_CFG_Typedef REF_CFG126;
  __IO BPLC_REF_CFG_Typedef REF_CFG127;
} BPLC_TypeDef;


// ������μĴ����Ǹ�FPGA�����ļĴ�����ʵ��оƬû�У�������ģ��ǰ�˰���ϵ�
/******************************************************************************/
/************************************* FPGA PGA *******************************/
/******************************************************************************/
typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG00_Typedef;

typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG01_Typedef;

typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG02_Typedef;

typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG03_Typedef;

typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG04_Typedef;

typedef union
{
  uint32_t Word;
} FPGA_PGA2_GC_CFG05_Typedef;

typedef struct
{
  __IO FPGA_PGA2_GC_CFG00_Typedef PGA2_GC_CFG00;
  __IO FPGA_PGA2_GC_CFG01_Typedef PGA2_GC_CFG01;
  __IO FPGA_PGA2_GC_CFG02_Typedef PGA2_GC_CFG02;
  __IO FPGA_PGA2_GC_CFG03_Typedef PGA2_GC_CFG03;
  __IO FPGA_PGA2_GC_CFG04_Typedef PGA2_GC_CFG04;
  __IO FPGA_PGA2_GC_CFG05_Typedef PGA2_GC_CFG05;

} FPGA_PGA_TypeDef;


/******************************************************************************/
/************************************* DMA ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RESERVED0: 3;
    uint32_t State: 4;
    uint32_t RESERVED1: 8;
    uint32_t Chnls_minus1: 5;
    uint32_t RESERVED2: 7;
    uint32_t Test_status: 4;
  };
  uint32_t Word;
} DMA_STA_Typedef;

typedef union
{
  struct
  {
    uint32_t EN: 1;
    uint32_t RESERVED0: 4;
    uint32_t Chnl_prot_ctrl: 3;
    uint32_t RESERVED1: 24;
  };
  uint32_t Word;
} DMA_CFG_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 8;
    uint32_t Ctrl_base_ptr: 24;
  };
  uint32_t Word;
} DMA_CTRLBASEPTR_Typedef;

typedef union
{
  struct
  {
    uint32_t ALTCTRLBASEPTR: 32;
  };
  uint32_t Word;
} DMA_ALTCTRLBASEPTR_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_waitonreq_status_0: 1;
    uint32_t Dma_waitonreq_status_1: 1;
    uint32_t Dma_waitonreq_status_2: 1;
    uint32_t Dma_waitonreq_status_3: 1;
    uint32_t Dma_waitonreq_status_4: 1;
    uint32_t Dma_waitonreq_status_5: 1;
    uint32_t Dma_waitonreq_status_6: 1;
    uint32_t Dma_waitonreq_status_7: 1;
    uint32_t Dma_waitonreq_status_8: 1;
    uint32_t Dma_waitonreq_status_9: 1;
    uint32_t Dma_waitonreq_status_10: 1;
    uint32_t Dma_waitonreq_status_11: 1;
    uint32_t Dma_waitonreq_status_12: 1;
    uint32_t Dma_waitonreq_status_13: 1;
    uint32_t Dma_waitonreq_status_14: 1;
    uint32_t Dma_waitonreq_status_15: 1;
    uint32_t Dma_waitonreq_status_16: 1;
    uint32_t Dma_waitonreq_status_17: 1;
    uint32_t Dma_waitonreq_status_18: 1;
    uint32_t Dma_waitonreq_status_19: 1;
    uint32_t Dma_waitonreq_status_20: 1;
    uint32_t Dma_waitonreq_status_21: 1;
    uint32_t Dma_waitonreq_status_22: 1;
    uint32_t Dma_waitonreq_status_23: 1;
    uint32_t Dma_waitonreq_status_24: 1;
    uint32_t Dma_waitonreq_status_25: 1;
    uint32_t Dma_waitonreq_status_26: 1;
    uint32_t Dma_waitonreq_status_27: 1;
    uint32_t Dma_waitonreq_status_28: 1;
    uint32_t Dma_waitonreq_status_29: 1;
    uint32_t Dma_waitonreq_status_30: 1;
    uint32_t Dma_waitonreq_status_31: 1;
  };
  uint32_t Word;
} DMA_WTonREQSTA_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_sw_req_0: 1;
    uint32_t Chnl_sw_req_1: 1;
    uint32_t Chnl_sw_req_2: 1;
    uint32_t Chnl_sw_req_3: 1;
    uint32_t Chnl_sw_req_4: 1;
    uint32_t Chnl_sw_req_5: 1;
    uint32_t Chnl_sw_req_6: 1;
    uint32_t Chnl_sw_req_7: 1;
    uint32_t Chnl_sw_req_8: 1;
    uint32_t plc_tx: 1;
    uint32_t plc_rx: 1;
    uint32_t Chnl_sw_req_11: 1;
    uint32_t Chnl_sw_req_12: 1;
    uint32_t Chnl_sw_req_13: 1;
    uint32_t Chnl_sw_req_14: 1;
    uint32_t Chnl_sw_req_15: 1;
    uint32_t Chnl_sw_req_16: 1;
    uint32_t Chnl_sw_req_17: 1;
    uint32_t Chnl_sw_req_18: 1;
    uint32_t Chnl_sw_req_19: 1;
    uint32_t Chnl_sw_req_20: 1;
    uint32_t Chnl_sw_req_21: 1;
    uint32_t Chnl_sw_req_22: 1;
    uint32_t Chnl_sw_req_23: 1;
    uint32_t Chnl_sw_req_24: 1;
    uint32_t Chnl_sw_req_25: 1;
    uint32_t Chnl_sw_req_26: 1;
    uint32_t Chnl_sw_req_27: 1;
    uint32_t Chnl_sw_req_28: 1;
    uint32_t Chnl_sw_req_29: 1;
    uint32_t Chnl_sw_req_30: 1;
    uint32_t Chnl_sw_req_31: 1;
  };
  uint32_t Word;
} DMA_SWREQ_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_useburst_set_0: 1;
    uint32_t Chnl_useburst_set_1: 1;
    uint32_t Chnl_useburst_set_2: 1;
    uint32_t Chnl_useburst_set_3: 1;
    uint32_t Chnl_useburst_set_4: 1;
    uint32_t Chnl_useburst_set_5: 1;
    uint32_t Chnl_useburst_set_6: 1;
    uint32_t Chnl_useburst_set_7: 1;
    uint32_t Chnl_useburst_set_8: 1;
    uint32_t Chnl_useburst_set_9: 1;
    uint32_t Chnl_useburst_set_10: 1;
    uint32_t Chnl_useburst_set_11: 1;
    uint32_t Chnl_useburst_set_12: 1;
    uint32_t Chnl_useburst_set_13: 1;
    uint32_t Chnl_useburst_set_14: 1;
    uint32_t Chnl_useburst_set_15: 1;
    uint32_t Chnl_useburst_set_16: 1;
    uint32_t Chnl_useburst_set_17: 1;
    uint32_t Chnl_useburst_set_18: 1;
    uint32_t Chnl_useburst_set_19: 1;
    uint32_t Chnl_useburst_set_20: 1;
    uint32_t Chnl_useburst_set_21: 1;
    uint32_t Chnl_useburst_set_22: 1;
    uint32_t Chnl_useburst_set_23: 1;
    uint32_t Chnl_useburst_set_24: 1;
    uint32_t Chnl_useburst_set_25: 1;
    uint32_t Chnl_useburst_set_26: 1;
    uint32_t Chnl_useburst_set_27: 1;
    uint32_t Chnl_useburst_set_28: 1;
    uint32_t Chnl_useburst_set_29: 1;
    uint32_t Chnl_useburst_set_30: 1;
    uint32_t Chnl_useburst_set_31: 1;
  };
  uint32_t Word;
} DMA_USEBURSTSET_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_useburst_clr_0: 1;
    uint32_t Chnl_useburst_clr_1: 1;
    uint32_t Chnl_useburst_clr_2: 1;
    uint32_t Chnl_useburst_clr_3: 1;
    uint32_t Chnl_useburst_clr_4: 1;
    uint32_t Chnl_useburst_clr_5: 1;
    uint32_t Chnl_useburst_clr_6: 1;
    uint32_t Chnl_useburst_clr_7: 1;
    uint32_t Chnl_useburst_clr_8: 1;
    uint32_t Chnl_useburst_clr_9: 1;
    uint32_t Chnl_useburst_clr_10: 1;
    uint32_t Chnl_useburst_clr_11: 1;
    uint32_t Chnl_useburst_clr_12: 1;
    uint32_t Chnl_useburst_clr_13: 1;
    uint32_t Chnl_useburst_clr_14: 1;
    uint32_t Chnl_useburst_clr_15: 1;
    uint32_t Chnl_useburst_clr_16: 1;
    uint32_t Chnl_useburst_clr_17: 1;
    uint32_t Chnl_useburst_clr_18: 1;
    uint32_t Chnl_useburst_clr_19: 1;
    uint32_t Chnl_useburst_clr_20: 1;
    uint32_t Chnl_useburst_clr_21: 1;
    uint32_t Chnl_useburst_clr_22: 1;
    uint32_t Chnl_useburst_clr_23: 1;
    uint32_t Chnl_useburst_clr_24: 1;
    uint32_t Chnl_useburst_clr_25: 1;
    uint32_t Chnl_useburst_clr_26: 1;
    uint32_t Chnl_useburst_clr_27: 1;
    uint32_t Chnl_useburst_clr_28: 1;
    uint32_t Chnl_useburst_clr_29: 1;
    uint32_t Chnl_useburst_clr_30: 1;
    uint32_t Chnl_useburst_clr_31: 1;
  };
  uint32_t Word;
} DMA_USEBURSTCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_req_mask_set_0: 1;
    uint32_t Chnl_req_mask_set_1: 1;
    uint32_t Chnl_req_mask_set_2: 1;
    uint32_t Chnl_req_mask_set_3: 1;
    uint32_t Chnl_req_mask_set_4: 1;
    uint32_t Chnl_req_mask_set_5: 1;
    uint32_t Chnl_req_mask_set_6: 1;
    uint32_t Chnl_req_mask_set_7: 1;
    uint32_t Chnl_req_mask_set_8: 1;
    uint32_t Chnl_req_mask_set_9: 1;
    uint32_t Chnl_req_mask_set_10: 1;
    uint32_t Chnl_req_mask_set_11: 1;
    uint32_t Chnl_req_mask_set_12: 1;
    uint32_t Chnl_req_mask_set_13: 1;
    uint32_t Chnl_req_mask_set_14: 1;
    uint32_t Chnl_req_mask_set_15: 1;
    uint32_t Chnl_req_mask_set_16: 1;
    uint32_t Chnl_req_mask_set_17: 1;
    uint32_t Chnl_req_mask_set_18: 1;
    uint32_t Chnl_req_mask_set_19: 1;
    uint32_t Chnl_req_mask_set_20: 1;
    uint32_t Chnl_req_mask_set_21: 1;
    uint32_t Chnl_req_mask_set_22: 1;
    uint32_t Chnl_req_mask_set_23: 1;
    uint32_t Chnl_req_mask_set_24: 1;
    uint32_t Chnl_req_mask_set_25: 1;
    uint32_t Chnl_req_mask_set_26: 1;
    uint32_t Chnl_req_mask_set_27: 1;
    uint32_t Chnl_req_mask_set_28: 1;
    uint32_t Chnl_req_mask_set_29: 1;
    uint32_t Chnl_req_mask_set_30: 1;
    uint32_t Chnl_req_mask_set_31: 1;
  };
  uint32_t Word;
} DMA_REQMASKSET_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_req_mask_clr_0: 1;
    uint32_t Chnl_req_mask_clr_1: 1;
    uint32_t Chnl_req_mask_clr_2: 1;
    uint32_t Chnl_req_mask_clr_3: 1;
    uint32_t Chnl_req_mask_clr_4: 1;
    uint32_t Chnl_req_mask_clr_5: 1;
    uint32_t Chnl_req_mask_clr_6: 1;
    uint32_t Chnl_req_mask_clr_7: 1;
    uint32_t Chnl_req_mask_clr_8: 1;
    uint32_t Chnl_req_mask_clr_9: 1;
    uint32_t Chnl_req_mask_clr_10: 1;
    uint32_t Chnl_req_mask_clr_11: 1;
    uint32_t Chnl_req_mask_clr_12: 1;
    uint32_t Chnl_req_mask_clr_13: 1;
    uint32_t Chnl_req_mask_clr_14: 1;
    uint32_t Chnl_req_mask_clr_15: 1;
    uint32_t Chnl_req_mask_clr_16: 1;
    uint32_t Chnl_req_mask_clr_17: 1;
    uint32_t Chnl_req_mask_clr_18: 1;
    uint32_t Chnl_req_mask_clr_19: 1;
    uint32_t Chnl_req_mask_clr_20: 1;
    uint32_t Chnl_req_mask_clr_21: 1;
    uint32_t Chnl_req_mask_clr_22: 1;
    uint32_t Chnl_req_mask_clr_23: 1;
    uint32_t Chnl_req_mask_clr_24: 1;
    uint32_t Chnl_req_mask_clr_25: 1;
    uint32_t Chnl_req_mask_clr_26: 1;
    uint32_t Chnl_req_mask_clr_27: 1;
    uint32_t Chnl_req_mask_clr_28: 1;
    uint32_t Chnl_req_mask_clr_29: 1;
    uint32_t Chnl_req_mask_clr_30: 1;
    uint32_t Chnl_req_mask_clr_31: 1;
  };
  uint32_t Word;
} DMA_REQMASKCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_enable_set_0: 1;
    uint32_t Chnl_enable_set_1: 1;
    uint32_t Chnl_enable_set_2: 1;
    uint32_t Chnl_enable_set_3: 1;
    uint32_t Chnl_enable_set_4: 1;
    uint32_t Chnl_enable_set_5: 1;
    uint32_t Chnl_enable_set_6: 1;
    uint32_t Chnl_enable_set_7: 1;
    uint32_t Chnl_enable_set_8: 1;
    uint32_t Chnl_enable_set_9: 1;
    uint32_t Chnl_enable_set_10: 1;
    uint32_t Chnl_enable_set_11: 1;
    uint32_t Chnl_enable_set_12: 1;
    uint32_t Chnl_enable_set_13: 1;
    uint32_t Chnl_enable_set_14: 1;
    uint32_t Chnl_enable_set_15: 1;
    uint32_t Chnl_enable_set_16: 1;
    uint32_t Chnl_enable_set_17: 1;
    uint32_t Chnl_enable_set_18: 1;
    uint32_t Chnl_enable_set_19: 1;
    uint32_t Chnl_enable_set_20: 1;
    uint32_t Chnl_enable_set_21: 1;
    uint32_t Chnl_enable_set_22: 1;
    uint32_t Chnl_enable_set_23: 1;
    uint32_t Chnl_enable_set_24: 1;
    uint32_t Chnl_enable_set_25: 1;
    uint32_t Chnl_enable_set_26: 1;
    uint32_t Chnl_enable_set_27: 1;
    uint32_t Chnl_enable_set_28: 1;
    uint32_t Chnl_enable_set_29: 1;
    uint32_t Chnl_enable_set_30: 1;
    uint32_t Chnl_enable_set_31: 1;
  };
  uint32_t Word;
} DMA_ENBSET_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_enable_clr_0: 1;
    uint32_t Chnl_enable_clr_1: 1;
    uint32_t Chnl_enable_clr_2: 1;
    uint32_t Chnl_enable_clr_3: 1;
    uint32_t Chnl_enable_clr_4: 1;
    uint32_t Chnl_enable_clr_5: 1;
    uint32_t Chnl_enable_clr_6: 1;
    uint32_t Chnl_enable_clr_7: 1;
    uint32_t Chnl_enable_clr_8: 1;
    uint32_t Chnl_enable_clr_9: 1;
    uint32_t Chnl_enable_clr_10: 1;
    uint32_t Chnl_enable_clr_11: 1;
    uint32_t Chnl_enable_clr_12: 1;
    uint32_t Chnl_enable_clr_13: 1;
    uint32_t Chnl_enable_clr_14: 1;
    uint32_t Chnl_enable_clr_15: 1;
    uint32_t Chnl_enable_clr_16: 1;
    uint32_t Chnl_enable_clr_17: 1;
    uint32_t Chnl_enable_clr_18: 1;
    uint32_t Chnl_enable_clr_19: 1;
    uint32_t Chnl_enable_clr_20: 1;
    uint32_t Chnl_enable_clr_21: 1;
    uint32_t Chnl_enable_clr_22: 1;
    uint32_t Chnl_enable_clr_23: 1;
    uint32_t Chnl_enable_clr_24: 1;
    uint32_t Chnl_enable_clr_25: 1;
    uint32_t Chnl_enable_clr_26: 1;
    uint32_t Chnl_enable_clr_27: 1;
    uint32_t Chnl_enable_clr_28: 1;
    uint32_t Chnl_enable_clr_29: 1;
    uint32_t Chnl_enable_clr_30: 1;
    uint32_t Chnl_enable_clr_31: 1;
  };
  uint32_t Word;
} DMA_ENBCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_pri_alt_set_0: 1;
    uint32_t Chnl_pri_alt_set_1: 1;
    uint32_t Chnl_pri_alt_set_2: 1;
    uint32_t Chnl_pri_alt_set_3: 1;
    uint32_t Chnl_pri_alt_set_4: 1;
    uint32_t Chnl_pri_alt_set_5: 1;
    uint32_t Chnl_pri_alt_set_6: 1;
    uint32_t Chnl_pri_alt_set_7: 1;
    uint32_t Chnl_pri_alt_set_8: 1;
    uint32_t Chnl_pri_alt_set_9: 1;
    uint32_t Chnl_pri_alt_set_10: 1;
    uint32_t Chnl_pri_alt_set_11: 1;
    uint32_t Chnl_pri_alt_set_12: 1;
    uint32_t Chnl_pri_alt_set_13: 1;
    uint32_t Chnl_pri_alt_set_14: 1;
    uint32_t Chnl_pri_alt_set_15: 1;
    uint32_t Chnl_pri_alt_set_16: 1;
    uint32_t Chnl_pri_alt_set_17: 1;
    uint32_t Chnl_pri_alt_set_18: 1;
    uint32_t Chnl_pri_alt_set_19: 1;
    uint32_t Chnl_pri_alt_set_20: 1;
    uint32_t Chnl_pri_alt_set_21: 1;
    uint32_t Chnl_pri_alt_set_22: 1;
    uint32_t Chnl_pri_alt_set_23: 1;
    uint32_t Chnl_pri_alt_set_24: 1;
    uint32_t Chnl_pri_alt_set_25: 1;
    uint32_t Chnl_pri_alt_set_26: 1;
    uint32_t Chnl_pri_alt_set_27: 1;
    uint32_t Chnl_pri_alt_set_28: 1;
    uint32_t Chnl_pri_alt_set_29: 1;
    uint32_t Chnl_pri_alt_set_30: 1;
    uint32_t Chnl_pri_alt_set_31: 1;
  };
  uint32_t Word;
} DMA_PRIALTSET_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_pri_alt_clr_0: 1;
    uint32_t Chnl_pri_alt_clr_1: 1;
    uint32_t Chnl_pri_alt_clr_2: 1;
    uint32_t Chnl_pri_alt_clr_3: 1;
    uint32_t Chnl_pri_alt_clr_4: 1;
    uint32_t Chnl_pri_alt_clr_5: 1;
    uint32_t Chnl_pri_alt_clr_6: 1;
    uint32_t Chnl_pri_alt_clr_7: 1;
    uint32_t Chnl_pri_alt_clr_8: 1;
    uint32_t Chnl_pri_alt_clr_9: 1;
    uint32_t Chnl_pri_alt_clr_10: 1;
    uint32_t Chnl_pri_alt_clr_11: 1;
    uint32_t Chnl_pri_alt_clr_12: 1;
    uint32_t Chnl_pri_alt_clr_13: 1;
    uint32_t Chnl_pri_alt_clr_14: 1;
    uint32_t Chnl_pri_alt_clr_15: 1;
    uint32_t Chnl_pri_alt_clr_16: 1;
    uint32_t Chnl_pri_alt_clr_17: 1;
    uint32_t Chnl_pri_alt_clr_18: 1;
    uint32_t Chnl_pri_alt_clr_19: 1;
    uint32_t Chnl_pri_alt_clr_20: 1;
    uint32_t Chnl_pri_alt_clr_21: 1;
    uint32_t Chnl_pri_alt_clr_22: 1;
    uint32_t Chnl_pri_alt_clr_23: 1;
    uint32_t Chnl_pri_alt_clr_24: 1;
    uint32_t Chnl_pri_alt_clr_25: 1;
    uint32_t Chnl_pri_alt_clr_26: 1;
    uint32_t Chnl_pri_alt_clr_27: 1;
    uint32_t Chnl_pri_alt_clr_28: 1;
    uint32_t Chnl_pri_alt_clr_29: 1;
    uint32_t Chnl_pri_alt_clr_30: 1;
    uint32_t Chnl_pri_alt_clr_31: 1;
  };
  uint32_t Word;
} DMA_PRIALTCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_priority_set_0: 1;
    uint32_t Chnl_priority_set_1: 1;
    uint32_t Chnl_priority_set_2: 1;
    uint32_t Chnl_priority_set_3: 1;
    uint32_t Chnl_priority_set_4: 1;
    uint32_t Chnl_priority_set_5: 1;
    uint32_t Chnl_priority_set_6: 1;
    uint32_t Chnl_priority_set_7: 1;
    uint32_t Chnl_priority_set_8: 1;
    uint32_t Chnl_priority_set_9: 1;
    uint32_t Chnl_priority_set_10: 1;
    uint32_t Chnl_priority_set_11: 1;
    uint32_t Chnl_priority_set_12: 1;
    uint32_t Chnl_priority_set_13: 1;
    uint32_t Chnl_priority_set_14: 1;
    uint32_t Chnl_priority_set_15: 1;
    uint32_t Chnl_priority_set_16: 1;
    uint32_t Chnl_priority_set_17: 1;
    uint32_t Chnl_priority_set_18: 1;
    uint32_t Chnl_priority_set_19: 1;
    uint32_t Chnl_priority_set_20: 1;
    uint32_t Chnl_priority_set_21: 1;
    uint32_t Chnl_priority_set_22: 1;
    uint32_t Chnl_priority_set_23: 1;
    uint32_t Chnl_priority_set_24: 1;
    uint32_t Chnl_priority_set_25: 1;
    uint32_t Chnl_priority_set_26: 1;
    uint32_t Chnl_priority_set_27: 1;
    uint32_t Chnl_priority_set_28: 1;
    uint32_t Chnl_priority_set_29: 1;
    uint32_t Chnl_priority_set_30: 1;
    uint32_t Chnl_priority_set_31: 1;
  };
  uint32_t Word;
} DMA_PRIORITYSET_Typedef;

typedef union
{
  struct
  {
    uint32_t Chnl_priority_clr_0: 1;
    uint32_t Chnl_priority_clr_1: 1;
    uint32_t Chnl_priority_clr_2: 1;
    uint32_t Chnl_priority_clr_3: 1;
    uint32_t Chnl_priority_clr_4: 1;
    uint32_t Chnl_priority_clr_5: 1;
    uint32_t Chnl_priority_clr_6: 1;
    uint32_t Chnl_priority_clr_7: 1;
    uint32_t Chnl_priority_clr_8: 1;
    uint32_t Chnl_priority_clr_9: 1;
    uint32_t Chnl_priority_clr_10: 1;
    uint32_t Chnl_priority_clr_11: 1;
    uint32_t Chnl_priority_clr_12: 1;
    uint32_t Chnl_priority_clr_13: 1;
    uint32_t Chnl_priority_clr_14: 1;
    uint32_t Chnl_priority_clr_15: 1;
    uint32_t Chnl_priority_clr_16: 1;
    uint32_t Chnl_priority_clr_17: 1;
    uint32_t Chnl_priority_clr_18: 1;
    uint32_t Chnl_priority_clr_19: 1;
    uint32_t Chnl_priority_clr_20: 1;
    uint32_t Chnl_priority_clr_21: 1;
    uint32_t Chnl_priority_clr_22: 1;
    uint32_t Chnl_priority_clr_23: 1;
    uint32_t Chnl_priority_clr_24: 1;
    uint32_t Chnl_priority_clr_25: 1;
    uint32_t Chnl_priority_clr_26: 1;
    uint32_t Chnl_priority_clr_27: 1;
    uint32_t Chnl_priority_clr_28: 1;
    uint32_t Chnl_priority_clr_29: 1;
    uint32_t Chnl_priority_clr_30: 1;
    uint32_t Chnl_priority_clr_31: 1;
  };
  uint32_t Word;
} DMA_PRIORITYCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Err_clr: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} DMA_ERRCLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Int_test_en: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} DMA_INTGRCFG_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_stall_status: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} DMA_STALLSTA_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_req_status_0: 1;
    uint32_t Dma_req_status_1: 1;
    uint32_t Dma_req_status_2: 1;
    uint32_t Dma_req_status_3: 1;
    uint32_t Dma_req_status_4: 1;
    uint32_t Dma_req_status_5: 1;
    uint32_t Dma_req_status_6: 1;
    uint32_t Dma_req_status_7: 1;
    uint32_t Dma_req_status_8: 1;
    uint32_t Dma_req_status_9: 1;
    uint32_t Dma_req_status_10: 1;
    uint32_t Dma_req_status_11: 1;
    uint32_t Dma_req_status_12: 1;
    uint32_t Dma_req_status_13: 1;
    uint32_t Dma_req_status_14: 1;
    uint32_t Dma_req_status_15: 1;
    uint32_t Dma_req_status_16: 1;
    uint32_t Dma_req_status_17: 1;
    uint32_t Dma_req_status_18: 1;
    uint32_t Dma_req_status_19: 1;
    uint32_t Dma_req_status_20: 1;
    uint32_t Dma_req_status_21: 1;
    uint32_t Dma_req_status_22: 1;
    uint32_t Dma_req_status_23: 1;
    uint32_t Dma_req_status_24: 1;
    uint32_t Dma_req_status_25: 1;
    uint32_t Dma_req_status_26: 1;
    uint32_t Dma_req_status_27: 1;
    uint32_t Dma_req_status_28: 1;
    uint32_t Dma_req_status_29: 1;
    uint32_t Dma_req_status_30: 1;
    uint32_t Dma_req_status_31: 1;
  };
  uint32_t Word;
} DMA_REQSTA_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_sreq_status_0: 1;
    uint32_t Dma_sreq_status_1: 1;
    uint32_t Dma_sreq_status_2: 1;
    uint32_t Dma_sreq_status_3: 1;
    uint32_t Dma_sreq_status_4: 1;
    uint32_t Dma_sreq_status_5: 1;
    uint32_t Dma_sreq_status_6: 1;
    uint32_t Dma_sreq_status_7: 1;
    uint32_t Dma_sreq_status_8: 1;
    uint32_t Dma_sreq_status_9: 1;
    uint32_t Dma_sreq_status_10: 1;
    uint32_t Dma_sreq_status_11: 1;
    uint32_t Dma_sreq_status_12: 1;
    uint32_t Dma_sreq_status_13: 1;
    uint32_t Dma_sreq_status_14: 1;
    uint32_t Dma_sreq_status_15: 1;
    uint32_t Dma_sreq_status_16: 1;
    uint32_t Dma_sreq_status_17: 1;
    uint32_t Dma_sreq_status_18: 1;
    uint32_t Dma_sreq_status_19: 1;
    uint32_t Dma_sreq_status_20: 1;
    uint32_t Dma_sreq_status_21: 1;
    uint32_t Dma_sreq_status_22: 1;
    uint32_t Dma_sreq_status_23: 1;
    uint32_t Dma_sreq_status_24: 1;
    uint32_t Dma_sreq_status_25: 1;
    uint32_t Dma_sreq_status_26: 1;
    uint32_t Dma_sreq_status_27: 1;
    uint32_t Dma_sreq_status_28: 1;
    uint32_t Dma_sreq_status_29: 1;
    uint32_t Dma_sreq_status_30: 1;
    uint32_t Dma_sreq_status_31: 1;
  };
  uint32_t Word;
} DMA_SREQSTA_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_done_set_0: 1;
    uint32_t Dma_done_set_1: 1;
    uint32_t Dma_done_set_2: 1;
    uint32_t Dma_done_set_3: 1;
    uint32_t Dma_done_set_4: 1;
    uint32_t Dma_done_set_5: 1;
    uint32_t Dma_done_set_6: 1;
    uint32_t Dma_done_set_7: 1;
    uint32_t Dma_done_set_8: 1;
    uint32_t plc_tx: 1;
    uint32_t plc_rx: 1;
    uint32_t Dma_done_set_11: 1;
    uint32_t Dma_done_set_12: 1;
    uint32_t Dma_done_set_13: 1;
    uint32_t Dma_done_set_14: 1;
    uint32_t Dma_done_set_15: 1;
    uint32_t Dma_done_set_16: 1;
    uint32_t Dma_done_set_17: 1;
    uint32_t Dma_done_set_18: 1;
    uint32_t Dma_done_set_19: 1;
    uint32_t Dma_done_set_20: 1;
    uint32_t Dma_done_set_21: 1;
    uint32_t Dma_done_set_22: 1;
    uint32_t Dma_done_set_23: 1;
    uint32_t Dma_done_set_24: 1;
    uint32_t Dma_done_set_25: 1;
    uint32_t Dma_done_set_26: 1;
    uint32_t Dma_done_set_27: 1;
    uint32_t Dma_done_set_28: 1;
    uint32_t Dma_done_set_29: 1;
    uint32_t Dma_done_set_30: 1;
    uint32_t Dma_done_set_31: 1;
  };
  uint32_t Word;
} DMA_DONESET_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_done_clr_0: 1;
    uint32_t Dma_done_clr_1: 1;
    uint32_t Dma_done_clr_2: 1;
    uint32_t Dma_done_clr_3: 1;
    uint32_t Dma_done_clr_4: 1;
    uint32_t Dma_done_clr_5: 1;
    uint32_t Dma_done_clr_6: 1;
    uint32_t Dma_done_clr_7: 1;
    uint32_t Dma_done_clr_8: 1;
    uint32_t Dma_done_clr_9: 1;
    uint32_t Dma_done_clr_10: 1;
    uint32_t Dma_done_clr_11: 1;
    uint32_t Dma_done_clr_12: 1;
    uint32_t Dma_done_clr_13: 1;
    uint32_t Dma_done_clr_14: 1;
    uint32_t Dma_done_clr_15: 1;
    uint32_t Dma_done_clr_16: 1;
    uint32_t Dma_done_clr_17: 1;
    uint32_t Dma_done_clr_18: 1;
    uint32_t Dma_done_clr_19: 1;
    uint32_t Dma_done_clr_20: 1;
    uint32_t Dma_done_clr_21: 1;
    uint32_t Dma_done_clr_22: 1;
    uint32_t Dma_done_clr_23: 1;
    uint32_t Dma_done_clr_24: 1;
    uint32_t Dma_done_clr_25: 1;
    uint32_t Dma_done_clr_26: 1;
    uint32_t Dma_done_clr_27: 1;
    uint32_t Dma_done_clr_28: 1;
    uint32_t Dma_done_clr_29: 1;
    uint32_t Dma_done_clr_30: 1;
    uint32_t Dma_done_clr_31: 1;
  };
  uint32_t Word;
} DMA_DONECLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_active_set_0: 1;
    uint32_t Dma_active_set_1: 1;
    uint32_t Dma_active_set_2: 1;
    uint32_t Dma_active_set_3: 1;
    uint32_t Dma_active_set_4: 1;
    uint32_t Dma_active_set_5: 1;
    uint32_t Dma_active_set_6: 1;
    uint32_t Dma_active_set_7: 1;
    uint32_t Dma_active_set_8: 1;
    uint32_t Dma_active_set_plc_tx: 1;
    uint32_t Dma_active_set_plc_rx: 1;
    uint32_t Dma_active_set_11: 1;
    uint32_t Dma_active_set_12: 1;
    uint32_t Dma_active_set_13: 1;
    uint32_t Dma_active_set_14: 1;
    uint32_t Dma_active_set_15: 1;
    uint32_t Dma_active_set_16: 1;
    uint32_t Dma_active_set_17: 1;
    uint32_t Dma_active_set_18: 1;
    uint32_t Dma_active_set_19: 1;
    uint32_t Dma_active_set_20: 1;
    uint32_t Dma_active_set_21: 1;
    uint32_t Dma_active_set_22: 1;
    uint32_t Dma_active_set_23: 1;
    uint32_t Dma_active_set_24: 1;
    uint32_t Dma_active_set_25: 1;
    uint32_t Dma_active_set_26: 1;
    uint32_t Dma_active_set_27: 1;
    uint32_t Dma_active_set_28: 1;
    uint32_t Dma_active_set_29: 1;
    uint32_t Dma_active_set_30: 1;
    uint32_t Dma_active_set_31: 1;
  };
  uint32_t Word;
} DMA_ACTIVESET_Typedef;

typedef union
{
  struct
  {
    uint32_t Dma_active_clr_0: 1;
    uint32_t Dma_active_clr_1: 1;
    uint32_t Dma_active_clr_2: 1;
    uint32_t Dma_active_clr_3: 1;
    uint32_t Dma_active_clr_4: 1;
    uint32_t Dma_active_clr_5: 1;
    uint32_t Dma_active_clr_6: 1;
    uint32_t Dma_active_clr_7: 1;
    uint32_t Dma_active_clr_8: 1;
    uint32_t Dma_active_clr_9: 1;
    uint32_t Dma_active_clr_10: 1;
    uint32_t Dma_active_clr_11: 1;
    uint32_t Dma_active_clr_12: 1;
    uint32_t Dma_active_clr_13: 1;
    uint32_t Dma_active_clr_14: 1;
    uint32_t Dma_active_clr_15: 1;
    uint32_t Dma_active_clr_16: 1;
    uint32_t Dma_active_clr_17: 1;
    uint32_t Dma_active_clr_18: 1;
    uint32_t Dma_active_clr_19: 1;
    uint32_t Dma_active_clr_20: 1;
    uint32_t Dma_active_clr_21: 1;
    uint32_t Dma_active_clr_22: 1;
    uint32_t Dma_active_clr_23: 1;
    uint32_t Dma_active_clr_24: 1;
    uint32_t Dma_active_clr_25: 1;
    uint32_t Dma_active_clr_26: 1;
    uint32_t Dma_active_clr_27: 1;
    uint32_t Dma_active_clr_28: 1;
    uint32_t Dma_active_clr_29: 1;
    uint32_t Dma_active_clr_30: 1;
    uint32_t Dma_active_clr_31: 1;
  };
  uint32_t Word;
} DMA_ACTIVECLR_Typedef;

typedef union
{
  struct
  {
    uint32_t Err_set: 1;
    uint32_t RESERVED0: 31;
  };
  uint32_t Word;
} DMA_ERRSET_Typedef;

typedef struct
{
  __I DMA_STA_Typedef STA;
  __O DMA_CFG_Typedef CFG;
  __IO DMA_CTRLBASEPTR_Typedef CTRLBASEPTR;
  __I DMA_ALTCTRLBASEPTR_Typedef ALTCTRLBASEPTR;
  __I DMA_WTonREQSTA_Typedef WTonREQSTA;
  __O DMA_SWREQ_Typedef SWREQ;
  __IO DMA_USEBURSTSET_Typedef USEBURSTSET;
  __IO DMA_USEBURSTCLR_Typedef USEBURSTCLR;
  __IO DMA_REQMASKSET_Typedef REQMASKSET;
  __IO DMA_REQMASKCLR_Typedef REQMASKCLR;
  __IO DMA_ENBSET_Typedef ENBSET;
  __IO DMA_ENBCLR_Typedef ENBCLR;
  __IO DMA_PRIALTSET_Typedef PRIALTSET;
  __IO DMA_PRIALTCLR_Typedef PRIALTCLR;
  __IO DMA_PRIORITYSET_Typedef PRIORITYSET;
  __IO DMA_PRIORITYCLR_Typedef PRIORITYCLR;
  uint32_t RESERVED0[3];
  __IO DMA_ERRCLR_Typedef ERRCLR;
  uint32_t RESERVED1[876];
  __IO DMA_INTGRCFG_Typedef INTGRCFG;
  uint32_t RESERVED2[1];
  __I DMA_STALLSTA_Typedef STALLSTA;
  uint32_t RESERVED3[1];
  __I DMA_REQSTA_Typedef REQSTA;
  uint32_t RESERVED4[1];
  __I DMA_SREQSTA_Typedef SREQSTA;
  uint32_t RESERVED5[1];
  __IO DMA_DONESET_Typedef DONESET;
  __IO DMA_DONECLR_Typedef DONECLR;
  __IO DMA_ACTIVESET_Typedef ACTIVESET;
  __IO DMA_ACTIVECLR_Typedef ACTIVECLR;
  uint32_t RESERVED6[5];
  __IO DMA_ERRSET_Typedef ERRSET;
} DMA_TypeDef;

/******************************************************************************/
/************************************* SYSTICK ********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t ENABLE: 1;
    uint32_t TICKINT: 1;
    uint32_t CLKSOURCE: 1;
    uint32_t RESERVED0: 13;
    uint32_t COUNTFLAG: 1;
    uint32_t RESERVED1: 15;
  };
  uint32_t Word;
} SYST_CSR_Typedef;

typedef union
{
  struct
  {
    uint32_t RELOAD: 24;
    uint32_t RESERVED0: 8;
  };
  uint32_t Word;
} SYST_RVR_Typedef;

typedef union
{
  struct
  {
    uint32_t CURRENT: 24;
    uint32_t RESERVED0: 8;
  };
  uint32_t Word;
} SYST_CVR_Typedef;

typedef union
{
  struct
  {
    uint32_t TENMS: 24;
    uint32_t RESERVED0: 6;
    uint32_t SKEW: 1;
    uint32_t NOREF: 1;
  };
  uint32_t Word;
} SYST_CALIB_Typedef;

typedef struct
{
  __IO SYST_CSR_Typedef CSR;
  __IO SYST_RVR_Typedef RVR;
  __IO SYST_CVR_Typedef CVR;
  __IO SYST_CALIB_Typedef CALIB;
} SYST_TypeDef;

/******************************************************************************/
/************************************* NVIC ***********************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t SETENA: 32;
  };
  uint32_t Word;
} NVIC_ISER0_Typedef;

typedef union
{
  struct
  {
    uint32_t SETENA: 32;
  };
  uint32_t Word;
} NVIC_ISER1_Typedef;

typedef union
{
  struct
  {
    uint32_t CLRENA: 32;
  };
  uint32_t Word;
} NVIC_ICER0_Typedef;

typedef union
{
  struct
  {
    uint32_t CLRENA: 32;
  };
  uint32_t Word;
} NVIC_ICER1_Typedef;

typedef union
{
  struct
  {
    uint32_t SETPEND: 32;
  };
  uint32_t Word;
} NVIC_ISPR0_Typedef;

typedef union
{
  struct
  {
    uint32_t SETPEND: 32;
  };
  uint32_t Word;
} NVIC_ISPR1_Typedef;

typedef union
{
  struct
  {
    uint32_t CLRPEND: 32;
  };
  uint32_t Word;
} NVIC_ICPR0_Typedef;

typedef union
{
  struct
  {
    uint32_t CLRPEND: 32;
  };
  uint32_t Word;
} NVIC_ICPR1_Typedef;

typedef union
{
  struct
  {
    uint32_t ACTIVE: 32;
  };
  uint32_t Word;
} NVIC_IABR0_Typedef;

typedef union
{
  struct
  {
    uint32_t ACTIVE: 32;
  };
  uint32_t Word;
} NVIC_IABR1_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 5;
    uint32_t PRI_0: 3;
    uint32_t RESERVED1: 5;
    uint32_t PRI_1: 3;
    uint32_t RESERVED2: 5;
    uint32_t PRI_2: 3;
    uint32_t RESERVED3: 5;
    uint32_t PRI_3: 3;
  };
  uint32_t Word;
} NVIC_PR0_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR1_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR2_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR3_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR4_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR5_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR6_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR7_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR8_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR9_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR10_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR11_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 32;
  };
  uint32_t Word;
} NVIC_PR12_Typedef;

typedef struct
{
  __IO NVIC_ISER0_Typedef ISER0;
  __IO NVIC_ISER1_Typedef ISER1;
  uint32_t RESERVED0[30];
  __IO NVIC_ICER0_Typedef ICER0;
  __IO NVIC_ICER1_Typedef ICER1;
  uint32_t RESERVED1[30];
  __IO NVIC_ISPR0_Typedef ISPR0;
  __IO NVIC_ISPR1_Typedef ISPR1;
  uint32_t RESERVED2[30];
  __IO NVIC_ICPR0_Typedef ICPR0;
  __IO NVIC_ICPR1_Typedef ICPR1;
  uint32_t RESERVED3[30];
  __IO NVIC_IABR0_Typedef IABR0;
  __IO NVIC_IABR1_Typedef IABR1;
  uint32_t RESERVED4[62];
  __IO NVIC_PR0_Typedef PR0;
  __IO NVIC_PR1_Typedef PR1;
  __IO NVIC_PR2_Typedef PR2;
  __IO NVIC_PR3_Typedef PR3;
  __IO NVIC_PR4_Typedef PR4;
  __IO NVIC_PR5_Typedef PR5;
  __IO NVIC_PR6_Typedef PR6;
  __IO NVIC_PR7_Typedef PR7;
  __IO NVIC_PR8_Typedef PR8;
  __IO NVIC_PR9_Typedef PR9;
  __IO NVIC_PR10_Typedef PR10;
  __IO NVIC_PR11_Typedef PR11;
  __IO NVIC_PR12_Typedef PR12;
} NVIC_TypeDef;

/******************************************************************************/
/************************************* SCB ************************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t REVISION: 4;
    uint32_t PARTNO: 12;
    uint32_t CONSTANT: 4;
    uint32_t VARIANT: 4;
    uint32_t IMPLEMENTER: 8;
  };
  uint32_t Word;
} SCB_CPUID_Typedef;

typedef union
{
  struct
  {
    uint32_t VECTACTIVE: 6;
    uint32_t RESERVED0: 6;
    uint32_t VECTPENDING: 6;
    uint32_t RESERVED1: 4;
    uint32_t ISRPENDDING: 1;
    uint32_t RESERVED2: 2;
    uint32_t PENDSTCLR: 1;
    uint32_t PENDSTSET: 1;
    uint32_t RESERVED3: 4;
    uint32_t NMIPENDSET: 1;
  };
  uint32_t Word;
} SCB_ICSR_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 1;
    uint32_t VECTCLRACTIVE: 1;
    uint32_t SYSRESETREQ: 1;
    uint32_t RESERVED1: 12;
    uint32_t ENDIANNESS: 1;
    uint32_t VECTKEY: 16;
  };
  uint32_t Word;
} SCB_AIRCR_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 1;
    uint32_t SLEEPONEXIT: 1;
    uint32_t SLEEPDEEP: 1;
    uint32_t RESERVED1: 1;
    uint32_t SEVONPEND: 1;
    uint32_t RESERVED2: 27;
  };
  uint32_t Word;
} SCB_SCR_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 3;
    uint32_t UNALIGN_TRP: 1;
    uint32_t RESERVED1: 5;
    uint32_t STKALIGN: 1;
    uint32_t RESERVED2: 22;
  };
  uint32_t Word;
} SCB_CCR_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 30;
    uint32_t PRI_11: 2;
  };
  uint32_t Word;
} SCB_SHPR2_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 22;
    uint32_t PRI_14: 2;
    uint32_t RESERVED1: 6;
    uint32_t PRI_15: 2;
  };
  uint32_t Word;
} SCB_SHPR3_Typedef;

typedef struct
{
  __I SCB_CPUID_Typedef CPUID;
  __IO SCB_ICSR_Typedef ICSR;
  uint32_t RESERVED0;
  __IO SCB_AIRCR_Typedef AIRCR;
  __IO SCB_SCR_Typedef SCR;
  __I SCB_CCR_Typedef CCR;
  uint32_t RESERVED1;
  __IO SCB_SHPR2_Typedef SHPR2;
  __IO SCB_SHPR3_Typedef SHPR3;
} SCB_TypeDef;

/******************************************************************************/
/************************************* Ethernet *******************************/
/******************************************************************************/
typedef union
{
  struct
  {
    uint32_t TRANSMIT_ENABLE: 1;
    uint32_t SYNCHRONIZED_TRANSMIT_ENABLE: 1;
    uint32_t RECEIVE_ENABLE: 1;
    uint32_t SYNCHRONIZED_RECEIVE_ENABLE: 1;
    uint32_t TRANSMIT_FLOW_CONTROL_ENABLE: 1;
    uint32_t RECEIVE_FLOW_CONTROL_ENABLE: 1;
    uint32_t RESERVED0: 2;
    uint32_t LOOP_BACK: 1;
    uint32_t RESERVED1: 7;
    uint32_t RESET_TX_FUNCTION: 1;
    uint32_t RESET_RX_FUNCTION: 1;
    uint32_t RESET_TX_MAC_CONTROL: 1;
    uint32_t RESET_RX_MAC_CONTROL: 1;
    uint32_t RESERVED2: 10;
    uint32_t SIMULATION_RESET: 1;
    uint32_t SOFT_RESET: 1;
  };
  uint32_t Word;
} ETH_MAC_CONF1_Typedef;

typedef union
{
  struct
  {
    uint32_t FULL_DUPLEX: 1;
    uint32_t CRC_ENABLE: 1;
    uint32_t PAD_CRC_ENABLE: 1;
    uint32_t RESERVED0: 1;
    uint32_t LENGTH_FIELD_CHECKING: 1;
    uint32_t HUGE_FRAME_ENABLE: 1;
    uint32_t RESERVED1: 2;
    uint32_t INTERFACE_MODE: 2;
    uint32_t RESERVED3: 2;
    uint32_t PREAMBLE_LENGTH: 4;
    uint32_t RESERVED4: 16;
  };
  uint32_t Word;
} ETH_MAC_CONF2_Typedef;

typedef union
{
  struct
  {
    uint32_t BBIPG: 7;
    uint32_t RESERVED0: 1;
    uint32_t MIE: 7;
    uint32_t IPGR2: 7;
    uint32_t RESERVED1: 1;
    uint32_t IPGR1: 7;
    uint32_t RESERVED2: 2;
  };
  uint32_t Word;
} ETH_IPFG_Typedef;

typedef union
{
  struct
  {
    uint32_t COLLISION_WINDOW: 10;
    uint32_t RESERVED0: 2;
    uint32_t RETRANSMISSION_MAXIMUM: 4;
    uint32_t EXCESSIVE_DEFER: 1;
    uint32_t NO_BACKOFF: 1;
    uint32_t BACKPRESSURE_NO_BACKOFF: 1;
    uint32_t ABEBE: 1;
    uint32_t ABEBT: 4;
    uint32_t RESERVED1: 8;
  };
  uint32_t Word;
} ETH_HFDUP_Typedef;

typedef union
{
  struct
  {
    uint32_t MAXIMUM_FRAME_LENGTH: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} ETH_MFLEN_Typedef;

typedef union
{
  struct
  {
    uint32_t SHORTCUT_SLOT_TIME: 1;
    uint32_t TEST_PAUSE: 1;
    uint32_t RTFE: 1;
    uint32_t AXIMUM_BACKOFF: 1;
    uint32_t RESERVED0: 28;
  };
  uint32_t Word;
} ETH_TSTR_Typedef;

typedef union
{
  struct
  {
    uint32_t MGCLK_SELECT: 3;
    uint32_t RESERVED0: 1;
    uint32_t PREAMBLE_SUPPRESSION: 1;
    uint32_t SCAN_AUTO_INCREMENT: 1;
    uint32_t RESERVED1: 25;
    uint32_t RST_MGMT: 1;
  };
  uint32_t Word;
} ETH_MGCONF_Typedef;

typedef union
{
  struct
  {
    uint32_t READ_CYCLE: 1;
    uint32_t SCAN_CYCLE: 1;
    uint32_t RESERVED0: 30;
  };
  uint32_t Word;
} ETH_MGCMD_Typedef;

typedef union
{
  struct
  {
    uint32_t REG_ADX: 5;
    uint32_t RESERVED0: 3;
    uint32_t PHY_ADX: 5;
    uint32_t RESERVED1: 19;
  };
  uint32_t Word;
} ETH_MGADR_Typedef;

typedef union
{
  struct
  {
    uint32_t WDATA: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} ETH_MGWDATA_Typedef;

typedef union
{
  struct
  {
    uint32_t RDATA: 16;
    uint32_t RESERVED0: 16;
  };
  uint32_t Word;
} ETH_MGRDATA_Typedef;

typedef union
{
  struct
  {
    uint32_t BUSY: 1;
    uint32_t SCANNING: 1;
    uint32_t NOT_VALID: 1;
    uint32_t RESERVED0: 29;
  };
  uint32_t Word;
} ETH_MGFIG_Typedef;

typedef union
{
  struct
  {
    uint32_t ENABLE_JABBER_PROTECTION: 1;
    uint32_t RESERVED0: 6;
    uint32_t RESET_GPSI: 1;
    uint32_t DISABLE_LINK_FAIL: 1;
    uint32_t NO_CIPHER: 1;
    uint32_t FORCE_QUIET: 1;
    uint32_t RESERVED1: 4;
    uint32_t RESET_PE100X: 1;
    uint32_t SPEED: 1;
    uint32_t RESERVED2: 6;
    uint32_t RESET_PERMII: 1;
    uint32_t PHY_MODE: 1;
    uint32_t LHDMODE: 1;
    uint32_t GHDMODE: 1;
    uint32_t TBIMODE: 1;
    uint32_t RESERVED3: 3;
    uint32_t RESET_INTERFACE_MODULE: 1;
  };
  uint32_t Word;
} ETH_ITFCON_Typedef;

typedef union
{
  struct
  {
    uint32_t JABBER: 1;
    uint32_t SQE_ERROR: 1;
    uint32_t LOSS_OF_CARRIER: 1;
    uint32_t LINK_AIL: 1;
    uint32_t SPEED: 1;
    uint32_t FULL_DUPLEX: 1;
    uint32_t LINK_OK: 1;
    uint32_t JABBER1: 1;
    uint32_t CLASH: 1;
    uint32_t EXCESS_DEFER: 1;
    uint32_t WOLDTCTD: 1;
    uint32_t RESERVED0: 21;
  };
  uint32_t Word;
} ETH_ITFSTA_Typedef;

typedef union
{
  struct
  {
    uint32_t octet_4: 8;
    uint32_t octet_3: 8;
    uint32_t octet_2: 8;
    uint32_t octet_1: 8;
  };
  uint32_t Word;
} ETH_STAADR1_Typedef;

typedef union
{
  struct
  {
    uint32_t RESERVED0: 16;
    uint32_t octet_6: 8;
    uint32_t octet_5: 8;
  };
  uint32_t Word;
} ETH_STAADR2_Typedef;

typedef struct
{
  __IO ETH_MAC_CONF1_Typedef MAC_CONF1;
  __IO ETH_MAC_CONF2_Typedef MAC_CONF2;
  __IO ETH_IPFG_Typedef IPFG;
  __IO ETH_HFDUP_Typedef HFDUP;
  __IO ETH_MFLEN_Typedef MFLEN;
  uint32_t RESERVED0[2];
  __IO ETH_TSTR_Typedef TSTR;
  __IO ETH_MGCONF_Typedef MGCONF;
  __IO ETH_MGCMD_Typedef MGCMD;
  __IO ETH_MGADR_Typedef MGADR;
  __O ETH_MGWDATA_Typedef MGWDATA;
  __I ETH_MGRDATA_Typedef MGRDATA;
  __I ETH_MGFIG_Typedef MGFIG;
  __IO ETH_ITFCON_Typedef ITFCON;
  __I ETH_ITFSTA_Typedef ITFSTA;
  __IO ETH_STAADR1_Typedef STAADR1;
  __IO ETH_STAADR2_Typedef STAADR2;
  __IO uint32_t FIFCONF0;    //__IO ETH_FIFCONF0_Typedef  FIFCONF0; // 0x0048
  __IO uint32_t FIFCONF1;    //__IO ETH_FIFCONF1_Typedef  FIFCONF1; // 0x004C
  __IO uint32_t FIFCONF2;    //__IO ETH_FIFCONF2_Typedef  FIFCONF2; // 0x0050
  __IO uint32_t FIFCONF3;    //__IO ETH_FIFCONF3_Typedef  FIFCONF3; // 0x0054
  __IO uint32_t FIFCONF4;    //__IO ETH_FIFCONF4_Typedef  FIFCONF4; // 0x0058
  __IO uint32_t FIFCONF5;    //__IO ETH_FIFCONF5_Typedef  FIFCONF5; // 0x005C
  __IO uint32_t FIFO0;       //__IO ETH_FIFO0_Typedef     FIFO0;    // 0x0060
  __IO uint32_t FIFO1;       //__IO ETH_FIFO1_Typedef     FIFO1;    // 0x0064
  __IO uint32_t FIFO2;       //__IO ETH_FIFO2_Typedef     FIFO2;    // 0x0068
  __IO uint32_t FIFO3;       //__IO ETH_FIFO3_Typedef     FIFO3;    // 0x006C
  __IO uint32_t FIFO4;       //__IO ETH_FIFO4_Typedef     FIFO4;    // 0x0070
  __IO uint32_t FIFO5;       //__IO ETH_FIFO5_Typedef     FIFO5;    // 0x0074
  __IO uint32_t FIFO6;       //__IO ETH_FIFO6_Typedef     FIFO6;    // 0x0078
  __IO uint32_t FIFO7;       //__IO ETH_FIFO7_Typedef     FIFO7;    // 0x007C
  uint32_t RESERVED1[64];    // 0x0080 - 0x017C
  __IO uint32_t DMATXCTL;    //__IO ETH_DMATXCTL_Typedef  DMATXCTL; // 0x180
  __IO uint32_t DMATXDES;    //__IO ETH_DMATXDES_Typedef  DMATXDES; // 0x184
  __IO uint32_t DMATXSTA;    //__IO ETH_DMATXSTA_Typedef  DMATXSTA; // 0x188
  __IO uint32_t DMARXCTL;    //__IO ETH_DMARXCTL_Typedef  DMARXCTL; // 0x18C
  __IO uint32_t DMARXDES;    //__IO ETH_DMARXDES_Typedef  DMARXDES; // 0x190
  __IO uint32_t DMARXSTA;    //__IO ETH_DMARXSTA_Typedef  DMARXSTA; // 0x194
  __IO uint32_t DMAIMR;      //__IO ETH_DMAIMR_Typedef    DMAIMR;   // 0x198
  __O  uint32_t DMAISR;      //__O  ETH_DMAISR_Typedef    DMAISR;   // 0x19C
} ETH_TypeDef;


////////////////////////////////////*������ַӳ��*//////////////////////////
/* Base addresses */
#define FLASH_BASE (0x00000000UL)
#define SRAM_BASE (0x20000000UL)
#define APB_BASE (0x40000000UL)
#define SYS_BASE (0xA0000000UL)
#define SYST_BASE (0xE000E010UL)
//#define NVIC_BASE (0xE000E100UL)
//#define SCB_BASE (0xE000ED00UL)

/* APB peripherals */
#define SCU_BASE (APB_BASE + 0x00000)
#define GPIO_BASE (APB_BASE + 0x00400)
#define IAP_BASE (APB_BASE + 0x00800)
#define ADC_BASE (APB_BASE + 0x01000)
#define WWDT_BASE (APB_BASE + 0x01800)
#define IWDT_BASE (APB_BASE + 0x01C00)
#define T16N0_BASE (APB_BASE + 0x02000)
#define T16N1_BASE (APB_BASE + 0x02400)
#define T16N2_BASE (APB_BASE + 0x02800)
#define T16N3_BASE (APB_BASE + 0x02C00)
#define T32N0_BASE (APB_BASE + 0x04000)
#define T32N1_BASE (APB_BASE + 0x04400)
#define T32N2_BASE (APB_BASE + 0x04800)
#define T32N3_BASE (APB_BASE + 0x04C00)
#define UART0_BASE (APB_BASE + 0x06000)
#define UART1_BASE (APB_BASE + 0x06400)
#define UART2_BASE (APB_BASE + 0x06800)
#define UART3_BASE (APB_BASE + 0x06C00)
#define SPI0_BASE (APB_BASE + 0x08000)
#define SPI1_BASE (APB_BASE + 0x08400)
#define SPI2_BASE (APB_BASE + 0x08800)
#define SPI3_BASE (APB_BASE + 0x08C00)
#define I2C0_BASE (APB_BASE + 0x09000)
#define I2C1_BASE (APB_BASE + 0x09400)
#define TRNG_BASE (APB_BASE + 0x0E400)
#define ECC_BASE (APB_BASE + 0x0E800)
#define CRC_BASE (APB_BASE + 0x10000)
#define AES_BASE (APB_BASE + 0x40000)
#define NTB_BASE (APB_BASE + 0x43C00)
#define BPLC_BASE (APB_BASE + 0x44000)
#define DMA_BASE (APB_BASE + 0x81000)
#define ETH_BASE (APB_BASE + 0xC0400)

#define PGA_BASE (APB_BASE + 0x443E8)


////////////////////////////////////*���趨��*///////////////////////////
#define SCU ((SCU_TypeDef *) SCU_BASE)
#define GPIO ((GPIO_TypeDef *) GPIO_BASE)
#define IAP ((IAP_TypeDef *) IAP_BASE)
#define ADC ((ADC_TypeDef *) ADC_BASE)
#define WWDT ((WWDT_TypeDef *) WWDT_BASE)
#define IWDT ((IWDT_TypeDef *) IWDT_BASE)
#define T16N0 ((T16N_TypeDef *) T16N0_BASE)
#define T16N1 ((T16N_TypeDef *) T16N1_BASE)
#define T16N2 ((T16N_TypeDef *) T16N2_BASE)
#define T16N3 ((T16N_TypeDef *) T16N3_BASE)
#define T32N0 ((T32N_TypeDef *) T32N0_BASE)
#define T32N1 ((T32N_TypeDef *) T32N1_BASE)
#define T32N2 ((T32N_TypeDef *) T32N2_BASE)
#define T32N3 ((T32N_TypeDef *) T32N3_BASE)
#define UART0 ((UART_TypeDef *) UART0_BASE)
#define UART1 ((UART_TypeDef *) UART1_BASE)
#define UART2 ((UART_TypeDef *) UART2_BASE)
#define UART3 ((UART_TypeDef *) UART3_BASE)
#define SPI0 ((SPI_TypeDef *) SPI0_BASE)
#define SPI1 ((SPI_TypeDef *) SPI1_BASE)
#define SPI2 ((SPI_TypeDef *) SPI2_BASE)
#define SPI3 ((SPI_TypeDef *) SPI3_BASE)
#define I2C0 ((I2C_TypeDef *) I2C0_BASE)
#define I2C1 ((I2C_TypeDef *) I2C1_BASE)
#define TRNG ((TRNG_TypeDef *) TRNG_BASE)
#define ECC ((ECC_TypeDef *) ECC_BASE)
#define CRC   ((CRC_TypeDef *) CRC_BASE)
#define AES ((AES_TypeDef *) AES_BASE)
#define NTB ((NTB_TypeDef *) NTB_BASE)
#define BPLC ((BPLC_TypeDef *) BPLC_BASE)
#define DMA ((DMA_TypeDef *) DMA_BASE)
#define ETH ((ETH_TypeDef *) ETH_BASE)
//#define SysTick ((SYST_TypeDef *) SYST_BASE)

#define PGA ((FPGA_PGA_TypeDef *) PGA_BASE)

/********************system clock config*****************/
#define  CPU_CLK                 (150000000)  /* 150MHz */
#define  PCLK                    (CPU_CLK / (0x01 << SCU->AHBEN.APB1_PRE1))   /* 75MHz */

#define __OS_ENTER_CRITICAL()             \
                                        \
    uint32_t cpu_sr = __get_PRIMASK();  \
    __set_PRIMASK(1)

#define __OS_EXIT_CRITICAL()    __set_PRIMASK(cpu_sr)

#endif /* __SSC1667_H */


