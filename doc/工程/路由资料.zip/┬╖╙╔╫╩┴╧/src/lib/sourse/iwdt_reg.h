/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      iwdt_reg.h
Description:    the iwdt control
Author:         ch
Version:        v1.0
Date:           2017/08/10
History:
*/
/************************************************************************************************/


#ifndef __IWDT_REG_H
#define __IWDT_REG_H


#include "ssc1667.h"
#include "type.h"
#include "scu.h"

#define IWDT_LOCK_KEY       (0x1ACCE551)
#define IWDT_CLK            (32000)             /* 32k */

typedef enum
{
    IWDT_PCLK           = 0x00,             /* iwdtѡ��ʱ��ΪPCLK */
    IWDT_LRC            = 0x01,             /* iwdtѡ��ʱ��ΪLRC */
} IWDT_CLK_SEL;

#define IWDT_RSTEN()        (IWDT->CON.RSTEN = 1)
#define IWDT_RSTDIS()       (IWDT->CON.RSTEN = 0)

#define IWDT_IEEN()         (IWDT->CON.IE = 1)
#define IWDT_IEDIS()        (IWDT->CON.IE = 0)

#define IWDT_EN()           (IWDT->CON.EN = 1)
#define IWDT_DIS()          (IWDT->CON.EN = 0)

#define IWDT_CLRIF()        (IWDT->INTCLR.Word = 1)
#define IWDT_GETIF()        (IWDT->RIS.Word)

#define IWDT_UNLOCK()       (IWDT->LOCK.Word = IWDT_LOCK_KEY)
#define IWDT_LOCK()       (IWDT->LOCK.Word = 0)
#define GET_IWDT_IE()       (IWDT->CON.IE)

#endif /* __IWDT_REG_H */

























