/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      t32n.c
Description:    the t32n control
Author:         ch
Version:        v1.0
Date:           2017/07/28
History:
*/
/************************************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "ssc1667.h"
#include "t32n_reg.h"
#include "t32n.h"
//#include "shell.h"
#include "irq.h"
#include "gpio.h"

T32N_MAT_HANDLE hash_pool[T32N_CNT][T32N_MAT_CNT] =
{
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL
};

T32N_MAT_HANDLE overflow_pool[T32N_CNT] =
{
    NULL, NULL, NULL, NULL
};

static void __isr__ t32n_0_isr(void);

static void __isr__ t32n_1_isr(void);

static void __isr__ t32n_2_isr(void);

static void __isr__ t32n_3_isr(void);

static void t32n_config_0(void);

static void t32n_config_1(void);

static void t32n_config_2(void);

static void t32n_config_3(void);

/*****************************************************************************************************/
/*
    Function    : t32n_init
    Description : config t32n0 as system timer
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_init(unsigned int tmr)
{
    T32N_CONFIG config[4] = {t32n_config_0, t32n_config_1, t32n_config_2, t32n_config_3};
    
    if (tmr >= T32N_CNT)
    {
        return;
    }
    
    config[tmr]();
}

/*****************************************************************************************************/
/*
    Function    : t32n_set_mat
    Description : config T32Nx_Matx
    Input       : tmr - T32N idx  [0,3]
                  mat - MAT idx  [0,3]
                  us  - timer interval (us)
                  isr - call back fun when timeout
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_set_mat(unsigned int tmr, unsigned char mat, unsigned int us, T32N_MAT_HANDLE isr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    unsigned int base = (unsigned int)(&(T32Nx->MAT0));
    T32N_MAT0_Typedef *MATx = (T32N_MAT0_Typedef *)(base + (mat * 4));

    T32Nx->CON0.Word      &= ~(0x11 << (MATS_0 + 2 *mat));
    T32Nx->CON0.Word      |= T32N_COUNT_INT1 << (MATS_0 + 2 * mat);   /* �������������ж� */
    MATx->Word             = us;
    hash_pool[tmr][mat]    = isr;
    T32Nx->IE.Word        |= (0x01 << mat);
}

/*****************************************************************************************************/
/*
    Function    : t32n_clear_mat
    Description : stop mat timing and disable interrupt
    Input       : tmr - T32N idx  [0,3]
                  mat - MAT idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_clear_mat(unsigned int tmr, unsigned char mat)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);

    T32Nx->IE.Word        &= ~(0x01 << mat);
    T32N_CLRIF(T32Nx, (0x01 << mat));
}

/*****************************************************************************************************/
/*
    Function    : t32n_set_overflow
    Description : config T32Nx overflow
    Input       : tmr - T32N idx [0,3]
                  isr - call back fun when timer is overflow
    Output      : none
    Return      : none
    Notes       : overflow timer = 4294967295 us = 4294967.295ms = 4294.967295s = 71.583min = 1.193h
*/
/*****************************************************************************************************/
void t32n_set_overflow(unsigned int tmr, T32N_MAT_HANDLE isr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    overflow_pool[tmr]  = isr;
    T32Nx->IE.IE        = 1;
}

/*****************************************************************************************************/
/*
    Function    : t32n_get_cnt
    Description : get cur cnt
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
unsigned int t32n_get_cnt(unsigned char tmr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    return T32Nx->CNT.Word;
}

/*****************************************************************************************************/
/*
    Function    : t32n_set_cnt
    Description : set current cnt
    Input       : tmr - T32N idx  [0,3]
                  cnt - init cnt to be set
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_set_cnt(unsigned char tmr, unsigned int cnt)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    T32Nx->CNT.Word     = cnt;
}

/*****************************************************************************************************/
/*
    Function    : t32n_tmr_start
    Description : start a timer for mat0
    Input       : tmr - T32N idx  [0,3]
                  inicnt - start cnt
                  endcnt - end cnt
                  isr    - call back func for timerout
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_tmr_start(unsigned int tmr, unsigned int inicnt, unsigned int endcnt, T32N_MAT_HANDLE isr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    
    t32n_stop(tmr);
    
    t32n_set_cnt(tmr, 0);
    
    t32n_set_mat(tmr, T32N_MAT0, endcnt, isr);
    
    T32Nx->CON0.MAT0S = T32N_HOLD_INT1;   /* ���ֲ����ж� */
    
    t32n_set_cnt(tmr, inicnt);
    
    t32n_start(tmr);
}

void t32n_tmr_start1(unsigned int tmr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);
    
    t32n_stop(tmr);
    
    t32n_set_cnt(tmr, 0);
    
    t32n_start(tmr);
}

/*****************************************************************************************************/
/*
    Function    : t32n_start
    Description : start counting
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_start(unsigned int tmr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);

    T32Nx->CON0.EN = 1;
}

/*****************************************************************************************************/
/*
    Function    : t32n_stop
    Description : stop a timer
    Input       : tmr - T32N idx  [0,3]
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
void t32n_stop(unsigned int tmr)
{
    T32N_TypeDef *T32Nx = (T32N_TypeDef * )_T32Nx(tmr);

    T32Nx->CON0.EN = 0;
}

/*****************************************************************************************************/
/*
    Function    : t32n_config_0
    Description : config t32n0
    Input       : none
    Output      : none
    Return      : none
    Notes       : 1M->1us/tick
*/
/*****************************************************************************************************/
static void t32n_config_0(void)
{
    T32N0->CON0.MOD = T32N_TIMING_MOD;
    T32N0->CON0.CS = T32N_PCLK;    /* 75M */

    T32N0->PREMAT.Word = 2;//74;            /* 1M */

    T32N0->IE.IE = 1;                   /* overflow */
    T32N0->CNT.Word = 0;

//     irq_release(T32N0_IRQn);
//     irq_request(T32N0_IRQn, PRI_T32N0, t32n_0_isr);

 //   t32n_start(TIMER32_0);
}

/*****************************************************************************************************/
/*
    Function    : t32n_config_1
    Description : config t32n1
    Input       : none
    Output      : none
    Return      : none
    Notes       : 1M->1us/tick
*/
/*****************************************************************************************************/
static void t32n_config_1(void)
{
    T32N1->CON0.MOD = T32N_TIMING_MOD;
    T32N1->CON0.CS = T32N_PCLK;    /* 75M */
    //T32N0->CON0.EN = 1;

    T32N1->PREMAT.Word = 74;            /* 1M */
#if 0
    T32N1->IE.IE = 1;             /* overflow */
    T32N1->CNT.Word = 0;

    irq_release(T32N1_IRQn);
    irq_request(T32N1_IRQn, PRI_T32N1 ,t32n_1_isr);
#else
    T32N1->CNT.Word = 0;
#endif

   // t32n_start(TIMER32_1);
}

/*****************************************************************************************************/
/*
    Function    : t32n_config_2
    Description : config t32n2
    Input       : none
    Output      : none
    Return      : none
    Notes       : 1M->1us/tick
*/
/*****************************************************************************************************/
static void t32n_config_2(void)
{
    T32N2->CON0.MOD = T32N_TIMING_MOD;
    T32N2->CON0.CS = T32N_PCLK;    /* 75M */
    //T32N0->CON0.EN = 1;

    T32N2->PREMAT.Word = 74;            /* 1M */

    T32N2->IE.IE = 1;             /* overflow */
    T32N2->CNT.Word = 0;

    irq_release(T32N2_IRQn);
    irq_request(T32N2_IRQn, PRI_T32N2 ,t32n_2_isr);

  //  t32n_start(TIMER32_2);
}

/*****************************************************************************************************/
/*
    Function    : t32n_config_3
    Description : config t32n3
    Input       : none
    Output      : none
    Return      : none
    Notes       : 1M->1us/tick
*/
/*****************************************************************************************************/
static void t32n_config_3(void)
{
    T32N3->CON0.MOD = T32N_TIMING_MOD;
    T32N3->CON0.CS = T32N_PCLK;    /* 75M */
    //T32N0->CON0.EN = 1;

    T32N3->PREMAT.Word = 74;            /* 1M */

    T32N3->IE.IE = 1;             /* overflow */
    T32N3->CNT.Word = 0;

    irq_release(T32N3_IRQn);
    irq_request(T32N3_IRQn, PRI_T32N3 ,t32n_3_isr);

  //  t32n_start(TIMER32_3);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ t32n_0_isr(void)
{
    int idx = 0;
    for (idx = 0; idx < T32N_MAT_CNT; idx++)
    {
        if (T32N_GetIF(T32N0, (0x01 << idx)))
        {
            T32N_CLRIF(T32N0, (0x01 << idx));
            if (hash_pool[0][idx] != NULL)
            {
                hash_pool[0][idx]();
            }
        }
    }

    if (T32N_GetIF(T32N0, T32N_FFFFIF))
    {
        T32N_CLRIF(T32N0, T32N_FFFFIF);
        if (overflow_pool[0] != NULL)
        {
            overflow_pool[0]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ t32n_1_isr(void)
{
    int idx = 0;
    for (idx = 0; idx < T32N_MAT_CNT; idx++)
    {
        if (T32N_GetIF(T32N1, (0x01 << idx)))
        {
            T32N_CLRIF(T32N1, (0x01 << idx));
            if (hash_pool[1][idx] != NULL)
            {
                hash_pool[1][idx]();
            }
        }
    }

    if (T32N_GetIF(T32N1, T32N_FFFFIF))
    {
        T32N_CLRIF(T32N1, T32N_FFFFIF);
        if (overflow_pool[1] != NULL)
        {
            overflow_pool[1]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ t32n_2_isr(void)
{
    int idx = 0;
    for (idx = 0; idx < T32N_MAT_CNT; idx++)
    {
        if (T32N_GetIF(T32N2, (0x01 << idx)))
        {
            T32N_CLRIF(T32N2, (0x01 << idx));
            if (hash_pool[2][idx] != NULL)
            {
                hash_pool[2][idx]();
            }
        }
    }

    if (T32N_GetIF(T32N2, T32N_FFFFIF))
    {
        T32N_CLRIF(T32N2, T32N_FFFFIF);
        if (overflow_pool[2] != NULL)
        {
            overflow_pool[2]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : none
    Output      : none
    Return      : none
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ t32n_3_isr(void)
{
    int idx = 0;
    for (idx = 0; idx < T32N_MAT_CNT; idx++)
    {
        if (T32N_GetIF(T32N3, (0x01 << idx)))
        {
            T32N_CLRIF(T32N0, (0x01 << idx));
            if (hash_pool[3][idx] != NULL)
            {
                hash_pool[3][idx]();
            }
        }
    }

    if (T32N_GetIF(T32N3, T32N_FFFFIF))
    {
        T32N_CLRIF(T32N3, T32N_FFFFIF);
        if (overflow_pool[3] != NULL)
        {
            overflow_pool[3]();
        }
    }
}
