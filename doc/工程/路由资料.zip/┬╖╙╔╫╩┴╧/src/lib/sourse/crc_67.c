/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      crc.c
Description:    the crc control
Author:         ch
Version:        v1.0
Date:           2017/08/04
History:
*/
/************************************************************************************************/
#include "nvic.h"
#include "crc_reg.h"
#include "crc_67.h"

#if 0
static void crc_config(CRC_DS ds, CRC_MOD mod);

static unsigned int crc_send(unsigned char *data, unsigned int len);
#endif

/*****************************************************************************************************/
/*
    Function    : crc24
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
int crc24(CRC_DS ds, unsigned char *data, unsigned int len, void *out)
{
    unsigned int config;

    config = crc_get_config(CRC_OUT_NOT, CRC_WITH_BYTE, CRC_MOD_CRC24, ds);
    *(unsigned int *)out = CRC_UserCal((unsigned int)data, len, config);

    if (CRC_CheckReset())
    {
        return -1;
    }

    return 0;
}

/*****************************************************************************************************/
/*
    Function    : crc16
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
int crc16(CRC_DS ds, unsigned char *data, unsigned int len, void *out)
{
    unsigned int config;

    config = crc_get_config(CRC_OUT_NOT, CRC_WITH_BYTE, CRC_MOD_CRC16, ds);
    *(unsigned int * )out = CRC_UserCal((unsigned int)data, len, config);

    if (CRC_CheckReset())
    {
        return -1;
    }

    return 0;
}

/*****************************************************************************************************/
/*
    Function    : crc32
    Description :
    Input       : ds - crc init value (0 - 0  1 - 0xFFFFFFFF)
                  data - data to be cal
                  len  - data len
    Output      : out - crc code
    Return      : state - (0 - success  1 - failed)
    Notes       :
*/
/*****************************************************************************************************/
int crc32(CRC_DS ds, unsigned char *data, unsigned int len, void *out)
{
    unsigned int config;

    config = crc_get_config(CRC_OUT_NOT, CRC_WITH_BYTE, CRC_MOD_CRC32, ds);
    *(unsigned int * )out = CRC_UserCal((unsigned int)data, len, config);

    if (CRC_CheckReset())
    {
        return -1;
    }

    return 0;
}

/*****************************************************************************************************/
/*
    Function    : crc_get_config
    Description : get config word
    Input       : oxor - ��������Ƿ�ȡ��
                  with - ���ݿ���
                  md   - crc ģʽ
                  ds   - CRC�����ֵ
    Output      : none
    Return      : �����ϳɵ������֣�32bit������
    Notes       : �������ڵ��ù̻���������У����ʱ���������������
*/
/*****************************************************************************************************/
unsigned int crc_get_config(CRC_XOROUT oxor, CRC_WITH with, CRC_MOD mod, CRC_DS ds)
{
    CRC_CON_Typedef con;

    con.Word = 0;

    con.XOROUT  = oxor;
    con.BYTE    = with;
    con.MOD     = mod;
    con.REFIN   = CRC_OUT_INVERT;
    con.REFOUT  = CRC_OUT_INVERT;
    con.DS      = ds;
    con.EN      = 1;

    return con.Word;
}

#if 0
/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void crc_config(CRC_DS ds, CRC_MOD mod)
{
    CRC_UNLOCK();

    CRC->CON.XOROUT     = CRC_OUT_NOT;
    CRC->CON.BYTE       = CRC_WITH_BYTE;
    CRC->CON.MOD        = mod;
    CRC->CON.DS         = ds;
    CRC->CON.REFIN      = CRC_OUT_INVERT;
    CRC->CON.REFOUT     = CRC_OUT_INVERT;

    CRC->CON.EN = 1;

    CRC->TRIG.Word = CRC_TRIG_CS;
    CRC_CLR_STA(CRC_STA_RST);

    CRC_LOCK();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static unsigned int crc_send(unsigned char *data, unsigned int len)
{
    unsigned int pos = 0;

    while (pos++ < len)
    {
        CRC_WriteData(data[pos]);
    }

    while (CRC_GET_STA(CRC_STA_BUSY));

    return CRC_GET_STA(CRC_STA_RST);
}
#endif

unsigned short crc16_soft1(unsigned char *buf, int len)
{
  unsigned short crc = crc16_soft(buf, len), crc1;
  
  crc ^= 0xFFFF;
  crc1 = ((crc & 0xFF) * 256) + (crc >> 8);
  return crc1;
}


