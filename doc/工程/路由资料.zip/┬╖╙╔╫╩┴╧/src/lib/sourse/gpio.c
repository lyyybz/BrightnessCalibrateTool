/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      gpio.c
Description:    the gpio control
Author:         ch
Version:        v1.0
Date:           2017/07/28
History:
*/
/************************************************************************************************/
#include "ssc1667.h"
#include "gpio.h"
#include "irq.h"
#include <string.h>

static void __isr__ gpio_0_isr(void);
static void __isr__ gpio_1_isr(void);
static void __isr__ gpio_2_isr(void);
static void __isr__ gpio_3_isr(void);
static void __isr__ gpio_4_isr(void);
static void __isr__ gpio_5_isr(void);
static void __isr__ gpio_6_isr(void);
static void __isr__ gpio_7_isr(void);

static EXT_IRQ_HANDLE gpio_isr_pool[GPIO_PINT_MAX] = {NULL};

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gpio_set_map(GPIO_PIN pin, GPIO_FUNC_MAP func)
{
    unsigned int base = (unsigned int)&(GPIO->FUNC0);
    GPIO_FUNC0_Typedef *FUNCx = (GPIO_FUNC0_Typedef * )(base + ((pin / 8) * sizeof(GPIO_FUNC0_Typedef)));

	FUNCx->Word &= (unsigned int)(~(0xF << (4 * (pin % 8))));
    FUNCx->Word |= (unsigned int)func;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gpio_set_dir(GPIO_PIN pin, GPIO_DIR dir)
{
    if (dir == GPIO_DIR_IN)
    {
        GPIO->DIRBSR.Word = (1 << pin);
    }
    else
    {
        GPIO->DIRBCR.Word   = (1 << pin);
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
unsigned int gpio_input(GPIO_PIN pin)
{
    return (GPIO->PORT.Word >> pin)  & 0x01;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gipo_out(GPIO_PIN pin, unsigned int bit)
{
    if (bit != 0)
        GPIO->DATABSR.Word = (1 << pin);
    else
        GPIO->DATABCR.Word = (1 << pin);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gipo_out_high(GPIO_PIN pin)
{
    GPIO->DATABSR.Word = (1 << pin);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gipo_out_low(GPIO_PIN pin)
{
    GPIO->DATABCR.Word = (1 << pin);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gpio_toggle(GPIO_PIN pin)
{
    GPIO->DATABRR.Word = (1 << pin);
}

void gpio_ode(GPIO_PIN pin)
{
    GPIO->ODE.Word |= (1 << pin);
}

unsigned char pint_get_itindex(GPIO_PIN pin)
{
  return pin % 8;
}

void pint_clear_itflag(GPIO_PIN pin)
{
	unsigned char pintx;

	pintx = pint_get_itindex(pin);

	GPIO->PINTIF.Word |= (1 << pintx);

	return;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
void gpio_pint_init(GPIO_PIN pin, PINT_Trigger_Style trigger, EXT_IRQ_HANDLE isr)
{
    IRQn_Type irqn[] = {GPIO_IRQn_ENUM};
    EXT_IRQ_HANDLE isrx[] = {gpio_0_isr, gpio_1_isr, gpio_2_isr, gpio_3_isr, gpio_4_isr, gpio_5_isr, gpio_6_isr, gpio_7_isr};
    irq_priority_t pri[] = {PRI_GPIO0, PRI_GPIO1, PRI_GPIO2, PRI_GPIO3, PRI_GPIO4, PRI_GPIO5, PRI_GPIO6, PRI_GPIO7};

    int pintx = GPIO_PINTx(pin);

    gpio_set_dir(pin, GPIO_DIR_IN);
    gpio_set_map(pin, (GPIO_FUNC_MAP)GPIOx_FUNCx(pin, GPIO_FUNC0));

    GPIO_CLRIF(pintx);
    GPIO_SETTRI(pintx, trigger);
    GPIO_SETSEL(pin);

    gpio_isr_pool[pintx] = isr;

    irq_release(irqn[pintx]);
    irq_request(irqn[pintx], pri[pintx], isrx[pintx]);

    GPIO_PINT_CLRMASK(pintx);
    GPIO_PINTEN(pintx);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_0_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT0))
    {
        GPIO_CLRIF(GPIO_PINT0);

        if (NULL != gpio_isr_pool[GPIO_PINT0])
        {
            gpio_isr_pool[GPIO_PINT0]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_1_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT1))
    {
        GPIO_CLRIF(GPIO_PINT1);

        if (NULL != gpio_isr_pool[GPIO_PINT1])
        {
            gpio_isr_pool[GPIO_PINT1]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_2_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT2))
    {
        GPIO_CLRIF(GPIO_PINT2);

        if (NULL != gpio_isr_pool[GPIO_PINT2])
        {
            gpio_isr_pool[GPIO_PINT2]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_3_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT3))
    {
        GPIO_CLRIF(GPIO_PINT3);

        if (NULL != gpio_isr_pool[GPIO_PINT3])
        {
            gpio_isr_pool[GPIO_PINT3]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_4_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT4))
    {
        GPIO_CLRIF(GPIO_PINT4);

        if (NULL != gpio_isr_pool[GPIO_PINT4])
        {
            gpio_isr_pool[GPIO_PINT4]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_5_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT5))
    {
        GPIO_CLRIF(GPIO_PINT5);

        if (NULL != gpio_isr_pool[GPIO_PINT5])
        {
            gpio_isr_pool[GPIO_PINT5]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_6_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT6))
    {
        GPIO_CLRIF(GPIO_PINT6);

        if (NULL != gpio_isr_pool[GPIO_PINT6])
        {
            gpio_isr_pool[GPIO_PINT6]();
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
static void __isr__ gpio_7_isr(void)
{
    if (GPIO_GETIF(GPIO_PINT7))
    {
        GPIO_CLRIF(GPIO_PINT7);

        if (NULL != gpio_isr_pool[GPIO_PINT7])
        {
            gpio_isr_pool[GPIO_PINT7]();
        }
    }
}




