/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      scu.h
Description:    the scu control
Author:         ch
Version:        v1.0
Date:           2017/07/28
History:
*/
/************************************************************************************************/


#ifndef __SCU_REG_H
#define __SCU_REG_H


#include "ssc1667.h"
#include "gpio.h"
//#include "types.h"


/* NMI���������ж�ѡ�� */
typedef enum
{
  SCU_NMIIRQ_RST      = -3,
  SCU_NMIIRQ_NMI      = -2,
  SCU_NMIIRQ_HardFault= -1,
  SCU_NMIIRQ_GPIO0    = 0,
  SCU_NMIIRQ_GPIO1    = 1,
  SCU_NMIIRQ_GPIO2    = 2,
  SCU_NMIIRQ_GPIO3    = 3,
  SCU_NMIIRQ_GPIO4    = 4,
  SCU_NMIIRQ_GPIO5    = 5,
  SCU_NMIIRQ_GPIO6    = 6,
  SCU_NMIIRQ_GPIO7    = 7,
  SCU_NMIIRQ_T16N0    = 8,
  SCU_NMIIRQ_T16N1    = 9,
  SCU_NMIIRQ_T16N2    = 10,
  SCU_NMIIRQ_T32N0    = 12,
  SCU_NMIIRQ_T32N1    = 13,
  SCU_NMIIRQ_T32N2    = 14,
  SCU_NMIIRQ_T32N3    = 15,
  SCU_NMIIRQ_IWDT     = 16,
  SCU_NMIIRQ_WWDT     = 17,
  SCU_NMIIRQ_SPI2     = 18,
  SCU_NMIIRQ_SPI3     = 19,
  SCU_NMIIRQ_UART0    = 20,
  SCU_NMIIRQ_UART1    = 21,
  SCU_NMIIRQ_UART2    = 22,
  SCU_NMIIRQ_UART3    = 23,
  SCU_NMIIRQ_SPI0     = 24,
  SCU_NMIIRQ_SPI1     = 25,
  SCU_NMIIRQ_I2C0     = 26,
  SCU_NMIIRQ_I2C1     = 27,
  SCU_NMIIRQ_AES      = 28,
  SCU_NMIIRQ_ADC      = 29,
  SCU_NMIIRQ_KINT     = 31,
  SCU_NMIIRQ_PLCRX    = 32,
  SCU_NMIIRQ_PLCTX    = 33,
  SCU_NMIIRQ_PLCTIMER = 34,
  SCU_NMIIRQ_DMACDONE = 36,
  SCU_NMIIRQ_DMACRR   = 37,
  SCU_NMIIRQ_ECC      = 38,
  SCU_NMIIRQ_Cache    = 40,
  SCU_NMIIRQ_LVD      = 44,
  SCU_NMIIRQ_COMP     = 45,
} SCU_TYPE_NMICS;

/* PWRC��λ״̬�Ĵ�����־λ */
typedef enum
{
  SCU_PWRC_CHIPRSTF = (1 << 1),     //����λCHIPRST��λ��־
  SCU_PWRC_PORF_3   = (1 << 2),     //POR3.3V��λ��־
  SCU_PWRC_RC_PORF  = (1 << 3),     //RC_POR��λ��־
  SCU_PWRC_BORF     = (1 << 4),     //BOR��λ��־
  SCU_PWRC_IWDTRSTF = (1 << 5),     //IWDT��λ��־
  SCU_PWRC_MRSTF    = (1 << 6),     //MRSTn��ʧ��־λ
  SCU_PWRC_SOFTRSTF = (1 << 7),     //������ʧ��־λ
  SCU_PWRC_POR_LOST = (1 << 8),     //POR��ʧ��־λ
  SCU_PWRC_LOCKUP_RST = (1 << 9),   //CPU������λ��־λ
  SCU_PWRC_WWDTRSTF = (1 << 10),    //WWDT��λ��־λ
} SCU_TYPE_PWRC;

/* LVD�Ĵ�����־λ */
typedef enum
{
  SCU_LVDFlag_IF  = (1 << 8),  //LVD�жϱ�־
  SCU_LVDFlag_Out = (1 << 15), //���״̬λ
} SCU_TYPE_LVDCON;

/* SYSCLKϵͳʱ�ӵ�ѡ�� */
typedef enum
{
  SCU_SYSCLK_LRC   = 0x01,      //�ڲ�����32KHz
  SCU_SYSCLK_HRC   = 0x02,      //�ڲ�����25MHz
  SCU_SYSCLK_XTAL  = 0x03,      //�ⲿ25MHz
  SCU_SYSCLK_DPLL2 = 0x04,     //DPLL2�����ʱ��
  WRONG_SET        = 0X0f,      //ʱ�Ӵ���
} SCU_TYPE_SYSCLK;

/*DPLL2��־λ*/
typedef enum
{
  SCU_DPLL2_LOCKED= (1 << 28), //DPLL2 LOCK ָʾλ
  SCU_DPLL2_FLAG1 = (1 << 29), //DPLL2���ֿ�������ȫ1ָʾ��־
  SCU_DPLL2_FLAG0 = (1 << 30), //DPLL2���ֿ�������ȫ0ָʾ��־
} SCU_TYPE_DPLL2;

typedef enum
{
  SCU_DMA = 0,
  SCU_USB = 1,
  SCU_SRAM = 2,
  SCU_APB1 = 3,
  SCU_APB2 = 4,
  SCU_ETH = 5,
} SCU_AHBPERI_Typedef;

typedef enum
{
  SCU_AHBEN_ABP2_PRE1_HCLK_0 = 0,
  SCU_AHBEN_ABP2_PRE1_HCLK_2,
  SCU_AHBEN_ABP2_PRE1_HCLK_4,
  SCU_AHBEN_ABP2_PRE1_HCLK_8,
}SCU_AHBEN_ABP2_PRE1_Typedef; 

typedef enum
{
  SCU_AHBEN_ABP1_PRE1_HCLK_2_0 = 0,
  SCU_AHBEN_ABP1_PRE1_HCLK_2_1 = 1,
  SCU_AHBEN_ABP1_PRE1_HCLK_4   = 2,
  SCU_AHBEN_ABP1_PRE1_HCLK_8   = 3,
}SCU_AHBEN_ABP1_PRE1_Typedef;

// PLLʱ��Դѡ��
typedef enum
{
  SCU_DPLL2_HRC   = 0x0,    //PLLʱ��ԴΪ�ڲ�25MHz
  SCU_DPLL2_XTAL  = 0x1,    //PLLʱ��ԴΪ�ⲿ25MHz
} SCU_DPLL2_Origin;

// PLLʱ�����Ƶ������
typedef enum
{
  SCU_DPLL2_200M  = 0x0 ,   //PLLʱ�����Ϊ200MHz
  SCU_DPLL2_150M  = 0x1 ,   //PLLʱ�����Ϊ150Mhz
} SCU_DPLL2_Out;


/************SCUģ��궨��***********/

/* SCUд�������� */
#define SCU_RegUnLock() (SCU->PROT.Word = 0x55AA6996)
#define SCU_RegLock()   (SCU->PROT.Word = 0x00000000)
/* TSTд�������� */
#define TST_RegUnLock_0() (SCU->TST_PROT.Word = 0x54455354)
#define TST_RegUnLock_1() (SCU->TST_PROT.Word = 0x4d4f4445)

#define TST_RegLock()   (SCU->TST_PROT.Word = 0x4d4f4400)

/* NMIʹ�ܿ��� */
#define SCU_NMI_Enable()    (SCU->NMICON.NMIEN = 0x1)
#define SCU_NMI_Disable()   (SCU->NMICON.NMIEN = 0x0)

/*-------LVDģ��-------*/

/* LVDʹ�ܿ��� */
#define SCU_LVD_Enable()    (SCU->LVDCON.EN = 0x1)
#define SCU_LVD_Disable()   (SCU->LVDCON.EN = 0x0)

/* LVD�˲�ʹ�ܿ��� */
#define SCU_LVDFLT_Enable()   (SCU->LVDCON.FLTEN = 0x1)
#define SCU_LVDFLT_Disable()  (SCU->LVDCON.FLTEN = 0x0)

/* LVD������ѹѡ�� */
#define SCU_LVDVS_1V80()  (SCU->LVDCON.VS = 0x0)
#define SCU_LVDVS_1V88()  (SCU->LVDCON.VS = 0x1)
#define SCU_LVDVS_1V96()  (SCU->LVDCON.VS = 0x2)
#define SCU_LVDVS_2V04()    (SCU->LVDCON.VS = 0x3)
#define SCU_LVDVS_2V12()  (SCU->LVDCON.VS = 0x4)
#define SCU_LVDVS_2V20()  (SCU->LVDCON.VS = 0x5)
#define SCU_LVDVS_2V28()  (SCU->LVDCON.VS = 0x6)
#define SCU_LVDVS_2V36()  (SCU->LVDCON.VS = 0x7)
#define SCU_LVDVS_2V44()  (SCU->LVDCON.VS = 0x8)
#define SCU_LVDVS_2V52()  (SCU->LVDCON.VS = 0x9)
#define SCU_LVDVS_2V60()  (SCU->LVDCON.VS = 0xA)
#define SCU_LVDVS_2V68()  (SCU->LVDCON.VS = 0xB)
#define SCU_LVDVS_2V76()    (SCU->LVDCON.VS = 0xC)
#define SCU_LVDVS_2V84()  (SCU->LVDCON.VS = 0xD)
#define SCU_LVDVS_2V92()  (SCU->LVDCON.VS = 0xE)
#define SCU_LVDVS_3V00()  (SCU->LVDCON.VS = 0xF)

/* LVD�ж�ʹ�ܿ��� */
#define SCU_LVDIT_Enable()  (SCU->LVDCON.IE = 0x1)
#define SCU_LVDIT_Disable() (SCU->LVDCON.IE = 0x0)

/* LVD�жϱ�־λ��� */
#define SCU_LVDClearIFBit() (SCU->LVDCON.IF = 1)

/* LVD�жϲ���ģʽѡ�� */
#define SCU_LVDIFS_Rise()   (SCU->LVDCON.IFS = 0x0) //LVDO�����ز����ж�
#define SCU_LVDIFS_Fall()   (SCU->LVDCON.IFS = 0x1) //LVDO�½��ز����ж�
#define SCU_LVDIFS_High()   (SCU->LVDCON.IFS = 0x2) //LVDO�ߵ�ƽ�����ж�
#define SCU_LVDIFS_Low()    (SCU->LVDCON.IFS = 0x3) //LVDO�͵�ƽ�����ж�
#define SCU_LVDIFS_Change() (SCU->LVDCON.IFS = 0x4) //LVDO��ƽ�仯�����ж�

/* FLASH���ʵȴ�ʱ��ѡ�� */
#define SCU_FlashWait_2Tclk() (SCU->FLASHWAIT.ACCT = 0x0)
#define SCU_FlashWait_3Tclk()   (SCU->FLASHWAIT.ACCT = 0x1)
#define SCU_FlashWait_4Tclk()   (SCU->FLASHWAIT.ACCT = 0x2)
#define SCU_FlashWait_5Tclk()   (SCU->FLASHWAIT.ACCT = 0x3)
#define SCU_FlashWait_6Tclk()   (SCU->FLASHWAIT.ACCT = 0x4)
#define SCU_FlashWait_7Tclk()   (SCU->FLASHWAIT.ACCT = 0x5)
#define SCU_FlashWait_8Tclk()   (SCU->FLASHWAIT.ACCT = 0x6)
#define SCU_FlashWait_9Tclk()   (SCU->FLASHWAIT.ACCT = 0x7)
#define SCU_FlashWait_10Tclk()  (SCU->FLASHWAIT.ACCT = 0x8)
#define SCU_FlashWait_11Tclk()  (SCU->FLASHWAIT.ACCT = 0x9)
#define SCU_FlashWait_12Tclk()  (SCU->FLASHWAIT.ACCT = 0xA)
#define SCU_FlashWait_13Tclk()  (SCU->FLASHWAIT.ACCT = 0xB)
#define SCU_FlashWait_14Tclk()  (SCU->FLASHWAIT.ACCT = 0xC)
#define SCU_FlashWait_15Tclk()  (SCU->FLASHWAIT.ACCT = 0xD)
#define SCU_FlashWait_16Tclk()  (SCU->FLASHWAIT.ACCT = 0xE)
#define SCU_FlashWait_17Tclk()  (SCU->FLASHWAIT.ACCT = 0xF)

/*ϵͳ��ʱ��Ԥ��Ƶѡ��*/
#define SCU_MCU_DIV1()  (SCU->SCLKEN0.MCU_DIV 0 = 0X00)
#define SCU_MCU_DIV2()  (SCU->SCLKEN0.MCU_DIV 0 = 0X01)
#define SCU_MCU_DIV4()  (SCU->SCLKEN0.MCU_DIV 0 = 0X11)

/* �ⲿʱ�ӵ͹���ģʽ */
#define SCU_XTAL_LP_Enable()    (SCU->SCLKEN0.XTAL_LP = 0)
#define SCU_XTAL_LP_Disable() (SCU->SCLKEN0.XTAL_LP = 1)

/* ��˯��ʱ�ر�XTAL�����· */
#define SCU_MOSC_XTAL_Enable()    (SCU->SCLKEN0.MOSCEN = 1)
#define SCU_MOSC_XTAL_Disable()   (SCU->SCLKEN0.MOSCEN = 0)

/* ��˯��ʱ�ر�XTAL�����˲���· */
#define SCU_MOSC_XTAL_FILT_Enable()   (SCU->SCLKEN0.CLKFLT_EN = 1)
#define SCU_MOSC_XTAL_FILT_Disable()  (SCU->SCLKEN0.CLKFLT_EN = 0)

/* ����APBʱ��Ԥ��ƵAPB2 */
#define SCU_APB2_PRE1_DIV1()     (SCU->AHBEN.APB2_PRE1 = 0X00)
#define SCU_APB2_PRE1_DIV2()     (SCU->AHBEN.APB2_PRE1 = 0X01)
#define SCU_APB2_PRE1_DIV4()     (SCU->AHBEN.APB2_PRE1 = 0X10)
#define SCU_APB2_PRE1_DIV8()     (SCU->AHBEN.APB2_PRE1 = 0X11)

/* ����APBʱ��Ԥ��ƵAPB1 */
#define SCU_APB1_PRE1_DIV1()     (SCU->AHBEN.APB1_PRE1 = 0X00)
#define SCU_APB1_PRE1_DIV2()     (SCU->AHBEN.APB1_PRE1 = 0X01)
#define SCU_APB1_PRE1_DIV4()     (SCU->AHBEN.APB1_PRE1 = 0X10)
#define SCU_APB1_PRE1_DIV8()     (SCU->AHBEN.APB1_PRE1 = 0X11)

/* �ж���������ӳ��ʹ�ܿ��� */
#define SCU_TBLRemap_Enable()   (SCU->TBLREMAPEN.EN= 1)
#define SCU_TBLRemap_Disable()  (SCU->TBLREMAPEN.EN= 0)

/* �ж�������ƫ�ƼĴ��� x���Ϊ2^24=16777216 */
#define SCU_TBL_Offset(x)   (SCU->TBLOFF.TBLOFF = (uint32_t)x)

#define AHBPERI_CLK_EN(periph)  \
{\
    SCU_RegUnLock();\
    SCU->AHBEN.Word |= (0x01 << (periph));\
    SCU_RegLock();\
}

#define AHBPERI_CLK_DIS(periph)  \
{\
    SCU_RegUnLock();\
    SCU->AHBEN.Word &= ~(0x01 << (periph));\
    SCU_RegLock();\
}

#define APB2PERI_CLK_EN(periph)   \
{\
    SCU_RegUnLock();\
    SCU->APB2EN.Word |= (0x01 << (periph));\
    SCU_RegLock();\
}

#define APB2PERI_CLK_DIS(periph)  \
{\
    SCU_RegUnLock();\
    SCU->APB2EN.Word &= ~(0x01 << (periph));\
    SCU_RegLock();\
}

#define APB1PERI_CLK_EN(periph)   \
{\
    SCU_RegUnLock();\
    SCU->APB1EN.Word |= (0x01 << (periph));\
    SCU_RegLock();\
}

#define APB1PERI_CLK_DIS(periph)    \
{\
    SCU_RegUnLock();\
    SCU->APB1EN.Word &= ~(0x01 << (periph));\
    SCU_RegLock();\
}

#endif /* __LIB_SCU_H */
