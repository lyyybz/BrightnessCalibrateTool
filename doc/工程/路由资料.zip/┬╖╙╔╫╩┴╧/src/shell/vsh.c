/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      vsh.c
Description:    A very tiny shell implementation, including views and commands.
Author:         ch
Version:        v1.0
Date:           2017/06/21
History:
*/
/************************************************************************************************/
#include "type.h"
#include "rbtree.h"
#include "sys.h"
#include "vsh.h"
#include "term.h"
#include "cmd.h"
#include "shell.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>


int pid_vsh;

#ifndef TINYSH
static int xsh_check_arg(xsh_t *xsh, command_t *cmd);
static void arg_versus_param(xsh_t *xsh, command_t *cmd);
static void cmd_dokey_tab(xsh_t *xsh, command_t *cmd);
static void print_info_cmd(xsh_t *xsh, command_t *cmd);
#endif

static int view_cmp(struct rb_node *n, void *key);

#if 0
view_t g_viewtab[] =
{
    VIEWTAB_ENTRY(root, "[1667 /]$ "),
};

command_t g_cmdtab[] = {
    CMDTAB_ENTRY(reboot, root, root, docmd_reboot, NULL),
    CMDTAB_ENTRY(read, root, root, docmd_read, &cmd_read_desc),
    CMDTAB_ENTRY(write, root, root, docmd_write, &cmd_write_desc),
    CMDTAB_ENTRY(os, root, root, docmd_os, &cmd_os_desc),
};
#endif

extern view_t g_viewtab[];
extern unsigned int g_viewtab_num;

extern command_t g_cmdtab[];
extern unsigned int g_cmdtab_num;

int ref = 0;
rb_tree_t g_view_tr;
xsh_t g_vsh;

param_t cmd_none_param_tab[] = {
    PARAM_EMPTY
};

void view_command_init()
{
    int i;

    if ( !ref ) ref = 1;
    else return;

    /* firstly, init view tree */
    rb_tree_init(&g_view_tr,
             view_cmp,
             rb_tree_find_default,
             rb_tree_insert_default,
             rb_tree_erase_default,
             (rb_treenode_del_fp)0,
             rb_tree_finalize_default);

    /* secondly, add views into the view tree */
    for ( i = 0; i < g_viewtab_num; i++ )
    {
        /*char *s;*/
        struct rb_node **p, *pa;

        /*
        if ( !(s = (char *)malloc(strlen(g_viewtab[i].prompt)+1)) ) {
            TRI_DEBUG("malloc error");
            continue;
        }
        strcpy(s, g_viewtab[i].prompt);
        g_viewtab[i].prompt = s;
        */

        rb_tree_init(&g_viewtab[i].cmd_tr,
                 command_cmp_ws,
                 rb_tree_find_default,
                 rb_tree_insert_default,
                 rb_tree_erase_default,
                 (rb_treenode_del_fp)0,
                 rb_tree_finalize_default);

        p = g_view_tr.find(&g_view_tr, g_viewtab[i].name, &pa);
        if ( !*p )
            g_view_tr.insert(&g_view_tr, &g_viewtab[i].rb, pa, p);
    }

#if 0
    {
        struct rb_node *n;

        //for ( n = g_view_tr.first; n; n = rb_next(n) ) {
        //  view_t *view = rb_entry(n, view_t, rb);
        //
        //  printf_s("[%s]\n", view->name);
        //}
        tree_traverse(rb,
                  &g_view_tr,
                  n,
                  view_t *view = rb_entry(n, view_t, rb);
                  printf_s("[%s]\n", view->name););
    }
#endif

    /* thirdly, add the commands into the corresponding view's command tree */
    for ( i = 0; i < g_cmdtab_num; i++ )
    {
        /*char *s;*/
        struct rb_node **p, *pa;
        view_t *view;
        param_t *param;
        command_t *cmd = &g_cmdtab[i];

        p = g_view_tr.find(&g_view_tr, cmd->cview_nm, &pa);
        if ( !*p ) continue;

        view = rb_entry(*p, view_t, rb);
        cmd->cview = view;
        p = view->cmd_tr.find(&view->cmd_tr, cmd->name, &pa);
        if ( !*p )
            view->cmd_tr.insert(&view->cmd_tr, &cmd->rb, pa, p);
        else
            XSH_PANIC();

        p = g_view_tr.find(&g_view_tr, cmd->nview_nm, &pa);
        if ( *p )
        {
            view = rb_entry(*p, view_t, rb);
            cmd->nview = view;
        }
        else
        {
            cmd->nview = (view_t *)0;
        }

        cmd->len = strlen(cmd->name) + (cmd->cview != cmd->nview ? 1 : 0);
        /*
        if ( !(s = (char *)malloc(cmd->len+1)) ) {
            TRI_DEBUG("malloc error");
            continue;
        }
        strcpy(s, cmd->name);
        cmd->name = s;
        */

        /* finally, build searching threads among parameter descriptors of a command */
        if (!cmd->desc) continue;

        for (param = cmd->desc->param_tab; param->type != PARAM_NONE; param++)
        {
            if (!(param->type & PARAM_SUB))
            {
                if (!cmd->desc->list)
                {
                    cmd->desc->list = param;
                    INIT_LIST_HEAD(&param->next);
                }
                else
                {
                    list_add_tail(&param->next, &cmd->desc->list->next);
                }
            }
            else
            {
                param_t *pa_param;
                //char __c, *__s, *tok;
                char *__s, *tok;
                int __slen = 0;

                for (pa_param = param-1; pa_param >= cmd->desc->param_tab;
                     pa_param--) {
                    /* SUB's parent must be a TOGGLE */
                    if (!(pa_param->type & PARAM_TOGGLE))
                        continue;

                    for (tok = __s = pa_param->help; ; ++__s)
                    {
                        ++__slen;
                        if (!*__s || *__s == '|')
                        {
                            //__c = *__s;
                            //*__s = '\0';

                            //if (strcmp(param->ref, tok) == 0)
                            if (memcmp(param->ref, tok, __slen - 1) == 0)
                            {
                                if (!pa_param->list)
                                {
                                    pa_param->list = param;
                                    INIT_LIST_HEAD(&param->next);
                                }
                                else
                                {
                                    list_add_tail(&param->next,
                                              &pa_param->list->next);
                                }

                                //*__s = __c;
                                goto out;
                            }

                           // *__s = __c;
                            if (!*__s) break;
                            tok = __s + 1;
                            __slen = 0;
                        }
                    }
                }

            out:
                continue;
            }
        }
    }

    return;
}


void vsh_init(tty_t *term)
{
    unsigned int i;
    xsh_t *vsh = &g_vsh;

    view_command_init();

    /* i'm lazy :-), otherwise i will search for root view */
    vsh->curr = vsh->root = &g_viewtab[0];

    vsh->exec = (command_t *)0;
    vsh->opts = (char *)0;
    vsh->nr_exec_ent = 0;
    INIT_LIST_HEAD(&vsh->exec_ent_list);

    /* these two do not need initialization actually */
    INIT_LIST_HEAD(&vsh->match);
    vsh->nr_match = 0;

    vsh->term = term;
    vsh->decor[0] = 0;
    strncpy(vsh->prompt, vsh->root->prompt, TTY_BUF_SIZE_MAX);

    vsh->term->context = (void *)vsh;
    vsh->term->hooks[VTAB]  = xsh_dokey_tab;
    vsh->term->hooks[VHELP] = xsh_dokey_help;
    vsh->term->hooks[VPREV] = xsh_dokey_previous;
    vsh->term->hooks[VNEXT] = xsh_dokey_next;

    INIT_LIST_HEAD(&vsh->histent[0].link);
    for ( i = 1; i < NR_HISTENT_MAX; i++ )
        list_add_tail(&vsh->histent[i].link, &vsh->histent[0].link);
    vsh->hist = vsh->hbeg = vsh->hend = &vsh->histent[0].link;
}


void task_xsh(ULONG arg)
{
#ifdef TINYSH
    int i;
    struct list_head *pos, *n;
    exec_ent_t *exec_ent;
#endif
    int ret;
    xsh_t *xsh = (xsh_t *)arg;

//    for ( ;; )
    xsh->line_size = xsh->term->op.getline(xsh->term, xsh->line, TTY_BUF_SIZE_MAX);
    if (xsh->line_size > 0)
    {
        /* Only when the `term' has got a line with at least ONE character,
         * `xsh' may need to perform command resolution. During the process,
         * `xsh' may find that the line is totally blank which doesn't need
         * to be added into history.
         */
        //if ( (xsh->line_size = xsh->term->op.getline(xsh->term, xsh->line, TTY_BUF_SIZE_MAX)) )
        {
            if ( (ret = xsh_resolve_cmd(xsh)) <= 0 )
            {
                if (ret < 0)
                    xsh->term->op.devprintf(xsh->term, "%s: Command not found!\n",
                                xsh->opts);
#           ifdef TINYSH
                list_for_each_safe(pos, n, &xsh->exec_ent_list) {
                    exec_ent = list_entry(pos, exec_ent_t, link);

                    list_del(&exec_ent->link);
                    free_exec_ent(exec_ent);
                }
                xsh->nr_exec_ent = 0;
#           endif
//                continue;
            }

#       ifdef TINYSH
            list_for_each_safe(pos, n, &xsh->exec_ent_list) {
                exec_ent = list_entry(pos, exec_ent_t, link);

                load_exec_ent(xsh, exec_ent);
#       endif
                if ( xsh->exec ) {
                    xsh->_argc = 1;
                    xsh->exec->action(xsh->exec, xsh);
                    xsh->exec = (command_t *)0;
                }
#       ifdef TINYSH
                list_del(&exec_ent->link);
                free_exec_ent(exec_ent);
            }
            xsh->nr_exec_ent = 0;
#       endif
        }
    }
    else if (xsh->line_size < 0)
    {
        return;
    }
    
    xsh->term->op.devputs(xsh->term, xsh->prompt);
    xsh->term->op.save_pos(xsh->term, strlen(xsh->prompt));

    return;
}


void xsh_push_hist(xsh_t *xsh, char *s)
{
    histent_t *ent;

    ent = list_entry(xsh->hend, histent_t, link);
    strncpy(ent->line, s, TTY_BUF_SIZE_MAX);

    xsh->hist = xsh->hend = xsh->hend->next;

    if ( xsh->hend == xsh->hbeg )
        xsh->hbeg = xsh->hbeg->next;

    return;
}


void xsh_update_view(xsh_t *xsh, view_t *view)
{
    char *brk;
    int len, decor_len;

    xsh->curr = view;
    decor_len = strlen(xsh->decor);
    brk       = strchr(xsh->curr->prompt, ' ');
    len       = brk - xsh->curr->prompt;

    strncpy(xsh->prompt, xsh->curr->prompt, len);
    strncpy(xsh->prompt+len, xsh->decor, decor_len);
    strncpy(xsh->prompt+len+decor_len, xsh->curr->prompt+len, TTY_BUF_SIZE_MAX-len-decor_len);
    return;
}


void xsh_update_decor(xsh_t *xsh, char *decor)
{
    char *brk;
    int len, decor_len;

    strncpy(xsh->decor, decor, TTY_BUF_SIZE_MAX/2);

    decor_len = strlen(xsh->decor);
    brk       = strchr(xsh->curr->prompt, ' ');
    len       = brk - xsh->curr->prompt;

    strncpy(xsh->prompt, xsh->curr->prompt, len);
    strncpy(xsh->prompt+len, xsh->decor, decor_len);
    strncpy(xsh->prompt+len+decor_len, xsh->curr->prompt+len, TTY_BUF_SIZE_MAX-len-decor_len);
    return;
}


int xsh_resolve_cmd(xsh_t *xsh)
{
#ifndef TINYSH
    int i, quot = 0;
    char *head, *tail;
    struct rb_node **p, *pa = NULL;

    /* remove leading white spaces */
    for ( head = xsh->line; *head && (*head == ' ' || *head == '\t'); head++ )
        ;
    tail = xsh->line + xsh->line_size;
    /* remove tailing white spaces */
    for ( tail = tail-1; (tail != head) && (*tail == ' ' || *tail == '\t'); tail-- )
        ;
    *(tail+1) = 0;

    if ( !*(xsh->opts = head) )
        return 0;

    /* arriving here, i know that at least this line is not a blank line */
    xsh_push_hist(xsh, xsh->opts);

    xsh->argc = 1;
    xsh->argv[0] = head;
    xsh->argv[1] = (char *)0;
    xsh->arg2param[1] = (param_t *)0;

    /* longer-first resolving for multi-word commands */
    while ( tail != head )
    {
        p = xsh->curr->cmd_tr.find(&xsh->curr->cmd_tr, xsh->opts, &pa);

        if ( *p )
        {
            xsh->exec = rb_entry(*p, command_t, rb);
            if ( !xsh_check_arg(xsh, xsh->exec) )
                goto arg_err;

            return 1;
        }

        if ( xsh->curr != xsh->root ) {
            p = xsh->root->cmd_tr.find(&xsh->root->cmd_tr, xsh->opts, &pa);
            if ( *p ) {
                xsh->exec = rb_entry(*p, command_t, rb);
                if ( !xsh_check_arg(xsh, xsh->exec) )
                    goto arg_err;

                return 1;
            }
        }

        /* spit out one word, and characters enclosed by a pair of quotation is
         * considered as a single word.
         */
        for ( ; (tail != head); tail-- ) {
            if ( *tail == '"' || *tail == '\'' )
                quot = !quot;
            else if ( !quot && (*tail == ' ' || *tail == '\t') )
                break;
        }
        if ( tail == head ) goto cmd_err;

        /* build argc & argv as comamnd execution environment */
        if ( ++xsh->argc > NR_ARG_MAX )
				  {
            XSH_PANIC();
						goto cmd_err;
					}
        xsh->arg2param[xsh->argc] = (param_t *)0;
        for ( i = xsh->argc; i > 1; i-- )
            xsh->argv[i] = xsh->argv[i-1];
        xsh->argv[1] = tail+1;

        /* skip white spaces leading this word */
        for ( ; (tail != head) && (*tail == ' ' || *tail == '\t'); tail-- )
            ;
        *(tail+1) = 0;
    }
    xsh->argv[xsh->argc] = (char *)0;

    /* only for the sake of the command name that consists of one character */
    p = xsh->curr->cmd_tr.find(&xsh->curr->cmd_tr, xsh->opts, &pa);

    if ( *p ) {
        xsh->exec = rb_entry(*p, command_t, rb);
        if ( !xsh_check_arg(xsh, xsh->exec) )
            goto arg_err;

        return 1;
    }

    if ( xsh->curr != xsh->root ) {
        p = xsh->root->cmd_tr.find(&xsh->root->cmd_tr, xsh->opts, &pa);
        if ( *p ) {
            xsh->exec = rb_entry(*p, command_t, rb);
            if ( !xsh_check_arg(xsh, xsh->exec) )
                goto arg_err;

            return 1;
        }
    }

 cmd_err:
    if ( quot ) xsh->term->op.devputs(xsh->term, "No matching quotations!\n");
    return -1;
 arg_err:
    xsh->exec = (command_t *)0;
    return 0;
#else
    extern int yyparse_resolve_cmd(xsh_t *xsh);
    return yyparse_resolve_cmd(xsh);
#endif
}


char * xsh_getopt(xsh_t *xsh)
{
    if (xsh->_argc == xsh->argc) 
    {
        return (char *)0;
    }

    return xsh->argv[xsh->_argc++];
}


#ifndef TINYSH
int xsh_check_arg(xsh_t *xsh, command_t *cmd)
{
    char *suffix[4], *ref = "", *s, *value;
    int i, len;
    tty_t *term = xsh->term;
    param_t *param, *_param;
    struct list_head *pos, *head;

    if ( !cmd->desc || !cmd->desc->param_tab || !cmd->desc->list )
    {
        if (cmd->desc &&
            cmd->desc->param_tab == cmd_none_param_tab &&
            xsh->argc > 1)
        {
            print_prompt(xsh->argv[1]-xsh->line, xsh);
            term->op.devprintf(term, "Unknown argument: %s\n", xsh->argv[1]);
            return 0;
        }

        return 1;
    }

    for ( param = cmd->desc->param_tab; param->type != PARAM_NONE;
          param++ )
    {
        param->type &= ~PARAM_DONE;
    }

    arg_versus_param(xsh, cmd);

    /* Check whether the inputing arguments are right, the wrong location
     * is indicated by the symbol '^', and
     * An argument of `PARAM_OPT' must have its value.
     * An argument of `PARAM_INTEGER' must not have any dot.
     * An argument of `PARAM_NUMBER' may have a dot.
     * An argument of `PARAM_STRING' must consis of printable characters.
     */
    for ( i = 1; i < xsh->argc; i++ )
    {
        s = xsh->argv[i];

        if ( !xsh->arg2param[i] )
        {
            suffix[0] = "Unknown argument: ";
            suffix[1] = xsh->argv[i];
            suffix[2] = suffix[3] = "";
            goto fail;
        }
        if ( (xsh->arg2param[i]->type & PARAM_OPT) || (xsh->arg2param[i]->type & PARAM_ARG) )
        {
            if ( xsh->arg2param[i]->type & PARAM_OPT )
            {
                s = strchr(s, '=');
                if ( !*(++s) )
                {
                    suffix[0] = "Missing value for argument: ";
                    suffix[1] = xsh->argv[i];
                    suffix[2] = suffix[3] = "";
                    goto fail;
                }
            }

            if ( xsh->arg2param[i]->type & PARAM_TOGGLE )
            {
                //char __c, *__s, *tok;
                char *__s, *tok;
                int ok = 0, __slen = 0;

                for (tok = __s = xsh->arg2param[i]->help; ; ++__s)
                {
                    ++__slen;
                    if (!*__s || *__s == '|')
                    {
                        //__c = *__s;
                        //*__s = '\0';

                        //if (strcmp(tok, s) == 0)
                        if (memcmp(tok, s, __slen-1) == 0)
                        {
                            //*__s = __c;
                            ok = 1;
                            break;
                        }

                        //*__s = __c;
                        if (!*__s) break;
                        tok = __s + 1;
                        __slen = 0;
                    }
                }
                if (ok) continue;

                suffix[0] = "Argument \"";
                suffix[1] = xsh->argv[i];
                suffix[2] = "\" should be ";
                suffix[3] = xsh->arg2param[i]->help;
                goto fail;
            }

            value     = s;
            suffix[0] = xsh->arg2param[i]->type & PARAM_OPT ? "Value \"" : "Argument \"";
            suffix[1] = xsh->arg2param[i]->type & PARAM_OPT ? value+1 : value;
            suffix[2] = "\" should be ";

            if (xsh->arg2param[i]->type & PARAM_INTEGER)
            {
                for (; *s; s++)
                {
                    if ((*s == '-' && s != value) ||
                        ((*s == 'x' || *s == 'X') && s != value+1 && *(s-1) != '0') ||
                        (!isxdigit((int)*s) && *s != '-' && *s != 'x' && *s != 'X'))
                    {
                        suffix[3] = "an integer";
                        goto fail;
                    }
                }
            }
            else if (xsh->arg2param[i]->type & PARAM_NUMBER)
            {
                for (; *s; s++)
                {
                    if ((*s == '-' && s != value) ||
                        ((*s == 'x' || *s == 'X') && s != value+1 && *(s-1) != '0') ||
                        (!isxdigit((int)*s) && *s != '.' && *s != '-' && *s != 'x' && *s != 'X'))
                    {
                        suffix[3] = "a number";
                        goto fail;
                    }
                }
            }
            else if (xsh->arg2param[i]->type & PARAM_STRING ||
                   xsh->arg2param[i]->type & PARAM_MAC ||
                   xsh->arg2param[i]->type & PARAM_IP)
            {
                for (; *s; s++)
                {
                    if (!isprint((int)*s))
                    {
                        suffix[3] = "a string";
                        goto fail;
                    }
                }
            }
        }

        continue;

    fail:
        len = s - xsh->line;
        print_prompt(len, xsh);
        term->op.devprintf(term, "%s%s%s%s.\n",
                   suffix[0], suffix[1], suffix[2], suffix[3]);
        return 0;
    }

    /* Check whether there's any ONE parameter descriptor cannot find its relevant argument.
     */
    pos = head = &cmd->desc->list->next;
    _param = cmd->desc->n;
    i = 0;

    do {
    again:
        param = list_entry(pos, param_t, next);

        if (param == _param)
        {
            _param = _param->n;
            i++;

            if ((param->type & PARAM_TOGGLE) && (param->list))
            {
                ref = xsh->argv[i];
                pos = head = &param->list->next;
                goto again;
            }

            goto out;
        }
        if ((param->type & PARAM_DONE) || (param->type & PARAM_OPTIONAL))
        {
            goto out;
        }
        if ((param->type & PARAM_SUB) && strcmp(ref, param->ref))
        {
            goto out;
        }

        param_info(param, suffix[0]);

        len = xsh->line_size;
        if (*(xsh->line + xsh->line_size - 1) != 0 &&
            *(xsh->line + xsh->line_size - 1) != ' ')
            ++len;
        print_prompt(len, xsh);

        term->op.devprintf(term,
                   "Missing argument: %s%s%s%s%s.\n",
                   param->type & PARAM_OPT ? "-" : "",
                   param->name,
                   param->type & PARAM_OPT ? "=" : "",
                   suffix[0],
                   param->type & PARAM_LIST ? "..." : "");
        return 0;

    out:
        pos = pos->next;
    } while (pos != head);

    return 1;
}


static void arg_versus_param(xsh_t *xsh, command_t *cmd)
{
    char *s, *ref;
    int i, illegal;
    param_t *param, **n;
    struct list_head *pos, *head;

    head = &cmd->desc->list->next;
    n = &cmd->desc->n;
    *n = 0;

    for (i = 1; i < xsh->argc; i++)
    {
        pos = head;

        do {
            param = list_entry(pos, param_t, next);

            if (!(param->type & PARAM_LIST) && (param->type & PARAM_DONE))
                continue;
            /* Donot worry about `ref', since it's value will be determined
             * right befored being used.
             */
            if ((param->type & PARAM_SUB) && strcmp(ref, param->ref))
                continue;

            if (param->type & PARAM_OPT)
            {
                if (xsh->argv[i][0] == '-' && (s = strchr(xsh->argv[i], '=')) &&
                    (strncmp(xsh->argv[i]+1, param->name, s-xsh->argv[i]-1) == 0))
                    goto found;
            }
            else if (param->type & PARAM_FLG)
            {
                if (xsh->argv[i][0] == '-' && !strchr(xsh->argv[i], '=') &&
                    strcmp(xsh->argv[i]+1, param->name) == 0)
                    goto found;
            }
            else if (param->type & PARAM_ARG)
            {
                if (param->type & PARAM_TOGGLE)
                {
                    char __c, *__s, *tok, help[100] = {'\0'};
                    int ok = 0;

                    strcpy(help, param->help);
                    //for (tok = __s = param->help; ; ++__s)
                    for (tok = __s = help; ; ++__s)
                    {

                        if (!*__s || *__s == '|')
                        {
                            __c = *__s;
                            *__s = '\0';

                            if (strprefix(tok, xsh->argv[i]))
                            {
                                *__s = __c;
                                ok = 1;
                                break;
                            }

                            *__s = __c;
                            if (!*__s) break;
                            tok = __s + 1;
                        }
                    }

                    if (ok)
                    {
                        if (param->list)
                        {
                            ref = xsh->argv[i];
                           head = &param->list->next;
                        }
                        goto found;
                    }
                }
                else if (param->type & PARAM_LIST)
                {
                    if (!strchr(xsh->argv[i], '-') && !strchr(xsh->argv[i], '='))
                        goto found;
                }
                else if (param->type & PARAM_RANGE)
                {
                    if (!strchr(xsh->argv[i], '='))
                        goto found;
                }
                else if (param->type & PARAM_OPTIONAL)
                {
                    if (param->type & PARAM_INTEGER)
                    {
                        for (illegal = 0, s = xsh->argv[i]; *s; s++)
                        {
                            if ((*s == '-' && s != xsh->argv[i]) ||
                                ((*s == 'x' || *s == 'X') && s != xsh->argv[i]+1 && *(s-1) != '0') ||
                                (!isxdigit((int)*s) && *s != '-' && *s != 'x' && *s != 'X'))
                            {
                                illegal = 1;
                                break;
                            }
                        }
                        if (!illegal)
                        {
                            goto found;
                        }
                    }
                    else if (param->type & PARAM_NUMBER)
                    {
                        for (illegal = 0, s = xsh->argv[i]; *s; s++)
                        {
                            if ((*s == '-' && s != xsh->argv[i]) ||
                                ((*s == 'x' || *s == 'X') && s != xsh->argv[i]+1 && *(s-1) != '0') ||
                                (!isxdigit((int)*s) && *s != '.' && *s != '-' && *s != 'x' && *s != 'X'))
                            {
                                illegal = 1;
                                break;
                            }
                        }
                        if (!illegal)
                        {
                            goto found;
                        }
                    }
                }
                else
                {
                    if (!strchr(xsh->argv[i], '-') && !strchr(xsh->argv[i], '='))
                    {
                        goto found;
                    }
                }
            }
        } while ((pos = pos->next) != head);
        continue;

    found:
        param->n = 0;
        *n = param;
        n = &param->n;
        xsh->arg2param[i] = param;
        xsh->arg2param[i]->type |= PARAM_DONE;
    }

    return;
}
#endif


void xsh_dokey_tab(void *context)
{
#ifndef TINYSH
    int len, i = 0, quot = 0;
    char c, *head, *tail;
    char *min_suffix, *suf_head;
    unsigned int min = 0xffffffff, max = 0;
    unsigned int gap, col;
    struct list_head *pos;
    struct rb_node *node, *_node, **p, *pa = NULL;
    command_t *cmd, *min_cmd;
    xsh_t *xsh = (xsh_t *)context;
    tty_t *term = xsh->term;

    xsh->nr_match = 0;
    INIT_LIST_HEAD(&xsh->match);

    xsh->line_size = xsh->term->op.read(xsh->term, xsh->line, TTY_BUF_SIZE_MAX);
    /* remove leading white spaces */
    for ( head = xsh->line; *head && *head == ' '; head++ )
        ;
    tail = xsh->line + xsh->line_size;

    if ( !*head ) {
        node = xsh->curr->cmd_tr.first;

        while ( node ) {
            cmd = rb_entry(node, command_t, rb);
            if ( max < cmd->len )
                max = cmd->len;

            list_add_tail(&cmd->list, &xsh->match);
            xsh->nr_match++;
            node = rb_next(node);
        }

        if ( xsh->nr_match == 0 )
            return;
        /* 界面下只有一条命令时，直接显示输出该命令 */
        if ( xsh->nr_match == 1 ) {
            term->op.seek(term, 0, TTY_SEEK_END);   /* 光标移动到end */
            term->op.insert(term, cmd->name);   /* 命令name插入到tty的line�?*/
            term->op.insert(term, " ");     /* 然后再插入一个空�?*/
            term->op.drain(term, TTY_DRAIN_CUR);    /* 从光标位置刷新显�?*/

            return;
        }

        goto out;
    }

    node = xsh->curr->cmd_tr.root.rb_node;
    /* be careful for empty views */
    if ( !node ) return;
    /* arriving here, i know that it's not a blank line and the view has
     * at least one command.
     */

    /* those command names that match prefix `s' must hide behind
     * those command names that don't match prefix `s'.
     */
    while ( node ) {
        _node = node;

        if ( command_cmp_ws(node, head) < 0 )
            break;

        node = node->rb_left;
    }

    node = _node;
    while ( node ) {
        cmd = rb_entry(node, command_t, rb);

        if ( strprefix(cmd->name, head) > 0 )
            break;

        node = rb_next(node);
    }

    while ( node ) {
        cmd = rb_entry(node, command_t, rb);

        if ( (len = strprefix(cmd->name, head)) > 0 ) {
            cmd->suffix = cmd->name + len;
            list_add_tail(&cmd->list, &xsh->match);
            xsh->nr_match++;

            if ( max < cmd->len )
                max = cmd->len;
            if ( min > cmd->len - len) {
                min = cmd->len - len;
                min_suffix = cmd->suffix;
                min_cmd = cmd;
            }
        }
        else {
            break;
        }

        node = rb_next(node);
    }

    xsh->argc = 1;
    xsh->argv[0] = head;
    xsh->argv[1] = (char *)0;
    xsh->arg2param[1] = (param_t *)0;

    /* if there is no command match, arguments may exist,
     * try to split and find further.
     */
    if (xsh->nr_match == 0) {
        for (tail--; *tail == ' ' || *tail == '\t'; tail--)
            ;
        if (tail == head) return;
    }
    while (xsh->nr_match == 0) {
        for (; tail != head; tail--) {
            if (*tail == '"' || *tail == '\'')
                quot = !quot;
            else if ( !quot && (*tail == ' ' || *tail == '\t'))
                break;
        }
        if (tail == head) return;

        if ( ++xsh->argc > NR_ARG_MAX )
            XSH_PANIC();
        xsh->arg2param[xsh->argc] = (param_t *)0;
        for (i = xsh->argc; i > 1; --i)
            xsh->argv[i] = xsh->argv[i-1];
        xsh->argv[1] = tail+1;

        for (; *tail == ' ' || *tail == '\t'; tail--)
            ;
        *(tail+1) = 0;

        p = xsh->curr->cmd_tr.find(&xsh->curr->cmd_tr, head, &pa);
        if (*p) xsh->nr_match = 1;

    }

    /* if there is exactly ONE command matching, try to expand
     * its options and arguments.
     */
    if (xsh->nr_match == 1) {
        if ( xsh->argc > 1 ) {
            cmd = rb_entry(*p, command_t, rb);
        }
        else {
            cmd = min_cmd;

            if (*(tail-1) != ' ') {
                term->op.seek(term, 0, TTY_SEEK_END);
                term->op.insert(term, min_suffix);
                term->op.insert(term, " ");
                term->op.drain(term, TTY_DRAIN_CUR);
                return;
            }
        }

        cmd_dokey_tab(xsh, cmd);
        return;
    }

    /* if there're more than one command matching the prefix, they could
     * have something in common, so try to expand this common string.
     */
    for ( suf_head = min_suffix+1; *suf_head; suf_head++ ) {
        c = *suf_head;
        *suf_head = '\0';

        list_for_each(pos, &xsh->match) {
            cmd = list_entry(pos, command_t, list);

            if ( cmd != min_cmd ) {
                if ( strstr(cmd->suffix, min_suffix) != cmd->suffix ) {
                    *suf_head = c;
                    goto suffix;
                }
            }
        }

        *suf_head = c;
    }

 suffix:
    if ( suf_head - min_suffix > 1 ) {
        c = *(suf_head-1);
        *(suf_head-1) = '\0';

        term->op.seek(term, 0, TTY_SEEK_END);
        term->op.insert(term, min_suffix);
        term->op.drain(term, TTY_DRAIN_CUR);

        *(suf_head-1) = c;
    }

 out:
    for ( gap = 2; (col = 80/(max+gap)) && (col*(max+gap) == 80); gap++ )
        ;

    term->op.devputs(term, "\n");
    list_for_each(pos, &xsh->match) {
        cmd = list_entry(pos, command_t, list);

        if ( cmd->cview != cmd->nview ) {
            term->op.devprintf(term, "/""%-*s", max+gap-1, cmd->name);
        }
        else {
            term->op.devprintf(term, "%-*s", max+gap, cmd->name);
        }

        if ( ++i == col ) {
            term->op.devputs(term, "\n");
            i = 0;
        }
    }

    if ( i != 0 ) term->op.devputs(term, "\n");
    term->op.devprintf(term, "%s", xsh->prompt);
    term->op.drain(term, TTY_DRAIN_BEG);
    return;
#else
    extern void yyparse_dokey_tab(xsh_t *xsh);
    yyparse_dokey_tab((xsh_t *)context);
    return;
#endif
}


#ifndef TINYSH
/*
 * cmd_dokey_tab - try to expand a command's options and arguments when tab key pressed.
 */
void cmd_dokey_tab(xsh_t *xsh, command_t *cmd)
{
    int last = xsh->argc-1;
    char *ref, *suffix1 = NULL, *suffix2 = NULL;
    tty_t *term = xsh->term;
    param_t *param;
    struct list_head *pos, *head;

    if (!cmd->desc || !cmd->desc->param_tab || (cmd->desc->param_tab->type == PARAM_NONE))
        return;

    for (param = cmd->desc->param_tab; param->type != PARAM_NONE;
         param++) {
        param->type &= ~PARAM_DONE;
    }

    if (xsh->argc == 1) {
        print_info_cmd(xsh, cmd);
        return;
    }

    arg_versus_param(xsh, cmd);

    /* if the last argument can't match a parameter explicitly, try to have it expanded
     * if it's an option or a flag.
     */
    if (!xsh->arg2param[last]) {
        if (*(xsh->argv[last]) != '-')
            return;

        param = (last == 1) ? cmd->desc->list : xsh->arg2param[last-1];
        if (!param) return;

        if (param->type & PARAM_TOGGLE)
            ref = xsh->argv[last-1];
        else
            ref = param->ref;

        if (param->list) {
            pos = head = &param->list->next;
        }
        else /*if (!list_empty(&param->next)) */{
            pos = head = &param->next;
        }
        //else {
        //  return;
        //}

        do {
            param = list_entry(pos, param_t, next);

            if (param->type & PARAM_DONE)
                continue;
            if ((param->type & PARAM_SUB) && strcmp(param->ref, ref))
                continue;

            if ((param->type & PARAM_OPT) || (param->type & PARAM_FLG)) {
                if (!*(xsh->argv[last]+1)) {
                    suffix1 = param->name;
                    break;
                }
                if (strstr(param->name, xsh->argv[last]+1) == param->name) {
                    suffix1 = param->name + strlen(xsh->argv[last]+1);
                        break;
                }
            }
        } while ((pos = pos->next) != head);

        if (suffix1) {
            if (param->type & PARAM_OPT)
                suffix2 = "=";
            else if (param->type & PARAM_FLG)
                suffix2 = " ";

            term->op.seek(term, 0, TTY_SEEK_END);
            term->op.insert(term, suffix1);
            term->op.insert(term, suffix2);
            term->op.drain(term, TTY_DRAIN_CUR);
        }

        return;
    }

    if (xsh->arg2param[last]->type & PARAM_ARG) 
    {
        if (xsh->arg2param[last]->type & PARAM_TOGGLE) 
        {
            char __c, *__s, help[100] = {'\0'};

            strcpy(help, xsh->arg2param[last]->help);
            //for (suffix1 = __s = xsh->arg2param[last]->help; ; ++__s)
            for (suffix1 = __s = help;; ++__s)
            {
                if (!*__s || *__s == '|')
                {
                    __c = *__s;
                    *__s = '\0';

                    if (strstr(suffix1, xsh->argv[last]) == suffix1)
                    {
                        suffix1 = suffix1 + strlen(xsh->argv[last]);
                        suffix2 = " ";
                        term->op.seek(term, 0, TTY_SEEK_END);
                        term->op.insert(term, suffix1);
                        term->op.insert(term, suffix2);
                        term->op.drain(term, TTY_DRAIN_CUR);

                        *__s = __c;
                        return;
                    }

                    *__s = __c;
                    if (!*__s) break;
                    suffix1 = __s + 1;
                }
            }
        }
        else
        {
            if (*(xsh->line+xsh->line_size-1) != ' ')
            {
                term->op.seek(term, 0, TTY_SEEK_END);
                term->op.insert(term, " ");
                term->op.drain(term, TTY_DRAIN_CUR);
                return;
            }
        }
    }
    else
    {
        char *s;

        if ((s = strchr(xsh->argv[last], '=')) && !s[1])
        {
            term->op.devprintf(term, "\n%s\n%s",
                       xsh->arg2param[last]->help, xsh->prompt);
            term->op.drain(term, TTY_DRAIN_BEG);
            return;
        }
        else if (*(xsh->line+xsh->line_size-1) != ' ')
        {
            term->op.seek(term, 0, TTY_SEEK_END);
            term->op.insert(term, " ");
            term->op.drain(term, TTY_DRAIN_CUR);
            return;
        }
    }

    print_info_cmd(xsh, cmd);
    return;
}


void print_info_cmd(xsh_t *xsh, command_t *cmd)
{
    char *suffix;
    struct list_head *pos, *head;
    param_t *param, *_param;
    int flag = 0;
    tty_t *term = xsh->term;

    _param = (xsh->argc == 1) ? cmd->desc->list : xsh->arg2param[xsh->argc-1];

    if (xsh->argc == 1) {
        pos = head = &_param->next;
    }
    else if (_param->list) {
        pos = head = &_param->list->next;
    }
    else if (!list_empty(&_param->next)) {
        pos = head = &_param->next;
    }
    else {
        return;
    }

    do {
        param = list_entry(pos, param_t, next);

        if (param->type & PARAM_DONE)
            continue;
        if ((param->type & PARAM_SUB) && _param->list && !strprefix(xsh->argv[xsh->argc-1], param->ref))
            continue;
        if ((param->type & PARAM_SUB) && !_param->list && strcmp(_param->ref, param->ref))
            continue;

        flag++;
        param_info(param, suffix);

        if (param->type & PARAM_OPT) {
            term->op.devprintf(term, "%s-%s=%s%s ",
                       param->type & PARAM_OPTIONAL ? "[" : "",
                       param->name,
                       suffix,
                       param->type & PARAM_OPTIONAL ? "]" : "");
        }
        else if (param->type & PARAM_FLG) {
            term->op.devprintf(term, "%s-%s%s ",
                       param->type & PARAM_OPTIONAL ? "[" : "",
                       param->name,
                       param->type & PARAM_OPTIONAL ? "]" : "");
        }
        else {
            term->op.devprintf(term,
                       "%s%s%s%s%s ",
                       param->type & PARAM_OPTIONAL ? "[" : "",
                       param->name,
                       suffix,
                       param->type & PARAM_LIST ? "..." : "",
                       param->type & PARAM_OPTIONAL ? "]" : "");
        }

    } while ((pos = pos->next) != head);

    if (flag > 0) {
        term->op.devprintf(term, "\n%s", xsh->prompt);
        term->op.drain(term, TTY_DRAIN_BEG);
    }

    return;
}
#endif


void print_prompt(int len, xsh_t *xsh)
{
    int i;
    tty_t *term = xsh->term;

    len = len + strlen(xsh->prompt);
    for ( i = 0; i < len; i++)
        term->op.devputs(term, " ");

    term->op.devputs(term, "^\n");

    return;
}


void xsh_dokey_help(void *context)
{
    xsh_t *xsh = (xsh_t *)context;
    tty_t *term = xsh->term;
    struct rb_node **p, *pa = NULL;
    command_t *cmd;
    param_t *param;
    char *head, *tail, *suffix;

    if ( !(xsh->line_size = xsh->term->op.read(xsh->term, xsh->line, TTY_BUF_SIZE_MAX)) )
    {
        xsh_dokey_tab(xsh);
        return;
    }
    for ( head = xsh->line; *head && *head == ' '; head++ )
        ;
    tail = xsh->line + xsh->line_size;
    for ( tail = tail-1; (tail != head) && (*tail == ' ' || *tail == '\t'); tail-- )
        ;
    *(tail+1) = 0;
    if ( !*head )
    {
        xsh_dokey_tab(xsh);
        return;
    }

    p = xsh->curr->cmd_tr.find(&xsh->curr->cmd_tr, head, &pa);
    if ( !*p ) return;

    cmd = rb_entry(*p, command_t, rb);

    term->op.devputs(term, "\nDescription:\n");
    if ( cmd->desc ) {
        term->op.devprintf(term, "  %s\n", cmd->desc->help);

        if ( (param = cmd->desc->param_tab) ) {
            term->op.devputs(term, "Syntax:\n");
            term->op.devprintf(term, "  %s", cmd->name);

            for ( ; param->type != PARAM_NONE; param++ ) {
                if ( param->type & PARAM_SUB )
                    continue;

                param_info(param, suffix);

                if ( param->type & PARAM_OPT ) {
                    term->op.devprintf(term, "%s-%s=%s%s ",
                               param->type & PARAM_OPTIONAL ? "[" : "",
                               param->name,
                               suffix,
                               param->type & PARAM_OPTIONAL ? "]" : "");
                }
                else if ( param->type & PARAM_FLG ) {
                    term->op.devprintf(term, "%s-%s%s ",
                               param->type & PARAM_OPTIONAL ? "[" : "",
                               param->name,
                               param->type & PARAM_OPTIONAL ? "]" : "");
                }
                else {
                    term->op.devprintf(term,
                               " %s%s%s%s%s",
                               param->type & PARAM_OPTIONAL ? "[" : "",
                               param->name,
                               suffix,
                               param->type & PARAM_LIST ? "..." : "",
                               param->type & PARAM_OPTIONAL ? "]" : "");
                }
            }

            term->op.devputs(term, "\n");

            if ( (param = cmd->desc->param_tab) &&
                 (param->type != PARAM_NONE) &&
                 (param->help) ) {
                term->op.devputs(term, "Options & Arguments:\n");

                for ( ; param->type != PARAM_NONE; param++ ) {
                    if ( param->type & PARAM_SUB )
                        continue;

                    term->op.devprintf(term, "  %s - %s\n", param->name, param->help);
                }
            }
        }
    }

    term->op.devprintf(term, "%s", xsh->prompt);
    term->op.drain(term, TTY_DRAIN_BEG);
    return;
}


void xsh_dokey_previous(void *context)
{
    xsh_t *xsh = (xsh_t *)context;

    if ( xsh->hist != xsh->hbeg ) {
        histent_t *ent;

        xsh->term->op.kill(xsh->term);

        xsh->hist = xsh->hist->prev;
        ent = list_entry(xsh->hist, histent_t, link);
        xsh->term->op.insert(xsh->term, ent->line);
        xsh->term->op.drain(xsh->term, TTY_DRAIN_BEG);
    }

    return;
}


void xsh_dokey_next(void *context)
{
    xsh_t *xsh = (xsh_t *)context;

    if ( xsh->hist != xsh->hend ) {
        histent_t *ent;

        xsh->term->op.kill(xsh->term);

        if ( (xsh->hist = xsh->hist->next) != xsh->hend ) {
            ent = list_entry(xsh->hist, histent_t, link);
            xsh->term->op.insert(xsh->term, ent->line);
            xsh->term->op.drain(xsh->term, TTY_DRAIN_BEG);
        }
    }

    return;
}


int view_cmp(struct rb_node *n, void *key)
{
    char *s = (char *)key;
    view_t *view = rb_entry(n, view_t, rb);

    return strcmp(view->name, s);
}


/**
 * command_cmp_ws - compare command's name against a key with whitespace wildcarding.
 * @return:
 *  the comparison result
 */
int command_cmp_ws(struct rb_node *n, void *key)
{
    command_t *cmd = rb_entry(n, command_t, rb);
    char *s = cmd->name;
    char *t = (char *)key;
    int ws = 0;

    for ( ; ; ) {
        if ( *s == *t ) {
            ws = (*s == ' ') ? 1 : 0;

            if ( *s == '\0' ) return 0;

            ++s; ++t;
        }
        else if ( *s == ' ' && ws )
            ++s;
        else if ( *t == ' ' && (ws || !*s) )
            ++t;
        else
            break;
    }

    return *s - *t;
}


/**
 * strprefix - test if `s' matches prefix `t' with whitespace wildcarding.
 * @return:
 *  the actual length of the prefix in `s', if true;
 *  0, if false
 */
int strprefix(char *s, char *t)
{
    char *_s = s;
    int ws = 0;

    for ( ;; ) {
        if ( *s == *t ) {
            ws = (*t == ' ') ? 1 : 0;

            if ( *t == '\0' ) return (s - _s);

            ++s; ++t;
        }
        else if ( *s == ' ' && ws )
            ++s;
        else if ( *t == ' ' && (ws || !*s) )
            ++t;
        else
            break;
    }

    if ( *t == '\0' ) return (s - _s);

    return 0;
}


ident_t * symtab_find(symtab_t *symtab, char *name)
{
    struct rb_node **p, *pa;

    for (; symtab; symtab = symtab->up) {
        p = symtab->ident_tr.find(&symtab->ident_tr, name, &pa);
        if (*p) {
            return rb_entry(*p, ident_t, rb);
        }
    }

    return (ident_t *)0;
}


ident_t * symtab_enter(symtab_t *symtab, ident_t *ident)
{
    struct rb_node **p, *pa;

    p = symtab->ident_tr.find(&symtab->ident_tr, ident->attr.text, &pa);
    if (*p) 
    {
        return rb_entry(*p, ident_t, rb);
    }
    else 
    {
        symtab->ident_tr.insert(&symtab->ident_tr, &ident->rb, pa, p);
        return (ident_t *)0;
    }

    //return (ident_t *)0;
}

