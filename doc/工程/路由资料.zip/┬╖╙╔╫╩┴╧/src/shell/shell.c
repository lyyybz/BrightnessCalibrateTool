
#include "shell/vsh.h"
#include <string.h>
#include "shell.h"
#include "sys.h"
#include "visys.h"
#include "../rtiii/include/db/db.h"
#include "vinets.h"
#include "viuart.h"
#include "tlib.h"
#include "ague.h"
#include "boot.h"
#include "aupd.h"
#include <stdio.h>
#include <stdarg.h>
#include "apprt.h"
#include "rt.h"
#include "rtpara.h"

extern cmd_desc_t cmd_read_desc;
extern void docmd_read(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_write_desc;
extern void docmd_write(command_t *cmd, xsh_t *xsh);
extern void docmd_reboot(command_t *cmd, xsh_t *xsh);

void docmd_view_ver_info(command_t *cmd, xsh_t *xsh);
void docmd_view_over_info(command_t *cmd, xsh_t *xsh);
void docmd_view_ndb_info(command_t *cmd, xsh_t *xsh);
void docmd_view_odb_info(command_t *cmd, xsh_t *xsh); 
void docmd_view_blacklist(command_t *cmd, xsh_t *xsh);
void docmd_view_run_info(command_t *cmd, xsh_t *xsh);
cmd_desc_t cmd_tei_desc;
void docmd_view_tei_info(command_t *cmd, xsh_t *xsh);

void docmd_phsidstart(command_t *cmd, xsh_t *xsh);
void docmd_phsidstop(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_variables_desc;
void docmd_variables(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_phsget_desc;
void docmd_phsget(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_taskget_desc;
void docmd_taskget(command_t *cmd, xsh_t *xsh); 

cmd_desc_t cmd_phsidstart_desc;
void docmd_phsidstart(command_t *cmd, xsh_t *xsh);


cmd_desc_t cmd_set_ntb_flag_desc;
void docmd_set_ntb_flag(command_t *cmd, xsh_t *xsh);


cmd_desc_t cmd_task_open_desc;
void docmd_task_open(command_t *cmd, xsh_t *xsh); 

extern cmd_desc_t cmd_es_print_desc;
void docmd_es_print(command_t *cmd, xsh_t *xsh);

extern cmd_desc_t cmd_upd_desc;
void docmd_upd(command_t *cmd, xsh_t *xsh);

extern cmd_desc_t cmd_gd_upd_desc;
void docmd_gd_upd(command_t *cmd, xsh_t *xsh);

extern cmd_desc_t cmd_dbg_cmd_desc;
void docmd_dbg_cmd(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_phy_cfg_desc;
void docmd_phy_config(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_set_chip_id_desc;
void docmd_set_chip_id(command_t *cmd, xsh_t *xsh);

cmd_desc_t cmd_lock_desc;
void docmd_lock(command_t *cmd, xsh_t *xsh);

command_t g_cmdtab[] = {
		CMDTAB_ENTRY(read, root, root, docmd_read, &cmd_read_desc),
		CMDTAB_ENTRY(write, root, root, docmd_write, &cmd_write_desc),
		CMDTAB_ENTRY(reboot, root, root, docmd_reboot, NULL),
		CMDTAB_ENTRY(ver, root, root, docmd_view_ver_info, NULL),
        CMDTAB_ENTRY(over, root, root, docmd_view_over_info, NULL),
		CMDTAB_ENTRY(ndb, root, root, docmd_view_ndb_info, NULL),
        CMDTAB_ENTRY(odb, root, root, docmd_view_odb_info, NULL),
		CMDTAB_ENTRY(blacklist, root, root, docmd_view_blacklist, NULL),
        CMDTAB_ENTRY(phsid_start, root, root, docmd_phsidstart, &cmd_phsidstart_desc),
		CMDTAB_ENTRY(phsid_stop, root, root, docmd_phsidstop, NULL),
		CMDTAB_ENTRY(var, root, root, docmd_variables, &cmd_variables_desc),
		CMDTAB_ENTRY(phs_get, root, root, docmd_phsget, &cmd_phsget_desc),
        CMDTAB_ENTRY(task_get, root, root, docmd_taskget, &cmd_taskget_desc),
		CMDTAB_ENTRY(print, root, root, docmd_es_print, &cmd_es_print_desc),
		CMDTAB_ENTRY(upd, root, root, docmd_upd, &cmd_upd_desc),
		CMDTAB_ENTRY(run, root, root, docmd_view_run_info, NULL),
		CMDTAB_ENTRY(tei, root, root, docmd_view_tei_info, &cmd_tei_desc),
		CMDTAB_ENTRY(start_upd, root, root, docmd_gd_upd, &cmd_gd_upd_desc),
	    CMDTAB_ENTRY(dbg_cmd, root, root, docmd_dbg_cmd, &cmd_dbg_cmd_desc),
        CMDTAB_ENTRY(phy, root, root, docmd_phy_config, &cmd_phy_cfg_desc),
        CMDTAB_ENTRY(set_chip_id, root, root, docmd_set_chip_id, &cmd_set_chip_id_desc),
	    CMDTAB_ENTRY(set_ntb_flag, root, root, docmd_set_ntb_flag, &cmd_set_ntb_flag_desc),
        CMDTAB_ENTRY(lock, root, root, docmd_lock, &cmd_lock_desc),
        CMDTAB_ENTRY(task_open, root, root, docmd_task_open, &cmd_task_open_desc),

};
extern struct net_node nnode[MAX_NODE + 1];
extern struct dbpara_info cco_para;
unsigned int g_cmdtab_num = sizeof(g_cmdtab)/sizeof(g_cmdtab[0]);
extern struct rtpara _rtparas;  /* global parameter */

#ifdef MODE_GD
view_t g_viewtab[] = {
	VIEWTAB_ENTRY(root,   "[1668_nw /]# "),
};
#else
view_t g_viewtab[] = {
#ifdef NEW_GW
	VIEWTAB_ENTRY(root,   "[1668 /]# "),
#else
	VIEWTAB_ENTRY(root,   "[RTB-55 /]# "),
#endif
};
#endif

unsigned int g_viewtab_num = sizeof(g_viewtab)/sizeof(g_viewtab[0]);

#if 0
#ifdef TARGET_RELEASE
void es_sys_panic(char *fmt, ...)
{
        INT8U panic_buffer[53];
        va_list args;
        extern void es_uart_puts(char *out);

        va_start(args, fmt);
        vsnprintf((char *)panic_buffer, 53, fmt, args);
        va_end(args);
        es_uart_puts((char *)panic_buffer);
}
#else
void es_sys_panic(char *fmt, ...)
{
        INT8U panic_buffer[128];
        va_list args;
        unsigned int cpu_sr;
        extern void es_uart_puts(char *out);

        va_start(args, fmt);
        vsnprintf((char *)panic_buffer, 128, fmt, args);
        va_end(args);

        es_uart_puts((char *)panic_buffer);

        cpu_sr = OS_ENTER_CRITICAL();
        for ( ;; )
                ;
}
#endif
#endif

void es_isr_uart0(void *data, void *context)
{
  //    uint8_t iifc;
  //
  //    iifc = GET_UART_IIFC(0) & 0xe;
  //
  //    if (iifc == 4 || iifc == 12)
  //        //es_tty_master_write(&tty);
  //    else if (iifc == 2)
  //        //tty_master_read(&tty);

  return;
}

void shell_init(void)
{
  //uart_config_1();
  sys_init();
}

void shell_run(void)
{
  task_xsh((ULONG)&g_vsh);
  task_printd(0);
  return;
}

/*******************�����ﶨ�����������vsh.c��g_es_cmdtab��ע��************************/

#define PRINT_BUF_SIZE        128
char print_buf[PRINT_BUF_SIZE + 0x20];  //Ԥ��һЩ�ռ�,��ֹԽ��

unsigned int print_opt = 0;
unsigned int print_mde = 0;

void set_print(unsigned int opt, unsigned int mde)
{
    if(mde == MODE_CLOSE)
    {
        print_opt = print_opt & (~ opt);
        print_mde = print_mde & (~ opt);
    }
    else if(mde == MODE_PRINT_D)
    {
        print_opt = print_opt | opt;
        print_mde = print_mde | opt;
    }
    else if(mde == MODE_PRINT_S)
    {
        print_opt = print_opt | opt;
        print_mde = print_mde & (~ opt);
    }

}

void close_all_print(void)
{
    print_opt = 0;
    print_mde = 0;
}

void es_printf(unsigned int opt, const char *fmt, ...)
{
    va_list args;

    if(print_opt & opt)
    {
        va_start(args, fmt);
        vsnprintf(print_buf, PRINT_BUF_SIZE, fmt, args);
        va_end(args);

        if(print_mde & opt)
        {
            print_d(print_buf);
        }
        else
        {
            print_s(print_buf);
        }
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void printf_s(const char *fmt, ...)
{
#if 0
    char buffer[128];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buffer, 128, fmt, args);
    va_end(args);

    tty_devputs(NULL, buffer);
#else  /* printf_sĿǰ��������es_printf��opt = APP_PRINT_OPT�� */
    unsigned int opt = APP_PRINT_OPT;
    va_list args;

    if(print_opt & opt)
    {
        va_start(args, fmt);
        vsnprintf(print_buf, PRINT_BUF_SIZE, fmt, args);
        va_end(args);

        if(print_mde & opt)
        {
            print_d(print_buf);
        }
        else
        {
            print_s(print_buf);
        }
    }

#endif
}

param_t cmd_es_print_param_tab[] = {
    {PARAM_ARG|PARAM_TOGGLE, "", "upd|phy|assoc|zc|succ_rate|phs_id|xxx|app|close-all"},
    {PARAM_ARG|PARAM_TOGGLE, "", "open-s|open-d|close",},
    PARAM_EMPTY
};

cmd_desc_t cmd_es_print_desc = CMD_DESC_ENTRY(
    "",
    cmd_es_print_param_tab);

void cmd_set_print(unsigned int opt, xsh_t *xsh)
{
    if(strcmp(xsh->argv[2], "close") == 0)
    {
        set_print(opt, MODE_CLOSE);
        printf_s("close \n");
    }
    else if(strcmp(xsh->argv[2], "open-d") == 0)
    {
        set_print(opt, MODE_PRINT_D);
        printf_s("open-d \n");
    }
    else if(strcmp(xsh->argv[2], "open-s") == 0)
    {
        set_print(opt, MODE_PRINT_S);
        printf_s("open-s \n");
    }
}

void docmd_es_print(command_t *cmd, xsh_t *xsh)
{
    if(strcmp(xsh->argv[1], "upd") == 0)
    {
        printf_s("\n upd print: ");
        cmd_set_print(UPD_PRINT_OPT, xsh);
    }
    else if(strcmp(xsh->argv[1], "phy") == 0)
    {
        printf_s("\n phy print: ");
        cmd_set_print(PHY_PRINT_OPT, xsh);
    }
    else if(strcmp(xsh->argv[1], "assoc") == 0)
    {
        printf_s("\n assoc print: ");
        cmd_set_print(ASSOC_PRINT_OPT, xsh);
    }
    else if(strcmp(xsh->argv[1], "xxx") == 0)
    {
        printf_s("\n xxx print: ");
        cmd_set_print(XXX_PRINT_OPT, xsh);
    }
    else if (strcmp(xsh->argv[1], "zc") == 0)
    {
       printf_s("\n zc print: ");
       cmd_set_print(ZC_PRINT_OPT, xsh);
    }
    else if (strcmp(xsh->argv[1], "succ_rate") == 0)
    {
       printf_s("\n succ_rate print: ");
       cmd_set_print(SUCC_RATE_PRINT_OPT, xsh); 
    }
    else if (strcmp(xsh->argv[1], "phs_id") == 0) 
    {
        printf_s("\n phs_id print: "); 
        cmd_set_print(PHS_PRINT_OPT, xsh); 
    }
    else if (strcmp(xsh->argv[1], "app") == 0) 
    {
        printf_s("\n app print: ");
        cmd_set_print(APP_PRINT_OPT, xsh); 
    }
    else if(strcmp(xsh->argv[1], "close-all") == 0)
    {
        printf_s("\n close all print \n");
        close_all_print();
    }
}

void show_ver_info(void)
{

}
void show_over_info(void)
{

}

void show_phs_info()
{

}

void show_ndb_info()
{

}

void show_blacklist()
{
}

unsigned int flag_db_addmt_eeprom;  /* ȫ�ֱ��������� */
unsigned int flag_db_delmt_eeprom;
unsigned int flag_db_flushmt_eeprom;
unsigned int flag_monit_update_eeprom;
unsigned int flag_monitplc2_eeprom;
unsigned int flag_rt_mntprocess_eeprom;
unsigned int flag_stage5_eeprom;
unsigned int flag_nl_reg_save_mtdata_eeprom;
unsigned int flag_db_format_eeprom;
unsigned int flag_db_clrall_newmtmask_eeprom;
unsigned int flag_db_new_eeprom;
unsigned int flag_again_eeprom;
unsigned int flag_rt_first_eeprom;
unsigned int flag_rt_init_eeprom;
unsigned int flag_rf_set_rdswitch_eeprom;
unsigned int flag_rf_set_clrmt_nw_eeprom;
unsigned int flag_rf_set_slev_nw_eeprom;
unsigned int flag_rf_set_sinkid_eeprom;
unsigned int flag_rf_ctrl_work_eeprom;
unsigned int flag_rf_ctrl_stop_eeprom;
unsigned int flag_rf_incrsno_eeprom;
unsigned int flag_rf_set_jzqid_nw_eeprom;
unsigned int flag_rf_set_jzqid_eeprom;
unsigned int flag_rf_areset_eeprom;
unsigned int flag_nl_start_net_eeprom;
unsigned int flag_set_apptype_eeprom;
unsigned int flag_rt_set_node_version_eeprom;
unsigned int flag_nl_deal_cjqreg_eeprom;
unsigned int flag_nl_get_panid_eeprom;
unsigned int flag_nl_set_node_ver_eeprom;
unsigned int flag_rt_set_mode_fixed_mode;

unsigned int flag_rt_mntplc_v_fail;
unsigned int flag_rt_mntprocess_fail;
unsigned int flag_rt_appmnt_fail;

unsigned int flag_rt_mntplc_v_succ;
unsigned int flag_rt_mntret_succ;
unsigned int flag_rt_mntprocess_succ;
unsigned int flag_monitret1_succ;
unsigned int flag_floodret1_succ;
unsigned int flag_monitplc2_succ;
unsigned int flag_nl_reg_save_mtdata_succ;
extern unsigned char local_viv_swi; 

void show_runinfo()
{
  struct run_info ri;
  unsigned short size, cnt;
  
  get_runinfo(&ri);
  
  printf_s("total meter num: %d\n", _rtparas.mtnum);
  printf_s("assoc succ num: %d\n", ri.assocnum);
  printf_s("read succ num: %d\n", ri.succnum);
  printf_s("_rtparas.state: %d\n", _rtparas.state);
  
  ses_get_task_info(&cnt, &size);
  printf_s("current task num: %d\n", cnt);
  
  int t = get_sys_tick() / 1000;
  printf_s("sys start time: %d m %d s\n", t / 60, t % 60);
  for (int i = 0; i < 16; i++)
    printf_s("the %d hop :%d\n", i, ri.lvl[i]);
  
  printf_s("mode:%d\n", local_viv_swi);

  printf_s("flag_db_addmt_eeprom:  %d\t\t", flag_db_addmt_eeprom);  /* ȫ�ֱ��������� */
  printf_s("flag_db_delmt_eeprom:  %d\t\t", flag_db_delmt_eeprom);
  printf_s("flag_db_flushmt_eeprom:  %d\t\t", flag_db_flushmt_eeprom);
  printf_s("flag_monit_update_eeprom:  %d\t\t", flag_monit_update_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_monitplc2_eeprom:  %d\t\t", flag_monitplc2_eeprom);
  printf_s("flag_rt_mntprocess_eeprom:  %d\t\t", flag_rt_mntprocess_eeprom);
  printf_s("flag_stage5_eeprom:  %d\t\t", flag_stage5_eeprom);
  printf_s("flag_nl_reg_save_mtdata_eeprom:  %d\t\t", flag_nl_reg_save_mtdata_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_db_format_eeprom:  %d\t\t", flag_db_format_eeprom);
  printf_s("flag_db_clrall_newmtmask_eeprom:  %d\t\t", flag_db_clrall_newmtmask_eeprom);
  printf_s("flag_db_new_eeprom:  %d\t\t", flag_db_new_eeprom);
  printf_s("flag_again_eeprom:  %d\t\t", flag_again_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_rt_first_eeprom:  %d\t\t", flag_rt_first_eeprom);
  printf_s("flag_rt_init_eeprom:  %d\t\t", flag_rt_init_eeprom);
  printf_s("flag_rf_set_rdswitch_eeprom:  %d\t\t", flag_rf_set_rdswitch_eeprom);
  printf_s("flag_rf_set_clrmt_nw_eeprom:  %d\t\t", flag_rf_set_clrmt_nw_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_rf_set_slev_nw_eeprom:  %d\t\t", flag_rf_set_slev_nw_eeprom);
  printf_s("flag_rf_set_sinkid_eeprom:  %d\t\t", flag_rf_set_sinkid_eeprom);
  printf_s("flag_rf_ctrl_work_eeprom:  %d\t\t", flag_rf_ctrl_work_eeprom);  
  printf_s("flag_rf_ctrl_stop_eeprom:  %d\t\t", flag_rf_ctrl_stop_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_rf_incrsno_eeprom:  %d\t\t", flag_rf_incrsno_eeprom);
  printf_s("flag_rf_set_jzqid_nw_eeprom:  %d\t\t", flag_rf_set_jzqid_nw_eeprom);
  printf_s("flag_rf_set_jzqid_eeprom:  %d\t\t", flag_rf_set_jzqid_eeprom);
  printf_s("flag_rf_areset_eeprom:  %d\t\t", flag_rf_areset_eeprom);
  
  printf_s("\n");
  
  printf_s("flag_nl_start_net_eeprom:  %d\t\t", flag_nl_start_net_eeprom);
  printf_s("flag_set_apptype_eeprom:  %d\t\t", flag_set_apptype_eeprom);
  printf_s("flag_rt_set_node_version_eeprom:  %d\t\t", flag_rt_set_node_version_eeprom);
  printf_s("flag_nl_deal_cjqreg_eeprom:  %d\t\t", flag_nl_deal_cjqreg_eeprom);

  printf_s("\n");
  
  printf_s("flag_nl_get_panid_eeprom:  %d\t\t", flag_nl_get_panid_eeprom);
  printf_s("flag_nl_set_node_ver_eeprom:  %d\t\t", flag_nl_set_node_ver_eeprom);
  printf_s("flag_rt_set_mode_fixed_mode:  %d\t\t", flag_rt_set_mode_fixed_mode);  
  printf_s("flag_rt_mntplc_v_fail:  %d\t\t", flag_rt_mntplc_v_fail);
  
  printf_s("\n");
  
  printf_s("flag_rt_mntprocess_fail:  %d\t\t", flag_rt_mntprocess_fail);
  printf_s("flag_rt_appmnt_fail:  %d\t\t", flag_rt_appmnt_fail);
  printf_s("flag_rt_mntplc_v_succ:  %d\t\t", flag_rt_mntplc_v_succ);
  printf_s("flag_rt_mntret_succ:  %d\t\t", flag_rt_mntret_succ);
  
  printf_s("\n");
  
  printf_s("flag_rt_mntprocess_succ:  %d\t\t", flag_rt_mntprocess_succ);
  printf_s("flag_monitret1_succ:  %d\t\t", flag_monitret1_succ);
  printf_s("flag_floodret1_succ:  %d\t\t", flag_floodret1_succ);
  printf_s("flag_monitplc2_succ:  %d\t\t", flag_monitplc2_succ);
  
  printf_s("\n");
  
  printf_s("flag_nl_reg_save_mtdata_succ:  %d\t\t", flag_nl_reg_save_mtdata_succ);

  printf_s("\n");

}

void show_odb_info()
{

}

void docmd_view_ver_info(command_t *cmd, xsh_t *xsh)
{
  print_ver();
}
void docmd_view_over_info(command_t *cmd, xsh_t *xsh)
{

}
void docmd_view_ndb_info(command_t *cmd, xsh_t *xsh)
{

}

void docmd_view_blacklist(command_t *cmd, xsh_t *xsh)
{

}

void docmd_view_run_info(command_t *cmd, xsh_t *xsh)
{
  show_runinfo();
}

void docmd_view_odb_info(command_t *cmd, xsh_t *xsh)
{

}


void docmd_phsidstart(command_t *cmd, xsh_t *xsh)
{

}

void docmd_phsidstop(command_t *cmd, xsh_t *xsh)
{

}

void docmd_set_ntb_flag(command_t *cmd, xsh_t *xsh)
{

}

void docmd_task_open(command_t *cmd, xsh_t *xsh)
{

}


param_t cmd_variables_param_tab[] = {
    {PARAM_ARG|PARAM_STRING, "num", "variable num"
    },
    {PARAM_OPT|PARAM_TOGGLE|PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
    },
    PARAM_EMPTY
};

param_t cmd_phsget_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
        },
    PARAM_EMPTY
    }; 

param_t cmd_taskget_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
        },
    PARAM_EMPTY
    }; 

param_t cmd_phsidstart_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
        },
    PARAM_EMPTY
    }; 

param_t cmd_set_chip_id_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
    PARAM_EMPTY
    };

param_t cmd_set_ntb_flag_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
        },
    PARAM_EMPTY
    }; 
param_t cmd_lock_param_tab[] = {
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
        { PARAM_ARG | PARAM_STRING, "num", "variable num"
        },
    PARAM_EMPTY
    };

param_t cmd_task_open_param_tab[] = {
    { PARAM_ARG | PARAM_STRING, "num", "variable num"
    },
    { PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
    },
    PARAM_EMPTY
}; 
    

cmd_desc_t cmd_variables_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_variables_param_tab
    ); 

cmd_desc_t cmd_phsget_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_phsget_param_tab
    );

cmd_desc_t cmd_taskget_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_taskget_param_tab
    ); 

cmd_desc_t cmd_phsidstart_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_phsidstart_param_tab
    ); 

cmd_desc_t cmd_set_chip_id_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_set_chip_id_param_tab
    );
cmd_desc_t cmd_set_ntb_flag_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_set_ntb_flag_param_tab
    ); 
cmd_desc_t cmd_lock_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_lock_param_tab
    );
cmd_desc_t cmd_task_open_desc = CMD_DESC_ENTRY(
    "Read variables addr and value.", cmd_task_open_param_tab
    ); 

void docmd_phsget(command_t *cmd, xsh_t *xsh)
{

}

void docmd_taskget(command_t *cmd, xsh_t *xsh)
{

}


void docmd_variables(command_t *cmd, xsh_t *xsh)
{
  if(strcmp(xsh->argv[1],"14")==0)
    {
      UART_CHN_CFG(1,115200,PARITY_EVEN);
      printf_s("set uart0 115200\n");
    }
  else if(strcmp(xsh->argv[1],"15")==0)
    {
      UART_CHN_CFG(1,9600,PARITY_EVEN);
      printf_s("set uart0 9600\n");
    }
}

param_t cmd_tei_param_tab[] = {
    {PARAM_ARG|PARAM_INTEGER, "num", "TEI"},
//    {PARAM_ARG|PARAM_INTEGER, "num", "TEI"},
    PARAM_EMPTY
};

cmd_desc_t cmd_tei_desc = CMD_DESC_ENTRY(
    "TEI info.", cmd_tei_param_tab
    );

void docmd_view_tei_info(command_t *cmd, xsh_t *xsh)
{

}

param_t cmd_upd_param_tab[] = {
    {PARAM_ARG|PARAM_TOGGLE, "", "show|all|sucs|ing|fail|fns|reboot|restart|end"},
    PARAM_EMPTY
};

cmd_desc_t cmd_upd_desc = CMD_DESC_ENTRY(
    "",
    cmd_upd_param_tab);

void docmd_upd(command_t *cmd, xsh_t *xsh)
{
	if(strcmp(xsh->argv[1], "show") == 0)
	{
		aupd_show_info();
	}
	else if(strcmp(xsh->argv[1], "all") == 0)
	{
		aupd_print_fail_node(0);
	}
	else if(strcmp(xsh->argv[1], "sucs") == 0)
	{
		aupd_print_fail_node(1);
	}
	else if(strcmp(xsh->argv[1], "ing") == 0)
	{
		aupd_print_fail_node(2);
	}
   else if(strcmp(xsh->argv[1], "fail") == 0)
	{
		aupd_print_fail_node(3);
	}
   else if(strcmp(xsh->argv[1], "fns") == 0)
	{
		aupd_print_fail_node(4);
	}
	else if(strcmp(xsh->argv[1], "reboot") == 0)
	{
		aupd_reboot();
	}
	else if (strcmp(xsh->argv[1], "restart") == 0)
	{
		
	}
	else if (strcmp(xsh->argv[1], "end") == 0)
	{
		aupd_stop();
	}
}

param_t cmd_gd_upd_param_tab[] = {
  {PARAM_ARG|PARAM_INTEGER,"num", "para",""},
  {PARAM_ARG|PARAM_TOGGLE, "", "image|boot"},
  {PARAM_ARG|PARAM_TOGGLE, "", "STA|CCO"},
  {PARAM_ARG|PARAM_TOGGLE, "", "in_flash|ex_flash"},
  PARAM_EMPTY
};
cmd_desc_t cmd_gd_upd_desc = CMD_DESC_ENTRY(
    "",
    cmd_gd_upd_param_tab);

void docmd_gd_upd(command_t *cmd, xsh_t *xsh)
{
  unsigned int blk_len = strtoul(xsh->argv[1], 0, 0);
  unsigned int file_addr = 0;
  int boot_flag = 0, node_type = UPD_STA;

  	if (strcmp(xsh->argv[2], "image") == 0)
	{
		boot_flag = 0;
    }
	else if (strcmp(xsh->argv[2], "boot") == 0)
	{
      boot_flag = 0x1;
	}
    else
     return;

  if (strcmp(xsh->argv[3], "STA") == 0)
	{
	  node_type = UPD_STA;
    }
  else if (strcmp(xsh->argv[3], "CCO") == 0)
	{
      node_type = UPD_CCO;
	}
  else
    return;

   if (strcmp(xsh->argv[4], "in_flash") == 0)
	{
		file_addr = IMAGE1_ADDR;
    }
	else if (strcmp(xsh->argv[4], "ex_flash") == 0)
	{
      return;
	}
    else
      return;

  if (blk_len < 40 || blk_len > 200)
	{
	  printf_s("blk_len ERR!!! \n");
	  return;
	}
  cmd_start_upgrd((uint8_t *)file_addr, blk_len, boot_flag, node_type);
}

param_t cmd_dbg_cmd_param_tab[] = {
  
  {PARAM_ARG|PARAM_TOGGLE, "", "node_reboot|image_change"},
  {PARAM_ARG|PARAM_INTEGER|PARAM_SUB,"dst", "dst","node_reboot"},
  {PARAM_ARG|PARAM_INTEGER|PARAM_SUB,"dst", "dst","image_change"},
  PARAM_EMPTY
};
cmd_desc_t cmd_dbg_cmd_desc = CMD_DESC_ENTRY(
    "",
    cmd_dbg_cmd_param_tab);

void docmd_dbg_cmd(command_t *cmd, xsh_t *xsh)
{

}

param_t cmd_phy_cfg_param_tab[] = {
  {PARAM_ARG|PARAM_TOGGLE, "", "freq|power"},
  {PARAM_OPT|PARAM_INTEGER|PARAM_SUB,"dig_index", "dig_index","power"},
  {PARAM_OPT|PARAM_INTEGER|PARAM_SUB,"ana_index", "ana_index","power"},
  {PARAM_ARG|PARAM_TOGGLE|PARAM_SUB, "", "131|411|89|49","freq"},
  PARAM_EMPTY
};

cmd_desc_t cmd_phy_cfg_desc = CMD_DESC_ENTRY(
    "",
    cmd_phy_cfg_param_tab);

void docmd_phy_config(command_t *cmd, xsh_t *xsh)
{

}

void docmd_set_chip_id(command_t *cmd, xsh_t *xsh)
{

}

void docmd_lock(command_t *cmd, xsh_t *xsh)
{

}