#ifndef _INCLUDE_H
#define _INCLUDE_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <stdarg.h>

#include "type.h"

#include "list.h"
#if DEF_ETOS
#include "etos.h"
#endif
#include "term.h"
#include "sys.h"
#include "vsh.h"

#endif
