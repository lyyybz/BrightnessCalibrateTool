/*
 * Copyright: (c) 2006-2007, 2008 Triductor Technology, Inc.
 * All Rights Reserved.
 *
 * File:        rbtree.c
 * Purpose:     Red black tree algorithms.
 * History:     07/15/2007, created by jetmotor
 */

#include <stdio.h>
#include "type.h"
#include "rbtree.h"


/* lcrs_tree_init - 二叉树初始化
 * @tree: 指向要初始化的二叉树的指针
 */
void lcrs_tree_init(lcrs_tree_t *tree)
{
	tree->nr = 0;
	tree->root.lcrs_node = NULL;
	return;
}


/* lcrs_tree_insert - 二叉树新节点插入
 * @tree: 指向被插入节点的二叉树
 * @n: 指向要插入的新节点
 * @parent: 指向要插入节点的父节点
 * @p: 返回值参数，p为指向插入节点指针的指针
 */
void lcrs_tree_insert(lcrs_tree_t *tree, struct lcrs_node *n, struct lcrs_node *parent, struct lcrs_node **p)
{
	n->lcrs_parent = parent;
	n->lcrs_left = n->lcrs_right = NULL;

	*p = n;
	++tree->nr;
	return;
}


static void rb_link_node(struct rb_node *node, struct rb_node *parent, struct rb_node **rb_link);
static void rb_insert_color(struct rb_root *root, struct rb_node *node);
static void rb_erase(struct rb_root *root, struct rb_node *node);
static void rb_erase_color(struct rb_root *root, struct rb_node *node, struct rb_node *parent);

static void rb_rotate_left(struct rb_node *node, struct rb_root *root);
static void rb_rotate_right(struct rb_node * node, struct rb_root * root);


/* rb_tree_init - 红黑树初始化
 * @tree: 要初始化操作的tree
 * @cmp: 节点比较操作的函数
 * @find: 节点查找操作的函数
 * @insert: 节点插入操作的函数
 * @erase: 某节点删除操作的函数
 * @del: 刪除操作函數
 * @finalize: 树删除操作的函数
 */
void rb_tree_init(rb_tree_t *tree, 
		     rb_treenode_cmp_fp cmp,
		     rb_tree_find_fp find,
		     rb_tree_insert_fp insert,
		     rb_tree_erase_fp erase,
		     rb_treenode_del_fp del,
		     rb_tree_finalize_fp finalize)
{
	tree->nr = 0;
	tree->root.rb_node = tree->first = NULL;

	tree->cmp = cmp;
	tree->find = find;
	tree->insert = insert;
	tree->erase = erase;
	tree->del = del;
	tree->finalize = finalize;

	return;
}


/* rb_tree_find_default - 节点查询操作的默认函数，查找从根节点开始
 * @tree: 指向被查找节点所在树
 * @key: 查找的节点，查找的节点结构是key指向结构的成员
 * @parent: 指向查找节点的父节点
 * @return: 如果找到和key节点相等的节点，返回该节点；如果没有找到相应节点，则返回*p=NULL
 */
struct rb_node ** rb_tree_find_default(rb_tree_t *tree, void *key, struct rb_node **parent)
{
	struct rb_node **p = &(tree->root.rb_node);
	int res;
	
	*parent = NULL;
	while ( *p ) {
		*parent = *p;
		res = tree->cmp(*parent, key);

		if ( res > 0 )
			p = &(*p)->rb_left;
		else if ( res < 0 )
			p = &(*p)->rb_right;
		else
			break;
	}

	return p;
}


/* rb_tree_insert_default - 节点插入处理函数
 * @tree: 被插入节点的树
 * @n: 要插入的节点
 * @parent: 要插入节点的父节点
 * @p: 返回值参数，p为指向插入节点指针的指针
 */
void rb_tree_insert_default(rb_tree_t *tree, struct rb_node *n, struct rb_node *parent, struct rb_node **p)
{
	rb_link_node(n, parent, p);
	rb_insert_color(&tree->root, n);
	tree->first = rb_first(&tree->root);
	tree->nr++;

	return;
}


/* rb_tree_erase_default - 从树中删除节点
 * @tree: 要执行删除操作的树
 * @n:被删除的节点 
 */
void rb_tree_erase_default(rb_tree_t *tree, struct rb_node *n)
{
	rb_erase(&tree->root, n);
	tree->nr--;
	if ( tree->first == n )
		tree->first = rb_first(&tree->root);
	
	return;
}


/* rb_tree_finalize_default - 树删除函数
 * @tree: 要被执行删除操作的树
 */
void rb_tree_finalize_default(rb_tree_t *tree)
{
	if ( tree->root.rb_node )
		_rb_tree_finalize_default(&tree->root.rb_node, tree->del);
	
	return;
}


/* _rb_tree_finalize_default - 删除指定节点及以下所有节点
 * @P: 删除起始节点，该节点开始向下全部删除
 * @del: 执行点删除操作的函数
 */
void _rb_tree_finalize_default(struct rb_node **p, rb_treenode_del_fp del)
{
	if ( (*p)->rb_left )
		_rb_tree_finalize_default(&(*p)->rb_left, del);
	else if ( (*p)->rb_right )
		_rb_tree_finalize_default(&(*p)->rb_right, del);
	else {
		if ( del ) {
			del(*p);
			*p = NULL;
		}
			
		return;
	}
}


/* rb_first - 找出树中最小(最左)节点
 * @root: 树根节点指针
 * @return: NULL 表示树空
 * 	    非0 返回最小(最左)节点地址
 */
struct rb_node * rb_first(struct rb_root *root)
{
	struct rb_node *n;


	if ( (n = root->rb_node) == NULL )
		return NULL;

	while ( n->rb_left )
		n = n->rb_left;

	return n;
}


/* rb_last - 找出树中最大(最右)节点
 * @root: 树根节点指针
 * @return: NULL 表示树空
 * 	    非0 返回最大(最右)节点地址
 */
struct rb_node * rb_last(struct rb_root *root)
{
	struct rb_node *n;
	
	
        if ( (n = root->rb_node) == NULL )
                return NULL;
	
        while ( n->rb_right )
                n = n->rb_right;

        return n;
}


/* rb_next - 查找节点的后继节点
 * @node:开始查找节点
 * @return: 非NULL 后继节点
 * 	    NULL 无后继节点
 */
struct rb_node * rb_next(struct rb_node *node)
{
	/* If we have a right-hand child, go down and then left as far
	 * as we can.
	 */
	if ( node->rb_right ) {
                node = node->rb_right;

                while ( node->rb_left )
                        node = node->rb_left;

                return node;
        }

        /* No right-hand children.  Everything down and left is
	 * smaller than us, so any 'next' node must be in the general
         * direction of our parent. Go up the tree; any time the
	 * ancestor is a right-hand child of its parent, keep going
         * up. First time it's a left-hand child of its parent, said
         * parent is our 'next' node.
	 */
        while ( node->rb_parent && node == node->rb_parent->rb_right )
                node = node->rb_parent;

        return node->rb_parent;
}


/* rb_prev - 查找先前节点
 * @node: 开始查找节点
 * @return: 非NULL 先前节点
 * 	    NULL 无先前节点
 */
struct rb_node * rb_prev(struct rb_node *node)
{
        /* If we have a left-hand child, go down and then right as far
	 * as we can.
	 */
        if ( node->rb_left ) {
                node = node->rb_left;

                while ( node->rb_right )
                        node = node->rb_right;

                return node;
        }

        /* No left-hand children. Go up till we find an ancestor which
         * is a right-hand child of its parent.
	 */
        while ( node->rb_parent && node == node->rb_parent->rb_left )
                node = node->rb_parent;

        return node->rb_parent;
}


/* rb_link_node - 节点插入到rbtree树中
 * @node: 要插入的节点
 * @parent：要插入节点的父节点
 * @rb_link: 返回值参数，rb_link为指向插入节点指针的指针
 */
void rb_link_node(struct rb_node *node, struct rb_node *parent, struct rb_node **rb_link)
{
	node->rb_parent = parent;
	node->rb_color = RB_RED;
	node->rb_left = node->rb_right = NULL;

	*rb_link = node;
}


/* rb_insert_color - 调整tree节点颜色
 * @root: 树根节点
 * @node: 新插入的节点
 */
void rb_insert_color(struct rb_root *root, struct rb_node *node)
{
	struct rb_node *parent, *gparent;


	while ( (parent = node->rb_parent) && parent->rb_color == RB_RED ) {
		gparent = parent->rb_parent;

		if ( parent == gparent->rb_left ) {
			{
				register struct rb_node *uncle = gparent->rb_right;

				if (uncle && uncle->rb_color == RB_RED)	{
					uncle->rb_color = RB_BLACK;
					parent->rb_color = RB_BLACK;
					gparent->rb_color = RB_RED;
					node = gparent;
					continue;
				}
			}

			if ( parent->rb_right == node ) {
				register struct rb_node *tmp;

				rb_rotate_left(parent, root);
				tmp = parent;
				parent = node;
				node = tmp;
			}

			parent->rb_color = RB_BLACK;
			gparent->rb_color = RB_RED;
			rb_rotate_right(gparent, root);

		} else {
			{
				register struct rb_node *uncle = gparent->rb_left;

				if ( uncle && uncle->rb_color == RB_RED ) {
					uncle->rb_color = RB_BLACK;
					parent->rb_color = RB_BLACK;
					gparent->rb_color = RB_RED;
					node = gparent;
					continue;
				}
			}

			if ( parent->rb_left == node ) {
				register struct rb_node *tmp;

				rb_rotate_right(parent, root);
				tmp = parent;
				parent = node;
				node = tmp;
			}

			parent->rb_color = RB_BLACK;
			gparent->rb_color = RB_RED;
			rb_rotate_left(gparent, root);
		}
	}

	root->rb_node->rb_color = RB_BLACK;
}


/* rb_erase - 节点删除操作函数
 * @root: 要执行删除操作的树
 * @node: 要删除的节点
 */
void rb_erase(struct rb_root *root, struct rb_node *node)
{
	struct rb_node *child, *parent;
	int color;


	if ( !node->rb_left )
		child = node->rb_right;
	else if ( !node->rb_right )
		child = node->rb_left;
	else {
		struct rb_node * old = node, * left;

		node = node->rb_right;
		while ( (left = node->rb_left) )
			node = left;

		child = node->rb_right;
		parent = node->rb_parent;
		color = node->rb_color;

		if ( child )
			child->rb_parent = parent;
		if ( parent ) {
			if ( parent->rb_left == node )
				parent->rb_left = child;
			else
				parent->rb_right = child;
		}
		else
			root->rb_node = child;

		if ( node->rb_parent == old )
			parent = node;
		node->rb_parent = old->rb_parent;
		node->rb_color = old->rb_color;
		node->rb_right = old->rb_right;
		node->rb_left = old->rb_left;

		if ( old->rb_parent ) {
			if (old->rb_parent->rb_left == old)
				old->rb_parent->rb_left = node;
			else
				old->rb_parent->rb_right = node;
		} else
			root->rb_node = node;

		old->rb_left->rb_parent = node;
		if ( old->rb_right )
			old->rb_right->rb_parent = node;
		goto color;
	}

	parent = node->rb_parent;
	color = node->rb_color;

	if ( child )
		child->rb_parent = parent;
	if ( parent ) {
		if ( parent->rb_left == node )
			parent->rb_left = child;
		else
			parent->rb_right = child;
	}
	else
		root->rb_node = child;

 color:
	if ( color == RB_BLACK )
		rb_erase_color(root, child, parent);
}


/* rb_erase_color - 删除节点之后tree颜色调整
 * @root: 颜色调整节点所在树的根节点
 * @node: 颜色需调整节点
 * @parent: 颜色调整节点的父节点
 */
void rb_erase_color(struct rb_root *root, struct rb_node *node, struct rb_node *parent)
{
	struct rb_node *other;

	while ( (!node || node->rb_color == RB_BLACK) && node != root->rb_node ) {

		if ( parent->rb_left == node ) {
			other = parent->rb_right;
			if ( other->rb_color == RB_RED ) {
				other->rb_color = RB_BLACK;
				parent->rb_color = RB_RED;
				rb_rotate_left(parent, root);
				other = parent->rb_right;
			}
			if ( (!other->rb_left || other->rb_left->rb_color == RB_BLACK)
			    && (!other->rb_right || other->rb_right->rb_color == RB_BLACK) ) {

				other->rb_color = RB_RED;
				node = parent;
				parent = node->rb_parent;
			}
			else {
				if ( !other->rb_right || other->rb_right->rb_color == RB_BLACK ) {
					register struct rb_node *o_left;
					if ( (o_left = other->rb_left) )
						o_left->rb_color = RB_BLACK;
					other->rb_color = RB_RED;
					rb_rotate_right(other, root);
					other = parent->rb_right;
				}
				other->rb_color = parent->rb_color;
				parent->rb_color = RB_BLACK;
				if ( other->rb_right )
					other->rb_right->rb_color = RB_BLACK;
				rb_rotate_left(parent, root);
				node = root->rb_node;
				break;
			}
		}
		else {
			other = parent->rb_left;
			if ( other->rb_color == RB_RED ) {
				other->rb_color = RB_BLACK;
				parent->rb_color = RB_RED;
				rb_rotate_right(parent, root);
				other = parent->rb_left;
			}
			if ( (!other->rb_left || other->rb_left->rb_color == RB_BLACK)
			    && (!other->rb_right || other->rb_right->rb_color == RB_BLACK) ) {
				other->rb_color = RB_RED;
				node = parent;
				parent = node->rb_parent;
			}
			else {
				if ( !other->rb_left || other->rb_left->rb_color == RB_BLACK ) {
					register struct rb_node *o_right;
					if ( (o_right = other->rb_right) )
						o_right->rb_color = RB_BLACK;
					other->rb_color = RB_RED;
					rb_rotate_left(other, root);
					other = parent->rb_left;
				}
				other->rb_color = parent->rb_color;
				parent->rb_color = RB_BLACK;
				if ( other->rb_left )
					other->rb_left->rb_color = RB_BLACK;
				rb_rotate_right(parent, root);
				node = root->rb_node;
				break;
			}
		}
	}

	if ( node )
		node->rb_color = RB_BLACK;
}


/* rb_rotate_left - node进行左旋转
 * @node: 旋转圆心节点
 * @root: 树根节点
 */
void rb_rotate_left(struct rb_node *node, struct rb_root *root)
{
	struct rb_node *right = node->rb_right;

	if ( (node->rb_right = right->rb_left) )
		right->rb_left->rb_parent = node;
	right->rb_left = node;
	
	if ( (right->rb_parent = node->rb_parent) ) {
		if ( node == node->rb_parent->rb_left )
			node->rb_parent->rb_left = right;
		else
			node->rb_parent->rb_right = right;
	}
	else
		root->rb_node = right;

	node->rb_parent = right;
}


/* rb_rotate_right - node进行右旋转
 * @node: 旋转圆心节点
 * @root: 树根节点
 */
void rb_rotate_right(struct rb_node *node, struct rb_root *root)
{
	struct rb_node *left = node->rb_left;
	
	if ( (node->rb_left = left->rb_right) )
		left->rb_right->rb_parent = node;
	left->rb_right = node;
	
	if ( (left->rb_parent = node->rb_parent) ) {
		if ( node == node->rb_parent->rb_right )
			node->rb_parent->rb_right = left;
		else
			node->rb_parent->rb_left = left;
	}
	else
		root->rb_node = left;

	node->rb_parent = left;
}
