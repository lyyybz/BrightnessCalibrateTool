/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      sys.c
Description:    System level functions
Author:         ch
Version:        v1.0
Date:           2017/07/07
History:
*/
/************************************************************************************************/
#include "include.h"
#include "sys.h"
//#include "uart.h"
#include "visys.h"
/*****************************************************************************************************/

static gdb_pool_t     g_printd_msg_po[NR_MSG_BUF];                    /* �ڴ�ع����ṹָ�� */

static list_head_t    gdb_free = {0, 0};
static list_head_t    gdb_print = {0, 0};

static void gdb_init_msg_pool(void);

static void *gdb_get_from_pool(void);

static void gdb_put_into_pool(void *po);

static void task_printd_init(void);

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void sys_init(void)
{
    char *tty_name[] = {"tty read_q empty", "tty read_q mutex", "tty write_q full", "tty write_q mutex"};

    tty_init(&tty,
         tty_name,
         tty_devgetc,
         tty_devputc,
         tty_devprintf,
         tty_devputs,
         NULL,
         tty_devwrite);

    tty.op.devputc   = tty_devputc;
    tty.op.devprintf = tty_devprintf;
    tty.op.devputs   = tty_devputs;
    tty.op.devwrite  = tty_devwrite;

    vsh_init(&tty);

    gdb_init_msg_pool();
    task_printd_init();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void sys_panic(char *fmt, ...)
{
    char panic_buffer[53];
    unsigned int len = 0;
    va_list args;

    va_start(args, fmt);
    len = vsnprintf(panic_buffer, 53, fmt, args);
    va_end(args);

    if (len > 0)
    {
        uart_puts(panic_buffer);
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void sys_dump(tty_t *term, unsigned char *p, unsigned int len)
{
    unsigned int i;

    for (i = 0; i < (len & 0xfffffff0); i+=16)
    {
        term->op.devprintf(term,
                   "%08x: "
                   "%02x%02x %02x%02x %02x%02x %02x%02x "
                   "%02x%02x %02x%02x %02x%02x %02x%02x\n",
                   i,
                   p[i],   p[i+1], p[i+2],  p[i+3],  p[i+4],  p[i+5],  p[i+6],  p[i+7],
                   p[i+8], p[i+9], p[i+10], p[i+11], p[i+12], p[i+13], p[i+14], p[i+15]);
    }

    if (i < len)
    {
        term->op.devprintf(term, "%08x:", i);
        for (; i < (len & 0xfffffffe); i+=2)
        {
            term->op.devprintf(term, " %02x%02x", p[i], p[i+1]);
        }
        if (i < len)
            term->op.devprintf(term, " %02x\n", p[i]);
    }

    return;
#if 0
    INT32U i;

    for ( i = 0; i < (len/16)*16; i += 16 ) {
        term->op.devprintf(term,
                   "0x%08x:  %02x%02x %02x%02x %02x%02x %02x%02x "
                   "%02x%02x %02x%02x %02x%02x %02x%02x\n", &p[i],
                   p[i], p[i+1], p[i+2], p[i+3], p[i+4], p[i+5],
                   p[i+6], p[i+7], p[i+8], p[i+9], p[i+10],
                   p[i+11], p[i+12], p[i+13], p[i+14], p[i+15]);
    }

    if ( len % 16 ) {
        term->op.devprintf(term, "0x%08x: ", &p[i]);

        for ( ; i < len; i++ ) {
            if ( !(i % 2) ) print_d(" ");
            term->op.devprintf(term, "%02x", p[i]);
        }

        term->op.devputs(term, "\n");
    }

    return;
#endif
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
#if 0
void printf_s(const char *fmt, ...)
{
    char buffer[128];
    va_list args;

    va_start(args, fmt);
    vsnprintf(buffer, 128, fmt, args);
    va_end(args);

    tty_devputs(NULL, buffer);
}
#endif
/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void print_s(const char *s)
{
    tty_devputs(NULL, (char *)s);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void printf_d(const char *fmt, ...)
{
    va_list args;
    gdb_pool_t *msg = NULL;

    if (NULL == (msg = (gdb_pool_t * )gdb_get_from_pool()))
    {
        return;
    }

    va_start(args, fmt);
    vsnprintf(msg->buf, MSG_BUF_SIZE, fmt, args);
    va_end(args);
    
    list_add_tail(&msg->link, &gdb_print);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void print_d(const char *s)
{
    gdb_pool_t *msg = NULL;

    if (NULL == (msg = (gdb_pool_t * )gdb_get_from_pool()))
    {
        return;
    }

    memcpy(msg->buf, s, MSG_BUF_SIZE);
    msg->buf[MSG_BUF_SIZE - 1] = '\0';
    
    list_add_tail(&msg->link, &gdb_print);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
static void gdb_init_msg_pool(void)
{
    unsigned int idx = 0;

    INIT_LIST_HEAD(&gdb_free);
    for (idx = 0; idx < NR_MSG_BUF; idx++)
    {
        list_add(&g_printd_msg_po[idx].link, &gdb_free);
    }
    
    INIT_LIST_HEAD(&gdb_print);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
static void *gdb_get_from_pool(void)
{
    list_head_t *item = NULL;
    gdb_pool_t *pos = NULL;
    unsigned int cpu_sr;
	
    cpu_sr = OS_ENTER_CRITICAL();
    if (list_empty(&gdb_free))
    {
        OS_EXIT_CRITICAL();
        return NULL;
    }

    item = gdb_free.next;

    list_del(item);
    pos = list_entry(item, gdb_pool_t, link);

    OS_EXIT_CRITICAL();
    return pos;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
static void gdb_put_into_pool(void *po)
{
    unsigned int cpu_sr;
	
    if (NULL == po)
    {
        return;
    }

    cpu_sr = OS_ENTER_CRITICAL();
    list_add(&((gdb_pool_t *)po)->link, &gdb_free);
    OS_EXIT_CRITICAL();
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void task_printd(ULONG arg)
{
    unsigned int cpu_sr;
    gdb_pool_t *msg = NULL;
    list_head_t *item;

    while (1)
    {   
        cpu_sr = OS_ENTER_CRITICAL();
        if (list_empty(&gdb_print))
        {
            OS_EXIT_CRITICAL();
            break;
        }

        item = gdb_print.next;

        list_del(item);
        msg = list_entry(item, gdb_pool_t, link);

        OS_EXIT_CRITICAL();
  
        tty_devputs(NULL, msg->buf);

        gdb_put_into_pool(msg);
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
static void task_printd_init(void)
{
#if 0
    q_printd = os_q_create(g_printd_msg_fifo, NR_MSG_BUF, "q_printd");
    if (NULL == q_printd)
    {
        sys_panic("<PRINTD PANIC> init g_printd_msg_que fail!\n");
    }

    pid_printd = task_create("task_printd",
                 task_printd,
                 0,
                 (void *)g_task_printd_stk,
                 TASK_PRINTD_STK_SIZE * sizeof(unsigned int),
                 TASK_PRIO_PRINTD);


    if (pid_printd < 0)
    {
        sys_panic("<PRINTD PANIC> init task_printd fail!\n");
    }
#endif
}

/***************************************gdb switch out***********************************************/
static unsigned int gdb_switch = 0;
static unsigned int gdb_type = 0;

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void gdb_switch_on(unsigned int lev, unsigned int type)
{
#if 0
    cpu_sr = OS_ENTER_CRITICAL();
    gdb_switch |= lev;
    gdb_type = type;
    OS_EXIT_CRITICAL(cpu_sr);
#endif
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void gdb_switch_off(unsigned int lev)
{
    //cpu_sr = OS_ENTER_CRITICAL();
    gdb_switch &= ~lev;
    gdb_type = 0;
    //OS_EXIT_CRITICAL(cpu_sr);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       :
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
void printf_m(unsigned int lev, const char *fmt, ...)
{
    char buffer[128];
    va_list args;

    if (0x00 == (gdb_switch & lev))
    {
        return;
    }

    va_start(args, fmt);
    vsnprintf(buffer, 128, fmt, args);
    va_end(args);

    if (GDB_OPEN_S == gdb_type)
    {
        print_s(buffer);
    }
    else if (GDB_OPEN_D == gdb_type)
    {
        print_d(buffer);
    }
}

