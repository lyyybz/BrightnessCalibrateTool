/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      term.c
Description:
Author:         ch
Version:        v1.0
Date:           2017/06/21
History:
*/
/************************************************************************************************/
#include "include.h"
#include "type.h"
#include "sys.h"
#include "term.h"
#include "vsh.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
//#include "uart.h"
#include "visys.h"

static int tty_get_line(tty_t *tty, char *buf, int size);
static int tty_read(tty_t *tty, char *buf, int size);
static int tty_seek_cursor(tty_t *tty, int offset, int origin);
static int tty_insert_text(tty_t *tty, char *s);
static void tty_kill_line(tty_t *tty);
static void tty_drain(tty_t *tty, int mode);
static void tty_savepos(tty_t *tty, int len);
static void tty_setecho(tty_t *tty, int mode);

static void tty_redisplay(tty_t *tty);

static int tty_insert_char(tty_t *tty, char c);
static int tty_delete_char(tty_t *tty);
static int tty_delete_text(tty_t *tty, int len);

static int tty_dokey_default(tty_t *tty, char key);
static int tty_dokey_tab(tty_t *tty, char key);
static int tty_dokey_backspace(tty_t *tty, char key);
static int tty_dokey_delete(tty_t *tty, char key);
static int tty_dokey_yank(tty_t *tty, char key);
static int tty_dokey_forward(tty_t *tty, char key);
static int tty_dokey_backward(tty_t *tty, char key);
static int tty_dokey_startofline(tty_t *tty, char key);
static int tty_dokey_endofline(tty_t *tty, char key);
static int tty_dokey_kill(tty_t *tty, char key);
static int tty_dokey_previous(tty_t *tty, char key);
static int tty_dokey_next(tty_t *tty, char key);
static int tty_dokey_crlf(tty_t *tty, char key);
static int tty_dokey_help(tty_t *tty, char key);

static int tty_dokey_escape(tty_t *tty, char key);
static int tty_dokey_up(tty_t *tty, char key);
static int tty_dokey_down(tty_t *tty, char key);
static int tty_dokey_left(tty_t *tty, char key);
static int tty_dokey_right(tty_t *tty, char key);
static int tty_dokey_home(tty_t *tty, char key);
static int tty_dokey_end(tty_t *tty, char key);

static int tty_docursor_forward(tty_t *tty, int n);
static int tty_docursor_backward(tty_t *tty, int n);
static int tty_docursor_erase(tty_t *tty, int n);
static int tty_docursor_up(tty_t *tty, int n);
static int tty_docursor_down(tty_t *tty, int n);
static int tty_docursor_clear(tty_t *tty);


tty_t tty;

/*****************************************************************************************************/
/*
    Function    : tty_master_write
    Description : �������ݽ����жϴ���������д��tty->read_q��buf��
    Input       : c:���ڽ����ַ�
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
__isr__ void tty_master_write(char c)
{
    int wp;
    volatile tty_que_t *ttyq = &tty.read_q;

    if (tty_que_full(ttyq, wp))
        return;

    /* now buffer is ready */
    ttyq->buf[ttyq->wp] = c;           /* Receiver FIFO output when read */
    ttyq->wp = wp;

    //sem_post(ttyq->empty);

    return;
}

/*****************************************************************************************************/
/*
    Function    : tty_devgetc
    Description : ��ѯ���Ӵ��ڶ�ȡһ���ֽ�
    Input       : c:���ڽ����ַ�
    Output      : none
    Return      : none
    Notes       : none
*/
/*****************************************************************************************************/
char tty_devgetc(tty_t *tty)
{
    tty = tty;

    return inbyte();
}

/*****************************************************************************************************/
/*
    Function    : tty_slave_getc
    Description : �Ӵ��ڶ�����������tty->read_q�л�ȡһ���ֽ�����
    Input       : tty:
    Output      : none
    Return      : ���ػ�ȡ�����ַ�
    Notes       : none
*/
/*****************************************************************************************************/
char tty_slave_getc(tty_t *tty)
{
#ifdef DEF_ETOS
    char c;
    volatile tty_que_t *ttyq = &tty->read_q;

    while (tty_que_empty(ttyq))
    {               /* �������Ϊ�գ��ȴ��ź��� */
        sem_pend(ttyq->empty);
    }

    /* now data is ready */
    cpu_sr = OS_ENTER_CRITICAL();
    c = ttyq->buf[ttyq->rp];
    ttyq->rp = (ttyq->rp + 1) & (TTY_QUE_BUF_SIZE_MAX - 1);
    OS_EXIT_CRITICAL(cpu_sr);

    return c;
#else
    return 0;
#endif
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
__isr__ void tty_master_read(tty_t *tty)
{
#if 0
    volatile tty_que_t *ttyq = &tty->write_q;
    while (GET_UART_LS_TFE(0) || GET_UART_LS_TE(0)) {
        if (tty_que_empty(ttyq)) {
            SET_UART_IE_THRE(0, 0);
            condition_post(ttyq->full);
            return;
        }

        SET_UART_FIFO(ttyq->buf[ttyq->rp], 0);
        ttyq->rp = (ttyq->rp + 1) & (TTY_QUE_BUF_SIZE_MAX - 1);
    }
#endif
    return;
}

/*****************************************************************************************************/
/*
    Function    : tty_devputc
    Description : ���ڲ�ѯ������һ���ֽ�����
    Input       : tty:API�ӿڹ����ṹ
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_devputc(tty_t *tty, char c)
{
    tty = tty;

    uart_putc(c);
    return 1;
}

/*****************************************************************************************************/
/*
    Function    : tty_slave_putc
    Description :  ��tty->write_q��buf��д��һ���ֽ����ݣ����������������ݷ���ʹ��
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_slave_putc(tty_t *tty, char c)
{
#if DEF_ETOS
    int wp;
    volatile tty_que_t *ttyq = &tty->write_q;

//    if (!OSIntNesting)
//        mutex_pend(ttyq->mutex);

    if (c == '\n')
    {
        while (tty_que_full(ttyq, wp))
        {
            sem_pend(ttyq->full);
        }

        /* now buffer is ready */
        cpu_sr = OS_ENTER_CRITICAL();
        ttyq->buf[ttyq->wp] = '\r';
        ttyq->wp = wp;
        OS_EXIT_CRITICAL(cpu_sr);
    }

    cpu_sr = OS_ENTER_CRITICAL();
    while (tty_que_full(ttyq, wp))
    {
        OS_EXIT_CRITICAL(cpu_sr);
        sem_pend(ttyq->full);
        cpu_sr = OS_ENTER_CRITICAL();
    }

    /* now buffer is ready */
    ttyq->buf[ttyq->wp] = c;
    ttyq->wp = wp;
    OS_EXIT_CRITICAL(cpu_sr);

//    if (!OSIntNesting)
//        mutex_post(ttyq->mutex);

    return 1;
#else
    
    return 0;
#endif
}

/*****************************************************************************************************/
/*
    Function    : tty_devprintf
    Description : ��ʽ������ַ���
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_devprintf(tty_t *tty, char *fmt, ...)
{
    char buf[512];
    int n;
    va_list args;

    va_start(args, fmt);
    n = vsnprintf(buf, 512, fmt, args);
    va_end(args);

    return tty_devwrite(tty, buf, n);
}

/*****************************************************************************************************/
/*
    Function    : tty_slave_printf
    Description : ���������д�뵽tty->write_q��buf�У������ж�ʹ���Դ�����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_slave_printf(tty_t *tty, char *fmt, ...)
{
    char buf[512];
    int n;
    va_list args;

    va_start(args, fmt);
    n = vsnprintf(buf, 512, fmt, args);
    va_end(args);

    return tty_slave_write(tty, buf, n);
}
/*****************************************************************************************************/
/*
    Function    : tty_devputs
    Description : �ַ�����ѯ�����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_devputs(tty_t *tty, char *s)
{
    uart_puts(s);
    return 1;
}

/*****************************************************************************************************/
/*
    Function    : tty_slave_puts
    Description : ��sָ������ݴ�д��tty->write_q��buf�У������ж�ʹ��
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_slave_puts(tty_t *tty, char *s)
{
//  unsigned int cpu_sr;
    char c, *b = s;
    int wp, first = 1;
    volatile tty_que_t *ttyq = &tty->write_q;

//    if (!OSIntNesting)
//        mutex_pend(ttyq->mutex);

    while (*b) {
        //cpu_sr = OS_ENTER_CRITICAL();
        while (tty_que_full(ttyq, wp)) {
            /* Be careful here :-), does anyone realize the trap?
             * If i'm just arriving here with the belief that "tty_que is full indeed",
             * an interrupt occurs which up brings the master-side an
             * opportunity to read something out then try to wake me up (though i'm not
             * sleeping yet). So it will do this, and i will wait for that waking, lead
             * to sleep forever, zzzZZZ...
             * So the belief should be verified again in a proper place.
             */
//          OS_EXIT_CRITICAL(cpu_sr);
//          condition_pend(ttyq->full, 0, tty_que_full(ttyq, wp));
//          cpu_sr = OS_ENTER_CRITICAL();
        }

        /* now buffer is ready */
        if (*b == '\n' && first)
            c = '\r';
        else
            c = *b;

        ttyq->buf[ttyq->wp] = c;
        ttyq->wp = wp;
    //  OS_EXIT_CRITICAL(cpu_sr);

        if (*b == '\n' && first) {
            first = 0;
        }
        else {
            first = 1;
            ++b;
        }
    }

//    if (!OSIntNesting)
//        mutex_post(ttyq->mutex);

    //SET_UART_IE_THRE(1, 0);
    return b-s;
}

/*****************************************************************************************************/
/*
    Function    : tty_devwrite
    Description : �ַ����鴮�ڷ���
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_devwrite(tty_t *tty, char *buf, int size)
{
    tty = tty;
    size = size;

    uart_puts(buf);
    return size;
}

/*****************************************************************************************************/
/*
    Function    : tty_slave_write
    Description : ָ���ռ�����ݶ����жϷ�ʽ����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_slave_write(tty_t *tty, char *buf, int size)
{
#ifdef DEF_ETOS
//  unsigned int cpu_sr;
    char c, *b = buf;
    int wp, n = size, first = 1;
    volatile tty_que_t *ttyq = &tty->write_q;

    /* In case multiple slaves share the same tty */
//    if (!OSIntNesting)
//        mutex_pend(ttyq->mutex);

    while (n > 0) {
        cpu_sr = OS_ENTER_CRITICAL();
        while (tty_que_full(ttyq, wp))
        {
            /* Be careful here :-), does anyone realize the trap?
             * If i'm just arriving here with the belief that "tty_que is full indeed",
             * an interrupt occurs which up brings the master-side an
             * opportunity to read something out then try to wake me up (though i'm not
             * sleeping yet). So it will do this, and i will wait for that waking, lead
             * to sleep forever, zzzZZZ...
             * So the belief should be verified again in a proper place.
             */
            OS_EXIT_CRITICAL(cpu_sr);
            sem_pend(ttyq->full);
            cpu_sr = OS_ENTER_CRITICAL();
        }

        /* now buffer is ready */
        if (*b == '\n' && first)
            c = '\r';
        else
            c = *b;

        ttyq->buf[ttyq->wp] = c;
        ttyq->wp = wp;
        OS_EXIT_CRITICAL(cpu_sr);

        if (*b == '\n' && first) {
            first = 0;
        }
        else {
            first = 1;
            --n; ++b;
        }
    }

//    if (!OSIntNesting)
//        mutex_post(ttyq->mutex);

    //SET_UART_IE_THRE(1, 0);
    return b-buf;
#else
    
    return 0;
#endif
}
/*****************************************************************************************************/
/*
    Function    : tty_fina
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : this function may never be called
*/
/*****************************************************************************************************/
void tty_fina(tty_t *tty)
{
#ifdef DEF_ETOS
    if ( tty->read_q.mutex )
        mutex_delete(tty->read_q.mutex);
    if ( tty->read_q.empty )
        sem_delete(tty->read_q.empty);
    if ( tty->read_q.full )
        sem_delete(tty->read_q.full);

    if ( tty->write_q.mutex )
        mutex_delete(tty->write_q.mutex);
    if ( tty->write_q.empty )
        sem_delete(tty->write_q.empty);
    if ( tty->write_q.full )
        sem_delete(tty->write_q.full);
    return;
#endif
}

/*****************************************************************************************************/
/*
    Function    : tty_get_line
    Description : ��ȡһ�в�����ָ�����ȵ��û��������ݣ���������ʾ��ֵ����
    Input       :
    Output      :
    Return      :
    Notes       :
*/
/*****************************************************************************************************/
int tty_get_line(tty_t *tty, char *buf, int size)
{
    char key;
    int i;

    if(tty->done)
    {
        tty->done = 0;
        tty->modified = 0;
        tty->point = tty->cursor = tty->end = 0;
    }

    //while ( !tty->done )
    {
        key = tty->op.devgetc(tty);

        if ( (key > 0 && key <= 127) && tty->handlers[(int)key]
             && (tty->handlers[(int)key](tty, key)) < 0 )
            ;/* i hope i can make the bell ring! */

        tty_redisplay(tty);
    }

    if(tty->done)
    {
        for ( i = 0; i < size-1 && i < tty->end; ++i )
          buf[i] = tty->line[i];
        buf[i] = 0;

        return i;
    }
    else
    {
        return -1;
    }
}

/*****************************************************************************************************/
/*
    Function    :
    Description : ��tty���û����뻺�����ж�ȡ����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_read(tty_t *tty, char *buf, int size)
{
    int i;

    for ( i = 0; i < size-1 && i < tty->end; ++i )
        buf[i] = tty->line[i];
    buf[i] = 0;

    return i;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : ��ʾ���´���
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
void tty_redisplay(tty_t *tty)
{
    int lines, tmp;

    if ( !tty->modified )
        return;

    if ( tty->line[tty->point] && tty->point <= tty->cursor ) {
        if ( tty->flag & (1 << TTY_ECHO) ) {
            tty->op.devputs(tty, &tty->line[tty->point]);

            if ( tty->cursor < tty->end ) {
                lines = (tty->end + tty->prev_pos) / TTY_COL_NR_MAX
                    - (tty->cursor + tty->prev_pos) / TTY_COL_NR_MAX;
                if (lines) {
                    tty_docursor_up(tty, lines);
                    tty_docursor_forward(tty, TTY_COL_NR_MAX);

                    tmp = (tty->prev_pos + tty->cursor) % TTY_COL_NR_MAX;
                    if (tmp != TTY_COL_NR_MAX - 1) {
                        tty_docursor_backward(tty, TTY_COL_NR_MAX - 1 - tmp);
                    }
                } else {
                    tty_docursor_backward(tty, tty->end - tty->cursor);
                }
            }
        }

        tty->point = tty->cursor;
        tty->modified = 0;
    }

    return;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : �û��������ݻ��������
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
void tty_kill_line(tty_t *tty)
{
    int lines;

    if ( tty->flag & (1<<TTY_ECHO) ) {
        if (tty->end) {
            if ((lines = (tty->prev_pos + tty->cursor) / TTY_COL_NR_MAX)) {
                tty_docursor_up(tty, lines);
                tty_docursor_backward(tty, TTY_COL_NR_MAX);
                tty_docursor_forward(tty, tty->prev_pos);
                tty_docursor_clear(tty);
            } else {
                tty_docursor_backward(tty, tty->cursor);
                tty_docursor_erase(tty, tty->end);
            }
        }
    }

    tty->point = tty->cursor = tty->end = 0;

    return;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : ������ʾ����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
void tty_drain(tty_t *tty, int mode)
{
    if ( mode == TTY_DRAIN_BEG ) {
        tty->point = 0;
        tty->cursor = tty->end;
    }

    if (tty->end != tty->point) {
        tty->modified = 1;
        tty_redisplay(tty);
    }

    return ;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : ��ȡviewsǰ׺��Ϣ����
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
void tty_savepos(struct tty_s *tty, int len)
{
    tty->prev_pos = len;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :  ��������
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
void tty_setecho(tty_t *tty, int mode)
{
    if ( mode )
        tty->flag |= 1 << TTY_ECHO;
    else
        tty->flag &= ~(1 << TTY_ECHO);

    return;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : �ַ�c�����û����뻺�����й��λ��
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_insert_char(tty_t *tty, char c)
{
    if ( tty->end+1 >= TTY_BUF_SIZE_MAX )
        return -1;

    if ( tty->cursor < tty->end )
        memmove(&tty->line[tty->cursor+1], &tty->line[tty->cursor],
            tty->end-tty->cursor+1);
    else
        tty->line[tty->end+1] = 0;

    tty->line[tty->cursor] = c;
    tty->cursor++;
    tty->end++;

    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description : ���������뻺������д��һ������
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_insert_text(tty_t *tty, char *s)
{
    int len;

    if ( !*s ) return 0;
    len = strlen(s);

    if ( tty->end+len >= TTY_BUF_SIZE_MAX )
        return -1;

    if ( tty->cursor < tty->end )
        memmove(&tty->line[tty->cursor+len], &tty->line[tty->cursor],
            tty->end-tty->cursor+1);
    else
        tty->line[tty->end+len] = 0;

    strncpy(&tty->line[tty->cursor], s, len);
    tty->cursor += len;
    tty->end += len;

    return len;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : tty_delete_char - Delete the character that `cursor' points to
*/
/*****************************************************************************************************/
int tty_delete_char(tty_t *tty)
{
    memmove(&tty->line[tty->cursor], &tty->line[tty->cursor+1],
        tty->end-tty->cursor);
    tty->end--;

    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : tty_delete_text - Delete len characters from where `cursor' points to
*/
/*****************************************************************************************************/
int tty_delete_text(tty_t *tty, int len)
{
    memmove(&tty->line[tty->cursor], &tty->line[tty->cursor+len],
        tty->end-tty->cursor-len+1);
    tty->end -= len;

    return len;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : tty_dokey_default - Process regular characters
*/
/*****************************************************************************************************/
int tty_dokey_default(tty_t *tty, char key)
{
    tty->modified = 1;

    return tty_insert_char(tty, (char)key);
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : tty_dokey_tab - Process ASCii 9, ^I
*/
/*****************************************************************************************************/
int tty_dokey_tab(tty_t *tty, char key)
{
    if ( tty->hooks[VTAB] ) tty->hooks[VTAB](tty->context);
    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
int tty_dokey_help(tty_t *tty, char key)
{
    if (tty->hooks[VHELP]) tty->hooks[VHELP](tty->context);
    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_backspace - Process ASCii 127, ^? */
int tty_dokey_backspace(tty_t *tty, char key)
{
    if ( tty->cursor ) {
        if ( tty->flag & (1<<TTY_ECHO) ) {
            if (tty->prev_pos + tty->end >= TTY_COL_NR_MAX){
                if ((tty->prev_pos + tty->cursor) % TTY_COL_NR_MAX == 0) {
                    tty_docursor_up(tty, 1);
                    tty_docursor_forward(tty, TTY_COL_NR_MAX);
                } else {
                    tty_docursor_backward(tty, 1);
                }

                tty->modified = 1;
                tty_docursor_clear(tty);
            } else {
                tty_docursor_backward(tty, 1);
                tty_docursor_erase(tty, 1);
            }
        }

        tty->point = --tty->cursor;
        tty_delete_char(tty);
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_delete - Process ASCii 4, ^D, `C-d' */
int tty_dokey_delete(tty_t *tty, char key)
{
    if ( tty->cursor < tty->end ) {
        tty_delete_char(tty);

        if ( tty->flag & (1<<TTY_ECHO) ) {
            if (tty->prev_pos + tty->end >= TTY_COL_NR_MAX){
                tty->modified = 1;
                tty_docursor_clear(tty);
            } else {
                tty_docursor_erase(tty, 1);
            }
        }
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_yank - Process ASCii 25, ^Y, `C-y' */
int tty_dokey_yank(tty_t *tty, char key)
{
    int ret = 1;

    if ( tty->killed_size ) {
        if ( (ret = tty_insert_text(tty, tty->killed)) > 0 )
            tty->modified = 1;
    }

    key = key;
    return ret;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_forward - Process ASCii 6, ^F, `C-f' */
int tty_dokey_forward(tty_t *tty, char key)
{
    if ( tty->cursor < tty->end ) {
        if ( tty->flag & (1<<TTY_ECHO) ) {
            if ((tty->prev_pos + tty->cursor + 1) % TTY_COL_NR_MAX == 0) {
                tty_docursor_down(tty, 1);
                tty_docursor_backward(tty, TTY_COL_NR_MAX);
            } else {
                tty_docursor_forward(tty, 1);
            }
        }

        tty->point = ++tty->cursor;
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_backward - Process ASCii 2, ^B, `C-b' */
int tty_dokey_backward(tty_t *tty, char key)
{
    if ( tty->cursor ) {
        if ( tty->flag & (1<<TTY_ECHO) ) {
            if ((tty->prev_pos + tty->cursor) % TTY_COL_NR_MAX == 0) {
                tty_docursor_up(tty, 1);
                tty_docursor_forward(tty, TTY_COL_NR_MAX);
            } else {
                tty_docursor_backward(tty, 1);
            }
        }

        tty->point = --tty->cursor;
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_startofline - Process ASCii 1, ^A, `C-a' */
int tty_dokey_startofline(tty_t *tty, char key)
{
    int lines;

    if ( tty->cursor ) {
        if ( tty->flag & (1<<TTY_ECHO) ) {
            lines = (tty->cursor + tty->prev_pos) / TTY_COL_NR_MAX;
            tty_docursor_up(tty, lines);
            tty_docursor_backward(tty, TTY_COL_NR_MAX);
            tty_docursor_forward(tty, tty->prev_pos);
        }

        tty->point = tty->cursor = 0;
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_endofline - Process ASCii 5, ^E, `C-e' */
int tty_dokey_endofline(tty_t *tty, char key)
{
    int lines;

    if ( tty->end > tty->cursor ) {
        if ( tty->flag & (1<<TTY_ECHO) ) {
            lines = (tty->end + tty->prev_pos) / TTY_COL_NR_MAX
                - (tty->cursor + tty->prev_pos) / TTY_COL_NR_MAX;
            tty_docursor_down(tty, lines);
            tty_docursor_backward(tty, TTY_COL_NR_MAX);
            tty_docursor_forward(tty, (tty->end + tty->prev_pos) % TTY_COL_NR_MAX);
        }

        tty->point = tty->cursor = tty->end;
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_kill - Process ASCii 11, ^K, `C-k' */
int tty_dokey_kill(tty_t *tty, char key)
{
    if ( tty->end > tty->cursor ) {
        strcpy(tty->killed, &tty->line[tty->cursor]);
        tty->killed_size = tty->end - tty->cursor;
        tty_delete_text(tty, tty->killed_size);
        if ( tty->flag & (1<<TTY_ECHO) ) {
            tty_docursor_clear(tty);
        }
    }

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_previous - Process ASCii 16, ^P, `C-p' */
int tty_dokey_previous(tty_t *tty, char key)
{
    if ( tty->hooks[VPREV] ) tty->hooks[VPREV](tty->context);
    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_next - Process ASCii 14, ^N, `C-n' */
int tty_dokey_next(tty_t *tty, char key)
{
    if ( tty->hooks[VNEXT] ) tty->hooks[VNEXT](tty->context);
    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_crlf - Process ASCii 13, ^M */
int tty_dokey_crlf(tty_t *tty, char key)
{
    tty->done = 1;
    tty->op.devputs(tty, "\n");

    key = key;
    return 1;
}

/*****************************************************************************************************/
/*
    Function    :
    Description :
    Input       : tty:
    Output      : none
    Return      :
    Notes       : none
*/
/*****************************************************************************************************/
/* tty_dokey_escape - Process ASCii 27, ^[ */
#define STEP0   0
#define STEP1   1
#define STEP2   2
#define STEP11  3
#define STEP111 4

int tty_dokey_escape(tty_t *tty, char key)
{
    int _key0, _key;
    int stat = STEP0;

    while ( 1 ) {
        //_key = tty->op.devgetc(tty);
        _key = inbyte_wait();
        //uart_send_data(0, (unsigned char *)&_key, 1);

        switch ( stat ) {
        case STEP0 :
            if ( _key == '[' )
                stat = STEP1;
            else if ( _key == 'O' )
                stat = STEP2;
            else
                return 1;
            break;
        case STEP1 :
            if ( _key == 'A' )
                return tty_dokey_up(tty, _key);
            else if ( _key == 'B' )
                return tty_dokey_down(tty, _key);
            else if ( _key == 'C' )
                return tty_dokey_right(tty, _key);
            else if ( _key == 'D' )
                return tty_dokey_left(tty, _key);
            else if ( _key == 'H' )
                return tty_dokey_home(tty, _key);
            else if ( _key == 'K' )
                return tty_dokey_end(tty, _key);
            else if ( _key >= '0' && _key <= '9' ) {
                _key0 = _key;
                stat = STEP11;
            }
            else
                return 1;
            break;
        case STEP11 :
            if ( _key == '~' ) {
                if ( _key0 == '3' )
                    return tty_dokey_delete(tty, _key);
                else
                    return 1;
            }
            else if ( _key >= '0' && _key <= '9' ) {
                _key0 = _key;
                stat = STEP111;
            }
            else
                return 1;
            break;
        case STEP111 :
            return 1;
        case STEP2 :
            if ( _key == 'H' )
                return tty_dokey_home(tty, _key);
            else if ( _key == 'F' )
                return tty_dokey_end(tty, _key);
            else
                return 1;
            //break;
        }
    }

    key = key;
    return 1;
}

/* tty_dokey_up - Process ASCii ^[[A */
int tty_dokey_up(tty_t *tty, char key)
{
    return tty_dokey_previous(tty, key);
}

/* tty_dokey_down - Process ASCii ^[[B */
int tty_dokey_down(tty_t *tty, char key)
{
    return tty_dokey_next(tty, key);
}

/* tty_dokey_left - Process ASCii ^[[D */
int tty_dokey_left(tty_t *tty, char key)
{
    return tty_dokey_backward(tty, key);
}

/* tty_dokey_right - Process ASCii ^[[C */
int tty_dokey_right(tty_t *tty, char key)
{
    return tty_dokey_forward(tty, key);
}

/* tty_dokey_home - Process ASCii ^[OH */
int tty_dokey_home(tty_t *tty, char key)
{
    return tty_dokey_startofline(tty, key);
}

/* tty_dokey_end - Process ASCii ^[OF */
int tty_dokey_end(tty_t *tty, char key)
{
    return tty_dokey_endofline(tty, key);
}


/* tty_seek_cursor - 设定光标位置
 * @tty: API接口管理结构
 * @offset: 光标移动位置相对基准位的偏移位置
 * @origin: 设定光标位置计算的基准位
 * @return: 0
 */
int tty_seek_cursor(tty_t *tty, int offset, int origin)
{
    int off;

    if ( origin == TTY_SEEK_END ) {
        off = tty->end - tty->cursor;
        off = (offset>=0) ? off : off+offset;
        if ( off ) {
            tty_docursor_forward(tty, off);
            tty->cursor += off;
            tty->point = tty->cursor;
        }
    }
    else if ( origin == TTY_SEEK_BEG ) {
        return 0;
    }
    else if ( origin == TTY_SEEK_CUR ) {
        return 0;
    }

    return 0;
}


/* tty_docursor_forward - 光标前移n个位�? * @tty: API接口管理结构
 * @n: 光标前移长度
 * @return: 0: 表示光标无需移动
 *      1: 表示光标移动成功
 */
int tty_docursor_forward(tty_t *tty, int n)
{
    if (n == 0) return 0;

    tty->op.devprintf(tty, "\x1b[%dC", n);

    return 1;
}


/* tty_docursor_backward - 光标后移n个位�? * @tty: API接口管理结构
 * @n: 光标后移长度
 * @return: 0: 表示光标无需移动
 *      1: 表示光标移动成功
 */
int tty_docursor_backward(tty_t *tty, int n)
{
    if (n == 0) return 0;

    tty->op.devprintf(tty, "\x1b[%dD", n);

    return 1;
}

/* tty_docursor_erase - 从光标位置开始擦除n个字节长度的数据的显�? * @tty: API接口管理结构
 * @n: 擦除显示的数据长�? */
int tty_docursor_erase(tty_t *tty, int n)
{
    if (n == 0) return 0;

    tty->op.devprintf(tty, "\x1b[%dP", n);

    return 1;
}

/* tty_docursor_up - 光标上移n�? * @tty: API接口管理结构
 * @n: 光标上移行数
 */
int tty_docursor_up(tty_t *tty, int n)
{
    if (n == 0) return 0;

    tty->op.devprintf(tty, "\x1b[%dA", n);

    return 1;
}

/* tty_docursor_down - 光标下移n�? * @tty: API接口管理结构
 * @n: 光标下移行数
 */
int tty_docursor_down(tty_t *tty, int n)
{
    if (n == 0) return 0;

    tty->op.devprintf(tty, "\x1b[%dB", n);

    return 1;
}

/* tty_docursor_clear - 清除从光标至屏末字符的显�? * @tty: API接口管理结构
 */
int tty_docursor_clear(tty_t *tty)
{
    tty->op.devputs(tty, "\x1b[J");

    return 1;
}

void tty_init(tty_t *tty,
              char **name,
              devgetc_fp devgetc,
              devputc_fp devputc,
              devprintf_fp devprintf,
              devputs_fp devputs,
              devputs_fp devputs_noblk,
              devwrite_fp devwrite)
{
    int i;

    tty->read_q.rp = 0;
    tty->read_q.wp = 0;

    tty->write_q.rp = 0;
    tty->write_q.wp = 0;

    tty->op.devgetc = devgetc;
    tty->op.devputc = devputc;
    tty->op.devprintf = devprintf;
    tty->op.devputs = devputs;
    tty->op.devputs_noblk = devputs_noblk;
    tty->op.devwrite = devwrite;

    tty->op.getline = tty_get_line;
    tty->op.read = tty_read;
    tty->op.seek = tty_seek_cursor;
    tty->op.insert = tty_insert_text;
    tty->op.kill = tty_kill_line;
    tty->op.drain = tty_drain;
    tty->op.save_pos = tty_savepos;
    tty->op.setecho = tty_setecho;

    tty->flag = 0;
    tty_setecho(tty, 1);

    for (i = 0; i < NR_KEY_HANDLER_MAX; i++) tty->handlers[i] = (tty_dokey_fp)0;
    for (i = 32; i < NR_KEY_HANDLER_MAX; i++) tty->handlers[i] = tty_dokey_default;

    tty->handlers[KEY_HT] = tty_dokey_tab;
    tty->handlers[KEY_EOT] = tty_dokey_delete;
    tty->handlers[KEY_EM] = tty_dokey_yank;
    tty->handlers[KEY_ACK] = tty_dokey_forward;
    tty->handlers[KEY_STX] = tty_dokey_backward;
    tty->handlers[KEY_SOH] = tty_dokey_startofline;
    tty->handlers[KEY_ENQ] = tty_dokey_endofline;
    tty->handlers[KEY_VT] = tty_dokey_kill;
    tty->handlers[KEY_DLE] = tty_dokey_previous;
    tty->handlers[KEY_SO] = tty_dokey_next;
    tty->handlers[KEY_CR] = tty_dokey_crlf;
    /*tty->handlers[KEY_LF] = tty_dokey_crlf;*/
    tty->handlers[KEY_ESC] = tty_dokey_escape;
    tty->handlers[KEY_BS] = tty_dokey_backspace;
    tty->handlers[KEY_BACKSPACE] = tty_dokey_delete;
    tty->handlers['?'] = tty_dokey_help;

    tty->context = 0;
    for (i = 0; i < NR_HOOK_MAX; i++)
    {
        tty->hooks[i] = (context_hook_fp)0;
    }
}

int ld_tty_devputs(tty_t *tty, char *s)
{
	unsigned int s_len = 0;
	unsigned char *s_bk = (unsigned char *)s;

	while (*s != 0)
	  {
			s++;
			s_len++;

// 			if (s_len > 2048)
// 			{
// 					break;
// 			}
	  }

	//write_print_data(s_bk,s_len);

	return 1;
}

int ld_tty_devprintf(tty_t *tty, char *fmt, ...)
{
	char buf[512];
	int n;
	va_list args;

	va_start(args, fmt);
	n = vsnprintf(buf, 512, fmt, args);
	va_end(args);

	//write_print_data((unsigned char *)buf, n);

	return 1;
}

char ld_tty_devgetc(tty_t *tty)
{
	tty = tty;

//	return ld_print_get_char();
}

void ld_take_over_shell()
{
	#include "visys.h"
	unsigned int cpu_sr;
	
	cpu_sr = OS_ENTER_CRITICAL();
  tty.op.devprintf = ld_tty_devprintf;
  tty.op.devputs   = ld_tty_devputs;
	tty.op.devgetc = ld_tty_devgetc;
	OS_EXIT_CRITICAL();
}

void ld_release_shell()
{
	unsigned int cpu_sr;
	
	cpu_sr = OS_ENTER_CRITICAL();
	tty.op.devprintf = tty_devprintf;
  tty.op.devputs   = tty_devputs;
	tty.op.devgetc = tty_devgetc;
	OS_EXIT_CRITICAL();
}
