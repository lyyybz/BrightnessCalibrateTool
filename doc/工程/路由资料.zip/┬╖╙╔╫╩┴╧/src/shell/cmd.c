/*************************************************************************************************/
/*
Copyright:      QingDao Eastsoft Communication Technology Co.,Ltd.
File Name:      cmd.c
Description:    Command functions implementation
Author:         ch
Version:        v1.0
Date:           2017/06/21
History:
*/
/************************************************************************************************/
#include "include.h"
#include "cmd.h"
#include "vsh.h"
#include "sys.h"

#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#define PREFIX  "  "

int check_integer(char *buf)
{
    char *s;

    for (s = buf; *s; ++s)
    {
        if ((!isxdigit((int)*s)) && (*s != '-') && (*s != 'x'))
            return -1;
        if ((*s == '-') && (s != &buf[0]))
            return -1;
        if ((*s == 'x') && (s != &buf[1]) && (buf[0] != 0))
            return -1;
    }

    return 1;

}

int get_positive_integer(tty_t *term, char *fmt, unsigned int param, unsigned int max, unsigned int min)
{
    int n;
    unsigned int tmp = param;
    char buf[11];

    term->op.devprintf(term, fmt, param);
    n = term->op.getline(term, buf, 11);

    if (check_integer(buf) < 0)
        goto err;

    if (n > 0)
    {
        tmp = strtoul(buf, 0, 0);
        if (((tmp) > (max)) || ((tmp) < (min)))
            goto err;
    }

    return tmp;
err:
    term->op.devputs(term, ">> invalid value!\n");
    return -1;
}

int term_get_string(tty_t *term, char *param)
{
    int n;
    char buf[512], *s;

    n = term->op.getline(term, buf, 512);

    for (s = buf; *s; ++s)
    {
        if (!isprint((int)*s)) goto err;
    }

    if (n < 0) goto err;

    if (n > 0)
    {
        memcpy(param, buf, n);
    }

    return n;
err:
    term->op.devputs(term, ">> invalid value!\n");
    return -1;

}


int continue_or_not(tty_t *term)
{
    char buf[8];
    char *s = buf;

    if (!term->op.getline(term, buf, 8))
        return 0;

    if ((*s != 'Y' && *s != 'y' && *s != 'N' && *s != 'n') || *(s + 1))
    {
        term->op.devputs(term, ">> invalid value!\n");
        return 0;
    }

    if (('Y' == *s) || ('y' == *s))
        return 1;

    return 0;
}

int get_mac(char *arg, unsigned char mac[])
{
    char *tok;
    int i = 0;
    unsigned long val;

    while ((tok = strchr(arg, ':')))
    {
        *tok = '\0';

        if ((val = strtoul(arg, 0, 16)) > 0xff)
            return -1;

        mac[i++] = (unsigned char)(val & 0xff);
        *tok = ':';
        arg = tok + 1;
    }

    if (arg[0] != '\0')
    {
        if ((val = (unsigned char)strtoul(arg, 0, 16)) > 0xff)
            return -1;
        mac[i++] = (unsigned char)(val & 0xff);
    }

    if (i != 6) {
        return -1;
    }

    return 1;
}

int get_ip(char *arg, unsigned char ip[])
{
    char *tok;
    int i = 0;
    unsigned long val;

    while ((tok = strchr(arg, '.')))
    {
        *tok = '\0';

        if ((val = strtoul(arg, 0, 0)) > 0xff)
            return -1;

        ip[i++] = (unsigned char)(val & 0xff);
        *tok = '.';
        arg = tok + 1;
    }

    if (arg[0] != '\0')
    {
        if ((val= (unsigned char)strtoul(arg, 0, 0)) > 0xff)
            return -1;
        ip[i++] = (unsigned char)(val & 0xff);
    }

    if (i != 4) {
        return -1;
    }

    return 1;
}

int get_ipv6(char *arg, unsigned short ipv6[])
{
    char *tok;
    int i = 0;
    unsigned long val;

    while ((tok = strchr(arg, ':')))
    {
        *tok = '\0';

        if ((val = strtoul(tok, 0, 16)) > 0xffff)
            return -1;

        ipv6[i++] = (unsigned short)(val & 0xffff);
        *tok = ':';
        arg  = tok + 1;
    }

    if (arg[0] != '\0')
    {
        if ((val = strtoul(arg, 0, 0)) > 0xffff)
            return -1;
        ipv6[i++] = (unsigned short)(val & 0xffff);
    }

    if (i != 8)
    {
        return -1;
    }

    return 1;
}

void docmd_reboot(command_t *cmd, xsh_t *xsh)
{
    tty_t *term = xsh->term;

    term->op.devputs(term, "reboot.......\n");

    hard_reset();
}

param_t cmd_read_param_tab[] =
{
    {PARAM_ARG | PARAM_INTEGER, "addr", "start address"
    },
    {PARAM_OPT | PARAM_INTEGER | PARAM_OPTIONAL, "len", "length in bytes"
    },
    {PARAM_OPT | PARAM_TOGGLE | PARAM_OPTIONAL, "fmt", "hex|dec|half|cplx|sclr"
    },
    PARAM_EMPTY
};
cmd_desc_t cmd_read_desc = CMD_DESC_ENTRY(
                           "Read memory or registers.", cmd_read_param_tab
                           );
void docmd_read(command_t *cmd, xsh_t *xsh) {
    tty_t *term = xsh->term;
    char *s, *fmt = "hex";
    unsigned int addr, len = 4, i;

    addr = strtoul(xsh->argv[1], 0, 0);
    if (addr & 3)
    {
        term->op.devputs(term, "illegal address.\n");
        return;
    }

    for (i = 2; i < xsh->argc; ++i)
    {
        if (strstr(xsh->argv[i], "-len") == xsh->argv[i])
        {
            s = strchr(xsh->argv[i], '=') + 1;
            len = (unsigned int)strtoul(s, 0, 0);
        }
        else if (strstr(xsh->argv[i], "-fmt") == xsh->argv[i])
        {
            fmt = strchr(xsh->argv[i], '=') + 1;
        }
    }

    for (i = 0; i < len; i += 4, addr += 4)
    {
        if (strcmp(fmt, "hex") == 0)
        {
            term->op.devprintf(term, "%08x ", REG32(addr));

            if (!((i + 4) & 0x1f))
                term->op.devputs(term, "\n");
        }
        else if (strcmp(fmt, "dec") == 0)
        {
            term->op.devprintf(term, "%8d ", REG32(addr));

            if (!((i + 4) & 0x1f))
                term->op.devputs(term, "\n");
        }
        else if (strcmp(fmt, "half") == 0)
        {
            unsigned int data;
            short high, low;

            data = REG32(addr);
            high = data >> 16;
            low = data & 0xffff;

            term->op.devprintf(term, "%8d %8d\n", high, low);
        }
        else if (strcmp(fmt, "cplx") == 0)
        {
            unsigned int data;
            int exp, re, im;

            data = REG32(addr);
            exp = ((data >> 28) & 0xf);
            re = ((int)(data << 18)) >> 18;
            im = ((int)(data << 4)) >> 18;

            term->op.devprintf(term, "%8d %8d %8d\n", exp, im, re);
        }
        else if (strcmp(fmt, "sclr") == 0)
        {
            unsigned int data;
            int exp, mts;

            data = REG32(addr);
            exp = ((data >> 26) & 0x3f);
            mts = ((int)(data << 6)) >> 6;
            term->op.devprintf(term, "%8d %32d\n", exp, mts);
        }
    }

    term->op.devputs(term, "\n");
    return;
}


param_t cmd_write_param_tab[] =
{
    {PARAM_ARG | PARAM_INTEGER, "addr", "target address"
    },
    {PARAM_ARG | PARAM_INTEGER, "value", "value"
    },
    PARAM_EMPTY
};
cmd_desc_t cmd_write_desc = CMD_DESC_ENTRY(
                            "Write memory or register.", cmd_write_param_tab
                            );
void docmd_write(command_t *cmd, xsh_t *xsh) {
    tty_t *term = xsh->term;
    unsigned int addr, data;

    addr = strtoul(xsh->argv[1], 0, 0);
    if (addr & 3)
    {
        term->op.devputs(term, "illegal address.\n");
        return;
    }

    data = strtoul(xsh->argv[2], 0, 0);
    REG32(addr) = data;
    data = REG32(addr);
    term->op.devprintf(term, "[0x%x]:0x%x\n", addr, data);

    return;
}

param_t cmd_os_param_tab[] =
{
    {PARAM_ARG | PARAM_TOGGLE, "", "pool|top|nest|task"
    },
    {PARAM_OPT | PARAM_INTEGER | PARAM_SUB, "pid", "task id",
        "task"
    },
    PARAM_EMPTY
};
cmd_desc_t cmd_os_desc = CMD_DESC_ENTRY(
                         "",
                         cmd_os_param_tab);

unsigned int nest_table[16][16];
void docmd_os(command_t *cmd, xsh_t *xsh)
{
    tty_t *term = xsh->term;;

    if (strcmp(xsh->argv[1], "pool") == 0)
    {
        //etos_pool(term);
    }
    else if (strcmp(xsh->argv[1], "top") == 0)
    {
        //trace_task_state(term);
    }
    else if (strcmp(xsh->argv[1], "nest") == 0)
    {
        unsigned int i, j;

       // cpu_sr = OS_ENTER_CRITICAL();
        //memcpy(nest_table, NEST_TABLE, sizeof(nest_table));
        //OS_EXIT_CRITICAL(cpu_sr);

        term->op.devputs(term, "Interrupt#N is nested by Interrupt(#0,#1,#2,#3,#4,#5,#6,#10)\n");
        term->op.devputs(term, "#N #0       #1       #2       #3       #4       #5       #6       #10\n");
        term->op.devputs(term, "--------------------------------------------------------------------\n");
        for (i = 0; i < 8; ++i)
        {
            term->op.devprintf(term, "%-2d ", i);

            for (j = 0; j < 8; ++j)
            {
                if (j == 7)
                    j = 10;
                term->op.devprintf(term, "%-8x ", nest_table[i][j]);
            }

            term->op.devputs(term, "\n");
        }
    }
    else if (strcmp(xsh->argv[1], "task") == 0)
    {
        int pid;

        pid = strtoul(strchr(xsh->argv[2], '=') + 1, 0, 0);

        //task_dump(term, pid);
    }

    return;
}


