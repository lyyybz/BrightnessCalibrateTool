/*
 * Copyright: (c) 2006-2007, 2008 Triductor Technology, Inc.
 * All Rights Reserved.
 *
 * File:        cmd.h
 * Purpose:     Command function prototypes.
 * History:     4/30/2007, created by jetmotor.
 */

#ifndef _CMD_H
#define _CMD_H

#include <string.h>
#include "vsh.h"

extern param_t cmd_none_param_tab[];
extern int get_positive_integer(tty_t *term, char *fmt, unsigned int param, unsigned int max, unsigned int min);
extern int term_get_string(tty_t *term, char *param);

#define get_param_integer(term, fmt, param, max, min) do {		\
	int tmp;							\
									\
	if ((tmp = get_positive_integer(term, fmt, param, max, min)) < 0)\
	    return ;							\
	else								\
	    param = tmp;						\
} while (0)


#define get_param_string(term, fmt, param)	do {	\
	term->op.devprintf(term, 1, fmt, param);			\
									\
	if (term_get_string(term, param) < 0)				\
		return;							\
									\
} while(0)

extern int continue_or_not(tty_t *term);
extern int get_mac(char *arg, unsigned char mac[]);
extern int get_ip(char *arg, unsigned char ip[]);
extern int get_ipv6(char *arg, unsigned short ipv6[]);
extern int check_integer(char *buf);


extern void docmd_xsh_exit(command_t *cmd, xsh_t *xsh);
extern void docmd_exception(command_t *cmd, xsh_t *xsh);
extern void docmd_reboot(command_t *cmd, xsh_t *xsh);
extern void docmd_exit(command_t *cmd, xsh_t *xsh);
extern void docmd_version(command_t *cmd, xsh_t *xsh);
extern void docmd_build(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mmsg_desc;
extern void docmd_mmsg(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_dy_brq_desc;
extern void docmd_dy_brq(command_t *cmd, xsh_t *xsh);
#ifdef UG_AUTO
extern void docmd_ug_auto(command_t *cmd, xsh_t *xsh);
#endif
#ifdef MODULE_TOP
extern cmd_desc_t cmd_test_top_desc;
extern void docmd_test_top(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_adj_desc;
extern void docmd_adj(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_send_top_desc;
extern void docmd_send_top(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_route_desc;
extern void docmd_route(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_get_conn_idx_desc;
extern void docmd_get_conn_idx(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_brt_desc;
extern void docmd_brt(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_on2brt_desc;
extern void docmd_on2brt(command_t *cmd, xsh_t *xsh);
extern void docmd_node_mask(command_t *cmd, xsh_t *xsh);
#endif 
extern cmd_desc_t cmd_imt_desc;
extern void docmd_imt(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_watch_desc;
extern void docmd_watch(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_level_desc;
extern void docmd_level(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_read_desc;
extern void docmd_read(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_write_desc;
extern void docmd_write(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_tftp_desc;
extern void docmd_tftp(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ping_desc;
extern void docmd_ping(command_t *cmd, xsh_t *xsh);
extern void docmd_readafe(command_t *cmd, xsh_t *xsh);
extern void docmd_writeafe(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_os_desc;
extern void docmd_os(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_rgain_desc;
extern void docmd_rgain(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_tgain_desc;
extern void docmd_tgain(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mdio_desc;
extern void docmd_mdio(command_t *cmd, xsh_t *vsh);
extern cmd_desc_t cmd_cpu_send_desc;
extern void docmd_cpu_send(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_conn_desc;
extern void docmd_conn(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mac_send_desc;
extern void docmd_mac_send(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_gmac_desc;
extern void docmd_gmac(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_aat_desc;
extern void docmd_aat(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ghn_desc;
extern void docmd_ghn(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_iet_desc;
extern void docmd_iet(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_crt_desc;
extern void docmd_crt(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mrt_desc;
extern void docmd_mrt(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_clf_desc;
extern void docmd_clf(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_sysconfig_desc;
extern void docmd_sysconfig(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_rx_desc;
extern void docmd_rx(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_tx_desc;
extern void docmd_tx(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_dm_desc;
extern void docmd_dm(command_t *cmd, xsh_t *xsh);
#ifdef EST_CE_CTRL
extern cmd_desc_t cmd_modify_desc;
extern void docmd_modify(command_t *cmd, xsh_t *xsh);
#endif
extern cmd_desc_t cmd_bat_desc;
extern void docmd_bat(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_pool_desc;
extern void docmd_pool(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ce_desc;
extern void docmd_ce(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_sfo_desc;
extern void docmd_sfo(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_snr_desc;
extern void docmd_snr(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_scg_desc;
void docmd_scg(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_macloopback_desc;
extern void docmd_macloopback(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_phy_desc;
extern void docmd_phy(command_t *cmd, xsh_t *xsh);
extern void docmd_trace(command_t *cmd, xsh_t *xsh);
#ifdef INET_LWIP
extern void docmd_lwip(command_t *cmd, xsh_t *xsh);
extern void docmd_app_trace(command_t *cmd, xsh_t *xsh);
#endif
extern cmd_desc_t cmd_snr_margin_desc;
extern void docmd_snr_margin(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mcast_desc;
extern void docmd_mcast(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_flow_desc;
extern void docmd_flow(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_increment_desc;
extern void docmd_increment(command_t *cmd, xsh_t *xsh);
extern void docmd_resign(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_bndpl_desc;
extern void docmd_bndpl(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_leave_desc;
extern void docmd_leave(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_gi_desc;
extern void docmd_gi(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_gpl_desc;
extern void docmd_gpl(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_sniff_desc;
extern void docmd_sniff(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ldpc_desc;
extern void docmd_ldpc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ser_desc;
extern void docmd_ser(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_cons_desc;
extern void docmd_cons(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_smpmemcpy_desc;
extern void docmd_smpmemcpy(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_aut_desc;
extern void docmd_aut(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_akm_desc;
extern void docmd_akm(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_passwd_desc;
extern void docmd_passwd(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ccm_desc;
extern void docmd_ccm(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_pkt_desc;
extern void docmd_pkt(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_noise_desc;
extern void docmd_noise(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_agc_desc;
extern void docmd_agc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_rmsc_desc;
extern void docmd_rmsc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_pmsc_desc;
extern void docmd_pmsc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_timezone_desc;
extern void docmd_timezone(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_swc_desc;
extern void docmd_swc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_llc_desc;
extern void docmd_llc(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_mac_desc;
extern void docmd_mac(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_lat_desc;
extern void docmd_lat(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ack_desc;
extern void docmd_ack(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_phead_desc;
extern void docmd_phead(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_ifg_desc;
extern void docmd_ifg(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_stat_tsmp_desc;
extern void docmd_stat_tsmp(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_i2c_desc;
extern void docmd_i2c(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_que_desc;
extern void docmd_que(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_fsm_desc;
extern void docmd_fsm(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_brq_desc;
extern void docmd_brq(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_cbts_desc;
extern void docmd_cbts(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_node_desc;
extern void docmd_node(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_rttimer_desc;
extern void docmd_rttimer(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_rmap_desc;
extern void docmd_rmap(command_t *cmd, xsh_t *xsh);
#ifdef EST_CHIP_MNG
extern cmd_desc_t cmd_chip_mng_desc;
extern void docmd_chip_mng(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_nodectrl_desc;
extern void docmd_nodectrl(command_t *cmd, xsh_t *xsh);
#endif
#if 1
extern void docmd_dma(command_t *cmd, xsh_t *xsh);
#endif
extern cmd_desc_t cmd_pmd_desc;
extern void docmd_pmd(command_t *cmd, xsh_t *xsh);
#ifdef EST_PLC_MODEM
extern cmd_desc_t cmd_pair_desc;
extern void docmd_pair(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_plc_desc;
extern void docmd_plc(command_t *cmd, xsh_t *xsh);
#endif
#ifdef EST_PART
extern cmd_desc_t cmd_part_desc;
extern void docmd_part(command_t *cmd, xsh_t *xsh);
#endif
#ifdef EST_WDT
extern cmd_desc_t cmd_wdt_desc;
extern void docmd_wdt(command_t *cmd, xsh_t *xsh);
#endif
extern cmd_desc_t cmd_adm_desc;
extern void docmd_adm(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_map_desc;
extern void docmd_map(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_zcpoint_desc;
extern void docmd_zcpoint(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_powerctl_desc;
extern void docmd_powerctl(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_logic_grp_desc;
extern void docmd_logic_grp(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_csma_desc;
extern void docmd_csma(command_t *cmd, xsh_t *xsh);
extern cmd_desc_t cmd_llr_mask_desc;
extern void docmd_llr_mask(command_t *cmd, xsh_t *xsh);

#if 0
typedef struct __phy_s {
	pmd_tmr_t *tmr;

	unsigned char   hdr;
	unsigned char   ace;
	unsigned short  pld;
	unsigned int  frame;
	unsigned int  tick;


#define PADDING		0
#define PART_PADDING	1
#define DATA		2
#define RANDOM		3
	unsigned char   diff		:4;
	unsigned char   tz		:4;
	char    gain;

	unsigned char   pid;

	unsigned char   phy		:1;
	unsigned char   always	:1;
	unsigned char   loopback	:1;
	unsigned char   repeat        :1; /* if repeat to send probe frames */
	unsigned char   smp		:1;
	unsigned char   rep		:3;
	/* flag */
#define NEVER_HOLD	0x00
#define HEADER_ERR	0x01
#define LPDU_ERR	0x02
#define ALL_ERR		0x03
#define HEADER_REC	0x04
#define LPDU_REC	0x08
#define ALL_REC		0x0c
#define PROBE_HOLD      0x10
#define MSG_HOLD        0x20
#define MAP_HOLD        0x40
#define PD_SEC1_HOLD    0x80
	unsigned char hold;
	unsigned char stime;
	unsigned char etime;
	unsigned char status;
#define SMP_NONE     0
#define SMP_SIMPLE   1
#define SMP_TIMEZONE 2
	unsigned char data;
	event_t *cond;

	/* counter */
	unsigned int nr_hdr_err;
	unsigned int nr_pld_err;
	unsigned int nr_hdr_rec;
	unsigned int nr_pld_rec;
} __phy_t;
extern __phy_t __PHY;

typedef struct __mac_s {
	pmd_tmr_t *tmr;

	unsigned char interrupt;

	conn_t *from;
	conn_t *to;

	unsigned int nseg;
	unsigned int ticks;
	unsigned char  cfg;
} __mac_t;
extern __mac_t __MAC;
#endif

static __inline const char *get_param_val(const char *argv, const char *param)
{
	const char *val;

	if (strstr(argv, param) != argv) {
		val = NULL;
        }
	else {
		val = strchr(argv, '=');
	}

	return NULL != val ? (val + 1) : NULL;
}

#define LOCAL_NODE_MAC GHN.me.eth_addr

struct cirque_s {
  unsigned int wr;
  unsigned int rd;
  unsigned int nr;
  unsigned int sz;
  unsigned int *data;
};

#define cirque_init(q, _data, _sz) do {		\
		q.wr = q.rd = q.nr = 0;		\
		q.sz = _sz;			\
		q.data = _data;			\
} while(0)

#define cirque_peek(q, pos) q.data[(q.rd + pos) & (q.sz - 1)]


#define cirque_put(q, val) do { \
	q.data[q.wr] = val; \
	/* queue full */ \
	if (((q.wr + 1) & (q.sz - 1)) == q.rd) { \
		q.wr = q.rd; \
		q.rd = (q.rd + 1) & (q.sz - 1); \
	} else { \
		q.wr = (q.wr + 1) & (q.sz - 1); \
		++q.nr; \
	} \
} while(0)

#define cirque_num(q) q.nr
#define cirque_full(q) (q.nr == q.sz - 1)

extern struct cirque_s consq;
extern struct cirque_s consq_scrm;
extern struct cirque_s consq_freq;
extern unsigned char SID[2];
extern unsigned char BAT_ID[2];
extern unsigned short TONE_IDX;
extern unsigned short nr_sniff_cp;
extern unsigned int *sniff_cp;
extern unsigned int cons_interval;
extern unsigned int cons_counter;
extern unsigned int cons_total;

void sniff_constellation(void);

#define SNIFF_CP_NUM  58
#define capture_constellation(ph) do {				     \
	if (ph->sid == SID[0] && ph->msg_ftsf.bat_id == BAT_ID[0]) { \
		if (cons_total > cirque_num(consq_scrm) && !cirque_full(consq_scrm)) { \
			if (++cons_counter > cons_interval) {		\
				cirque_put(consq_scrm, GET_PMD_FDATA_0()); \
				cirque_put(consq_freq, GET_PMD_FDATA_1()); \
				cons_counter = 0;			\
									\
				if (cirque_num(consq_scrm) >= cons_total || cirque_full(consq_scrm)) {		\
					printf_d("%u constellation points have been captured, " \
						 "you can read the data from %p(scrm) and %p(freq) \n", \
						 cirque_num(consq_scrm), consq_scrm.data, consq_freq.data); \
				}					\
			}						\
		}							\
									\
		if (!sniff_is_on())					\
			break;						\
									\
		SET_PMD_CAU_MEM2_DATA_FMT(0);				\
		SET_PMD_CAU_MEM2_DATA_FMT_WE(1);			\
		/* invalid cache and be sure to read new value */	\
		cache_invalidate((unsigned int)((unsigned int *)MEM_CAU_MEM2 + TONE_IDX), sizeof(unsigned int)); \
		cirque_put(consq, ((unsigned int *)MEM_CAU_MEM2)[TONE_IDX]); \
		if (nr_sniff_cp < SNIFF_CP_NUM) {			\
			sniff_cp[nr_sniff_cp++]  = ((unsigned int *)MEM_CAU_MEM2)[TONE_IDX]; \
			if (nr_sniff_cp >= SNIFF_CP_NUM) {		\
				sniff_constellation();			\
			}						\
		}							\
	}								\
} while(0)

#define TFTP_MEM_ADDR SW_SMP_MEM_ADDR

#endif	/* end of _CMD_H */
