#ifndef ES_SHELL_H
#define ES_SHELL_H

#include "type.h"

#define UPD_PRINT_OPT       0x00000001
#define ASSOC_PRINT_OPT     0x00000002
#define XXX_PRINT_OPT       0x00000004
#define ZC_PRINT_OPT        0x00000008
#define SUCC_RATE_PRINT_OPT 0x00000010
#define PHS_PRINT_OPT       0x00000020
#define PHY_PRINT_OPT       0x00000040
#define APP_PRINT_OPT       0x00000080

#define MODE_CLOSE    0
#define MODE_PRINT_D  1
#define MODE_PRINT_S  2

void es_printf(unsigned int opt, const char *fmt, ...);
void set_print(unsigned int opt, unsigned int mde);
void close_all_print(void);

void shell_init(void);
void shell_run(void);

void es_sys_panic(char *fmt, ...);
#endif
