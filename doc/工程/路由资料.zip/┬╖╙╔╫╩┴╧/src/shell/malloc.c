/*
 * Copyright: (c) 2006-2010, 2011 Triductor Technology, Inc.
 * All Rights Reserved.
 *
 * File:        malloc.c
 * Purpose:     Dynamic memory manipulator.
 * History:     07/22/2011, created by jetmotor
 *		Learn from TCPL: A Storage Allocator
 *		Learn from glibc: ptmalloc
 */

#include "list.h"
#include "rbtree.h"

#include <stddef.h>
#include <string.h>

#if 0
static char const ffsb[256] = {
	-1, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x00 to 0x0F */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x10 to 0x1F */
	5,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x20 to 0x2F */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x30 to 0x3F */
	6,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x40 to 0x4F */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x50 to 0x5F */
	5,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x60 to 0x6F */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x70 to 0x7F */
	7,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x80 to 0x8F */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x90 to 0x9F */
	5,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xA0 to 0xAF */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xB0 to 0xBF */
	6,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xC0 to 0xCF */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xD0 to 0xDF */
	5,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xE0 to 0xEF */
	4,  0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0        /* 0xF0 to 0xFF */
};


#define NR_UNIT		(1U << 17)		/* the contiguous storage space is NR_UNIT * UNIT_SIZE */
#define UNIT_SIZE	sizeof(malloc_unit_t)	/* must be 2's power */
#define UNIT_POWER	5			/* UNIT_SIZE = 2^UNIT_POWER */


typedef union malloc_unit_s {
	struct {
		union malloc_unit_s *prev;
		union malloc_unit_s *next;
		unsigned int size;

		struct rb_node rb;
	}c;

	struct {
		long long align1;
		long long align2;
		long long align3;
		long long align4;
	} d;
}malloc_unit_t;


//malloc_unit_t *MEM = (malloc_unit_t *)0x60800000;
rb_tree_t m_tr;

malloc_unit_t *freep = NULL;


static int m_cmp(struct rb_node *na, void *key)
{
	malloc_unit_t *p = rb_entry(na, malloc_unit_t, c.rb);

	return ((void *)p - key);
}


void * tri_malloc(size_t size)
{
	malloc_unit_t *p, *prevp;
	struct rb_node **rbp, *rbpa;
	unsigned int nunits;

	nunits = ((size + UNIT_SIZE - 1) >> 5) + 1;
	
	if (!freep) {
		prevp = &MEM[0];
		prevp->c.size = 1;

		freep = &MEM[1];
		freep->c.size = NR_UNIT;
		prevp->c.next = freep;
		prevp->c.prev = freep;
		freep->c.next = prevp;
		freep->c.prev = prevp;

		rb_tree_init(&m_tr,
			     m_cmp,
			     rb_tree_find_default,
			     rb_tree_insert_default,
			     rb_tree_erase_default,
			     (rb_treenode_del_fp)0,
			     rb_tree_finalize_default);
	}

	for (p = freep; ; p = p->c.next) {
		if (p->c.size >= nunits) {
			if (p->c.size != nunits) {
				p->c.size -= nunits;
				p += p->c.size;
				p->c.size = nunits;
			}
			else {
				prevp = p->c.prev;
				prevp->c.next = p->c.next;
				p->c.next->c.prev = prevp;

				freep = prevp;
			}

			rbp = m_tr.find(&m_tr, p, &rbpa);
			if (!*rbp) m_tr.insert(&m_tr, &p->c.rb, rbpa, rbp);

			return (void *)(p+1);
		}

		if (p == freep)	return (void *)0;
	}

	return (void *)0;
}


void tri_free(void *ptr)
{
	malloc_unit_t *bp, *p, *nextp, *prevp;
	struct rb_node **rbp, *rbpa;
	

	bp = (malloc_unit_t *)ptr - 1;
	rbp = m_tr.find(&m_tr, bp, &rbpa);
	if (!*rbp) return;

	p = freep;
	if (bp > p) {
		for (; bp > (nextp = p->c.next) && nextp > p; p = nextp)
			;
	}
	else {
		for (; bp < (prevp = p->c.prev) && prevp < p; p = prevp)
			;
		nextp = p;
		p = prevp;
	}

	if (bp + bp->c.size != nextp) {
		bp->c.next = nextp;
		nextp->c.prev = bp;
	}
	else {
		bp->c.size += nextp->c.size;
		bp->c.next = nextp->c.next;
		nextp->c.next->c.prev = bp;
	}

	if (p + p->c.size != bp) {
		p->c.next = bp;
		bp->c.prev = p;
	}
	else {
		p->c.size += bp->c.size;
		p->c.next = bp->c.next;
		bp->c.next->c.prev = p;
	}

	freep = p;
	return;
}


/*
    Either allocated or free chunks are in multipliers of `MALLOC_ALIGNMENT'.
    Bit `P' stands for "previous inuse bit". "Size of previous chunk" only
    makes senses when `P' is cleard, that is, previous non-inuse.


    An allocated chunk looks like this:

    chunk-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of previous chunk, if allocated            | |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of chunk, in bytes                         |P|
      mem-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             User data starts here...                          .
            .                                                               .
            .                                                               .
            .                                                               |
nextchunk-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of previous chunk                            |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


    Free chunks are stored in circular doubly-linked lists, and look like this:

    chunk-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of previous chunk                            |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of chunk, in bytes                         |P|
      mem-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Doubly linkage to the next and previous free      |
            +                                                               +
            |             chunks of the same list                           |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Unused space (may be 0 bytes long)                .
            .                                                               .
            .                                                               |
nextchunk-> +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Size of previous chunk                            |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
typedef struct mchunk_s {
	unsigned int prev_size;
	unsigned int size;

	struct list_head link;
	struct list_head link_sz;
}mchunk_t;

#define	PREV_INUSE		0x1
#define SIZE_BITS		(PREV_INUSE|0x6)
#define prev_inuse(p)		((p)->size & PREV_INUSE)

#define MALLOC_OVERHEAD		sizeof(mchunk_t)/*offsetof(mchunk_t, link_sz)*/
#define MALLOC_ALIGNMENT	(sizeof(unsigned int) << 1)
#define MALLOC_ALIGN_MASK	((unsigned int)(MALLOC_ALIGNMENT - 1))
#define chunk2mem(p)		((void *)((char *)(p) + offsetof(mchunk_t, link)))
#define mem2chunk(mem)		((mchunk_t *)((char *)(mem) - offsetof(mchunk_t, link)))

/* All the allocated spaces will be of at least `MALLOC_OVERHEAD' size, 
 * or increase in pace of `MALLOC_ALIGNMENT'.
 */
#define request2size(sz)\
(((sz) + MALLOC_OVERHEAD + MALLOC_ALIGN_MASK) & ~MALLOC_ALIGN_MASK)

#define chunksize(p)		((p)->size & ~(SIZE_BITS))

/* Next physical mchunk */
#define next_chunk(p)		((mchunk_t *)(((char *)(p)) + ((p)->size & ~SIZE_BITS)))

/* Previous physical mchunk */
#define prev_chunk(p)		((mchunk_t *)(((char *)(p)) - ((p)->prev_size)))

/* Treat space at ptr + offset as a chunk */
#define chunk_at_offset(p, s)	((mchunk_t *)(((char *)(p)) + (s)))

/* extract p's inuse bit */
#define inuse(p)\
((((mchunk_t *)(((char *)(p)) + chunksize(p)))->size) & PREV_INUSE)

/* set/clear chunk as being inuse without otherwise disturbing */
#define set_inuse(p)\
((mchunk_t *)(((char *)(p)) + chunksize(p)))->size |= PREV_INUSE

#define clear_inuse(p)\
((mchunk_t *)(((char *)(p)) + chunksize(p)))->size &= ~(PREV_INUSE)

/* check/set/clear inuse bits in known places */
#define inuse_bit_at_offset(p, s)\
(((mchunk_t *)(((char *)(p)) + (s)))->size & PREV_INUSE)

#define set_inuse_bit_at_offset(p, s)\
(((mchunk_t *)(((char *)(p)) + (s)))->size |= PREV_INUSE)

#define clear_inuse_bit_at_offset(p, s)\
(((mchunk_t *)(((char *)(p)) + (s)))->size &= ~(PREV_INUSE))

/* Set size at head, without disturbing its use bit */
#define set_head_size(p, s)	((p)->size = (((p)->size & SIZE_BITS) | (s)))

/* Set size/use field */
#define set_head(p, s)		((p)->size = (s))

/* Set size at footer (only when chunk is not in use) */
#define set_foot(p, s)		(((mchunk_t *)((char *)(p) + (s)))->prev_size = (s))


#define NFASTBINS		10
#define NBINS			128
#define NSMALLBINS		64
#define MIN_LARGE_SIZE		512

/*
	start	stop	Bin index
	-------------------------	bins for size 8
	0	*	doesn't exist
	8	*	doesn't exist
	16	*  	2
	24	*  	3
	32	*  	4
	40	*  	5
	48	*  	6
	56	*  	7
	64	*  	8
	72	*  	9
	80	*  	10
	88	*  	11
	96	*   	12
	104	*   	13
	112	*   	14
	120	*   	15
	128	*   	16
	136	*   	17
	144	*   	18
	152	*   	19
	160	*   	20
	168	*   	21
	176	*   	22
	184	*   	23
	192	*   	24
	200	*   	25
	208	*   	26
	216	*   	27
	224	*   	28
	232	*   	29
	240	*   	30
	248	*   	31
	256	*   	32
	264	*   	33
	272	*   	34
	280	*   	35
	288	*   	36
	296	*   	37
	304	*   	38
	312	*   	39
	320	*   	40
	328	*   	41
	336	*   	42
	344	*   	43
	352	*   	44
	360	*   	45
	368	*   	46
	376	*   	47
	384	*   	48
	392	*   	49
	400	*   	50
	408	*   	51
	416	*   	52
	424	*   	53
	432	*   	54
	440	*   	55
	448	*   	56
	456	*   	57
	464	*   	58
	472	*   	59
	480	*   	60
	488	*   	61
	496	*   	62
	504	*   	63
	-------------------------	bins for size 64
	512	575	64
	576	639	65
	640	703	66
	704	767	67
	768	831	68
	832	895	69
	896	959	70
	960	1023	71
	1024	1087	72
	1088	1151	73
	1152	1215	74
	1216	1279	75
	1280	1343	76
	1344	1407	77
	1408	1471	78
	1472	1535	79
	1536	1599	80
	1600	1663	81
	1664	1727	82
	1728	1791	83
	1792	1855	84
	1856	1919	85
	1920	1983	86
	1984	2047	87
	2048	2111	88
	2112	2175	89
	2176	2239	90
	2240	2303	91
	2304	2367	92
	2368	2431	93
	2432	2495	94
	-------------------------	bins for size 512
	2496	2559	95
	2560	3071	96
	3072	3583	97
	3584	4095	98
	4096	4607	99
	4608	5119	100
	5120	5631	101
	5632	6143	102
	6144	6655	103
	6656	7167	104
	7168	7679	105
	7680	8191	106
	8192	8703	107
	8704	9215	108
	9216	9727	109
	9728	10239	110
	10240	10751	111
	--------------------------	bins for size 4096
	10752	12287	112
	12288	16383	113
	16384	20479	114
	20480	24575	115
	24576	28671	116
	28672	32767	117
	32768	36863	118
	36864	40959	119
	40960	45055	120
	--------------------------	bins for size 32768
	45056	65535	120
	65536	98303	121
	98304	131071	122
	131072	163839	123
	--------------------------	bins for size 262144
	163840	262143	124
	262144	524287	125
	524288	786431	126
	--------------------------	bin for the others
	786432	2^32	126
*/
/* It doesn't matter if requests supposed to be of different bin size
 * are actually mapped to the same bin.
 */

#define in_smallbin_range(sz)\
((unsigned int)(sz) < (unsigned int)MIN_LARGE_SIZE)

#define smallbin_index(sz)\
(((unsigned int)(sz)) >> 3)

#define largebin_index(sz)\
(((((unsigned int)(sz)) >>  6) <= 38)?  56 + (((unsigned int)(sz)) >>  6): \
 ((((unsigned int)(sz)) >>  9) <= 20)?  91 + (((unsigned int)(sz)) >>  9): \
 ((((unsigned int)(sz)) >> 12) <= 10)? 110 + (((unsigned int)(sz)) >> 12): \
 ((((unsigned int)(sz)) >> 15) <=  4)? 119 + (((unsigned int)(sz)) >> 15): \
 ((((unsigned int)(sz)) >> 18) <=  2)? 124 + (((unsigned int)(sz)) >> 18): \
                                       126)

#define bin_index(sz)\
((in_smallbin_range(sz)) ? smallbin_index(sz) : largebin_index(sz))


#define BINMAPSHIFT	3
#define BINMAPSIZE	(NSMALLBINS >> BINMAPSHIFT)

typedef struct list_head bin_t;
typedef struct mchunk_state_s {
#ifdef TRIOS
	event_t *mutex;
#endif

	unsigned int miss;
	mchunk_t *last;
	mchunk_t *top;
	unsigned int last_hit;

	bin_t bins[NBINS];
	unsigned int bin_hits[NBINS];

	unsigned char smallbin_grp;
	unsigned char largebin_grp;

	unsigned short bin_grp;
	unsigned char bin_map[16];

	/* all chunks of a bin are linked in unsorted order */
	unsigned char smallbin_map[BINMAPSIZE];
	/* all chunks of a bin are linked in descending order */
	unsigned char largebin_map[BINMAPSIZE];
}mchunk_state_t;

mchunk_state_t ARENA;

#define idx2x(i)	(((unsigned int)(i)) & 7)
#define idx2y(i)	(((unsigned int)(i)) >> 3)
#define bitmap(i)	(1U << (i))
#define bitmask(i)	((1U << (i))-1)
#define xy2idx(x,y)	((((unsigned int)(y)) << 3) + (x))
#define mark_bin(m,i)	do { \
	int x, y; \
\
	if ((i) < NSMALLBINS) { \
		x = idx2x(i); \
		y = idx2y(i); \
		(m)->smallbin_map[y] |= bitmap(x); \
		(m)->smallbin_grp |= bitmap(y); \
	} \
	else { \
		x = idx2x(i - NSMALLBINS); \
		y = idx2y(i - NSMALLBINS); \
		(m)->largebin_map[y] |= bitmap(x); \
		(m)->largebin_grp |= bitmap(y); \
	} \
} while (0)
#define unmark_bin(m,i,x,y)	do { \
	if ((i) < NSMALLBINS) { \
		if (!((m)->smallbin_map[y] &= ~bitmap(x))); \
			(m)->smallbin_grp &= ~bitmap(y); \
	} \
	else { \
		if (!((m)->largebin_map[y] &= ~bitmap(x))); \
			(m)->largebin_grp &= ~bitmap(y); \
	} \
} while (0)

#define unsorted_bin(m)	(&(m)->bins[0])
#define bin_at(m,i)	(&(m)->bins[i])
#define bin_first(b)	list_entry((b)->next, mchunk_t, link)
#define bin_last(b)	list_entry((b)->prev, mchunk_t, link)

#if 1
void unlink(bin_t *b, mchunk_t *p)
{
	if (!list_empty(&(p)->link_sz)) {
		mchunk_t *nextp = list_entry((p)->link.next, mchunk_t, link);
		mchunk_t *nextszp = list_entry((p)->link_sz.next, mchunk_t, link_sz);

		if ((p)->link.next != b && nextp != nextszp)
			list_add(&nextp->link_sz, &(p)->link_sz);
		list_del(&(p)->link_sz);
	}

	list_del(&(p)->link);
	return;
}
#else
#define unlink(b, p) do { \
	if (!list_empty(&(p)->link_sz)) { \
		mchunk_t *__nextp = list_entry((p)->link.next, mchunk_t, link); \
		mchunk_t *__nextszp = list_entry((p)->link_sz.next, mchunk_t, link_sz); \
 \
		if ((p)->link.next != b && __nextp != __nextszp) \
			list_add(&__nextp->link_sz, &(p)->link_sz); \
		list_del(&(p)->link_sz); \
	} \
 \
	list_del(&(p)->link); \
} while (0)
#endif

void attach_on_bin(mchunk_state_t *av, mchunk_t *victim, size_t size)
{
	struct list_head *bck;
	mchunk_t *bckp, *p, *_p;
	int idx;

	if (in_smallbin_range(size)) {
		idx = smallbin_index(size);
		bck = bin_at(av, idx);
		INIT_LIST_HEAD(&victim->link_sz);
	}
	else {
		idx = largebin_index(size);
		bck = bin_at(av, idx);

		if (!list_empty(bck)) {
			p = bin_first(bck);

			if (size < p->size) {
				_p = p;
				bck = p->link_sz.next;
				for (bckp = list_entry(bck, mchunk_t, link_sz);
				     bckp != p && chunksize(bckp) > size;
				     bckp = list_entry(bck, mchunk_t, link_sz)) {
					bck = bck->next;
					_p = bckp;
				}

				if (chunksize(bckp) != size) {
					bck = &_p->link;
					list_add(&victim->link_sz, &_p->link_sz);
					goto out;
				}
				bck = &bckp->link;
			}
			else if (size > p->size) {
				list_add_tail(&victim->link_sz, &p->link_sz);
				goto out;
			}
			else {
				bck = &p->link;
			}
		}

		INIT_LIST_HEAD(&victim->link_sz);
	}

 out:
	list_add(&victim->link, bck);
	mark_bin(av, idx);
	return;
}


static int malloc_initialized;
void malloc_init(mchunk_state_t *av)
{
	int i, len = NR_UNIT * UNIT_SIZE - offsetof(mchunk_t, link);

	for (i = 2; i < NBINS; i++) {
		INIT_LIST_HEAD(&av->bins[i]);
		av->bin_hits[i] = 0;
	}

	av->miss = 0;
	av->last = (mchunk_t *)MEM;
	av->top = (mchunk_t *)((unsigned int)MEM + len);
	set_head(av->last, len|PREV_INUSE);
	set_foot(av->last, len);
	attach_on_bin(av, av->last, len);
	
	malloc_initialized = 1;
	return;
}


int malloc_profile(mchunk_state_t *av)
{
	int X, Y, idx;

	if ((Y = ffsb[av->largebin_grp]) >= 0) {
		X = ffsb[av->largebin_map[Y]];
		idx = xy2idx(X, Y) + NSMALLBINS;
	}
	else if ((Y = ffsb[av->smallbin_grp]) >= 0) {
		X = ffsb[av->smallbin_map[Y]];
		idx = xy2idx(X, Y);
	}

	return chunksize(bin_first(bin_at(av, idx)));
}


void bin_watch(mchunk_state_t *av, int start, int stop)
{
	int i, f, X, Y;
	bin_t *bin;
	mchunk_t *p, *_p;
	struct list_head *pos;

	for (i = start; i < stop; i++) {
		f = 0;
		bin = bin_at(av, i);
		if (i < NSMALLBINS) {
			X = idx2x(i);
			Y = idx2y(i);

			if (av->smallbin_map[Y] & bitmap(X))
				f = 1;
		}
		else {
			X = idx2x(i-NSMALLBINS);
			Y = idx2y(i-NSMALLBINS);

			if (av->largebin_map[Y] & bitmap(X))
				f = 1;
		}

		if (!list_empty(bin) || f) {
			printf("bin[%d]:", i);
			list_for_each(pos, bin) {
				p = list_entry(pos, mchunk_t, link);
				printf(" %d@%p", p->size, p);
			}
			printf("\n");

			p = bin_first(bin);
			printf("bin[%d]:", i);
			printf(" %d@%p", p->size, p);
			if (!list_empty(&p->link_sz)) {
				list_for_each(pos, &p->link_sz) {
					_p = list_entry(pos, mchunk_t, link);
					printf(" %d@%p", _p->size, _p);
				}
			}
			printf("\n");
		}
	}

	return;
}


/*
   Remainder discarding when an allocation satified in a large bin:

    victim-> +===============+
             |     prev_size | : leave as before
             |     size      | : leave as before
             |     inuse     | : leave as before
             |               |
             |               |
             |               |
 remainder-> +- - - - - - - -+
             |               |
 nextchunk-> +===============+
             |     prev_size | : leave as before
             |     size      | : leave as before
             |     inuse     | : modified as set
             |               |
             |               |
             |               |
             |               |
             |               |
             +===============+


   Chunk splitting when an allocation satisfied in a large bin:

    victim-> +===============+
             |     prev_size | : leave as before
             |     size      | : modified as requested size
             |     inuse     | : leave as before
             |               |
             |               |
             |               |
 remainder-> +- - - - - - - -+
             |     prev_size | : untouched
             |     size      | : modified as remainder's size
             |     inuse     | : modified as set
             |               |
 nextchunk-> +===============+
             |     prev_size | : modified as remainder's size
             |     size      | : leave as before
             |     inuse     | : shall be cleared, leave as before
             |               |
             |               |
             |               |
             |               |
             |               |
             +===============+
 */
void * tri_malloc2(size_t bytes, mchunk_state_t *av)
{
	int X, Y, tmp;
	size_t nb, size, remainder_sz;
	unsigned int idx;
	bin_t *bin;
	struct list_head *bck;
	mchunk_t *victim, *p, *remainder;

	nb = request2size(bytes);

	/* Chunks in the same small bin are of the same size and also large
	 * enough to accomodate storage requests that're assigned to that bin.
	 * But chunks in large bins are not of such a case.
	 */
	if (in_smallbin_range(nb)) {
		idx = smallbin_index(nb);
		X = idx2x(idx);
		Y = idx2y(idx);

		if (av->smallbin_map[Y] & bitmap(X)) {
			bin = bin_at(av, idx);
			victim = bin_last(bin);

			list_del(&victim->link);
			set_inuse_bit_at_offset(victim, nb);
			if (list_empty(bin)) unmark_bin(av, idx, X, Y);

			++av->bin_hits[idx];
			return chunk2mem(victim);
		}
	again_sbin:
		if ((Y = ffsb[av->largebin_grp]) >= 0) {
			X = ffsb[av->largebin_map[Y]];
			goto inbin;
		}
		if (!malloc_initialized) {
			malloc_init(av);
			goto again_sbin;
		}

		++av->miss;
		return (void *)0;
	}

	/* If it's a large request, search from the current bin to all
	 * the larger bins for the smallest fit chunk with the aid of
	 * binmap as to avoid checking bins one by one.
	 */
	idx = largebin_index(nb);
	X = idx2x(idx - NSMALLBINS);
	Y = idx2y(idx - NSMALLBINS);

	if (av->largebin_map[Y] & bitmap(X)) {
		bin = bin_at(av, idx);
		victim = bin_first(bin);

		if (victim->size >= nb) {
			bck = victim->link_sz.prev;
				
			for (victim = list_entry(bck, mchunk_t, link_sz);
			     (size = chunksize(victim)) < nb;
			     victim = list_entry(bck, mchunk_t, link_sz))
				bck = bck->prev;
				
			/* If `link' next of `victim' has the same size, always use
			 * the second one.
			 */
			if (victim->link.next != bin) {
				p = list_entry(victim->link.next, mchunk_t, link);
						
				if (chunksize(p) == size)
					victim = p;
			}

			goto inhand;
		}
	}

 again_lbin:
	/* Find the smallest fit chunk in the closest bin */
	if (av->largebin_map[Y] >= bitmap(X+1)) {
		X = ffsb[av->largebin_map[Y] & ~bitmask(X+1)];
	}
	else if ((tmp = av->largebin_grp & ~bitmask(Y+1))) {
		Y = ffsb[tmp];
		X = ffsb[av->largebin_map[Y]];
	}
	else {
		if (!malloc_initialized) {
			malloc_init(av);
			goto again_lbin;
		}
		++av->miss;
		return (void *)0;
	}

 inbin:
	idx = xy2idx(X, Y) + NSMALLBINS;
	bin = bin_at(av, idx);
	victim = bin_last(bin);
	size = chunksize(victim);

 inhand:
	unlink(bin, victim);
	if (list_empty(bin)) unmark_bin(av, idx, X, Y);

	remainder_sz = size - nb;
	if (remainder_sz <= MALLOC_OVERHEAD) {
		/* If the remainder is of size [8, MALLOC_OVERHEAD], which is insufficient
		 * to accomondate the complete essential part of `mchunk_t', (i.e.
		 * `prev_size', `size' and `link'), it's impossible to have it again
		 * attached in a bin, waiting for later consolidation when its previous
		 * chunk gets freed. Have it allocated as a whole.
		 */
		set_inuse_bit_at_offset(victim, size);
	}
	else {
		remainder = chunk_at_offset(victim, nb);
		set_head_size(victim, nb);
		set_head(remainder, remainder_sz | PREV_INUSE);
		set_foot(remainder, remainder_sz);

		attach_on_bin(av, remainder, remainder_sz);
	}

	++av->bin_hits[idx];
	return chunk2mem(victim);
}


/*
  Chunk consolidation backward and forward:

             +- - - - - - - -+ 
             |               |
             |               |
             |               |
             |               |
             |               |
             |               |
    victim-> +===============+
             |     prev_size |
             |     size      |
             |     inuse     |
             |               |
             |               |
             |               |
     nextp-> +===============+
             |     prev_size |
             |     size      |
             |     inuse     |
             |               |
             |               |
             |               |
             |               |
             |               |
             +- - - - - - - -+
             .     prev_size .
             .     size      .
             .     inuse     .
             .               .
             .               .
             .               .
             .               .
             . . . . . . . . .
 */
void tri_free2(void *ptr, mchunk_state_t *av)
{
	mchunk_t *victim, *nextp;
	bin_t *bin;
	size_t size, nextsize;
	int idx, X, Y;

	victim = mem2chunk(ptr);
	size = chunksize(victim);
	nextp = next_chunk(victim);
	nextsize = chunksize(nextp);

	if (!prev_inuse(victim)) {
		if (in_smallbin_range(victim->prev_size)) {
			idx = smallbin_index(victim->prev_size);
			X = idx2x(idx);
			Y = idx2y(idx);
		}
		else {
			idx = largebin_index(victim->prev_size);
			X = idx2x(idx-NSMALLBINS);
			Y = idx2y(idx-NSMALLBINS);
		}

		size += victim->prev_size;
		victim = prev_chunk(victim);
		bin = bin_at(av, idx);
		unlink(bin, victim);
		if (list_empty(bin))
			unmark_bin(av, idx, X, Y);
	}

	if (!inuse(nextp)) {
		size += nextsize;

		if (in_smallbin_range(nextsize)) {
			idx = smallbin_index(nextsize);
			X = idx2x(idx);
			Y = idx2y(idx);
		}
		else {
			idx = largebin_index(nextsize);
			X = idx2x(idx-NSMALLBINS);
			Y = idx2y(idx-NSMALLBINS);
		}

		bin = bin_at(av, idx);
		unlink(bin, nextp);
		if (list_empty(bin))
			unmark_bin(av, idx, X, Y);
	}
	else {
		/* If `nextp' is still inuse, PREV_INUSE of `nextp' shall be cleared,
		 * and `nextp->prev_size' will be set appropriately later.
		 */
		clear_inuse_bit_at_offset(nextp, 0);
	}

	set_head_size(victim, size);
	set_foot(victim, size);

	attach_on_bin(av, victim, size);
	return;
}


void malloc2_init(void)
{
#ifdef TRIOS
	if (!(ARENA.mutex = mutex_create()))
		fprintf(stderr, "<malloc panic> %s: %d\n", __func__, __LINE__);
#endif

	ARENA.smallbin_grp = 0;
	ARENA.largebin_grp = 0;
	memset(ARENA.smallbin_map, 0, sizeof(ARENA.smallbin_map));
	memset(ARENA.largebin_map, 0, sizeof(ARENA.largebin_map));
	return;
}


int malloc2_profile()
{
	int size;

#ifdef TRIOS
	mutex_pend(ARENA.mutex);
#else
	unsigned int cpu_sr;
//	OS_ENTER_CRITICAL();
#endif

	size = malloc_profile(&ARENA);

#ifdef TRIOS
	mutex_post(ARENA.mutex);
#else
//	//OS_EXIT_CRITICAL();
#endif

	return size;
}


void * malloc2(size_t size)
{
	void *ptr;

#ifdef TRIOS
	mutex_pend(ARENA.mutex);
#else
	unsigned int cpu_sr;
//	OS_ENTER_CRITICAL();
#endif

//	ptr = tri_malloc2(size, &ARENA) + 0x20000000;

#ifdef TRIOS
//	mutex_post(ARENA.mutex);
#else
	////OS_EXIT_CRITICAL();
#endif

	return ptr;
}


void free2(void *ptr)
{
//#ifdef TRIOS
//	mutex_pend(ARENA.mutex, 0);
//#else
//	unsigned int cpu_sr;
//	OS_ENTER_CRITICAL();
//#endif

	tri_free2(ptr - 0x20000000, &ARENA);

//#ifdef TRIOS
//	mutex_post(ARENA.mutex);
//#else
//	//OS_EXIT_CRITICAL();
//#endif

	return;
}


#ifdef SIM
struct m_info {
	struct list_head link;
	unsigned int size;
	void *ptr;
};

LIST_HEAD(m_alloc);
unsigned int nr = 0;

int main(int argc, char **argv)
{
	int flip, i, j;
	struct m_info *p;
	struct list_head *pos, *n;
	mchunk_state_t *av = &ARENA;

	for (j = 0; j < 100000; j++) {
		flip = rand();
		flip &= 0xf;

		if (flip <= 7) {
			if ((p = (struct m_info *)malloc(sizeof(struct m_info)))) {
				flip = rand();
				p->size = flip % 10240;
				if (!(p->ptr = malloc2(p->size))) {
					printf("miss on %d\n", p->size);
					free(p);
					continue;
				}
				
				++nr;
				list_add_tail(&p->link, &m_alloc);
				
				printf("malloc2: %p, %d\n",
				       mem2chunk(p->ptr), chunksize(mem2chunk(p->ptr)));
			}
		}
		else {
			if (!nr) continue;
			i = 0;
			flip = rand();
			flip %= nr;
			list_for_each_safe(pos, n, &m_alloc) {
				if (++i == flip) {
					--nr;
					list_del(pos);

					p = list_entry(pos, struct m_info, link);
					printf("free2: %p, %d\n",
					       mem2chunk(p->ptr), chunksize(mem2chunk(p->ptr)));
					free2(p->ptr);
					
					free(p);
					break;
				}
			}
		}
	}

	printf("miss: %d\n", av->miss);
	for (j = 0; j < NBINS; j += 8) {
		printf("bin[%03d] - bin[%03d]:"
		       "%05d %05d %05d %05d %05d %05d %05d %05d\n", j, j+7,
		       av->bin_hits[j], av->bin_hits[j+1], av->bin_hits[j+2], av->bin_hits[j+3],
		       av->bin_hits[j+4], av->bin_hits[j+5], av->bin_hits[j+6], av->bin_hits[j+7]);
	}

	return 0;
}


int m_watch(void)
{
	struct m_info *p;
	struct list_head *pos;

	list_for_each(pos, &m_alloc) {
		p = list_entry(pos, struct m_info, link);
		if ((unsigned int)mem2chunk(p->ptr) == chunksize(mem2chunk(p->ptr))) {
			printf("m_watch: %p, %d\n",
			       mem2chunk(p->ptr), chunksize(mem2chunk(p->ptr)));
			return 1;
		}
	}

	return 0;
}

#endif

#endif
