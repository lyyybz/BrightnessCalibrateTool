/*
 * Copyright: (c) 2006-2007, 2008 Triductor Technology, Inc.
 * All Rights Reserved.
 *
 * File:        sys.h
 * Purpose:     System data structure; each system consists of 4 ports.
 * History:     01/15/2007, created by andyzhou
 */

#ifndef _SYS_H
#define _SYS_H

#include "type.h"
#include "term.h"

#ifndef REG32
    #define REG32(x)                    (*(volatile unsigned int *)(x))
#endif

#define TASK_PRINTD_STK_SIZE    1024*2
#define NR_MSG_BUF              256
#define MSG_BUF_SIZE            128

typedef struct gdb_pool_s
{
    list_head_t    link;
    char           buf[MSG_BUF_SIZE];

} gdb_pool_t;

extern void printf_s(const char *fmt, ...);

extern void print_s(const char *s);

#define assert_s(e) \
    ((e) ? (void)0 : printf_s("%s: %d: Assertion \"%s\" failed.\n", __func__, __LINE__, #e))

extern void printf_d(const char *fmt, ...);

extern void print_d(const char *s);

#define assert_d(e)     \
        ((e) ? (void)0 : printf_d("%s: %d: Assertion \"%s\" failed.\n", __func__, __LINE__, #e))

extern void sys_panic(char *fmt, ...);

extern void sys_dump(tty_t *term, INT8U *p, INT32U len);

/************************************gdb_switch_out********************************************/
#define GDB_OPEN_D        0x01
#define GDB_OPEN_S        0x02

#define GDB_LEV_PHY       (1 << 0)
#define GDB_LEV_MAC       (1 << 1)
#define GDB_LEV_NWK       (1 << 2)
#define GDB_LEV_APP       (1 << 3)
#define GDB_LEV_DEV       (1 << 4)
#define GDB_LEV_WDG       (1 << 5)
#define GDB_LEV_TCP       (1 << 6)

#define GDB_LEV_ALL       (0xFFFFFFFF)

void gdb_switch_on(unsigned int lev, unsigned int type);

void gdb_switch_off(unsigned int lev);

void printf_m(unsigned int lev, const char *fmt, ...);

void task_printd(ULONG arg);

#endif  /* end of _SYS_H */
