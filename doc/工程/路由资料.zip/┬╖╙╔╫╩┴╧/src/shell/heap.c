/**********************************************************
 *  Copyright (C) 2006 Triductor Technology, Inc
 * ********************************************************
 *  The copyright to the computer program(s) herein
 *  is the property of Triductor Technology, Inc. U.S.A.
 *  The program(s) may be used and/or copied only with
 *  the written permission of Triductor Technology, Inc.
 *  or in accordance with the terms and conditions
 *  stipulated in the agreement/contract under which
 *  the program(s) have been supplied.
 *
 *  File: heap.c
 *  Description:
 *
 *  Rev:
 *     18/11/2008, Created, Jerry Liu.
 **********************************************************/
#include <stdlib.h>                /*use the malloc function in link lib*/
#include <string.h>
#include "type.h"


#if 0
/************************************************************************
 *							   M A C R O
 *************************************************************************/

#define OS_NUM_HEAP_PARTS              		14    /*  number of normal memory partitions*/
#define OS_MAX_SIZE_HEAP_BLOCK     		8448	/*for diagresult 8312*/
#define OS_HEAP_NOT_USE_LINK         		1

#define OS_MIN_LARGE_POOL_SIZE 			10240
#if !OS_HEAP_NOT_USE_LINK
#define OS_MAX_LARGE_POOL_SIZE 			(4*1024*1024 + 16)
#endif
#define OS_MALLOC_NORMAL                		0    /*normal alloc*/
#define OS_MALLOC_LINK                     			1    /*use the link api for alloc*/
#define OS_MALLOC_LARGE                  			2   /*large alloc */
#define OS_LARGE_BLOCK_ALLOC        			0xAAAAAAAAUL
#define OS_LARGE_BLOCK_FREE                         0xFFFFEEEEUL
#define OS_MEM_HEAP0_BLOCK_SIZE                16
#define OS_MEM_HEAP1_BLOCK_SIZE                32
#define OS_MEM_HEAP2_BLOCK_SIZE                64
#define OS_MEM_HEAP3_BLOCK_SIZE                128
#define OS_MEM_HEAP4_BLOCK_SIZE                256
#define OS_MEM_HEAP5_BLOCK_SIZE                320
#define OS_MEM_HEAP6_BLOCK_SIZE                576
#define OS_MEM_HEAP7_BLOCK_SIZE                676
#define OS_MEM_HEAP8_BLOCK_SIZE                896
#define OS_MEM_HEAP9_BLOCK_SIZE                960
#define OS_MEM_HEAP10_BLOCK_SIZE              1024
#define OS_MEM_HEAP11_BLOCK_SIZE              2560
#define OS_MEM_HEAP12_BLOCK_SIZE              3072
#define OS_MEM_HEAP13_BLOCK_SIZE              8448	/*for diagresult 8312*/		
//#define OS_MEM_HEAP14_BLOCK_SIZE                6656
//#define OS_MEM_HEAP15_BLOCK_SIZE                8192
//#define OS_MEM_HEAP16_BLOCK_SIZE                10240
//#define OS_MEM_HEAP17_BLOCK_SIZE                OS_MAX_LARGE_POOL_SIZE
  
#define OS_MEM_HEAP0_BLOCK_NUM                 1000//2000 -> 1000
#define OS_MEM_HEAP1_BLOCK_NUM                 1000//1400 -> 700
#define OS_MEM_HEAP2_BLOCK_NUM                 1200//2300 -> 1200
#define OS_MEM_HEAP3_BLOCK_NUM                 0
#define OS_MEM_HEAP4_BLOCK_NUM                 400//800 -> 200
#define OS_MEM_HEAP5_BLOCK_NUM                 0
#define OS_MEM_HEAP6_BLOCK_NUM                 0
#define OS_MEM_HEAP7_BLOCK_NUM                 30//50 -> 20
#define OS_MEM_HEAP8_BLOCK_NUM                 0
#define OS_MEM_HEAP9_BLOCK_NUM                 0
#define OS_MEM_HEAP10_BLOCK_NUM               0
#define OS_MEM_HEAP11_BLOCK_NUM               20//40 ->15
#define OS_MEM_HEAP12_BLOCK_NUM                0
#define OS_MEM_HEAP13_BLOCK_NUM               7// 15->5  

//#define OS_MEM_HEAP14_BLOCK_NUM                  0
//#define OS_MEM_HEAP15_BLOCK_NUM                  0
//#define OS_MEM_HEAP16_BLOCK_NUM                  0
//#define OS_MEM_HEAP17_BLOCK_NUM                  1
#define OS_HEAP_MEM_NO_ERR                          0u
#define OS_HEAP_MEM_INVALID_PART               110u
#define OS_HEAP_MEM_INVALID_BLKS               111u
#define OS_HEAP_MEM_INVALID_SIZE               112u
#define OS_HEAP_MEM_NO_FREE_BLKS              113u
#define OS_HEAP_MEM_INVALID_ADDR              114u
#define OS_HEAP_MEM_FULL                              115u
#define OS_HEAP_MEM_INVALID_PBLK              116u
#define OS_HEAP_MEM_INVALID_PMEM             117u
#define OS_HEAP_MEM_INVALID_PDATA           118u


/************************************************************************
 *						E X T E R N A L   D A T A
 *************************************************************************/

/************************************************************************
 *						P R I V A T E   D A T A
 *************************************************************************/
typedef unsigned int                                           CPU_SR;

/*
***control information and Stat.of the heap(blocks) 
*/
typedef struct OS_MEM_BLOCK_S{                
	VOID *pOSMemAddr;                   
	VOID *pOSMemFreeList;              
	UINT ulOSMemBlkSize;                
	UINT ulOSMemNBlks;                 
	UINT ulOSMemNFree;                 
	UINT ulOSMemMaxUsed;
	INT8U ucLargeAlloc;
	UINT ulAvailableSize; /* for large malloc*/
	VOID *pOffset;
}OS_MEM_BLOCK_ST;


/*
***memory control block
*/
typedef struct OS_MEM_CB_S
{
	OS_MEM_BLOCK_ST *pstParts[OS_NUM_HEAP_PARTS];
	OS_MEM_BLOCK_ST *pstLargeParts;
	UINT ulNum;
	UINT ulLargeNum;
	UINT ulMaxBlockSize;	
/*
***the information(include block size and block num)of 
***each pool (partition) 
*/
	UINT* pulConfigParas;
}OS_MEM_CB_ST;

UINT g_pulOSMEM_Paras[OS_NUM_HEAP_PARTS][2] = {
	{OS_MEM_HEAP0_BLOCK_SIZE, OS_MEM_HEAP0_BLOCK_NUM},
	{OS_MEM_HEAP1_BLOCK_SIZE, OS_MEM_HEAP1_BLOCK_NUM},
	{OS_MEM_HEAP2_BLOCK_SIZE, OS_MEM_HEAP2_BLOCK_NUM},
	{OS_MEM_HEAP3_BLOCK_SIZE, OS_MEM_HEAP3_BLOCK_NUM},
	{ OS_MEM_HEAP4_BLOCK_SIZE, OS_MEM_HEAP4_BLOCK_NUM},
	{OS_MEM_HEAP5_BLOCK_SIZE, OS_MEM_HEAP5_BLOCK_NUM},
	{OS_MEM_HEAP6_BLOCK_SIZE, OS_MEM_HEAP6_BLOCK_NUM},
	{OS_MEM_HEAP7_BLOCK_SIZE, OS_MEM_HEAP7_BLOCK_NUM},
	{OS_MEM_HEAP8_BLOCK_SIZE, OS_MEM_HEAP8_BLOCK_NUM},
	{OS_MEM_HEAP9_BLOCK_SIZE, OS_MEM_HEAP9_BLOCK_NUM},
	{OS_MEM_HEAP10_BLOCK_SIZE, OS_MEM_HEAP10_BLOCK_NUM},
	{OS_MEM_HEAP11_BLOCK_SIZE, OS_MEM_HEAP11_BLOCK_NUM},
	{OS_MEM_HEAP12_BLOCK_SIZE, OS_MEM_HEAP12_BLOCK_NUM},
	{OS_MEM_HEAP13_BLOCK_SIZE, OS_MEM_HEAP13_BLOCK_NUM}
	// {OS_MEM_HEAP14_BLOCK_SIZE, OS_MEM_HEAP14_BLOCK_NUM},
//{OS_MEM_HEAP15_BLOCK_SIZE, OS_MEM_HEAP15_BLOCK_NUM},
//{OS_MEM_HEAP16_BLOCK_SIZE, OS_MEM_HEAP16_BLOCK_NUM},
//{OS_MEM_HEAP17_BLOCK_SIZE, OS_MEM_HEAP17_BLOCK_NUM}
};

static OS_MEM_CB_ST g_stOSMEM_MemCB;
static  OS_MEM_BLOCK_ST *g_pstOSMemFreeList;                                
static  OS_MEM_BLOCK_ST g_astOSMemTbl[OS_NUM_HEAP_PARTS];   

/************************************************************************
 *					E X T E R N A L   F U N C T I O N
 *************************************************************************/
extern VOID SYS_Printf(const CHAR *strFmt, ...);
extern VOID sys_panic(CHAR *fmt, ...);
extern int SYS_GetCurrTaskPrio();

#define OS_HEAP_PRINTF                                 printf_s
#define OS_HEAP_PANIC                                  sys_panic
/************************************************************************
 *					 P R I V A T E   F U N C T I O N
 *************************************************************************/
static INT  OS_CreateLargeMemPool(OS_MEM_BLOCK_ST* pstMem);
static INT OS_MEM_Lookup(VOID* pMem);
static OS_MEM_BLOCK_ST* OS_GetMemBlock(VOID* pBlock);
static VOID* OS_MemLargeAlloc(OS_MEM_BLOCK_ST* pstMem, UINT ulSize);
static INT OS_MemLargeFree(VOID *pMemory, OS_MEM_BLOCK_ST* pstMem);
static VOID* OS_MemAbnormalAlloc(UINT ulSize);
static VOID OS_MemAbnormalFree(VOID *ptr, OS_MEM_BLOCK_ST* pstMem);
//static VOID OS_ShowMemBlocks(UCHAR ucFlag, UCHAR ucPoolIndex);
//static VOID OS_ShowHeapStatus();
//static VOID OS_ShowAbnormalPool();
//static VOID OS_ShowNormalPools();
//static VOID OS_ShowNormalPool(OS_MEM_BLOCK_ST* pstMem);
static UCHAR  OS_FreeMem (OS_MEM_BLOCK_ST *pstMem, VOID *pBlk);
static VOID  *OS_AllocMem (OS_MEM_BLOCK_ST *pstMem, UCHAR *pucErr);
static OS_MEM_BLOCK_ST  *OS_CreateMem(VOID *pAddr, UINT ulBlks, UINT ulBlkSize, UCHAR *pucErr);
static VOID  OS_InitHeapMem(VOID);
static VOID  OS_MemClear (UCHAR *pucDest, UINT ulSize);
static CPU_SR OS_DisableIntr();
static VOID OS_EnableIntr(CPU_SR sr);

/************************************************************************
 *				
 *************************************************************************/
static CPU_SR OS_DisableIntr()
{
	CPU_SR cpuSr  = XT_RSIL(5); 
	
	XT_ESYNC();

	return cpuSr;
}

static VOID OS_EnableIntr(CPU_SR sr)
{
	XT_WSR_PS(sr); 
	XT_ESYNC();

	return;
}

static VOID OS_MemClear(UCHAR *pucDest, UINT ulSize)
{
	while(ulSize > 0) 
	{
		*pucDest++ = (UCHAR)0;		
		ulSize--;
	}
	return;	
}

static VOID OS_InitHeapMem(VOID)
{
	OS_MEM_BLOCK_ST *pstMem;
	UINT ulIndex;    	

	OS_MemClear((UCHAR *)&g_astOSMemTbl[0], sizeof(g_astOSMemTbl));   
	
	pstMem = &g_astOSMemTbl[0];      
	
	for(ulIndex = 0; ulIndex < (OS_NUM_HEAP_PARTS - 1); ulIndex++) 
	{         
		pstMem->pOSMemFreeList = (VOID *)&g_astOSMemTbl[ulIndex+1];		
		pstMem = (OS_MEM_BLOCK_ST*)((UINT)pstMem + sizeof(OS_MEM_BLOCK_ST));
	}
	
	pstMem->pOSMemFreeList = (VOID *)0;   
	
	g_pstOSMemFreeList = &g_astOSMemTbl[0]; 
	return;
}


static OS_MEM_BLOCK_ST *OS_CreateMem
(VOID *pAddr, UINT ulBlks, UINT ulBlkSize, UCHAR *pucErr)
{
	OS_MEM_BLOCK_ST *pstMem;
	UCHAR*pucBlk;
	VOID** ppLink;
	UINT ulIndex;	
	CPU_SR sr = 0;
          
	if(pucErr == (UCHAR *)0) 
	{                         
		return ((OS_MEM_BLOCK_ST *)0);
	}
	
	if(pAddr == (VOID *)0) 
	{                         
		*pucErr = OS_HEAP_MEM_INVALID_ADDR;
		return ((OS_MEM_BLOCK_ST *)0);
	}
	
	if(((UINT)pAddr & (sizeof(VOID *) - 1)) != 0)
	{  
		*pucErr = OS_HEAP_MEM_INVALID_ADDR;
		return ((OS_MEM_BLOCK_ST *)0);
	}
	if(ulBlks < /*2*/1) 
	{                                
		*pucErr = OS_HEAP_MEM_INVALID_BLKS;
		return ((OS_MEM_BLOCK_ST *)0);
	}
	if(ulBlkSize < sizeof(VOID *)) 
	{                 
		*pucErr = OS_HEAP_MEM_INVALID_SIZE;
		return ((OS_MEM_BLOCK_ST *)0);
	}
	if((ulBlkSize % sizeof(VOID *)) != 0) 
	{         
		*pucErr = OS_HEAP_MEM_INVALID_SIZE;                   
		return ((OS_MEM_BLOCK_ST *)0);
	}

	sr = OS_DisableIntr();
	
	pstMem = g_pstOSMemFreeList;                           
	if(g_pstOSMemFreeList != (OS_MEM_BLOCK_ST *)0) 
	{           
		g_pstOSMemFreeList = (OS_MEM_BLOCK_ST *)	
			g_pstOSMemFreeList->pOSMemFreeList;
	}
	
	OS_EnableIntr(sr);
	
	if(pstMem == (OS_MEM_BLOCK_ST *)0) 
	{                      
		*pucErr = OS_HEAP_MEM_INVALID_PART;
		return ((OS_MEM_BLOCK_ST *)0);
	}
	
	ppLink = (VOID **)pAddr;                           
	pucBlk = (UCHAR *)((UINT)pAddr + ulBlkSize);
	
	for(ulIndex = 0; ulIndex < (ulBlks - 1); ulIndex++) 
	{
		*ppLink = (VOID *)pucBlk;                        
		ppLink = (VOID **)(UINT)pucBlk;                     
		pucBlk = (UCHAR *)((UINT)pucBlk + ulBlkSize);    
	}
	
	*ppLink = (VOID *)0;                  
	pstMem->pOSMemAddr = pAddr;                      
	pstMem->pOSMemFreeList = pAddr;                     
	pstMem->ulOSMemNFree = ulBlks;                   
	pstMem->ulOSMemNBlks = ulBlks;
	pstMem->ulOSMemBlkSize = ulBlkSize;
	pstMem->ulOSMemMaxUsed = 0;
	pstMem->ucLargeAlloc = OS_MALLOC_NORMAL;
	
	*pucErr = OS_HEAP_MEM_NO_ERR;
	return (pstMem);
}

static UCHAR  OS_FreeMem (OS_MEM_BLOCK_ST *pstMem, VOID *pblk)
{
	if(pstMem == (OS_MEM_BLOCK_ST *)0) 
	{                   
		return (OS_HEAP_MEM_INVALID_PMEM);
	}
	if(pblk == (VOID *)0) 
	{                   
		return (OS_HEAP_MEM_INVALID_PBLK);
	}

	if(pstMem->ulOSMemNFree >= pstMem->ulOSMemNBlks)
	{  
		return (OS_HEAP_MEM_FULL);
	}
	
	*(VOID **)pblk = pstMem->pOSMemFreeList;   
	pstMem->pOSMemFreeList = pblk;
	pstMem->ulOSMemNFree++;  
	
	return (OS_HEAP_MEM_NO_ERR);                          
}

static VOID  *OS_AllocMem (OS_MEM_BLOCK_ST *pstMem, UCHAR *pucErr)
{
	VOID *pblk;
	
	if(pucErr == (UCHAR *)0) 
	{                          
		return ((VOID *)0);
	}
	
	if(pstMem == (OS_MEM_BLOCK_ST *)0) 
	{                     
		*pucErr = OS_HEAP_MEM_INVALID_PMEM;
		return ((VOID *)0);
	}

	if(pstMem->ulOSMemNFree > 0) 
	{                      
		pblk = pstMem->pOSMemFreeList;   
		pstMem->pOSMemFreeList = *(VOID **)pblk;        
		pstMem->ulOSMemNFree--;                          
		*pucErr = OS_HEAP_MEM_NO_ERR; 
		
		return (pblk);                              
	} 
	
	*pucErr = OS_HEAP_MEM_NO_FREE_BLKS;                     
	return ((VOID *)0);                             
}

INT32U Init_ulAvailableSize = 0;
static INT OS_CreateLargeMemPool(OS_MEM_BLOCK_ST* pstMem)
{
	CHAR *strBlockPtr, *strStart;
	
	if(pstMem == NULL)
	{
		return -1;
	}

	if(pstMem->ulOSMemBlkSize < OS_MIN_LARGE_POOL_SIZE)
	{
		return -2;
	}
	if(pstMem->pOSMemAddr == NULL)
	{
		return -3;
	}
   
	pstMem->ulOSMemNBlks = 2;	
	pstMem->ulAvailableSize = pstMem->ulOSMemBlkSize - sizeof(VOID*) - sizeof(CHAR*);	
	Init_ulAvailableSize = pstMem->ulAvailableSize;
	pstMem->pOffset = pstMem->pOSMemAddr;	
	pstMem->ucLargeAlloc = OS_MALLOC_LARGE;	
	strStart = (CHAR*)(pstMem->pOSMemAddr);	
	strBlockPtr = strStart + pstMem->ulOSMemBlkSize;	
/*
***Backup the end of the pool pointer and build 
***the pre-allocated block. Jerry Liu 2008-08-09
*/
	strBlockPtr =  strBlockPtr - sizeof(VOID*);
	*((UINT *) strBlockPtr) = OS_LARGE_BLOCK_ALLOC;
	strBlockPtr =  strBlockPtr - sizeof(CHAR*);
	*((CHAR* *) strBlockPtr) = strStart;
/*
***Now setup the large available block in the pool. 
***Jerry Liu 2008-08-09
*/
	*((CHAR**)strStart) = strBlockPtr;
	strBlockPtr = strStart;
	strBlockPtr = strBlockPtr + sizeof(CHAR*);
	*((UINT *) strBlockPtr) = OS_LARGE_BLOCK_FREE;

	return 0;
	
}

INT OS_CreateMemBlocks()
{
#if OS_HEAP_NOT_USE_LINK
	INT32U ulHeapSentry;
	INT32U ulStackSentry;
#endif
	OS_MEM_BLOCK_ST* pstMem;
	VOID* pBlock;	
	UCHAR ucIndex, ucErr;
	UINT ulBlockSize, ulBlockNum, *pulMemParas;
		
	g_stOSMEM_MemCB.pstLargeParts = NULL;
	g_stOSMEM_MemCB.ulLargeNum = 0;
	g_stOSMEM_MemCB.ulNum = 0;
	g_stOSMEM_MemCB.ulMaxBlockSize = OS_MAX_SIZE_HEAP_BLOCK;
	g_stOSMEM_MemCB.pulConfigParas = &g_pulOSMEM_Paras[0][0];
	
	OS_InitHeapMem();
/*
***create large pool first Jerry Liu 2008-10-09
*/
#if OS_HEAP_NOT_USE_LINK
	extern INT32U _heap_sentry;
	extern INT32U _stack_sentry;
	ulHeapSentry = (INT32U)&_heap_sentry;
	ulStackSentry = (INT32U)&_stack_sentry;
	
	if(ulHeapSentry - ulStackSentry <= 51200)
	{
		return -2;
	}
	
	ulBlockSize = ulHeapSentry - ulStackSentry - 51200;
	printf_s("%d - %d - 51200 = %d\n", ulHeapSentry, ulStackSentry, ulBlockSize);
	pBlock = malloc(ulBlockSize);
	if(pBlock == NULL)
	{
		return -3;
	}	
#else
	pBlock = malloc(OS_MAX_LARGE_POOL_SIZE);
	if(pBlock == NULL)
	{
		return -4;
	}
	ulBlockSize = OS_MAX_LARGE_POOL_SIZE; 	
#endif

	pstMem = OS_CreateMem(pBlock, 1, ulBlockSize, &ucErr);			
	if(pstMem == NULL || ucErr != OS_HEAP_MEM_NO_ERR)
	{			
		return -5;
	}
	
	OS_CreateLargeMemPool(pstMem);
	pstMem->pOSMemFreeList = NULL;
	
	g_stOSMEM_MemCB.pstLargeParts = pstMem;
	g_stOSMEM_MemCB.ulLargeNum = 1;	
	
	for (ucIndex = 0; ucIndex < OS_NUM_HEAP_PARTS; ucIndex++)         
  	{
	 	pulMemParas = g_stOSMEM_MemCB.pulConfigParas + ucIndex * 2;
		g_stOSMEM_MemCB.pstParts[ucIndex] = NULL;		
		ulBlockSize = pulMemParas[0];
		ulBlockNum = pulMemParas[1];	
		
		if(ulBlockNum == 0)
		{			
			continue;
		}
		
#if OS_HEAP_NOT_USE_LINK
		pBlock = OS_MemLargeAlloc(g_stOSMEM_MemCB.pstLargeParts, ulBlockNum * ulBlockSize);	
#else
		pBlock = malloc(ulBlockNum * ulBlockSize);		
#endif
		if(pBlock == NULL)
		{					
			return -6;				
		}
		
		pstMem = OS_CreateMem(pBlock, ulBlockNum, ulBlockSize, &ucErr);			
		if(pstMem == NULL || ucErr != OS_HEAP_MEM_NO_ERR)
		{			
			return -7;
		}
		
		pstMem->ucLargeAlloc = OS_MALLOC_NORMAL;
		pstMem->ulAvailableSize = 0;
		pstMem->pOffset = NULL;
		pstMem->ulOSMemMaxUsed = 0;	
		
		g_stOSMEM_MemCB.pstParts[ucIndex] = pstMem;
		g_stOSMEM_MemCB.ulNum++;		
	}

	return 0;	
}

static INT OS_MEM_Lookup(VOID* pMem)
{
	UINT ulBlock;
	UCHAR ucIndex;
	OS_MEM_BLOCK_ST* pstMem;	
     
	for (ucIndex = 0; ucIndex < OS_NUM_HEAP_PARTS; ucIndex++)         
	{
        	ulBlock = (UINT)(g_stOSMEM_MemCB.pstParts[ucIndex]);
		if(ulBlock == (UINT)pMem)
		{			
			return 0;
		}
	}

	pstMem = g_stOSMEM_MemCB.pstLargeParts;
	while(pstMem != NULL)
	{
	  	ulBlock = (UINT)(pstMem);		
		if(ulBlock == (UINT)pMem)
		{			
			return 0;
		}
		pstMem = (OS_MEM_BLOCK_ST*)(pstMem->pOSMemFreeList);
	}
	 
	return -1;
}

INT OS_IsInHeap(VOID *pBlock)
{
	UINT ulHeapStart = 
		(UINT)(g_stOSMEM_MemCB.pstLargeParts->pOSMemAddr);	

	if((UINT)pBlock < ulHeapStart)
	{
		goto ret;
	}
	
	ulHeapStart = (UINT)pBlock - ulHeapStart;

	if(ulHeapStart >= 8 && ulHeapStart < 
	   (g_stOSMEM_MemCB.pstLargeParts->ulOSMemBlkSize) - 8)
	{
		return 1;
	}
	
 ret:		
	return 0;
}
static OS_MEM_BLOCK_ST* OS_GetMemBlock(VOID* pBlock)
{
	OS_MEM_BLOCK_ST* pstMem;
	VOID** pLink;
	
	if(OS_IsInHeap(pBlock) == 0)
	{
		OS_HEAP_PRINTF("The block:%p is out of the heap address range\r\n", pBlock);
		return NULL; 
	}
	
	pLink= (VOID**)((UINT)pBlock - sizeof(VOID*)); 	
	pstMem = (OS_MEM_BLOCK_ST*)(*pLink);
	
	if(OS_MEM_Lookup(pstMem) == -1)
	{
		return NULL;
	}
	else
	{
		return pstMem;
	}
	
	return 0;
}

static VOID* OS_MemLargeAlloc(OS_MEM_BLOCK_ST* pstMem, UINT ulSize)
{
	CHAR *strCurr, *strNext;
	UINT ulAvailSize, ulExamineBlocks;

	if(pstMem == NULL)
	{
		return NULL;
	}
	
/*
***This guarantees proper alignment to prevent from crashing. 
***It is must.Jerry Liu 2008-08-26
*/
	ulSize = ((ulSize + sizeof(UINT) - 1) / sizeof(UINT)) * sizeof(UINT);	
	if(ulSize + sizeof(VOID*) + sizeof(CHAR*) > pstMem->ulAvailableSize)
	{
		return NULL;
	}
    
	strCurr = (CHAR*)(pstMem->pOffset);
	ulAvailSize = 0;
	ulExamineBlocks = pstMem->ulOSMemNBlks + 1;
	
	do
	{
		if(*((UINT*)(strCurr + sizeof(VOID*))) == OS_LARGE_BLOCK_FREE)
		{
			strNext = *((CHAR**)strCurr);
			ulAvailSize = strNext - strCurr - sizeof(VOID*) - sizeof(CHAR*);
			
			if(ulAvailSize >= ulSize)
			{
				break;
			}
			else
			{
				ulAvailSize = 0;
				
				/*
			       ***Not enough memory, check to see if the neighbor is
			       ***free and can be merged. Jerry Liu 2008-08-09
			       */
				if(*((UINT*)(strNext + sizeof(VOID*))) == OS_LARGE_BLOCK_FREE)
				{
					*((CHAR**)strCurr) = *((CHAR**)strNext);
					pstMem->ulOSMemNBlks--;
					
					if((CHAR*)(pstMem->pOffset) == strNext)
					{
						pstMem->pOffset = strCurr;
					}
				}
				else
				{
					/*
				       *** Neighbor is not free so we can skip over it
				       ***Jerry Liu 2008-08-09
				       */
					strCurr = *((CHAR**)strNext);
					if(ulExamineBlocks)
					{
						ulExamineBlocks--;
					}
				}
			}
		}
		else
		{			
			/*
		       ***Block is not free, move to next block.  
		       ***Jerry Liu 2008-08-09
		       */
			strCurr = *((CHAR**)strCurr);			
		}
		if(ulExamineBlocks)
		{
			ulExamineBlocks--;
		}
	}while(ulExamineBlocks);

	if(ulAvailSize)
	{
	
		/*
	       ***Determine if we need to split this block. 
	       ***Jerry Liu 2008-08-09
	       */
		if(ulAvailSize - ulSize > OS_MIN_LARGE_POOL_SIZE)
		{
			strNext = strCurr + ulSize + sizeof(VOID*) + sizeof(CHAR*);
			*((CHAR**)strNext) = *((CHAR**)strCurr);
			*((UINT *) (strNext+ sizeof(CHAR*))) =  OS_LARGE_BLOCK_FREE;
			pstMem->ulOSMemNBlks++;
			*((CHAR**)strCurr) = strNext;
			ulAvailSize = ulSize;
		}
		
		/*
	       ***In any case, mark the current block as allocated:
	       ***size of the block. Jerry Liu 2008-08-09
	       */
        	*((OS_MEM_BLOCK_ST**)(strCurr + sizeof(CHAR*))) = pstMem;  		
		pstMem->ulAvailableSize = pstMem->ulAvailableSize - 
			ulAvailSize - sizeof(CHAR*) - sizeof(VOID*);

		strCurr = strCurr + sizeof(VOID*) + sizeof(CHAR*);		
	}

	else
	{
		strCurr = NULL;
	}
	return strCurr;
}

static INT OS_MemLargeFree(VOID *pMemory, OS_MEM_BLOCK_ST* pstMem)
{
	CHAR* strWorkPtr;
	if(pMemory == NULL || pstMem == NULL)
	{
		return -1;
	}

	strWorkPtr = (CHAR*)pMemory;
	if((UINT)(*((OS_MEM_BLOCK_ST**)(strWorkPtr - sizeof(VOID*)))) != (UINT)pstMem)
	{
		return -2;
	}

	strWorkPtr = strWorkPtr - sizeof(CHAR*) - sizeof(VOID*);
	
	if (*((UINT *) (strWorkPtr + sizeof(CHAR*))) != OS_LARGE_BLOCK_FREE)
	{
		*((UINT *) (strWorkPtr + sizeof(CHAR*))) = OS_LARGE_BLOCK_FREE;
		pstMem->ulAvailableSize = pstMem->ulAvailableSize + 
			(*((CHAR**)strWorkPtr) - strWorkPtr);
		pstMem->pOffset = strWorkPtr;
	}
	else
	{
		return -3;
	}
	
	return 0;
}
	
static VOID* OS_MemAbnormalAlloc(UINT ulSize)
{
	OS_MEM_BLOCK_ST *pstMem = g_stOSMEM_MemCB.pstLargeParts;
	VOID **pLink;
	VOID *pBlock;

	while(pstMem != NULL)
	{
/*
***should not come here Jerry Liu 2008-09-01
*/
		if(pstMem->ucLargeAlloc == OS_MALLOC_LINK)
		{
			if((pstMem->ulOSMemBlkSize >= ulSize + sizeof(VOID*)) && 
			   (pstMem->ulOSMemNFree == 1))
			{
				pstMem->ulOSMemNFree = 0;
				pBlock = pstMem->pOSMemAddr;
				pBlock = (VOID*)((UINT)pBlock + sizeof(VOID*));
			
				return pBlock;
			}
		}

		if(pstMem->ucLargeAlloc == OS_MALLOC_LARGE)
		{
			pBlock = OS_MemLargeAlloc(pstMem, ulSize);
			if(pBlock != NULL)
			{
				//OS_HEAP_PRINTF("\r\nLarge alloc %u successifully\r\n", ulSize);
				return pBlock;
			}
#if OS_HEAP_NOT_USE_LINK
			else
			{
				OS_HEAP_PRINTF("\r\nfail to Large alloc %u\r\n", ulSize);
				return NULL;
			}
#endif
		}
		pstMem = (OS_MEM_BLOCK_ST*)(pstMem->pOSMemFreeList);
	}
/*
***alloc by the link api(malloc) Jerry Liu 2008-08-09
*/
	ulSize = ulSize + sizeof(VOID*)  + sizeof(OS_MEM_BLOCK_ST); 	
	pBlock = malloc(ulSize);
	if(pBlock == NULL)
	{
		OS_HEAP_PRINTF("fail to Large(link) malloc size =%u\r\n", ulSize);
		return NULL;
	}	
	
	pstMem = (OS_MEM_BLOCK_ST*)pBlock;		
	pstMem->pOSMemAddr = pBlock;	
	pstMem->ulOSMemBlkSize = ulSize - sizeof(OS_MEM_BLOCK_ST) - sizeof(VOID*);		
	pstMem->ulOSMemNBlks = 1;
	pstMem->ulOSMemNFree = 0;
	pstMem->ucLargeAlloc = OS_MALLOC_LINK;  //it is large malloc
	
	pstMem->pOSMemFreeList = g_stOSMEM_MemCB.pstLargeParts;	
	g_stOSMEM_MemCB.pstLargeParts = pstMem;
	g_stOSMEM_MemCB.ulLargeNum++;
	
	pBlock =(VOID*)((UINT) pBlock + sizeof(OS_MEM_BLOCK_ST));	
	pLink = (VOID**)pBlock;
	*pLink = pstMem;
	pBlock = (VOID*)((UINT)pBlock + sizeof(VOID*));	
	 
	return pBlock;
}

static VOID OS_MemAbnormalFree(VOID *ptr, OS_MEM_BLOCK_ST* pstMem)
{	
	OS_MEM_BLOCK_ST* pstCurr, *pstPrev;

	pstCurr = g_stOSMEM_MemCB.pstLargeParts;
	while(pstCurr != NULL)
	{
		pstPrev = pstCurr;
		if((UINT)pstCurr == (UINT)pstMem)
		{
			break;
		}
		pstCurr = pstCurr->pOSMemFreeList;
	}
	
	if(pstCurr == NULL)
	{
		OS_HEAP_PRINTF("\r\nit is not valid memory block");
		return;
	}

	if(pstMem->ucLargeAlloc == OS_MALLOC_LARGE)
	{
		CHAR cErr = OS_MemLargeFree(ptr, pstMem);

		if(cErr != 0)
		{
			OS_HEAP_PRINTF("\r\nfail to large free err = %d\r\n", cErr);			
		}
		return;
	}
#if OS_HEAP_NOT_USE_LINK
 	else
 	{
 		OS_HEAP_PRINTF("\r\nit is invalid memory block:%p", ptr);
		return;
 	}
#endif
 
	/*
       ***use the link api to free  Jerry Liu 2008-08-11
       */
	if(pstCurr == g_stOSMEM_MemCB.pstLargeParts)
	{
		g_stOSMEM_MemCB.pstLargeParts = 
			g_stOSMEM_MemCB.pstLargeParts->pOSMemFreeList;
	}
	else
	{
		pstPrev->pOSMemFreeList = pstCurr->pOSMemFreeList;
	}
	
	pstMem->ucLargeAlloc = OS_MALLOC_NORMAL;
	g_stOSMEM_MemCB.ulLargeNum--;
	free(pstMem);
	
	return;
}

VOID* OS_Malloc(UINT ulSize)
{
	OS_MEM_BLOCK_ST* pstMem;
	VOID **pLink, *pBlock = NULL;
	UCHAR ucErr,  ucIndex;
	UINT ulBlockSize, ulBlockNum, *pulMemParas;                     
	CPU_SR sr = 0;
	   
	if(ulSize == 0)
	{
		return NULL;
	}

	sr = OS_DisableIntr();
	
	if(ulSize + sizeof(VOID*) > g_stOSMEM_MemCB.ulMaxBlockSize)
	{
//		OS_HEAP_PRINTF("\r\nLarge malloc size =%u\r\n", ulSize);
		pBlock = OS_MemAbnormalAlloc(ulSize);	
		goto post;	
	}
	
	/*
       ***	normal partition can support ---Jerry Liu 2008-03-24---
       */
	for (ucIndex = 0; ucIndex < OS_NUM_HEAP_PARTS; ucIndex++)         
        {
		pulMemParas = g_stOSMEM_MemCB.pulConfigParas + ucIndex * 2;
		ulBlockSize = pulMemParas[0];
		ulBlockNum = pulMemParas[1];
		
        	if(ulBlockSize < (ulSize + sizeof(VOID*)) || ulBlockNum <= 0)
        	{
        		continue;
        	}
			
		pstMem = g_stOSMEM_MemCB.pstParts[ucIndex];	
		pBlock = OS_AllocMem(pstMem, &ucErr);
		if(pBlock == NULL || ucErr != OS_HEAP_MEM_NO_ERR)
		{			
//			OS_HEAP_PRINTF("the size = %u blocks = %u,error = %u\r\n", 
//								pstMem->ulOSMemBlkSize, pstMem->ulOSMemNBlks, ucErr);
			continue;
		}
		 
		pLink = (VOID**)pBlock;
		*pLink = (VOID*)pstMem;
		pBlock = (VOID*)((UINT)pBlock + sizeof(VOID*));			
		if((pstMem->ulOSMemNBlks - pstMem->ulOSMemNFree) > pstMem->ulOSMemMaxUsed)
		{
			pstMem->ulOSMemMaxUsed = 
				pstMem->ulOSMemNBlks - pstMem->ulOSMemNFree;
		}
		
		goto post;
	}	
	  
	pBlock = OS_MemAbnormalAlloc(ulSize);	
	 
 post:
	OS_EnableIntr(sr);     
//	printf_s("\r\n in OS_Malloc, ulSize == %d, pBlock == %p\r\n",ulSize,pBlock);
	
	return pBlock;	
}


VOID OS_Free(VOID *ptr)
{
	OS_MEM_BLOCK_ST* pstMem;	
	UINT ulSize, ulLen;                  
	CPU_SR sr = 0;
   
	sr = OS_DisableIntr();
	
	pstMem = OS_GetMemBlock(ptr);
	if(pstMem == NULL)
	{		
		OS_HEAP_PRINTF("it is not the valid memory block, the pointer = %p\r\npri of the current task = %d\r\n", 
			       ptr, task_query());

		goto post;
	}
	
	if(pstMem->ucLargeAlloc != OS_MALLOC_NORMAL)
	{
		OS_MemAbnormalFree(ptr, pstMem);	
		goto post;
	}
	
	ulSize =  (pstMem->ulOSMemBlkSize) * (pstMem->ulOSMemNBlks);
	ulLen = (UINT)ptr - (UINT)(pstMem->pOSMemAddr) - sizeof(VOID*);
	
	if(ulLen < 0 || ulLen >= ulSize || ulLen % (pstMem->ulOSMemBlkSize))
	{
		OS_HEAP_PANIC("can not free invalid address =%p, block size = %u, block start addr = %p\r\n", 
			      ptr, pstMem->ulOSMemBlkSize, pstMem->pOSMemAddr);
		goto post;
	}
	else
	{
		ptr = (UCHAR *)((UINT)ptr - sizeof(VOID*));			 
		if(OS_FreeMem(pstMem, ptr) != OS_HEAP_MEM_NO_ERR)
		{		
			OS_HEAP_PANIC("fail to free the size =%u memory block\r\n", pstMem->ulOSMemBlkSize);		
			goto post;
		}		
	}
	
 post:
	OS_EnableIntr(sr);
	return;
	
}

VOID * OS_Calloc(UINT ulNum, UINT ulSize)
{	
	VOID *ptr;
	UINT ulAllSize;
	
	ulAllSize = ulNum * ulSize;
	if(ulAllSize == 0)
	{
		return NULL;
	}
	
	if ((ptr = OS_Malloc(ulAllSize)) != NULL)
	{
		memset(ptr, 0, ulAllSize);		
	}
	else
	{
		/*reboot API*/
		OS_HEAP_PRINTF("fail to calloc,size = %u\r\n", ulAllSize);
		return 0;
	}
	
	return ptr;
}

VOID *OS_Realloc(VOID*pOld, UINT ulSize)
{
	VOID *pNew;
	UINT ulOldSize = 0;				/* old memory allocated size	*/
	OS_MEM_BLOCK_ST *pstMem;
	
/*
***only free the old memory block
*/
	if ( ulSize == 0 )  
	{
		pNew = NULL;		
		goto free_old;
	} 
	
/*
***get the information of the old block
*/
	if (pOld != NULL )
	{	
		pstMem = OS_GetMemBlock(pOld);
		if(pstMem == NULL)
		{
			OS_HEAP_PRINTF("In realloc it is not the valid memroy block,pointer = %p\r\n", pOld);
			return 0;
		}

		if(pstMem->ucLargeAlloc == OS_MALLOC_LARGE)
		{
			CHAR *strWorkPtr = pOld;

			strWorkPtr = strWorkPtr - sizeof(CHAR*) - sizeof(VOID*);
			ulOldSize = *((CHAR**)strWorkPtr) - strWorkPtr - sizeof(VOID*) - sizeof(CHAR*);
		}
		else
		{
			ulOldSize = pstMem->ulOSMemBlkSize -  sizeof(VOID*);	
		}
	}
	
/*
***whether it is necessary to alloc a new block 
*/
	if(ulOldSize < ulSize)
	{
		pNew = OS_Malloc(ulSize);

		if (pNew == NULL )
		{
			OS_HEAP_PRINTF("fail to realloc, size = %u\r\n", ulSize);
			goto free_old;
		}
		memcpy(pNew, pOld, (ulSize > ulOldSize ? ulOldSize : ulSize));	
	}
	else
	{
		pNew = pOld;
		goto end_of_realloc;
	}
	
 free_old:
	if ( pOld != NULL )
	{
		//OS_HEAP_PRINTF("from realloc go to free, pointer = %p\r\n", pOld);
		OS_Free(pOld);		
	}

 end_of_realloc:
	return pNew;

} 

/*
  static VOID OS_ShowNormalPool(OS_MEM_BLOCK_ST* pstMem)
  {
  UCHAR *pucBlock;
  UINT ulIndex;
	
  if(pstMem == NULL)
  {
  return;
  }	
       
  OS_HEAP_PRINTF("\r\nBeginning of memory partition = %p\r\nSize (in bytes) of each block of memory = %u\r\n", 
  pstMem->pOSMemAddr, pstMem->ulOSMemBlkSize);
  OS_HEAP_PRINTF("Total number of blocks in this partition = %u\r\nNumber of free blocks in this partition = %u\r\n",
  pstMem->ulOSMemNBlks, pstMem->ulOSMemNFree);
  OS_HEAP_PRINTF("Number of max used = %u\r\nThe start of free blocks = %p\r\nThe addr of the MCB = %p\r\n", 
  pstMem->ulOSMemMaxUsed, pstMem->pOSMemFreeList, pstMem);

  OS_HEAP_PRINTF("************all the blocks************:\r\n");

  pucBlock = (UCHAR*)(pstMem->pOSMemAddr);

  for(ulIndex = 0; ulIndex < pstMem->ulOSMemNBlks; ulIndex++)
  {
  if(*((VOID**)pucBlock) == pstMem)
  {
  OS_HEAP_PRINTF("The block addr = %p, the block is alloced\r\n", pucBlock);
  }
  else
  {
  OS_HEAP_PRINTF("The block addr = %p, the next block addr = %p\r\n", pucBlock, *((VOID**)pucBlock));
  }
		
  pucBlock = (UCHAR *)((UINT)pucBlock + pstMem->ulOSMemBlkSize);
		
  Pause(10);		
  }
	
  return;
  }

  static VOID OS_ShowNormalPools()
  {
  OS_MEM_BLOCK_ST* pstMem;
  UINT ulIndex, ulNum, ulTotal = 0, ulFree= 0;

  OS_HEAP_PRINTF("\r\n###################The normal partition is as follow###################:");
  OS_HEAP_PRINTF("\r\nNumber = %u\r\n", g_stOSMEM_MemCB.ulNum);	                                              

  for (ulNum = 0, ulIndex = 0; ulIndex < OS_NUM_HEAP_PARTS; ulIndex++)         
  {
  pstMem = g_stOSMEM_MemCB.pstParts[ulIndex];
  if(pstMem == NULL || pstMem->ucLargeAlloc == OS_MALLOC_LARGE)
  {
  continue;
  }
		
  OS_HEAP_PRINTF("*******************The satus of partition %u *******************:\r\n",ulNum + 1);
  OS_HEAP_PRINTF( "Beginning of memory partition = %p\r\nSize (in bytes) of each block of memory = %u\r\n", 
  pstMem->pOSMemAddr, pstMem->ulOSMemBlkSize);
  OS_HEAP_PRINTF("Total number of blocks in this partition = %u\r\nNumber of free blocks in this partition = %u\r\n",
  pstMem->ulOSMemNBlks, pstMem->ulOSMemNFree);
  OS_HEAP_PRINTF("Number of max used = %u\r\n", pstMem->ulOSMemMaxUsed);
  OS_HEAP_PRINTF("****************************************************************\r\n");
  ulNum++;
  ulTotal += pstMem->ulOSMemNBlks * pstMem->ulOSMemBlkSize;
  ulFree += pstMem->ulOSMemNFree * pstMem->ulOSMemBlkSize;
  }
	  
  OS_HEAP_PRINTF("*******************The summary of normal partitions*******************\r\n");
  OS_HEAP_PRINTF("The total size of normal partitions = %u\r\n", ulTotal);
  OS_HEAP_PRINTF("The free size of the normal partitions = %u\r\n", ulFree);
  OS_HEAP_PRINTF("The usage size of the normal partitions = %u\r\n", ulTotal - ulFree);
	  
  OS_HEAP_PRINTF("###############################################################\r\n");
  OS_HEAP_PRINTF("\r\n");
  return;
  }

  static VOID OS_ShowAbnormalPool()
  {
  OS_MEM_BLOCK_ST* pstMem;
  UINT  ulNum;
  CHAR *strWorkPtr, *strEndPtr;	
	
  OS_HEAP_PRINTF("###################Abnormal partition is as follow###################:");
  OS_HEAP_PRINTF("\r\nThe number of Abnormal partition = %u\r\n", g_stOSMEM_MemCB.ulLargeNum);
	 
  pstMem = g_stOSMEM_MemCB.pstLargeParts;
  ulNum = 0;	
	  
  while(pstMem != NULL)
  {
  OS_HEAP_PRINTF("*******************The satus of partition %u *******************:\r\n", ulNum + 1);
		
  if(pstMem->ucLargeAlloc == OS_MALLOC_LARGE)
  {
  OS_HEAP_PRINTF("Beginning of memory partition = %p\r\nTotal size (in bytes) of the large pool = %u\r\n", 
  pstMem->pOSMemAddr, pstMem->ulOSMemBlkSize);
  OS_HEAP_PRINTF("This partition is for large alloc\r\n");
  OS_HEAP_PRINTF("Total number of blocks in this pool(partition) = %u\r\n", pstMem->ulOSMemNBlks);	
  OS_HEAP_PRINTF("The available size = %u\r\n", 
  pstMem->ulAvailableSize > 8 ? pstMem->ulAvailableSize - 8 : 0);	
			
  strWorkPtr = (CHAR*)(pstMem->pOSMemAddr);
  strEndPtr = 
  (CHAR*)(pstMem->pOSMemAddr + pstMem->ulOSMemBlkSize - sizeof(CHAR*) - sizeof(VOID*));
			
  ulNum = 0;
			
  while(1)
  {
  UINT ulSize = (*((CHAR**)strWorkPtr) - strWorkPtr) - sizeof(CHAR*) - sizeof(VOID*);
  UINT ulSta = *((UINT*)(strWorkPtr + sizeof(CHAR*)));

  if(strWorkPtr == strEndPtr)
  {
  ulSize = 0;
  }
				
  ulNum++;
				
  OS_HEAP_PRINTF("-------------------The satus of block %u -------------------:\r\n", ulNum);
  OS_HEAP_PRINTF("Addr = %p, available size = %u, status =", strWorkPtr, ulSize);
				
  if(ulSta == (UINT)(pstMem) || ulSta == OS_LARGE_BLOCK_ALLOC)
  {
  OS_HEAP_PRINTF("allocated\r\n");
  }
  else if(ulSta == OS_LARGE_BLOCK_FREE)
  {
  OS_HEAP_PRINTF("free\r\n");
  }
  else
  {
  OS_HEAP_PRINTF("unknown\r\n");
  }

  OS_HEAP_PRINTF("---------------------------------------------------------------\r\n");
				
  if(strWorkPtr == strEndPtr)
  {
  break;
  }
				
  strWorkPtr = *((CHAR**)strWorkPtr);
  }
  }
  else
  {
  OS_HEAP_PRINTF("Beginning of memory partition = %p\r\nSize (in bytes) of the link block = %u\r\n", 
  pstMem->pOSMemAddr, pstMem->ulOSMemBlkSize);	

  OS_HEAP_PRINTF("This partition is for link alloc\r\n");
  OS_HEAP_PRINTF("Total number of blocks in this partition = %u\r\n", pstMem->ulOSMemNBlks);
  OS_HEAP_PRINTF("Number of memory blocks remaining in this partition = %u\r\n", pstMem->ulOSMemNFree);
  }
		
  pstMem = (OS_MEM_BLOCK_ST*)(pstMem->pOSMemFreeList);
  ulNum++;
  }
  OS_HEAP_PRINTF("################################################################\r\n");
  return;
  }
*/

INT32U OS_GetHeapTotalSize(void)
{
	OS_MEM_BLOCK_ST *pstMem = g_stOSMEM_MemCB.pstLargeParts;
	
	return pstMem->ulOSMemBlkSize;
}

INT32U OS_GetHeapAvaiSize(void)
{
	OS_MEM_BLOCK_ST *pstMem = g_stOSMEM_MemCB.pstLargeParts;
	
	return pstMem->ulAvailableSize;
}

unsigned char create_memblocks()
{
	return OS_CreateMemBlocks();
}

/*
  static VOID OS_ShowHeapStatus()
  {
  OS_MEM_BLOCK_ST *pstMem = g_stOSMEM_MemCB.pstLargeParts;
	
  #if !OS_HEAP_NOT_USE_LINK
  OS_ShowAbnormalPool();
  return;
  #endif

  OS_HEAP_PRINTF("\r\n###################Heap Status###################\r\n");

  OS_HEAP_PRINTF("Heap total size = %u bytes\r\n", pstMem->ulOSMemBlkSize);
		
  OS_HEAP_PRINTF("Heap usage = %u bytes\r\n", pstMem->ulOSMemBlkSize - pstMem->ulAvailableSize);
		
  OS_HEAP_PRINTF("Heap available size = %u\r\n", pstMem->ulAvailableSize);
	 
  //OS_HEAP_PRINTF("Heap max available block size = %u\r\n", pstMem->ulAvailableSize > 8 ? pstMem->ulAvailableSize - 8 : 0);
  OS_HEAP_PRINTF("Total number of blocks = %u\r\n", pstMem->ulOSMemNBlks);	
		
  OS_HEAP_PRINTF("The start address of heap = %p\r\n", pstMem->pOSMemAddr);
		
  OS_HEAP_PRINTF("The end address of heap = %p\r\n", pstMem->pOSMemAddr + pstMem->ulOSMemBlkSize);

  OS_HEAP_PRINTF("The first Heap available size == %u \r\n",Init_ulAvailableSize); 
  return;
	
  }

  static VOID OS_ShowMemBlocks(UCHAR ucFlag, UCHAR ucPoolIndex)
  {
  switch(ucFlag)
  {
  case 0:
  OS_ShowNormalPools();
  OS_ShowAbnormalPool();
  break;
            
  case 1:
  OS_ShowNormalPools();
  break;
            
  case 2:
  OS_ShowAbnormalPool();
  break;
            
  case 3:
  if(ucPoolIndex < OS_NUM_HEAP_PARTS)
  {
  OS_ShowNormalPool(g_stOSMEM_MemCB.pstParts[ucPoolIndex]);
  }
  else
  {
  OS_HEAP_PRINTF("The pool index:%u is out of the range[0-%u]\r\n", 
  ucPoolIndex, OS_NUM_HEAP_PARTS);
  }
  break;
            
  default:
  OS_HEAP_PRINTF("\r\nUsage:\r\n0:show all the blocks(normal and abnormal pools)\r\n");
  OS_HEAP_PRINTF("1:show  the blocks of all the normal pools\r\n2:show the blocks of abnormal pools\r\n");
  OS_HEAP_PRINTF("3:show the the blocks of the specify normal pool\r\n");
  break;
			
  }
	
  return;
		
  }
*/

#endif
