/*
*********************************************************************************************************
* Product:   Router
* CopyRight: Qingdao Eastsoft Computer Technology Co. Ltd.
*            All Rights Reserved
*
* File:      router.c
* Description: ·����Ӧ�ù��ܴ���������
*********************************************************************************************************
*/

#include "dev_ctrl.h"
#include "router.h"
#include "string.h"
#include "nwtask.h"

int hard_new = 1;

void sys_tick_hook(void)
{
  static unsigned int _tick_count = 0;
  static unsigned int second_tick = 0;

  if((unsigned int)(get_sys_tick() - _tick_count) >= SYS_TICK_INTERVAL)
  {
    if(++second_tick >= (1000 / SYS_TICK_INTERVAL))
    {
      second_tick = 0;
      rtc_second_tick_hook();
      update_sec_tick();  //��������ʱ�����������в��ϱ��¼������Զ�����
      ses_task_time_tick();
      ses_task_switch();

    //  nw_task_sec_tick();

    }

    set_to_add_ee_idle_time();
    uart_tick_hook(0x00);
    uart_tick_hook(0x01);
    uart_tick_hook(0x02);
    uart_tick_hook(0x03);
    uart_tick_hook(0x04);
	app_rt_test_tick();
    _tick_count += SYS_TICK_INTERVAL;

  }

  hard_new = is_hard_new();

  scan_to_recycle_flash();
}