#ifndef _DEV_ADAPTER_H_
#define _DEV_ADAPTER_H_


#pragma pack(1)

void sys_tick_hook(void);
void _free(void *ptr);
void *_malloc(int n);

#endif
