#include "stdio.h"
#include "stdlib.h"
#include "dev_ctrl.h"
#include "string.h"
#include "update.h"
#include "app.h"
#include "broad.h"
#include "rtpara.h"
#include "rt.h"
//#include "plcnl.h"
#include "setjmp.h"
#include "dev_adapter.h"
#include "nwtask.h"
#include <assert.h>
#include "../shell/shell.h"
#include "router.h"

/*************************************************************************************
* Variable Declaration:
**************************************************************************************/
struct _system_status system_status;   // ϵͳ״̬����
struct _plc_comm_para plc_comm_para;   // ϵͳ״̬����
struct _user_comm_para user_comm_para;   // ϵͳ״̬����

struct _dianchao_taskinfo dianchao_taskinfo;  // DM�㳭������Ϣ

extern unsigned int reset_times;
extern unsigned char reset_flag;
void timer10min()
{
  if (reset_times >= 2)
    reset_flag = 1;
  reset_times = 0;
  alloc_a_timer(TIMER_10_MIN, 60000, 60000, timer10min);
  
  fast_task_tick();
  node_rd_min_tick();
  Tno6TaskTimer();  /* 43ע����� */
}

int main()
{
  modules_init();
#ifdef UPDATE_STA
  upd_init();
#endif
  wdog_init();
  shell_init();
  printf_s("hello, world!\n");
//   enable_irq();
  //efs_format();
  rt_init();
  alloc_a_timer(TIMER_INIT_III, 3000, 3000, rt_sendmode);
  alloc_a_timer(TIMER_GDTASK_TICK, 1000, 1000, nw_task_sec_tick);
  alloc_a_timer(TIMER_10_MIN, 60000, 60000,timer10min);
  while(1)
  {
    sys_tick_hook();
    timers_event_deal();
    rt_autorun();
    watchdog();
  #ifdef UPDATE_STA
    upd_run();
  #endif
    shell_run();
  }
}

void __aeabi_assert(const char *expr, const char *file, int line)
{
  printf_s("%s: %d: Assertion %s\n", file, line, expr);
  
  return;//������Ҫִ�е�����
}