/*
*********************************************************************************************************
* Product:   Router
* CopyRight: Qingdao Eastsoft Computer Technology Co. Ltd.
*            All Rights Reserved
*  
* File:      router.c
* Description: ·����Ӧ�ù��ܴ���������
*********************************************************************************************************
*/

#include "dev_ctrl.h"
#include "comfunc.h"
#include "router.h"
#include "taskManager.h"
#include "dm_command.h"
#include "string.h"
#include "route_iv.h"
#include "task_iv.h"
#include "cycles.h"
#include "plc38_manage.h"
#include "data_item.h"
#include "dm_command_IV.h"

void  dm_dc_over();

unsigned int test_addr[] = {
  0x00000,
  0x00001,
  0x00002,
  0x00004,
  0x00008,
  0x00010,
  0x00020,
  0x00040,
  0x00080,
  0x00100,
  0x00200,
  0x00400,
  0x00800,
  0x01000,
  0x02000,
  0x04000,
  0x08000,
  0x10000,
  0x20000,
  0x40000,
  0x80000,
};


void backup_data(unsigned char buf[])
{
    unsigned int i = 0, t;
    
    while(i < (sizeof(test_addr) / sizeof(test_addr[0])))
    {
        t = test_addr[i];
        buf[2 * i] = *(unsigned char *)(0x60000000 + t);
        
        t = (~test_addr[i]) & 0xFFFFF;
        buf[2 * i + 1] = *(unsigned char *)(0x60000000 + t);       
        i++;
    }
}


void restore_data(unsigned char buf[])
{
    unsigned int i = 0, t;
    
    while(i < (sizeof(test_addr) / sizeof(test_addr[0])))
    {
        t = test_addr[i];
        *(unsigned char *)(0x60000000 + t) = buf[2 * i];
        
        t = (~test_addr[i]) & 0xFFFFF;
        *(unsigned char *)(0x60000000 + t) = buf[2 * i + 1];        
        i++;
    }
}




int test_psram_addr(void)
{
    unsigned char buf[0x100];
    unsigned int t, i = 0;
    
    backup_data(&buf[0]);

    while(i < (sizeof(test_addr) / sizeof(test_addr[0])))
    {
        t = test_addr[i] & 0xFFFFF;
        *(unsigned char *)(0x60000000 + t) = i;

        t = (~test_addr[i])&0xFFFFF;
        *(unsigned char *)(0x60000000 + t) = i;
        i++;
    }

    i = 0;

    while(i < (sizeof(test_addr) / sizeof(test_addr[0])))
    {
        t = test_addr[i] & 0xFFFFF;
        if(*(unsigned char *)(0x60000000 + t) != i)
        {
            restore_data(&buf[0]);
            return(-1);
        }

        t = (~test_addr[i])&0xFFFFF;
        if(*(unsigned char *)(0x60000000 + t) != i)  /* ��ǰ�ļ���ʱ���� */
        {
            restore_data(&buf[0]);
            return(-1);
        }

        i++;
    }

    restore_data(&buf[0]);
    return(0);  //ȫ��ͨ��
}

int test_psram_data(void)
{
    unsigned int i = 0, t, temp, bit;
    
    temp = *(volatile unsigned int *)0x60000000;

    while(i <= 0x10000)
    {
        if(0 == i)
        {
            bit = 0;
        }
        else
        {
            bit = (1<<(i - 1));
        }
        
        if(bit >= 0x10000)
        {
            break;
        }
        
        t = bit & 0xFFFFF;

        *(volatile unsigned int *)0x60000000 = t;

        if(*(volatile unsigned int *)0x60000000 != t)
        {
            *(volatile unsigned int *)0x60000000 = temp;
            return(-1);
        }

        t = (~bit)&0xFFFFF;
        *(volatile unsigned int *)0x60000000 = t;

        if(*(volatile unsigned int *)0x60000000 != t)
        {
            *(volatile unsigned int *)0x60000000 = temp;
            return(-1);
        }

        i++;
    }
    
    *(volatile unsigned int *)0x60000000 = temp;
    return(0);
}

int hard_test_router(void)
{
    int t = 0;

    if((test_psram_addr() < 0) || (test_psram_data() < 0))
    {
        t |= 0x01;
    }

    if(is_memory_eep() >= 0)
    {
        t |= 0x02;
    }

    return(t);
}



void frame_empty_send(void)
{
    unsigned char buf[0x40], app_type;
    struct frame698_42 *pframe = (struct frame698_42 *)&buf[0];
    struct app_data_698 *papp = (struct app_data_698 *)&pframe->user_data[6 + 12];	
    struct info_up_698 *pinfo = (struct info_up_698 *)&pframe->user_data[0];

    memset(&buf[0], 0x00, sizeof(buf));
    set_frame_head(pframe, dianchao_taskinfo.ccw);
    set_info_default((unsigned char *)&pframe->user_data[0], dianchao_taskinfo.ccw, 0);
    set_info_frame_sno((unsigned char *)&pframe->user_data[0], dianchao_taskinfo.sno);
    pinfo->com_module = 1;
	
    app_type = dianchao_taskinfo.apptype;

    if(0x01 == dianchao_taskinfo.ccw)
    {
        pframe->user_data[0] = dianchao_taskinfo.depth;

        if(is_protocol_edit() >= 0)
        {
            app_type = 0;
        }
    }

    memcpy(&pframe->user_data[6], &dianchao_taskinfo.meter_id[0], 6);
    get_jzq_address(&pframe->user_data[12]);
    bin_to_bcd(&pframe->user_data[6], 12);

    papp->afn = dianchao_taskinfo.afn;
    papp->data_type[0] = dianchao_taskinfo.dt[0];
    papp->data_type[1] = dianchao_taskinfo.dt[1];

    papp->data_unit[0] = app_type;
    papp->data_unit[1] = 0;

    if((0x13 == papp->afn) && dianchao_taskinfo.ver_new)
    {
        papp->data_unit[0] = 0;
        papp->data_unit[1] = 0;
        papp->data_unit[2] = app_type;
        papp->data_unit[3] = 0;
        set_frame_tail(pframe, FRMAE_DEFAULT_LEN + 12 + 4);
    }
    else
    {
        set_frame_tail(pframe, FRMAE_DEFAULT_LEN + 12 + 2);
    }

    send_data_to_dm(&buf[0], pframe->length);
}

/******************************************************************************* 
*   ����������DM����ĵ㳭����ʱ��:��DM���ͷ���֡
*   ����˵��: ����698.42��ת������/�ӽڵ����
*   �������⣺698.42��ת������û��ָ������ʧ�ܺ��Ӧ��֡.
*******************************************************************************/ 
void  dm_dc_timeout()
{
    unsigned int method;
    // �����㳭����
    dm_dc_over();

    if(get_left_plc_send_phase() != 0)
    {
        return;
    }

    if((0x01 == dianchao_taskinfo.ccw) && (0x04 == dianchao_taskinfo.afn))
    {
        // ��DM���ͷ���֡����ʱ��
        frame_negate_sno_send(1, E_OVER_TIME, dianchao_taskinfo.sno);
    }
    else
    {
        //�ظ�����Ϊ0�ı���
	 frame_empty_send();
     if(0 == dianchao_taskinfo.fail_proc)
     {
         return;   //�����һ������ 
     }
	     //�Ĵ�ģʽ�£�ʹ�ü�����ʧ�ܽ��ڵ����ȼ�1
	     //��������ת���Ȳ����˴���
	     if((0x01 == dianchao_taskinfo.ccw) && (0x13 == dianchao_taskinfo.afn) && (0x01 == dianchao_taskinfo.dt[0]))
	     {
             method = get_p2p_task_method();
             rt_set_node_fail(&dianchao_taskinfo.meter_id[0], method, 0);
	     }

	    if((0x07 == dianchao_taskinfo.ccw) && (0x01 == dianchao_taskinfo.afn) && (0x04 == dianchao_taskinfo.dt[0]))
	    {
            // ��չģʽ�㳭ʧ�ܣ���ȼ�1
             method = get_p2p_task_method();
             rt_set_node_fail(&dianchao_taskinfo.meter_id[0], method, 0);
	    }
	 
    }

    set_protocol_edit(0);
}



#define RT_CTRL_ASWTCH   0x01
#define RT_CTRL_VDTCT    0x02

struct {
    unsigned char last_sno;
    unsigned char afn;
    unsigned short dt;
    unsigned char sum;

    unsigned char cnt;
    unsigned char s_cnt;
    unsigned char checking;
} rt_ver_info;

//ֹͣ�汾�����յ����޸�ǣ������֡
void set_rt_ver_check_over(void)
{
     rt_ver_info.checking = 0;
}

int is_rt_in_ver_checking(void)
{
    if(rt_ver_info.checking)
    {
        return(0);
    }

    return(-1);
}

extern unsigned int flag_rt_set_mode_fixed_mode;
void rt_set_mode_fixed(int i)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(0 == i)
    {
        if(t & RT_CTRL_ASWTCH)
        {
            return;
        }

        t |= RT_CTRL_ASWTCH;
    }
    else
    {
        if(0 == (t & RT_CTRL_ASWTCH))
        {
            return;
        }

        t &= ~RT_CTRL_ASWTCH;
    }

    eep_set(e2rom_addr(rt_ctrl), t, 1);
    
    flag_rt_set_mode_fixed_mode++;
}

int is_rt_mode_fixed(void)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(t & RT_CTRL_ASWTCH)
    {
        return(-1);
    }
    else
    {
        return(0);
    }
}
#if 0
void rt_set_ver_detect(int i)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(i)
    {
        if(t & RT_CTRL_VDTCT)
        {
            return;
        }

        t |= RT_CTRL_VDTCT;
    }
    else
    {
        if(0 == (t & RT_CTRL_VDTCT))   //�汾���ɱ�
        {
            return;
        }

        t &= ~RT_CTRL_VDTCT;
    }

    eep_set(e2rom_addr(rt_ctrl), t, 1);
}
#endif
unsigned char rt_get_ver_detect_para(void)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(t & RT_CTRL_VDTCT)
    {
        return(0x03);
    }

    if(RT_VER_NEW == system_status.rt_ver)
    {
        return(0x02);
    }

    return(0x01);
}




//����ccwΪ1������Ϊ����վ
//���߿��ԱȶԿ�ʼ����������ʶ�����̵ķ��ϳ̶�
void check_rt_ver(unsigned char afn, unsigned short dt, unsigned char sno, unsigned char sum)
{
    if(0 == rt_ver_info.checking)
    {
        return;
    }

    if((rt_ver_info.afn == afn) && (dt == rt_ver_info.dt) && (sum == rt_ver_info.sum))
    {
        return;  //�˵��������ط��Ĳ���
    }

    rt_ver_info.afn = afn;
    rt_ver_info.dt = dt;
    rt_ver_info.sum = sum;

    if(0 == rt_ver_info.cnt)
    {
        rt_ver_info.last_sno = sno;  //��һ��
    }

    rt_ver_info.cnt++;

    if(sno == rt_ver_info.last_sno)
    {
        rt_ver_info.s_cnt++;
    }
    else
    {
        rt_ver_info.s_cnt = 0;
    }

    rt_ver_info.last_sno = sno;

    if(rt_ver_info.cnt < 3)
    {
        return;
    }

    rt_ver_info.checking = 0;
    if(rt_ver_info.s_cnt >= 3)
    {
        rt_set_version(RT_VER_OLD);
        //check_to_reset_to_mode_iii(0);
    }
}

void rt_set_raw_version(unsigned char ver)
{
#if 0
    if(ver != system_status.rt_ver)
    {
        system_status.rt_ver = ver;
        eep_set(e2rom_addr(version), ver, 1);
    }
#endif
}

void rt_set_version(unsigned char ver)
{
    rt_ver_info.checking = 0;  //�Զ�ʶ�����

    if(eep_get(e2rom_addr(rt_ctrl)) & RT_CTRL_VDTCT)
    {
        rt_set_raw_version(ver);
    }
}

/******************************************************************************* 
����������DM����ĵ㳭���������ʱʧ��ʱ�������㳭����
*******************************************************************************/ 
void  dm_dc_over()
{    
    // ����㳭����״̬
    system_status.dm_dc_status = 0;
    del_a_timer( TIMER_DM_DC );
    //router����㳭�Ĵ�������ʧ�ܱ�״̬ 

    // �������б��Ľ���
    set_rts_value(CHN_38_1, 1);       
    clr_plc_extra_time();

    clr_data_item_send();
}


