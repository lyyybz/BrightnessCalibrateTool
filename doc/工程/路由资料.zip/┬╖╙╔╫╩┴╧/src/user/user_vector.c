/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : stm32f10x_vector.c
* Author             : MCD Application Team
* Version            : V1.1.1
* Date               : 06/13/2008
* Description        : STM32F10x vector table for EWARM5.x toolchain.
*                      This module performs:
*                      - Set the initial SP
*                      - Set the initial PC == __iar_program_start,
*                      - Set the vector table entries with the exceptions ISR address,
*                      - Configure external SRAM mounted on STM3210E-EVAL board
*                       to be used as data memory (optional, to be enabled by user)
*                      After Reset the Cortex-M3 processor is in Thread mode,
*                      priority is Privileged, and the Stack is set to Main.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "router.h"

/* Private typedef -----------------------------------------------------------*/
typedef void( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

/* Private define ------------------------------------------------------------*/
/* Uncomment the following line if you need to use external SRAM mounted on
   STM3210E-EVAL board as data memory */
/* #define DATA_IN_ExtSRAM */

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


#pragma language=extended
#pragma segment="CSTACK"


void __iar_program_start( void );

#pragma location = ".intvec"
/* STM32F10x Vector Table entries */
const intvec_elem __vector_table[] =
{
  { .__ptr = __sfe( "CSTACK" ) },
  __iar_program_start,
  0,
  0,
  0,
  0,
  0,
  (intfunc)0x0003,       /* support RTB-III-E and RTB-IV bootloader*/
  0, 
  0, 
  0,            /* Reserved */ 
  0,
  0,
  0,                      /* Reserved */
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0, 
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  (intfunc)0xffffffff,//4 * 76
  (intfunc)0xffffffff,//4 * 77
  (intfunc)0xffffffff,//4 * 78
  (intfunc)0xffffffff,//4 * 79
  (intfunc)0xffffffff,//4 * 80
  (intfunc)0xffffffff,//4 * 81
  (intfunc)0xffffffff,//4 * 82
  (intfunc)0xffffffff,//4 * 83
  (intfunc)0xffffffff,//4 * 84
  (intfunc)0xffffffff,//4 * 85
  (intfunc)0xffffffff,//4 * 86  
  (intfunc)0xffffffff,//4 * 87 
  (intfunc)0xffffffff,//4 * 88 
  (intfunc)0xffffffff,//4 * 89 
  (intfunc)0xffffffff,//4 * 84
  (intfunc)0xffffffff,//4 * 85
  (intfunc)0xffffffff,//4 * 86  
  (intfunc)0xffffffff,//4 * 87 
  (intfunc)0xffffffff,//4 * 88 
  (intfunc)0xffffffff,//4 * 89 
  
  (intfunc)0x00000001,//4 * 90 ������
  (intfunc)0x00000001,//4 * 91   �汾
  (intfunc)0xffffffff,//4 * 98 
  (intfunc)0xffffffff,//4 * 99 
  (intfunc)0xffffffff,//4 * 100 , 0x08004190, ��������д��־
  (intfunc)0xffffffff,//4 * 101 , 0x08004194, ������У��
  (intfunc)0xffffffff,//4 * 102 , 0x08004198, ������ĩ�˵�ַ
  (intfunc)RT_VERSION,//4 * 103 , 0x0800419c, ������汾��
  (intfunc)_COMP_YEAR,//4 * 104 
  (intfunc)_COMP_MON, //4 * 105 
  (intfunc)_COMP_DAY, //4 * 106 
  (intfunc)RT_VERDATA,//4 * 107 
  (intfunc)0xffffffff,//4 * 108 
  (intfunc)0xffffffff,//4 * 109 
  (intfunc)0xffffffff,//4 * 110 
};

//#ifdef DATA_IN_ExtSRAM
#pragma language=extended

__interwork int __low_level_init(void);

#pragma location="ICODE"
__interwork int __low_level_init(void)
{
  return (1);
}
//#endif /*DATA_IN_ExtSRAM*/

/******************* (C) COPYRIGHT 2008 STMicroelectronics *****END OF FILE****/


