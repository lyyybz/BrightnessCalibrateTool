/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: uart.c
 *
 * Description: General UART control module
 *
 * Version: v1.0
 * Time:    2009-12-11
 *
 */

#include "../include/tool/ague.h"
#include "../include/dev/uart.h"

#ifdef _LINUXPC
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>


static int spd[] = {B38400, B19200, B9600, B4800, B2400, B1200, B600, B300};
static int spdname[] = {38400, 19200, 9600, 4800, 2400, 1200, 600, 300};

static int setspd(int fd, size_t baudrate);
static int setattr(int fd,size_t databits, size_t stopbits, unsigned char parity);
#else
#include "dev_ctrl.h"
#endif

int uart_open(size_t uartno, size_t baudrate, size_t databits, size_t stopbits, 
	      unsigned char parity)
{
#ifdef _LINUXPC
  int  fd;
  char dev[20];
  
  sprintf(dev, "/dev/ttyS%d", uartno - 1);
  if ((fd = open(dev, O_RDWR)) == -1)
    return -1;

  if (setspd(fd, baudrate) != 0)
      return -1;
  if (setattr(fd, databits, stopbits, parity) != 0)
      return -1;
  
   return fd;
#else
   return 0;
#endif
}

size_t uart_read(int fd, unsigned char *buff, size_t rbytes)
{
  assert(buff);
  
#ifdef _LINUXPC
  return read(fd, buff, rbytes);
#else
  return sys_uart_read(fd, buff, rbytes);
#endif
}

size_t uart_write(int fd, unsigned char *buff, size_t wbytes)
{
  assert(buff);
  
#ifdef _LINUXPC 
  return write(fd, buff, wbytes);
#else
  return sys_uart_write(fd, buff, wbytes);
#endif
}

int uart_close(int fd)
{
#ifdef _LINUXPC 
  return close(fd);
#else
  return 0;
#endif
}

#ifdef _LINUXPC 
static int setspd(int fd, size_t baudrate)
{
  struct termios term;

  if (tcgetattr(fd, &term) != 0)
    return -1;
  for (size_t i = 0, j = sizeof(spdname) / sizeof(spdname[0]); i < j; ++i)
    {
      if (spdname[i] == baudrate)
	{
	  cfsetispeed(&term, spd[i]);
	  cfsetospeed(&term, spd[i]);
	  if (tcsetattr(fd, TCSAFLUSH, &term) != 0)
	    return -1;
	  return 0;
	}
    }

  return -1;
}

static int setattr(int fd, size_t databits, size_t stopbits, unsigned char parity)
{
  struct termios term;

  if (tcgetattr(fd, &term) != 0)
      return -1;

  term.c_cflag &= ~CSIZE;
  term.c_cflag |= CLOCAL | CREAD;
  term.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  term.c_oflag &= ~OPOST;
  term.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
  
  switch (databits)
    {
    case 5:
      term.c_cflag |= CS5;
      break;
    case 6:
      term.c_cflag |= CS6;
      break;
    case 7:
      term.c_cflag |= CS7;
      break;
    case 8:
      term.c_cflag |= CS8;
      break;
    default:
      return -1;
    }
  
  switch (parity)
    {
    case 'n':
    case 'N':
      term.c_iflag &= ~INPCK;
      term.c_cflag &= ~PARENB;
      break;
    case 'o':
    case 'O':
      term.c_iflag |= INPCK;
      term.c_cflag |= PARENB;
      term.c_cflag |= PARODD;
      break;
    case 'e':
    case 'E':
      term.c_iflag |= INPCK;
      term.c_cflag |= PARENB;
      term.c_cflag &= ~PARODD;
      break;
    default:
      return -1;
    }

  switch (stopbits)
    {
    case 1:
      term.c_cflag &= ~CSTOPB;
      break;
    case 2:
      term.c_cflag |= CSTOPB;
      break;
    default:
      return -1;
    }

  term.c_cc[VTIME] = 0;
  term.c_cc[VMIN]  = 0;
  
  if (tcsetattr(fd, TCSAFLUSH, &term) != 0)
    return -1;

  return 0;
}
#endif


#ifdef _LINUXPC 

void mdelay(unsigned int m)
{

}

unsigned int get_cts_value(unsigned int chn)
{
  return 0;
}

void set_rts_value(unsigned int chn, unsigned int value)
{

}

#endif

