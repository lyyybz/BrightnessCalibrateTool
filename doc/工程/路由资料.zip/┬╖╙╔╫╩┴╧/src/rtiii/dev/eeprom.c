/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: eeprom.c
 *
 * Description: eeprom driver
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#include "../include/tool/ague.h"
#include "../include/dev/eeprom.h"

#ifdef _LINUXPC

#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#else

#include "dev_ctrl.h"

#endif 

#ifdef _LINUXPC

static int fd;

#endif

void eeprom_init()
{
#ifdef _LINUXPC
    
  if((fd = open(EEPROM, O_RDWR)) == -1)
    {
      fd = open(EEPROM, O_RDWR | O_CREAT,S_IRUSR | S_IWUSR);
      assert(fd != -1);
      for(int i = 0, n = 0, c = 0; i < (0x10000 / 4); ++i)
	{
	  n = write(fd, &c, sizeof(c));
	  assert(sizeof(c) == n );
	}      
    }
#else
  //efs_mount();
#endif
}

size_t eeprom_read(ADDRESS addr, unsigned char *src, size_t rbytes)
{
#ifdef _LINUXPC
  
  size_t ret;
  
  lseek(fd, (off_t)addr, SEEK_SET); 
  ret = read(fd, src, rbytes);
  assert(ret == rbytes);
  
  return ret;
  
#else
  
  return ee_read_flash(addr, src,rbytes);
  
#endif

}

size_t eeprom_write(ADDRESS addr, unsigned char *dest, size_t wbytes)
{
#ifdef _LINUXPC
  
  size_t ret;
  
  lseek(fd, (off_t)addr, SEEK_SET);
  ret = write(fd, dest, wbytes);
  assert(ret == wbytes);
  
  return ret;
  
#else
  
  ee_write_flash(addr, dest, wbytes);
  
  return wbytes;
#endif
}




