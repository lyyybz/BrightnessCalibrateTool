/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: toolfun.c
 *
 * Description: Tool functions kit
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"

#ifdef _LINUXPC
#include <time.h>
#endif

#define YEAR_21CENT_BEGIN 2000
#define TM_YEAR_BEGIN     1900
#define TM_MONTH_BEGIN    1

size_t atobcd(const char *src, size_t alen, unsigned char *dest)
{
  assert(src);
  assert(dest);

  if (alen == 0)
    alen = strlen(src);
  if (alen == 0)
    return 0;
  
  size_t bcdlen = 0;
  for (size_t i = 0; i < alen; i += 2)
    {
      if (src[i] - 0x41 < 0)   /* high byte is a digit */
	{
	  if (src[i + 1] - 0x41 < 0)  
	    dest[bcdlen++] = ((src[i] - 0x30) << 4) | (src[i + 1]  - 0x30);
	  else
	    dest[bcdlen++] = ((src[i] - 0x30) << 4) | (src[i + 1]  - 0x37);
	}
      else   /* high byte is a character */
	{
	  if (src[i + 1] - 0x41 < 0)
	    dest[bcdlen++] = ((src[i] - 0x37) << 4) | (src[i + 1] - 0x30);
	  else
	    dest[bcdlen++] = ((src[i] - 0x37) << 4) | (src[i + 1] - 0x37);
	}
    }

  return bcdlen;
}

size_t bcdtoa(const unsigned char *src, size_t bcdlen, char *dest)
{
  assert(src && dest);

  size_t alen = 0;
  for (size_t i = 0; i < bcdlen; ++i)
    {
      if (src[i] / 16 < 10)   /* high byte is digit */
	{
	  dest[alen++] = src[i] / 16 + 0x30;
	  if (src[i] % 16 < 10)
	    dest[alen++] = src[i] % 16 + 0x30;
	  else
	    dest[alen++] = src[i] % 16 + 0x37;
	}
      else   /* low byte is character*/
	{
	  dest[alen++] = src[i] / 16 + 0x37;
	  if (src[i] % 16 < 10)
	    dest[alen++] = src[i] % 16 + 0x30;
	  else
	    dest[alen++] = src[i] % 16 + 0x37;
	}
    }
  dest[alen] = 0;

  return alen;
}

void reverse(unsigned char * buff, size_t bufflen)
{
  assert(buff);
  
  unsigned char *rp = buff + bufflen - 1;
  while (rp > buff)
    swap(rp--, buff++);
}

void swap(unsigned char *c1, unsigned char *c2)
{
  assert(c1 && c2);

  *c1 ^= *c2;
  *c2  = *c1 ^ *c2;
  *c1 ^= *c2;  
}

void getbcdtm(unsigned char *buff)
{
  assert(buff);

#ifdef _LINUXPC

  unsigned char   tmp[15];
  time_t t = time(NULL);
  struct tm *ltm = localtime(&t);

  sprintf(tmp, "%04d%02d%02d%02d%02d%02d", ltm->tm_year + TM_YEAR_BEGIN, 
	  ltm->tm_mon + TM_MONTH_BEGIN, ltm->tm_mday, ltm->tm_hour, 
	  ltm->tm_min, ltm->tm_sec);
  memmove(tmp, tmp + 2, 12);
  tmp[12] = 0;
  atobcd(tmp, strlen(tmp), buff);
  
#endif

}

int setbcdtm(const unsigned char *buf)
{
#ifdef _LINUXPC
  
  

#endif
  return 0;
}

time_t getcurrtime()
{
#ifdef _LINUXPC
  
  struct tm *ltm;
  time_t t = time(NULL);
  ltm = localtime(&t);
  
  ltm->tm_year = 1981 - TM_YEAR_BEGIN;
  ltm->tm_mon  = 0;
  ltm->tm_mday = 29;

  return mktime(ltm);

#endif

  return 0;
}

time_t gettime(size_t hour, size_t min)
{
  assert(0 <= hour && hour < 24);
  assert(0 <= min && min < 60);

#ifdef _LINUXPC

  time_t t = time(NULL);
  struct tm *ltm = localtime(&t);
  
  ltm->tm_year = 1981 - TM_YEAR_BEGIN;
  ltm->tm_mon  = 0;
  ltm->tm_mday = 29;
  ltm->tm_hour = hour;
  ltm->tm_min  = min;
  ltm->tm_sec  = 0;
 
  return mktime(ltm);

#endif

  return 0;
}

void id_bcdtobin(unsigned char id[])
{
  int i;
  for (i = 0;i < 6; ++i)
    id[i] = bcdtobin(id[i]);
  reverse(id, 6);
}

void id_bintobcd(unsigned char id[])
{
  int i;
  for (i = 0;i < 6; ++i)
    id[i] = bintobcd(id[i]);
  reverse(id, 6);
}

/*
    FUNCTION:           check sum caculate
    FUNCTION NAME:      checksum
 */
unsigned char checksum (const unsigned char *data, int len)
{
    unsigned char cs = 0;

    while( len-- > 0 )
        cs += *data++;
    return(cs);
}

/*
    FUNCTION:           check xor caculate
    FUNCTION NAME:      checkxor
 */
unsigned char checkxor (const unsigned char *data, int len)
{
    unsigned char cs = 0;

    while( len-- > 0 )
        cs ^= *data++;
    return(cs);
}

void bcd_to_bin(unsigned char s[], unsigned int len)
{
    if(0 == len) 
    {
        return;
    }

    while(len--) 
    {
        s[len] = BCD2BIN(s[len]);
    }
}

void bin_to_bcd(unsigned char s[], unsigned int len)
{
    if(0 == len) 
    {
        return;
    }

    while(len--) 
    {
        s[len] = BIN2BCD(s[len]);
    }
}

void order_reverse(void *buff,  int len)
{
 
    unsigned char *rearp = (unsigned char*)buff + len - 1;
    unsigned char *headp = (unsigned char *)buff;
    unsigned char tmp;

    if( len < 0x01 ) return;
    while( headp < rearp )
    {
        tmp = *headp;
        *headp++ = *rearp;
        *rearp-- = tmp;
    }
 
}


/************************************************************************************************
*	����˵��:  ���Meter��ID�Ƿ�㲥��ַ
*
*	�������:   meter_id --  ��Ҫ���ı���ID(BCD��)
*	����ֵ:	    0: ��ʾIDΪ�ǹ㲥��ַ,                   
*                   1: ��ʾIDΪ�㲥��ַ(0x99/0xAA)
************************************************************************************************/
int MeterID_IsBroadcast(unsigned char meter_id[])
{
    int i;
    for(i=1; i<6; i++)
    {
        if(meter_id[i]!=meter_id[i-1]) return 0;
    }
    if(meter_id[0] == 0x99 || meter_id[0]==0xAA || meter_id[0] == 0x00)  return 1;    
    return 0;
}