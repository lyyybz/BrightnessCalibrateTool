/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: debug.c
 *
 * Description: Some debug functions
 *              Function working when macro "_DEBUG" had defined
 *              All print info output into stderr because of stderr no input buffer
 *
 * Version: v1.0
 * Time:    2009-12-01
 */

#include <stdarg.h>
#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/tool/debug.h"
#include "../include/dev/uart.h"

//static char asci[] = {0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
//                      0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x20};

void dbg_prtcmd(const char *title, const unsigned char *cmd, size_t cmdlen)
{
#ifdef _LINUXPC
#ifdef _DEBUG
  
  unsigned char tm[6];
  assert(cmd);

  if (title)
    fprintf(stderr, "%s ", title);
  getbcdtm(tm);
  for (size_t i = 3; i < 6; ++i)
    fprintf(stderr, "%02X", tm[i]);
  fprintf(stderr, " ");
  for (size_t i = 0; i < cmdlen; ++i)
    fprintf(stderr, "%02X ", cmd[i]);
  fprintf(stderr, "\n");

#endif
#endif
}

void dbg_printf(const char *fmt, ...)
{
#ifdef _DEBUG
#ifndef _LINUXPC
    va_list ap;
    char *s;
    int  len = 0;
    char d, dx, buf[1024];

    va_start(ap, fmt);
    while (*fmt)
    {
        if (*fmt != '%')
        {
          buf[len++] = *fmt++;
          continue;
        }
        if(*fmt == '%')
        {
           switch (*++fmt)
            {
            case 's':
                s = va_arg(ap, char *);
                for ( ; *s; s++) 
                {
                  d = buf[len];
                  buf[len++] = *s;
                }
                len -= 1;
                break;
            case 'd':
                d = va_arg(ap, int);
                if(d < 10)
                buf[len++] = asci[d];
                else
                {
                  dx = d >> 4;
                  buf[len++] = asci[dx];
                  dx = d & 0x0F;
                  buf[len++] = asci[dx];
                }
                break;
            case 'x':
            case 'X':
                d = va_arg(ap, int);
                buf[len++] = asci[0];
                buf[len++] = 'X';
                if(d < 0x10)
                {
                  buf[len++] = asci[0];
                  buf[len++] = asci[d];
                }
                else
                {
                  dx = d >> 4;
                  buf[len++] = asci[dx];
                  dx = d & 0x0F;
                  buf[len++] = asci[dx];
                }
                break;       
            default:  
               buf[len++] = *fmt++;
                break;
           }
        }   
        fmt++;
    }
    va_end(ap);
    buf[len++] = asci[16];//space
    dbg_putdev(buf,len);
#else
    
    va_list args;

    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
    
#endif
#endif
}


