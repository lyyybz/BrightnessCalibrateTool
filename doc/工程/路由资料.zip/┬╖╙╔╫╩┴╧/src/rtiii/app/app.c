/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: app.c
 *
 * Description: Abstract layer between router and application.
 *
 * Version: v1.0
 * Time:    2010-1-28
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/app/apprt.h"
#include "../include/app/appgb.h"
#include "../include/app/app.h"
#include "../include/rt/rtpara.h"
#include "../include/app/nwtask.h"
#define PRTCL_RT 0x01 /* rt protocol */
#define PRTCL_GB 0x02 /* GB376.2 protocol */


unsigned char get_apptype();
int set_apptype(unsigned char apptype);

int app_cfm()
{
  if (get_apptype() == (unsigned char)PRTCL_RT)
    return apprt_sendack();

  if (get_apptype() == (unsigned char)PRTCL_GB)
    return appgb_cfm(0);

  return -1;
}

int app_data(unsigned char *mid, unsigned char *data, int datalen,unsigned char pro, unsigned char event)
{
  assert(mid);
  assert(data);

  return nw_report_data(TASK_EXE_RT, mid, pro,data, datalen);

}

int app_warnup_new(unsigned char *mid, unsigned char *data, int datalen)
{
  assert(mid);
  assert(data);

  // return appgb_data_new(mid, data, datalen, 0);
  return nw_report_event_new(mid, data, datalen, 0);
}

int app_warnup(unsigned char *mid, unsigned char *data, int datalen)
{
  assert(mid);
  assert(data);

  return 0;
#if 0
  if (get_apptype() == (unsigned char)PRTCL_GB)
  {
    if (_share.version == NEW_GBPRO)
    {
      _rtparas.dlytm |= 0x02;
      _task.appd.dlytm = 0;
    }
    else
      _rtparas.dlytm &= ~0x02;
    return appgb_data(mid, data, datalen, 0);
  }

  if (get_apptype() == (unsigned char)PRTCL_RT)
    return apprt_report(mid, data, datalen);
#endif
  //return -1;
}

int app_regup_new(unsigned char *mtid, unsigned char *cid, unsigned char pro)
{
    assert(mtid);
//    int nw_report_node_new(unsigned char *mtid, unsigned char *cid, unsigned char pro)

    return nw_report_node_new(mtid, cid, pro);

}

int app_regup(unsigned char *mid)
{
  assert(mid);

  return 0;
  #if 0
  if (get_apptype() == (unsigned char)PRTCL_GB)
    return appgb_regup(mid);

  if (get_apptype() == (unsigned char)PRTCL_RT)
    return apprt_report(mid, NULL, 0);

  return -1;
  #endif
}

int app_res(unsigned char *data, int datalen)
{
  if (datalen > 0)
    assert(data);

  if (get_apptype() == PRTCL_RT)
    return apprt_res(RTFTRESPONSE, data, datalen);
  if (get_apptype() == PRTCL_GB)
    return appgb_cfm(2);

  return -1;
}

int app_gbbroad_over()
{
    unsigned int tid;
    unsigned char aid[6];

    tid = get_nw_task_id(TASK_EXE_HIGH);
    get_nw_task_appid(TASK_EXE_HIGH, aid);
    nw_report_task_state(tid, aid, TASK_STATUS_SUC);

    del_cur_task(TASK_EXE_HIGH);

    return 0;
}
int app_gbcomm(unsigned char *mtid, unsigned char pro, unsigned char *data, int datalen)
{
    unsigned char errbuf1[] = { 0xC0, 0x01 }, errbuf2[] = { 0xC0, 0x02 }, errbuf3[] = { 0xC0, 0x03 };

    int ret = 0;
    if (0 == memcmp(data, errbuf1, 2)
        || 0 == memcmp(data, errbuf2, 2)
        || 0 == memcmp(data, errbuf3, 2))
    {
        data = NULL;
    }
#if 0
  unsigned char ctemp = 0xF11;
  send_uart_data_blocking(CHN_DM,&ctemp,1);
  send_uart_data_blocking(CHN_DM, data,datalen);
#endif

    if (data == NULL)
    {

      ret = report_task_fail(mtid, TASK_EXE_HIGH, TASK_STATUS_NO_RES);
    }
    else
    {

       ret = nw_report_data(TASK_EXE_HIGH, mtid, pro, data, datalen);
    }


    if (ret >= 0)
    {
        del_cur_task(TASK_EXE_HIGH);
    }
    else
    {
        init_nw_cur_task(TASK_EXE_HIGH);//С��0��˵�����Ų��ԣ�ֻ�������ִ�е����񣬵���ɾ������
    }

    //return appgb_comm_data(mtid, pro, data, datalen);
    return 0;
}

int app_info(unsigned char *data, int datalen)
{
  assert(data);

  if (get_apptype() == PRTCL_RT)
  {
    if (datalen != 1)
      return -1;
    apprt_info(*data);
  }

  return -1;
}

int app_err(unsigned char *data, int datalen)
{
  assert(data);

  if (get_apptype() == PRTCL_RT)
  {
    if (datalen != 1)
      return -1;
    return apprt_err(*data);
  }
  else
    if (get_apptype() == PRTCL_GB)
    {
      if (datalen != 1)
        return -1;
      return appgb_deny(*data);
    }

  return -1;
}

int app_request(unsigned char type, unsigned char cnt, unsigned char *mt)
{


  switch (type)
  {
  case RQBRDC:
    return appgb_reqbrd();
  case RQMNTC:
    assert(mt);
    return appgb_reqdata(mt);
  //case RQDLYTM:
  //  return appgb_reqdlytm(mt);
  }
  return -1;
}

int app_pwd()
{
  unsigned char pwdwmode;
  pwdwmode = apprt_get_pwdwmode();

  if (pwdwmode == RTSSUCC)
    return 0;
  else
    return -1;
}

int app_decode(unsigned char *frame, int len)
{
  int del;
  unsigned char  frm[0x200];

  //  unsigned char  buf[5] = { 0x11, 0x22, 0x33, 0x44, 0x55 };
  // rf_write(frame, len, 2);
  del = 0;
  len = app_frm_check(frame, len, frm, &del);

  if (len > 0)
    app_frm_decode(frm);

  return del;

}




