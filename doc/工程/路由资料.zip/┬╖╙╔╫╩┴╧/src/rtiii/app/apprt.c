/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: apprt.c
 *
 * Description:  Implementation of Route Application between Router and DM.
 *
 * Version: v1.0
 * Time:    2010-1-22
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/rt/rtfuns.h"
#include "../include/rt/rterrs.h"
#include "../include/app/apprt.h"

#define RTSTART 0x7E
#define RTDATAPOS  0x02   /* Data start position */
#define RTLENPOS   0x01   /* The location of frame length */
#define RTSUMPOS(flen) ((flen) - 2)   /* The location of sum verify */
#define RTXORPOS(flen) ((flen) - 1)   /* The location of xor verify */
#define RTFMINSIZE  0x04   /* Minimum number of a frame to be parsed correct */
#define RTFMAXSIZE  0xFF   /* Maximum number of a frame */
#define RTLFIXUP    0x04   /* Number of fixup character in a frame */

#define IDLEN 6
#define SNOLEN 2

/* mask of instruction */
#define RTIMASK 0xC0
#define RTIGET  0x00
#define RTISET  0x40
#define RTITRAS 0x80
#define RTICTRL 0xC0

/* type of requst option */
#define REQPWD   0x01
#define REQWMODE 0x02
#define REQBRD   0x03
#define REQMNT   0x04
#define RWQRES   0x05

/* information: broad operation start */
#define INBRDSTA 0x04

/* default time of waiting cts */
#define DCHKMS 1000

static unsigned char pwdwmode = 0;
static unsigned char reqtype;

enum
  {
    /* Instruction frame type */

    RTRVER       = 0x01,   /* Read router program version */
    RTRDTIME     = 0x02,   /* Read router program design time */
    RTRIDNUM     = 0x03,   /* Read amount of PLC meter */
    RTRDLID      = 0x04,   /* Download all PLC meter infomation */
    RTRDLRID     = 0x05,   /* Download relay IDs  */
    RTRSLEVEL    = 0x06,   /* Read router search level */
    RTRBREAK     = 0x07,   /* Read router current work break point */
    RTRMDEEP     = 0x08,   /* Read router maximum deep level */
    RTRTCMD      = 0x09,   /* Read test command data sign */
    RTRUNTHNUM   = 0x0A,
    RTRUNTHID    = 0x0B,
    RTRSINKID    = 0x0C,
    RTRRUNMODE   = 0x11,
    RTREXTENDMD  = 0x12,
    RTRPLTM      = 0x13,
    RTRSNOMT     = 0x3C,
    RTRMTSNO     = 0x3D,
    RTRTHQ       = 0x3E,
	RTGETBRD     = 0x3F,
    RTSCLEAR     = 0x41,   /* clear all IDs */
    RTSAID       = 0x42,   /* Add a ID */
    RTSDID       = 0x43,   /* Delete a ID */
    RTSRID       = 0x44,   /* Replace old ID to new ID */
    RTSSMK       = 0x45,   /* Set selected ID mark */
    RTSCSMK      = 0x46,   /* Clear selected ID mark */
    RTSRMK       = 0x47,   /* Set relay ID mark */
    RTSCRMK      = 0x48,   /* Clear relay ID mark */
    RTSINSRELAY  = 0x49,   /* Insert a relay ID */
    RTSSLEVEL    = 0x4A,   /* Set router search level */
    RTSBEGIN     = 0x4B,   /* Set router work point to begin */
    RTSWRKMODE   = 0x4C,   /* Set router work mode */
    RTSMDEEP     = 0x4D,   /* Set router maximum deep level */ 
    RTSTCMD      = 0x4E,   /* Set test command data sign */
    RTSISINK     = 0x4F,   /* initialize sink id */
    RTSSINK      = 0x50,   /* set sink id */
    RTSRUMMD     = 0x51,   /* set run mode */
    RTSEXMD      = 0x52,   /* set extend run mode */
    RTSETBRD     = 0x53,   /* set extend run mode */
    RTTDATA      = 0x81,   /* Send data to ID */
    RTTRDATA     = 0x82,   /* Send data to ID pass through another ID(repeater) */
    RTTPLC38II   = 0x83,   /* Communicate to PLC38-II */
    RTTMONITOR   = 0x84,   /* Start meter monitor mode */
    RTCCHGP      = 0xC1,   /* Change phase */
    RTCWORK      = 0xC2,   /* Control router start working */
    RTCSTOP      = 0xC3,   /* Stop router work */
    RTCRESET     = 0xC4,   /* Router restart */
    RTCBRD       = 0xC5,   /* Control router start broadcast */
    RTCCHKP      = 0xC6,   /* Control router start phase check */
    RTCPARAL     = 0xC7,   /* Control router start paralle task */
  
    /* Response frame type */
    
    RTACONFIRM  = 0xE0,    /* Response confirm frame */
    RTAPWD      = 0xE1,    /* Response router require startup password */
    RTAWMODE    = 0xE2,    /* Response router require work mode */
    RTABRDCAST  = 0xE3,    /* Response router require broadcast command */
    RTASDATA    = 0xE4,    /* Response router require send data */
    RTASDCYCLE  = 0xE5,    /* Response router require monitor meter command */

    /* Information frame type */
    
    RTIIDLE    = 0x01,    /* router is idle */
    RTICHGPAHT = 0x02,    /* change path */
    RTIWKSTATE = 0x03,    /* report work state */
    RTIBRDBGN  = 0x04,    /* broad is beginning */
    RTIBRDEND  = 0x05,    /* broad is over */
    RTIONWK    = 0x06,    /* be on work */
  };

enum
  {
    DEMASK = 0x01,  /* Mask of misdata frame*/
    DERROR = 0x01,  /* Misdata frame */
    DRMASK = 0x02,  /* Mask of reading from repeater */
    DRELAY = 0x02,  /* Read from repeater */
    EXTDRPT = 0x80, /* Extend data frame: report */
    EXTDAPT = 0x81, /* Extend data frame: appoint */
    EXTDMNT = 0x82, /* Extend data frame: monitor */
  };

static int apprt_get_ver(unsigned char *tmp, unsigned char len);
static int apprt_get_prgtm(unsigned char *tmp, unsigned char len);
static int apprt_get_amount(unsigned char *tmp, unsigned char len);
static int apprt_get_mtinfo(unsigned char *tmp, unsigned char len);
static int apprt_get_relay(unsigned char *mtid, unsigned char idlen);
static int apprt_get_searchlev(unsigned char *tmp, unsigned char len);
static int apprt_get_break(unsigned char *tmp, unsigned char len);
static int apprt_get_maxrd(unsigned char *tmp, unsigned char len);
static int apprt_get_testcmd(unsigned char *tmp, unsigned char len);
static int apprt_get_untouchnum(unsigned char *tmp, unsigned char len);
static int apprt_get_untouchid(unsigned char *tmp, unsigned char len);
static int apprt_get_sinkid(unsigned char *tmp, unsigned char len);
static int apprt_get_runmode(unsigned char *tmp, unsigned char len);
static int apprt_get_extendmd(unsigned char *tmp, unsigned char len);
static int apprt_get_sno(unsigned char *mtid, unsigned char idlen);
static int apprt_get_id(unsigned char *sno, unsigned char snolen);
static int apprt_get_brd(unsigned char *data, unsigned char len);

static int apprt_set_clrmt(unsigned char *para, unsigned char len);
static int apprt_set_addmt(unsigned char *para, unsigned char len);
static int apprt_set_delmt(unsigned char *para, unsigned char len);
static int apprt_set_mdfid(unsigned char *para, unsigned char len);
static int apprt_set_inserp(unsigned char *para, unsigned char len);
static int apprt_set_slev(unsigned char *para, unsigned char len);
static int apprt_set_begin(unsigned char *para, unsigned char len);
static int apprt_set_wrkmd(unsigned char *para, unsigned char len);
static int apprt_set_maxhop(unsigned char *para, unsigned char len);
static int apprt_set_test(unsigned char *para, unsigned char len);
static int apprt_set_asink(unsigned char *para, unsigned char len);
static int apprt_set_sink(unsigned char *para, unsigned char len);
static int apprt_set_runmd(unsigned char *para, unsigned char len);
static int apprt_set_exmd(unsigned char *para, unsigned char len);

static int apprt_set_brd(unsigned char *para, unsigned char len);
static int apprt_ctrl_chgphs(unsigned char *para, unsigned char len);
static int apprt_ctrl_work(unsigned char *para, unsigned char len);
static int apprt_ctrl_stop(unsigned char *para, unsigned char len);
static int apprt_ctrl_reset(unsigned char *para, unsigned char len);
static int apprt_ctrl_broad(unsigned char *para, unsigned char len);
static int apprt_ctrl_chkphs(unsigned char *para, unsigned char len);
static int apprt_ctrl_paral(unsigned char *para, unsigned char len);

static int apprt_set(unsigned char type,unsigned char *para, unsigned char len);
static int apprt_ctrl(unsigned char type,unsigned char *para, unsigned char len);

static int apprt_comm_direct(unsigned char *data, unsigned char datalen);
static int apprt_comm_plc38(unsigned char *data, unsigned char datalen);

struct rtproc
{
  unsigned char type;
  int (*func)(unsigned char *para, unsigned char len);
  unsigned char paralen;
};

static const struct rtproc rtget[] = 
  {
    {RTRVER, apprt_get_ver, 0},
    {RTRDTIME, apprt_get_prgtm, 0},
    {RTRIDNUM, apprt_get_amount,0},
    {RTRDLID, apprt_get_mtinfo,0},
    {RTRDLRID, apprt_get_relay, IDLEN},
    {RTRSLEVEL, apprt_get_searchlev,0},
    {RTRBREAK, apprt_get_break, 0},
    {RTRMDEEP, apprt_get_maxrd, 0},
    {RTRTCMD, apprt_get_testcmd, 0},
    {RTRUNTHNUM, apprt_get_untouchnum, 0},
    {RTRUNTHID, apprt_get_untouchid, 0},
    {RTRSINKID, apprt_get_sinkid, 0},
    {RTRRUNMODE, apprt_get_runmode, 0},
    {RTREXTENDMD, apprt_get_extendmd,0},
    {RTRSNOMT, apprt_get_id, SNOLEN},
    {RTRMTSNO, apprt_get_sno, IDLEN},
	{RTGETBRD, apprt_get_brd, 0},
  };
#if 0
static const struct rtproc rtset[] = 
  {
    {RTSCLEAR, apprt_set_clrmt, 0x00},
    {RTSAID, apprt_set_addmt, 0x06},
    {RTSDID, apprt_set_delmt, 0x06},
    {RTSRID, apprt_set_mdfid, 0x0C},
    {RTSINSRELAY, apprt_set_inserp, 0x0c},
    {RTSSLEVEL, apprt_set_slev, 0x01},
    {RTSBEGIN, apprt_set_begin, 0x00},
    {RTSWRKMODE, apprt_set_wrkmd, 0x01},
    {RTSMDEEP, apprt_set_maxhop, 0x01},
    {RTSTCMD, apprt_set_test, 0x02},
    {RTSISINK, apprt_set_asink, 0x00},
    {RTSSINK, apprt_set_sink, 0x02},
    {RTSRUMMD, apprt_set_runmd, 0x01},
    {RTSEXMD, apprt_set_exmd, 0x01},
	{RTSEXMD, apprt_set_brd, 0x01},
  };
#endif
static const struct rtproc rtctrl[] = 
  {
    {RTCCHGP, apprt_ctrl_chgphs, 0x01},
    {RTCWORK, apprt_ctrl_work, 0x00},
    {RTCSTOP, apprt_ctrl_stop, 0x00},
    {RTCRESET, apprt_ctrl_reset, 0x00},
    {RTCBRD, apprt_ctrl_broad, 0x00},
    {RTCCHKP, apprt_ctrl_chkphs, 0x00},
    {RTCPARAL, apprt_ctrl_paral, 0x02}
  };

static const struct rtproc rttrans[] = 
  {
    {RTTDATA, apprt_comm_direct, 0},
    {RTTPLC38II, apprt_comm_plc38, 0},
  };

int apprt_find(unsigned char *frame, int len)
{
    const unsigned char *pos;
    int offset = -1;

    if (len < 5)        //7E LEN CMD DATA SUM XOR (ȷ��֡DATA��Ϊ��)
    {
        return -1;
    }

    if ((pos = (const unsigned char *)memchr(frame, RTSTART, len)) != NULL)
    {
        offset = pos - frame;
        
        if(len < (offset + 5))
        {
            return -1;
        }
        
        if (frame[offset + RTLENPOS] < 1)
        {
            return -1;
        }

        return offset;
    }

    return -1;
}

int apprt_check(unsigned char *frame, int len, int *begin, int *end)
{
  if (len < RTFMINSIZE)
    return -1;

  int findex = 0, flen = 0;
  for (int i = 0; i < len; ++i)
    {
      if (frame[i] == RTSTART) /* begin check */
	{
	  *begin = i;
	  if (i < len -1)
	    {
	      flen = frame[i + RTLENPOS]; /* data len */
              if(flen < 1)
                continue;
	      findex = i;
	      if (len - findex >= flen + 1 + 1 + 2) /* datalen + head + lenbyte + sumbyte + xorbyte */
		{
		  *end = findex + flen + 1 + 2; /* datalen + lenbyte + sumbyte + xorbyte */

		  unsigned char sumv = 0, xorv = 0; /* check cs */
		  for (int j = 0; j < flen; ++j)
		    {
		      sumv += frame[findex +  RTDATAPOS + j];
		      xorv ^= frame[findex +  RTDATAPOS + j];
		    }

		  if (sumv == frame[findex + 2 + flen] && xorv == frame[findex + 3 + flen])
		    {
		      *end += 1;
		      return 0;
		    }

		  continue;
		}
	    }
	}
    }
  return -1;
}

int apprt_build(unsigned char type, unsigned char opt, unsigned char *data, int datalen,
		unsigned char *frame, int *framelen)
{
  assert(frame);
  if (datalen > 0)
    assert(data);

  size_t index = 3;
  unsigned char sum = type, xor = type;
  frame[0] = RTSTART;
  frame[1] = datalen + 1;
  frame[2] = type;

  if (type == RTFTINST || type == RTFTINFO) /* instruct frame or info frame */
    {
      ++frame[1];
      frame[3] = opt;
      sum += opt;
      xor ^= opt;
      ++index;
    }
  if (index + datalen + 2 > 255) /* may overflow!! */
    {
      *framelen = 0;
      return -1;
    }
  for (size_t i = 0; i < datalen; ++i)
    {
      frame[index++] = data[i];
      sum += data[i];
      xor ^= data[i];
    }

  frame[index++] = sum;
  frame[index++] = xor;

  *framelen = index; 

  return 0;
}

int apprt_get(unsigned char type, unsigned char *data, int datalen)
{
  int err;
  
  for (int i = 0; i < sizeof(rtget) / sizeof(rtget[0]); ++i)
    {
      if (type == rtget[i].type)
	{
	  if (datalen != rtget[i].paralen)
	    {
	      apprt_err(RTFERR_CMDLEN);
	      return 0;
	    }
	  if (rtget[i].func(data, datalen) != 0)
	    {
	      err = rf_geterr();
	      apprt_err(err);
	    }
	  return 0;
	}
    } 

  apprt_err(RTFEER_CMDNOT);
  return 0;
}

int apprt_res(unsigned char type, unsigned char *data, int datalen)
{
  if (datalen > 0)
    assert(data);
  unsigned char frame[255];
  int framelen = 255;

  apprt_build(type, 0, data, datalen, frame, &framelen);
  
  return rf_write(frame, framelen, DCHKMS);
}

int apprt_trans(unsigned char type, unsigned char *data, int datalen)
{
  int err;
  
  for (int i = 0; i < sizeof(rttrans) / sizeof(rttrans[0]); ++i)
    {
      if (type == rttrans[i].type)
	{
	  if (rttrans[i].func(data, datalen) != 0)
	    {
	      err = rf_geterr();
	      apprt_err(err);
	    }
	  return 0;
	}
    } 

  apprt_err(RTFEER_CMDNOT);
  return 0;
}

int apprt_report(unsigned char *mtid, unsigned char *data, int datalen)
{
  unsigned char tmpdata[255], frame[255];
  int tmplen = 0, framelen = 255;
  
  memcpy(tmpdata, mtid, IDLEN); /* id */
  id_bintobcd(tmpdata);
  tmplen += IDLEN;
  tmpdata[tmplen++] = 0x80; /* active update */
  
  if (tmplen + datalen > sizeof(tmpdata))
    return -1;
  if (datalen > 0)
    {
      tmpdata[tmplen++] = data[0]; /* ctrl */

      tmpdata[tmplen++] = datalen - 1;  /* datalen */

      memcpy(tmpdata + tmplen, data + 1, datalen - 1); /* data*/
      tmplen += datalen - 1;
    }

  if (apprt_build(RTFTDATA, 0, tmpdata, tmplen, frame, &framelen) != 0)
    return -1;

  rf_write(frame, framelen, DCHKMS);

  reqtype = RWQRES;
  return 0;
}

int apprt_data(unsigned char *mtid, unsigned char *data, int datalen)
{
  assert(mtid);
  if (datalen > 0)
    assert(data);
  unsigned char phase, depth, tmpdata[255], frame[255];
  int tmplen = 0, framelen = 255;

  if (rf_get_mt(mtid, &phase, &depth) != 0)
    {
      int err = rf_geterr();
      apprt_err(err);
      return -1;
    }
  memcpy(tmpdata, mtid, IDLEN); /* id */
  id_bintobcd(tmpdata);
  tmplen += IDLEN;
  tmpdata[tmplen++] = (phase << 5) + depth; /* phase depth */
  if (datalen > 0)
    {
      tmpdata[tmplen++] = data[0]; /* ctrl */

      tmpdata[tmplen++] = datalen - 1;  /* datalen */

      memcpy(tmpdata + tmplen, data + 1, datalen - 1); /* data*/
      tmplen += datalen - 1;
    }

  if (apprt_build(RTFTDATA, 0, tmpdata, tmplen, frame, &framelen) != 0)
    return -1;

  rf_write(frame, framelen, DCHKMS);

  reqtype = RWQRES;
  return 0;
}

int apprt_info(unsigned char opt)
{
  unsigned char frame[255], id[6];
  int framelen = 255, datalen;

  if (opt == RTIWKSTATE)
    {
      unsigned char data[2 + IDLEN];

      data[0] = rf_get_wrkno();
      data[1] = rf_get_stage();
      rf_get_curid(id, &datalen);
      memcpy(data + 2, id, datalen); 
      apprt_build(RTFTINFO, opt, data, sizeof(data), frame, &framelen);
    }
  else
    apprt_build(RTFTINFO, opt, NULL, 0, frame, &framelen);

  rf_write(frame, framelen,DCHKMS);
  return 0;
}

int apprt_err(unsigned char errcode)
{
  unsigned char data = errcode, frame[255];
  int framelen = 255;

  apprt_build(RTFTERROR, 0, &data, sizeof(unsigned char), frame, &framelen);
  rf_write(frame, framelen, DCHKMS);
  
  return 0;
}

int apprt_sendack()
{
  unsigned char frame[0x20];
  int len = sizeof(frame);

  apprt_build(RTFTRESPONSE, 0, NULL, 0, frame, &len);
  rf_write(frame, len,DCHKMS);
  return 0;
}

int apprt_reqpwd()
{
  unsigned char data[2], frame[0x20];
  int len = sizeof(frame);

  reqtype = REQPWD;

  data[0] = REQPWD;
  apprt_build(RTFTREQUIRE, 0, data, 1, frame, &len);
  rf_write(frame, len, DCHKMS);

  return 0;
}

int apprt_reqwmode()
{
  unsigned char data[2], frame[0x20];
  int len = sizeof(frame);

  reqtype = REQWMODE;

  data[0] = REQWMODE;
  apprt_build(RTFTREQUIRE, 0, data, 1, frame, &len);
  rf_write(frame, len, DCHKMS);

  return 0;
}

int apprt_reqbrd(unsigned char cnt)
{
  unsigned char data[2], frame[0x20];
  int len = sizeof(frame);

  reqtype = REQBRD;

  data[0] = REQBRD;
  data[1] = cnt;
  apprt_build(RTFTREQUIRE, 0, data, 2, frame, &len);
  rf_write(frame, len,DCHKMS);

  return 0;
}

int apprt_reqmnt(unsigned char *mt, unsigned char cnt)
{
  unsigned char data[0x10], frame[0x30];
  int len = sizeof(frame), index = 0;

  reqtype = REQMNT;
  data[index++] = REQMNT;
  data[index++] = rf_get_wrkmd();
  if (cnt == 0)
    data[index - 1] |= 0x80; 
  data[index++] = rf_get_wrkno();
  data[index++] = rf_get_stage();
  memcpy(&data[index], mt, IDLEN);
  id_bintobcd(&data[index]);
  index += IDLEN;
  apprt_build(RTFTREQUIRE, 0, data, index, frame, &len);
  rf_write(frame, len, DCHKMS);

  return 0;
}
#if 0
int apprt_proc(unsigned char *frame, int len)
{
  unsigned char type = frame[RTDATAPOS];
  int ret = -1 , datalen = frame[RTLENPOS];
  
  assert(datalen + 4 == len);
  switch (type)
    {
    case RTFTINST:
      assert(len > 2);
      if (pwdwmode != RTSSUCC)
        return -1;
      if ((frame[RTDATAPOS + 1] & RTIMASK) ==  RTIGET)
	return apprt_get(frame[RTDATAPOS + 1], &frame[RTDATAPOS + 2], datalen - 2);
      if ((frame[RTDATAPOS + 1] & RTIMASK) ==  RTISET)
	return apprt_set(frame[RTDATAPOS + 1], &frame[RTDATAPOS + 2], datalen - 2);
      if ((frame[RTDATAPOS + 1] & RTIMASK) ==  RTITRAS)
	return apprt_trans(frame[RTDATAPOS + 1], &frame[RTDATAPOS + 2], datalen - 2);
      else  
	return apprt_ctrl(frame[RTDATAPOS + 1], &frame[RTDATAPOS + 2], datalen - 2);
    case RTFTRESPONSE:
      if (reqtype == REQPWD)
	{
	  ret = rf_setpwdwmode(REQPWD, &frame[RTDATAPOS + 1], datalen - 1);
	  if(ret == 0)
	    pwdwmode = RTSWMODE;
	}
      else if (reqtype == REQWMODE)
	{
	  ret = rf_setpwdwmode(REQWMODE, &frame[RTDATAPOS + 1], datalen - 1);
	  if(ret == 0)
	    pwdwmode = RTSSUCC;
	}
      else if (reqtype == REQBRD)
        {
          if (datalen == 1)
            ret = rf_setappd(APPRCFM, NULL, 0, 0);
          else  
            ret = rf_setappd(APPRDATA, &frame[RTDATAPOS + 1], datalen - 1, 0);
        }
      else if (reqtype == REQMNT)
	{
	  if (datalen == 1)
	    ret = rf_setappd(APPRCFM, NULL, 0, 0);
	  else if (frame[RTDATAPOS + 1] == 0x00 && datalen > 2)
	    ret = rf_setappd(APPRDATA, &frame[RTDATAPOS + 2], datalen - 2, 0);
	  else if (frame[RTDATAPOS + 1] == 0x02 && datalen > 3)
	    ret = rf_setappd(APPRDATA, &frame[RTDATAPOS + 3], datalen - 3, frame[RTDATAPOS + 2]);
	}
      else if (reqtype == RWQRES)
	{
	  if (datalen == 1)
	    ret = rf_setappd(APPRCFM, NULL, 0, 0);
	}
      else apprt_err(RTFERR_NOTCMD);
      
      if (ret == 0)
        {
          reqtype = 0;
          rf_setdmmode(DMMD_SUC);
        }
      break;
      
    default:
      apprt_err(RTFEER_CMDNOT);
    }

  return 0;
}
#endif
static int is_allbcd(unsigned char data[], unsigned char len)
{
  for(int i = 0x00 ; i < len ; i++) 
    {
      if(((data[i] & 0x0F) > 0x09)||((data[i] & 0xF0) > 0x90))
	return -1;
    }
  return 0;
}
#if 0
static int apprt_set_clrmt(unsigned char *para, unsigned char len)
{
  assert(para);
  
  return rf_set_clrmt();
}
#endif
static int apprt_set_addmt(unsigned char *para, unsigned char len)
{
  assert (para);
  
  if (is_allbcd(para, len) != 0)
    return seterrno(RTFERR_CMDCONT);

  return rf_set_addmt_rt(para);
}

static int apprt_set_delmt(unsigned char *para, unsigned char len)
{
  assert (para);
  
  if (is_allbcd(para, len) != 0)
    return seterrno(RTFERR_CMDCONT);

  return rf_set_delmt(para);
}

static int apprt_set_mdfid(unsigned char *para, unsigned char len)
{
  assert(para);
  
  if (is_allbcd(para, len) != 0)
    return seterrno(RTFERR_CMDCONT);
  
  return rf_set_mdfid(para + 6, para);
}

static int apprt_set_inserp(unsigned char *para, unsigned char len)
{
  assert(para);

  if (is_allbcd(para, len) != 0)
    return seterrno(RTFERR_CMDCONT);
  
  return rf_set_inserp(para + 6, para);
}
#if 0
static int apprt_set_slev(unsigned char *para, unsigned char len)
{
  assert(para);
  
  return rf_set_slev(*para);
}
#endif
static int apprt_set_begin(unsigned char *para, unsigned char len)
{
  return rf_set_begin();
}

static int apprt_set_wrkmd(unsigned char *para, unsigned char len)
{
  assert(para);
  
  return rf_set_wrkmd(*para);
}

static int apprt_set_maxhop(unsigned char *para, unsigned char len)
{
  assert(para);
  
  return 0;
}

static int apprt_set_test(unsigned char *para, unsigned char len)
{
  assert(para);
  
  return rf_set_test(para);
}
#if 0
static int apprt_set_asink(unsigned char *para, unsigned char len)
{
  return rf_set_randsinkid();
}
#endif
static int apprt_set_sink(unsigned char *para, unsigned char len)
{
  assert(para);
  
//   return rf_set_sinkid(para);
}
#if 0
static int apprt_set_runmd(unsigned char *para, unsigned char len)
{
  assert(para);

  return rf_set_runmd(*para);
}
#endif
static int apprt_set_exmd(unsigned char *para, unsigned char len)
{
  assert(para);

  return rf_set_exmd(*para);
}
#if 0
static int apprt_set_brd(unsigned char *para, unsigned char len)
{
  if(rf_isstop() != 0)
  	return(-1);

  rt_setbrd(*para);
  return(0);
}
#endif

static int apprt_ctrl_chgphs(unsigned char *para, unsigned char len)
{
  return rf_ctrl_chgphs(*para);
}

static int apprt_ctrl_work(unsigned char *para, unsigned char len)
{
  return rf_ctrl_work(*para);
}

static int apprt_ctrl_stop(unsigned char *para, unsigned char len)
{
  return rf_ctrl_stop(*para);
}

static int apprt_ctrl_reset(unsigned char *para, unsigned char len)
{
  return 0;
}

static int apprt_ctrl_broad(unsigned char *para, unsigned char len)
{
  return rf_ctrl_startbrd(*para);
}

static int apprt_ctrl_chkphs(unsigned char *para, unsigned char len)
{
  return rf_ctrl_startbrd(*para);
}

static int apprt_ctrl_paral(unsigned char *para, unsigned char len)
{
  if (para[0] != 0x01 || para[1] < 3)
    return seterrno(RTFERR_CMDCONT);
  if (rf_autoreg(para[1]) < 0)
    return seterrno(RTFERR_SYSRUN);
  
  return 0;    
}
#if 0
static int apprt_set(unsigned char type,unsigned char *para, unsigned char len)
{
  
  for (int i = 0; i < sizeof(rtset) / sizeof(rtset[0]); ++i)
    {
      if (type == rtset[i].type)
	{
	  if (len != rtset[i].paralen)
	    {
	      return apprt_err(RTFERR_CMDLEN);
	    }
	  if (rtset[i].func(para, len) == 0)
	    apprt_sendack();	      
	  else	 
	    apprt_err(rf_geterr());

	  return 0;
	}
    } 

  apprt_err(RTFEER_CMDNOT);
  return 0;
}
#endif
static int apprt_ctrl(unsigned char type,unsigned char *para, unsigned char len)
{
  for (int i = 0; i < sizeof(rtctrl) / sizeof(rtctrl[0]); ++i)
    {
      if (type == rtctrl[i].type)
	{
	  if (len != rtctrl[i].paralen)
	    return apprt_err(RTFERR_CMDLEN);
	  if (rtctrl[i].func(para, len) == 0)
	    {
              if (type != RTCPARAL)
                apprt_sendack();
              if (type == RTCRESET)
		rf_reset(2);/* hard_reset(); */
	    }
	  else         
	    apprt_err(rf_geterr());
          
	  return 0;
	}
    }

  apprt_err(RTFEER_CMDNOT);
  return 0;
}

static int apprt_get_ver(unsigned char *tmp, unsigned char len) /* 0x01-Read router program version */
{
  unsigned char data[255];
  int datalen = 255;

  rf_get_ver(data, &datalen);
  data[datalen++] = 0x0D;
  data[datalen++] = 0x0A;

  apprt_res(RTFTRESPONSE, data, datalen);
  return 0;
}

static int apprt_get_prgtm(unsigned char *tmp, unsigned char len) /* 0x02-Read router program design time */
{
  unsigned char data[255];
  int datalen = 255;

  rf_get_prgtm(data, &datalen);
  data[datalen++] = 0x0D;
  data[datalen++] = 0x0A;

  apprt_res(RTFTRESPONSE, data, datalen);

  return 0;
}

static int apprt_get_amount(unsigned char *tmp, unsigned char len) /* 0x03-Read amount of PLC meter */
{
  unsigned char data[10];
  int datalen;
  
  rf_get_amount(data, &datalen);

  apprt_res(RTFTRESPONSE, data, datalen);

  return 0;
}

static int apprt_get_mtinfo(unsigned char *tmp, unsigned char len) /* 0x04-Download all PLC meter infomation */
{
  unsigned char phase, depth, data[IDLEN + 2];
  unsigned int idx = 0;

  rf_init_mttrav();
  
  while(1)
    {
      if(rf_get_mtinfo(data, &phase, &depth) != 0)
        break;
      data[IDLEN] = 0x00;
      data[IDLEN + 1] = (phase << 5) + depth;
   
      if (apprt_res(RTFTMIDDLE, data, sizeof(data)) != 0)
        return -1;
      ++idx;
      if (idx % 20 == 0)
          watchdog();
      mdelay(15);
    }
  
  apprt_res(RTFTRESPONSE, NULL, 0); /* confirm frame */
  return 0;
}

static int apprt_get_relay(unsigned char *mtid, unsigned char idlen) /* 0x05-Download relay IDs */
{
  assert(idlen == IDLEN);
  unsigned char phase, depth, data[IDLEN + 2];
  int datalen = IDLEN + 2;
  if(rf_init_rptrav(mtid, &phase, &depth) != 0)
    return apprt_err(RTFERR_IDNOT);  /* ID not exist */
  memcpy(data, mtid, IDLEN);
  data[IDLEN] = 0x00;
  data[IDLEN + 1] = (phase << 5) + depth;
  if (apprt_res(RTFTMIDDLE, data, datalen) != 0)
    return -1;
  
  datalen = IDLEN + 1;
  while(1)
    {
      if(rf_get_rpinfo(data, &phase, &depth) != 0)
        break;
      data[IDLEN] = (phase << 5) + depth;
    
      if (apprt_res(RTFTMIDDLE, data, datalen) != 0)
        return -1;
      mdelay(15);
    }

  apprt_res(RTFTRESPONSE, NULL, 0); /* confirm frame */

  return 0;
}

static int apprt_get_searchlev(unsigned char *tmp, unsigned char len)  /* 0x06-Read router search level */
{
  unsigned char data;
 
  data = rf_get_slevel();
  apprt_res(RTFTRESPONSE, &data, sizeof(data));

  return 0;
}

static int apprt_get_break(unsigned char *tmp, unsigned char len)  /* 0x07-Read router current work break point */
{
  unsigned char data[3 + IDLEN], curid[6];
  int datalen;

  data[0] = rf_get_wrkmd();
  data[1] = rf_get_wrkno();
  data[2] = rf_get_stage();
  rf_get_curid(curid, &datalen);

  memcpy(data + 3, curid, IDLEN);

  apprt_res(RTFTRESPONSE, data, sizeof(data));
  return 0;
}

static int apprt_get_maxrd(unsigned char *tmp, unsigned char len) /* 0x08-Read router maximum deep level */
{
  unsigned char data;

  data = rf_get_maxrd();
  apprt_res(RTFTRESPONSE, &data, sizeof(unsigned char));

  return 0;
}

static int apprt_get_testcmd(unsigned char *tmp, unsigned char len)  /* 0x09-Read test command data sign */
{
  unsigned char data[255];
  int datalen = 255;

  rf_get_testcmd(data, &datalen);
  apprt_res(RTFTRESPONSE, data, datalen);

  return 0;
}

static int apprt_get_untouchnum(unsigned char *tmp, unsigned char len) /* 0x0A-Read Untouched id num */
{
  unsigned char data[10];
  int datalen;
  
  rf_get_untouchnum(data, &datalen);

  apprt_res(RTFTRESPONSE, data, datalen);

  return 0;
}

static int apprt_get_untouchid(unsigned char *tmp, unsigned char len) /* 0x0B-Read untouched id */
{
  unsigned char data[20];
  int datalen, idx = 0;

  rf_init_mttrav();
  
  while(1)
    {
      if(rf_get_untouchid(data, &datalen) != 0)
        break;

      if (apprt_res(RTFTMIDDLE, data, datalen) != 0)
        return -1;
      ++idx;
      if(idx % 20 == 0)
          watchdog();
      mdelay(15);
    }

  apprt_res(RTFTRESPONSE, NULL, 0);

  return 0;
}

static int apprt_get_sinkid(unsigned char *data, unsigned char len) /* 0x0C-Read sinkid */
{
  unsigned char sinkid[20];
  int datalen;
  
  rf_get_sinkid(sinkid, &datalen);
  apprt_res(RTFTRESPONSE, sinkid, datalen);

  return 0;
}

static int apprt_get_runmode(unsigned char *tmp, unsigned char len) /* 0x11-Read run mode(II, III) */
{
  unsigned char data;
 
  /* data = rf_get_runmd(); */
  data = 0x03;
  apprt_res(RTFTRESPONSE, &data, sizeof(unsigned char));

  return 0;
}

static int apprt_get_extendmd(unsigned char *tmp, unsigned char len) /* 0x12-Read extend work mode */
{
  unsigned char data;
 
  data = rf_get_extdmd();
  apprt_res(RTFTRESPONSE, &data, sizeof(unsigned char));

  return 0;
}

static int apprt_get_sno(unsigned char *mtid, unsigned char idlen) /* 0x3D-Read sno of one meter */
{
  assert(idlen == IDLEN);
  assert(mtid);

  unsigned char data[SNOLEN];

  if (rf_get_sno(mtid, data) != 0)
    {
      apprt_err(RTFERR_IDNOT);  /* ID������ */
      return -1;
    }

  apprt_res(RTFTRESPONSE, data, SNOLEN);
  return 0;
}

static int apprt_get_id(unsigned char *sno, unsigned char snolen) /* 0x3C-Read meter id by way of sno */
{
  assert(snolen == SNOLEN);
  assert(sno);

  unsigned char data[IDLEN];

  if (rf_get_id(sno, data) != 0)
    {
      apprt_err(RTFERR_IDNOT);  /* ID not exist */
      return -1;
    }

  apprt_res(RTFTRESPONSE, data, IDLEN);
  return 0;
}

int apprt_get_brd(unsigned char *data, unsigned char len)
{
  unsigned char c;
  c = rt_getbrd();
  apprt_res(RTFTRESPONSE, &c, 1);
  return 0;
}

static int apprt_comm_direct(unsigned char *data, unsigned char datalen) /* send data to mtid directly */
{
  assert(data);
  unsigned char mtid[IDLEN];

  if(datalen < 6) // id(5B) + ctrl + data
    {
      rf_seterr(RTFERR_CMDLEN);
      return -1;
    }
  memcpy(mtid, data, IDLEN);
  reverse(mtid, IDLEN);
  /* rf_settask(); */
  if (rf_monit(mtid, 0x00, data + IDLEN, datalen - IDLEN, 0x00) != 0)
    {
      int err = rf_geterr();
      apprt_err(err);
    }
  return 0;
}

static int apprt_comm_plc38(unsigned char *data, unsigned char datalen) /* send data to PLCi38 directly */
{
  assert(data);
  unsigned char tmp[255];
  extern unsigned char plc_new;
  
  if (datalen < sizeof(tmp))
    {
      if(plc_new) /*38-IV error,dont support 0xFC*/
        memcpy(tmp, data, datalen);
      else
      {
        tmp[0] = 0xFC;
        memcpy(&tmp[1], data, datalen);
        ++datalen;
      }
    }
  rf_settask();  
  rf_comm38(tmp, datalen);
  //rt_write(data, datalen, 1000);

  return 0;
}

unsigned char apprt_get_pwdwmode()
{
  return pwdwmode;
}
