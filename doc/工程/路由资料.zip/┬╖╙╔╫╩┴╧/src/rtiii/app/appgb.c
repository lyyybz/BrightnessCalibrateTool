/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: appgb.c
 *
 * Description:  Implementation of Route Application between Router and DM.
 *               GB376.2
 *
 * Version: v1.0
 * Time:    2010-02-06
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/rt/rtfuns.h"
#include "../include/rt/rterrs.h"
#include "../include/app/appgb.h"
#include "../include/app/nwtask.h"

#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "router.h"
#include "../include/db/node.h"
#include "update.h"
#include "apprt.h"
#include <time.h>

#define MAX_FORCST_NUM      0x10

#define GBSTART   0x68
#define GBLENPOS  0x01
#define GBCTLPOS  0x03
#define GBUSERPOS 0x04
#define GBINFOPOS 0x04
#define GBEND     0x16



#define FIXLEN   0x06

#define MINLEN   12 //without data and address, since unknown  68+L+C+AFN+SEQ+DT+JIAOYAN+16
//#define MINLEN   0x0E
#define FRMAE_DEFAULT_GW_LEN 15
#define DTCTLPOS 0x08 /* position of ctrl in 645frame */
#define MINTICK 1000

#define YEAR_21CENT_BEGIN 2000
#define TM_YEAR_BEGIN     1900
#define TM_MONTH_BEGIN    1

#define IDLEN 6
#define SNOLEN 2

#define MINUTE 60
#define HOUR (60*MINUTE)
#define DAY (24*HOUR)
#define YEAR (365*DAY)

#define COM_JZQ 0xE8
#define COM_CJQ 0xEA

#define  MAX_CHK_TASK_NUM  100  //��������ѯ��ʱ��·�ɷ��ص����������
extern int hard_new;

#define TASK_BUF_SIZE       0x1000
#define MAX_TASK_ID         0xEFFF
#define TASK_ID_INVALID     0xFFFF//����task id ��Χ0x0000-0xEFFF
typedef struct
{
    unsigned char ctrl;
    unsigned char len;
    unsigned char data[0x04];
}HIGH_DATAITEM_T;

HIGH_DATAITEM_T high_item[] =
{
    { 0x11, 0x04, { 0x34, 0x34, 0x39, 0x38 } }, //05060101
    { 0x11, 0x04, { 0x34, 0x33, 0x34, 0x33 } }, //00010001
    { 0x11, 0x04, { 0x34, 0x35, 0x39, 0x38 } }, //05060201
    { 0x01, 0x02, { 0x43, 0xc3, 0x00, 0x00 } }, //9010
    { 0x01, 0x02, { 0x52, 0xc3, 0x00, 0x00 } }, //901f
    { 0x01, 0x02, { 0x52, 0xc7, 0x00, 0x00 } },//941F
};

#define SZ_HIGH_ITEM (sizeof(high_item)/sizeof(high_item[0]))
/* interestingly, we assume leap-years */
static int month[12] = {
    0,
    DAY * (31),
    DAY * (31 + 29),
    DAY * (31 + 29 + 31),
    DAY * (31 + 29 + 31 + 30),
    DAY * (31 + 29 + 31 + 30 + 31),
    DAY * (31 + 29 + 31 + 30 + 31 + 30),
    DAY * (31 + 29 + 31 + 30 + 31 + 30 + 31),
    DAY * (31 + 29 + 31 + 30 + 31 + 30 + 31 + 31),
    DAY * (31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30),
    DAY * (31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31),
    DAY * (31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30)
};


enum
  {
    COMMJZ  = 0x01,
    COMMEXD = 0x07,
  };

enum
  {
    DIRMASK  = 0x80,
    PRMMASK  = 0x40,
    COMMMASK = 0x3F,
    ENDFMASK = 0x01,
    RTMASK   = 0x01,
    CMDLMASK = 0x04,
    RPMASK   = 0xF0,
  };

static struct gbbrd_info
{
    unsigned char appdata[65];
    unsigned char len;
    unsigned char start;
    unsigned int curtick;
    unsigned int ms;
} brdinfo;

struct gbbrd_info_v brdinfo_v;
struct gb_message gbmessage;
//struct node_up aid_table [MAX_NODE];
//struct node_mtup mt_up;


static unsigned char request = 0;
static unsigned char report = 0;
//static struct appgb_para headpara, tmheadpara;
//static unsigned char wrkmd = 0;


int restart_flag = 0;
unsigned char callmeter = 0;
unsigned char callflag = 0;
unsigned char local_viv_swi = 0;
static unsigned char appchn;

extern struct iv_update_info update_info;
struct _update_frame_nw update_nw;
struct _update_content_nw content_nw;
struct rt_test_info rt_test;

static int is_allbcd(unsigned char data[], unsigned char len);

int orgframe645(unsigned char *mtid, unsigned char *data, int datalen, unsigned char *frame);
static int is_valid645(unsigned char *frame, unsigned char len);
static void id_bcd2bin(unsigned char id[]);


static unsigned char chksum(const unsigned char *data, int len)
{
    unsigned char cs = 0;

    while (len-- > 0)
        cs += *data++;
    return (cs);
}

int orgframe645(unsigned char *mtid, unsigned char *data, int datalen, unsigned char *frame)
{
    assert(mtid);
    assert(data);
    assert(frame);
    unsigned char index = DTCTLPOS;
    frame[0] = 0x68;
    frame[7] = 0x68;
    memcpy(&frame[1], mtid, IDLEN);
    for (int i = 0; i < IDLEN; ++i)
        frame[i + 1] = bintobcd(frame[i + 1]);
    frame[index++] = data[0];
    frame[index] = datalen - 1;
    for (int i = 1; i < datalen; ++i)
        frame[index + i] = data[i] + 0x33;
    index += datalen;
    frame[index] = chksum(frame, index);
    frame[index + 1] = 0x16;

    return index + 2;
}

static int is_valid645(unsigned char *frame, unsigned char len)
{
    int ps = 0;

    while ((frame[ps] != 0x68) && (ps < len))
    {
        ps++;
    }

    if (len < (12 + ps))
    {
        return (-1);
    }
    len -= ps;

    if (frame[ps + 0] != 0x68 || frame[ps + 7] != 0x68)
        return -1;
    if (frame[ps + len - 2] != chksum(&frame[ps], len - 2))
        return -1;
    if (len != frame[ps + DTCTLPOS + 1] + 12)
        return -1;

    memmove(&frame[0], &frame[ps], len);
    return (ps);
}




static int is_allbcd(unsigned char data[], unsigned char len)
{
    for (int i = 0x00; i < len; i++)
    {
        if (((data[i] & 0x0F) > 0x09) || ((data[i] & 0xF0) > 0x90))
            return -1;
    }
    return 0;
}



static void id_bcd2bin(unsigned char id[])
{
    int i;
    for (i = 0; i < 6; ++i)
        id[i] = bcdtobin(id[i]);
}
static unsigned char err_rt2gb(unsigned char errcode)
{
    switch (errcode)
    {
        case RTFERR_NORES:
            return GBERR_TIMEOUT;
        case RTFERR_CMDCONT:
            return GBERR_DATA;
        case RTFERR_CMDLEN:
            return GBERR_LEN;
        case RTFERR_SUM:
            return GBERR_CS;
        case RTFEER_CMDNOT:
            return GBERR_DT;
        case RTFERR_FRM:
            return GBERR_FORMAT;
        case RTFERR_IDEXST:
            return GBERR_IDEXIST;
        case RTFERR_IDNOT:
            return GBERR_IDNO;
        case RTFERR_TMOUT:
            return GBERR_MCU;
        default:
            return GBERR_OTHER;
    }
}
int appgb_build_645cmd(const unsigned char *meter, unsigned char ctrl, unsigned char *data, int dlen, unsigned char *buff)
{
    int len = 0, i;
    unsigned char cs = 0, id[6];

    memcpy(id, meter, 6);
    id_bintobcd(id);
    reverse(id, 6);
#if 0
    unsigned char c1temp = 0xF4;
    send_uart_data_blocking(CHN_DM,&c1temp,1);
    send_uart_data_blocking(CHN_DM,&ctrl,1);
    send_uart_data_blocking(CHN_DM, data, dlen);
#endif
    buff[len++] = 0x68;
    memcpy(&buff[len], id, 6);
    len += 6;
    buff[len++] = 0x68;
    buff[len++] = ctrl;
    buff[len++] = dlen;
    memcpy(&buff[len], data, dlen);
    if(ctrl != 0xC0)
     {
       for (i = 0; i < dlen; i++)
       buff[len + i] += 0x33;
     }
    len += dlen;

    for (i = 0; i < len; i++)
        cs += buff[i];

    buff[len++] = cs;
    buff[len++] = 0x16;
#if 0
      c1temp = 0xF5;
    send_uart_data_blocking(CHN_DM,&c1temp,1);
    send_uart_data_blocking(CHN_DM, buff, len);
#endif
    return len;
}
static void timetotm(const unsigned char *time, struct tm *tm)
{
    assert(time);
    assert(tm);

    unsigned char tmp[6];

    memcpy(tmp, time, sizeof(tmp));
    for (int i = 0; i < sizeof(tmp); ++i)
        tmp[i] = bcdtobin(tmp[i]);
    tm->tm_sec  = tmp[0];
    tm->tm_min  = tmp[1];
    tm->tm_hour = tmp[2];
    tm->tm_mday = tmp[3];
    tm->tm_mon  = tmp[4] - TM_MONTH_BEGIN;
    tm->tm_year = tmp[5] + YEAR_21CENT_BEGIN - TM_YEAR_BEGIN;

}
static time_t my_mktime_1(struct tm *tm)
{
    time_t res;
    int year;

    year = tm->tm_year - 70;

    res = YEAR * year + DAY * ((year + 1) / 4); /* magic offsets (y+1) needed to get leapyears right.*/
    res += month[tm->tm_mon];

    if (tm->tm_mon > 1 && ((year + 2) % 4))   /* and (y+2) here. If it wasn't a leap-year, we have to adjust */
        res -= DAY;
    res += DAY * (tm->tm_mday - 1);
    res += HOUR * tm->tm_hour;
    res += MINUTE * tm->tm_min;
    res += tm->tm_sec;
    return res;
}
static void mdfappd(unsigned int tick)
{
    unsigned char s = ((tick - brdinfo.curtick) / 1000); /* 1000 tick = 1s */
    struct tm tm, *tmp;
    time_t t;

    brdinfo.ms += (tick - brdinfo.curtick) % 1000;
    if (_ndscont.num > 0 && _ndscont.num < 15)
        brdinfo.ms += (_ndscont.num - 1) / 2;
    if (brdinfo.ms >= 1000)
    {
        ++s;
        brdinfo.ms -= 1000;
    }
    brdinfo.curtick = tick;

    timetotm(&brdinfo.appdata[1], &tm);
    t = my_mktime_1(&tm);
    t += s;
    tmp = localtime(&t);
    brdinfo.appdata[1] = bintobcd(tmp->tm_sec);
    brdinfo.appdata[2] = bintobcd(tmp->tm_min);
    brdinfo.appdata[3] = bintobcd(tmp->tm_hour);
    brdinfo.appdata[4] = bintobcd(tmp->tm_mday);
    brdinfo.appdata[5] = bintobcd(tmp->tm_mon + TM_MONTH_BEGIN);
    brdinfo.appdata[6] = bintobcd(tmp->tm_year + TM_YEAR_BEGIN - YEAR_21CENT_BEGIN);
}


//----------------------------------------------------------------
const unsigned char rt_info_nw[] =
{
    0x01,
    0xFF, 0x00,
    0x80, 0x00,
    0x14,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    MAX_NODE & 0xff, MAX_NODE >> 8,
    0x00, 0x00,
    0x0A, 0x00,
    0x01, 0x08, 0x17,

    0x53, 0x45, 0x54, 0x52, RT_VERDATA, RT_VERDATA >> 8, RT_VERDATA >> 16, RT_VERSION & 0xff, RT_VERSION >> 8,
};



enum
{
    APP_FRM_NW = 1,
    APP_FRM_GW,
};
#define FRMAE_DEFAULT_GW_LEN 15
int nw_addr_len;
static unsigned char nw_frm_up_sn = 0;
static unsigned char app_frm_type = APP_FRM_NW;
static unsigned char last_nw_frame_sno = 0;
static unsigned char last_gw_frame_sno = 0;
static int app_get_frm_addr_len(struct frame_nw *frm);
static int appgb_get_task_num(struct afn_desc_nw *self, struct frame_nw *frm);
static void app_set_frm_auto_up(struct frame_nw *frm);
static int app_frm_negate(unsigned char e_code);
static int app_frm_confirm(unsigned int wait_time, unsigned char sno);
unsigned char get_frm_up_sn()
{
    return (nw_frm_up_sn++);
}
static int app_get_frm_addr_len(struct frame_nw *frm)
{
    if (frm->addr)
        return 12;
    else
        return 0;
}
static void app_set_last_frame_sno(unsigned char sno)
{
    last_nw_frame_sno = sno;
}
static unsigned int app_get_di(unsigned char *d)
{
    return *(unsigned int *)d;
}
static struct app_data_nw* app_get_app(struct frame_nw *frm, int al)
{
    return ((struct app_data_nw *)&frm->data[al]);
}
static void app_set_frm_head(struct frame_nw *frm, unsigned char addr)
{
    frm->head = 0x68;
    frm->dir = 1;
    frm->prm = 0;
    frm->addr = addr;
    frm->ver = 0;
    frm->rsv = 0;
}
static void app_set_frm_sno(struct app_data_nw *p, unsigned char sno)
{
    p->sno = sno;
    return;
}
static void app_set_frm_tail(struct frame_nw *frm, unsigned short len)
{
    frm->len = len;
    ((unsigned char *)frm)[len - 2] = checksum(((unsigned char *)frm) + 3, len - 5);
    ((unsigned char *)frm)[len - 1] = 0x16;
}
int app_frm_check(unsigned char *buf, int len, unsigned char *frm, int *del)
{
    unsigned int idx = 0, dlen;
    unsigned char *pos;

    pos = memchr(buf, RTSTARTCH, len);

    if (NULL == pos)
    {
        *del = len;
        return -1;
    }
    if (pos >= buf)
    {
        idx = pos - buf;
    }
    else
    {
        return -1;
    }
    if (len >= idx)
    {
        memcpy(frm, &buf[idx], len - idx);
    }
    else
    {
        return -1;
    }

    *del = idx;
    len -= idx;

    if (len < MINLEN)
        return -1;

    dlen = frm[1] + ((unsigned int)frm[2] * 0x100);

    if (dlen > 0x180)
    {
        (*del)++;
        return -1;
    }

    if (len < dlen)
        return -1;

    *del = idx + dlen;

    if (frm[dlen - 1] != 0x16)
        return -1;

    return dlen;
}
static int set_jzq_id(unsigned char *para, unsigned char len)
{
    unsigned char bk_mid[6];

    memcpy(bk_mid, para, len);
#if 0
    for (int i = 0; i < len; i++)
    {
        c = para[i];
        para[i] = bcdtobin(para[i]);
        if (c != bintobcd(para[i]))
        {
            app_frm_negate(E_INVALID_DATA);
            return -1;
        }
    }
#endif

    for (int i = 0; i < len; i++)
    {
        para[i] = (para[i]) % 100;
    }

    rf_set_jzqid(para);
    rf_set_jzqid_nw(bk_mid);
    return 0;
}
static int appgb_ackdn(struct afn_desc_nw *self, struct frame_nw *frm)
{

    if (report != 0 && rf_setappd(APPRCFM, NULL, 0, 0) == 0)
    {
        report = 0;
        rf_setdmmode(DMMD_SUC);
        return 0;
    }

    unsigned char c;
    rf_get_rtmd(&c);
    if (request != 0 && c == 0x02 && rf_setappd(APPRCFM, NULL, 0, 0) == 0)
    {
        request = 0;
        rf_setdmmode(DMMD_SUC);
        return 0;
    }

    return -1;
}
static int appgb_negdn(struct afn_desc_nw *self, struct frame_nw *frm)
{
    if (report != 0 && rf_setappd(APPRCFM, NULL, 0, 0) == 0)
    {
        report = 0;
        rf_setdmmode(DMMD_SUC);
        return 0;
    }

    unsigned char c;
    rf_get_rtmd(&c);
    if (request != 0 && c == 0x02 && rf_setappd(APPRCFM, NULL, 0, 0) == 0)
    {
        request = 0;
        rf_setdmmode(DMMD_SUC);
        return 0;
    }

    return -1;
}
static int appgb_hardinit(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned char buf[0x20];
    // int len = 0;
    struct frame_nw *p = (struct frame_nw *)buf;
    struct app_data_nw *q = app_get_app(p, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    app_frm_confirm(2, last_nw_frame_sno);

    rf_hardinit();

    return 0;
}

static int appgb_parainit(struct afn_desc_nw *self, struct frame_nw *frm)
{
    if (rf_set_clrmt_nw() == 0 && rf_set_slev_nw(2) == 0) //�������������嵵�������ܵ�ǰ�Ƿ����ڳ���
    {

        init_nw_task_info(); //��ʼ����ʱ��ֹͣ�����񣬼���ǰ��״̬
        rf_ctrl_stop();
        app_frm_confirm(2, last_nw_frame_sno); /* wait 2s */
        return 0;
    }
    else
    {
        app_frm_negate(E_OTHER);

        return -1;
    }
}
static int app_frm_negate(unsigned char e_code)
{
    unsigned char buf[0x20];
    struct frame_nw *p = (struct frame_nw *)buf;
    struct app_data_nw *papp = app_get_app(p, 0);

    memset(buf, 0x00, sizeof(buf));

    app_set_frm_head(p, 0);
    app_set_frm_sno(papp, last_nw_frame_sno);

    papp->afn = 0x00;
    papp->di[0] = 0x02;
    papp->di[1] = 0x00;
    papp->di[2] = 0x01;
    papp->di[3] = 0xE8;
    papp->data[0] = e_code;

    app_set_frm_tail(p, MINLEN + 1);
    rf_write(buf, MINLEN + 1, 0);

    return (MINLEN + 1);
}
static int app_frm_confirm(unsigned int wait_time, unsigned char sno)
{
    unsigned char buf[0x20];
    struct frame_nw *p =  (struct frame_nw *)buf;
    struct app_data_nw *papp = app_get_app(p, 0);
    int len = 0;

    memset(&buf[0], 0x00, sizeof(buf));
    app_set_frm_head(p, 0);
    app_set_frm_sno(papp, sno);

    papp->afn = 0x00;
    papp->di[0] = 0x01;
    papp->di[1] = 0x00;
    papp->di[2] = 0x01;
    papp->di[3] = 0xE8;
    papp->data[0] = wait_time % 256;
    papp->data[1] = wait_time / 256;

    len = 2;
    app_set_frm_tail(p, MINLEN + len);
    rf_write(buf, p->len, 5);

    return (MINLEN + len);
}


static int appgb_taskinit(struct afn_desc_nw *self, struct frame_nw *frm)
{
   // unsigned char sta;
    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

#if 0
    clear_task_buf();
    sta = get_nw_task_sta();
    clear_task_info();
    set_nw_task_sta(sta);
    init_nw_cur_task();
#endif

    init_nw_task_info(); //��ʼ����ʱ��ֹͣ�����񣬼���ǰ��״̬

    rt_stop_mnt();
    rt_stop_brd();
    clear_rtparas_para();
    if (_rtparas.mtnum > 0)
    {
        rf_ctrl_stop();
        if (rf_set_begin() == 0 && rf_ctrl_work() == 0) //����ֹͣ�ˣ������������¿���
        {
            app_frm_confirm(2, last_nw_frame_sno); /* wait 2s */
            //rt_selfchk();
        }
        else
            app_frm_negate(err_rt2gb(rf_geterr())); /* negative frame */
    }else
    {
      app_frm_confirm(2, last_nw_frame_sno); /* wait 2s */
    }


    // app_frm_confirm(0, last_nw_frame_sno);
    return 0;
}
static int is_high_data_item(unsigned char ctr,unsigned char len, unsigned char *data)
{
    int i;
    if (len != 2 && len != 4)
    {
        return -1;
    }

    for (i = 0; i < SZ_HIGH_ITEM; i++)
    {
        if (high_item[i].ctrl == ctr
            && high_item[i].len == len
            && 0 == memcmp(high_item[i].data, data, len))
        {
            return 0;
        }
    }
    return -1;
}
static int appgb_add_task(struct afn_desc_nw *self, struct frame_nw *frm)
{
    int start = 0;
   // unsigned char aid[6];
    unsigned char addr[12] = { 0 };
    unsigned char buf[255];
    unsigned char item[255];
    unsigned char itemlen = 0;
    int i;
    memset(&_ntask, 0x00, sizeof (struct ntask));/* clear ntask */
    memset(buf, 0x00, sizeof(buf));
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    struct task_frm_info *p = (struct task_frm_info *)&papp->data[0];
    struct task_buf_info *ptask = (struct task_buf_info *)buf;


    if (frm->len != (MINLEN + IDLEN * 2 + 6 + p->len)) /* ����Ҫ��ַ�� */
    {
        app_frm_negate(E_WRONGFORMAT);
        return 0;
    }

    memcpy(addr, frm->data, IDLEN * 2);

    if (p->pri > 3)
    {
        app_frm_negate(E_WRONGFORMAT);
        return 0;
    }
    if (p->id > MAX_TASK_ID)
    {
        app_frm_negate(E_WRONGFORMAT);
        return 0;
    }
    if (ses_find_task(p->id) != NULL)
    {
        app_frm_negate(E_TASK_REPEAT);
        return 0;
    }


    if ((start = get_645_frame(&p->buf[0], p->len)) >= 0)
    {
        if (start)
        {
            p->len -= start;
            memmove(&p->buf[0], &p->buf[start], p->len);
        }
        if (is_data_all_same(&p->buf[1], IDLEN, 0x99) && p->rep != 0) //�㲥��Ӧ����Ҫ��Ӧ
        {
            app_frm_negate(E_WRONGFORMAT);
            return 0;
        }

        if (_rtparas.cycle > 0
            && 0 == is_data_all_same(ptask->add, IDLEN, 0x99)
            && (p->pri == TASK_PRI_2 || p->pri == TASK_PRI_3)
            && is_high_data_item(p->buf[8],p->buf[9], &p->buf[10]) >= 0)
        {
            ptask->pre_pri = p->pri;//����ԭʼ���ȼ�
            p->pri = TASK_PRI_1;
            ptask->pri_chang = 1;

        }

        memcpy(ptask->add, &p->buf[1], IDLEN);
        ptask->pro = DLT64507;
        if (0 == is_data_all_same(ptask->add, IDLEN, 0x99))
        {
            itemlen = 1;
            itemlen += p->buf[9];//len
            item[0] = p->buf[8];//ctrl
          for (i = 1; i < itemlen; i++)//item
          {
            //  item[i] = p->buf[9 + i]- 0x33;
              item[i] = p->buf[9 + i];
          }

           add_task_setmtitem(ptask->add, 4, ptask->pro, item, itemlen);
        }

    }
    else //188Э��
    {
        if (frm->addr == 0)
        {
            app_frm_negate(E_WRONGFORMAT);
            return 0;
        }
        memcpy(ptask->add, &frm->data[6], IDLEN);
        ptask->pro = DLT188;
        add_task_setmtitem(ptask->add, 0, ptask->pro, &p->buf[0], p->len);
    }
    if (ptask->pro == DLT188)
    {
        set_mt_pro(ptask->add, 0, 0x03);
    }
    else
    {
        set_mt_pro(ptask->add, 0, ptask->pro);
    }
    memcpy((unsigned char *)&ptask->frm.id, &papp->data[0], p->len + TASK_FRM_DEFAULT_LEN);

    if (0 == is_data_all_same(ptask->add, IDLEN, 0x99)
        && (p->pri == TASK_PRI_2 || p->pri == TASK_PRI_3)) //��2��3����·������
    {
        clear_mt_cm1suc_flag(ptask->add); //�ǵ㳭���򽫸ñ��ɹ���־���
#if 0
        if (is_task_pri_need_higher(ptask->add) >= 0)
        {
            p->pri = TASK_PRI_1;
        }
#endif
    }


    if (ses_add_task(ptask) < 0)
    {
        app_frm_negate(E_TASK_BUF_FULL);
        return 0;
    }

    app_frm_confirm(0, last_nw_frame_sno);
    return 0;
}
static int appgb_del_task(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    struct task_frm_info *ptask = (struct task_frm_info *)papp->data;
   // struct mtinfo *mt;
    unsigned int tid;

    tid =  get_nw_task_id(TASK_EXE_RT);
    if (frm->len != (MINLEN + nw_addr_len + 2))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    if (ptask->id == tid)
    {
        app_frm_negate(E_OTHER);
        return 0;
#if 0
      //  if ((mt = db_find(nw_task.appid)) != NULL)
       // {
         //   mt->node.envi |= NCMD1SUC;  //���Ըñ����г����������ݱ�ʶȫ��������ɱ�־��Ϊ��Ч
       // }
        rf_ctrl_stop();
        if (rf_set_begin() == 0 && rf_ctrl_work() == 0) //����ֹͣ�ˣ������������¿���
        {
            //rt_selfchk();
        }
#endif
    }

    if (ses_del_task(ptask->id) < 0)
    {
        app_frm_negate(E_NO_TASK);
        return 0;
    }


    app_frm_confirm(0, last_nw_frame_sno);
    return 0;
}
static int app_frm_normal(unsigned char *data, unsigned int len)
{
    unsigned char buf[0x200];
    struct frame_nw *p = (struct frame_nw *)buf;
    struct app_data_nw *papp = app_get_app(p, 0);

    memset(buf, 0x00, sizeof(buf));
    app_set_frm_head(p, 0);

    len = len + MINLEN;
    memcpy((unsigned char *)papp, data, len);
    app_set_frm_sno((struct app_data_nw *)&p->data[nw_addr_len], last_nw_frame_sno);
    app_set_frm_tail(p, len);

    rf_write(buf, p->len, 0);
    return (len);
}
static int appgb_get_task_num(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned short size, cnt;
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    ses_get_task_info(&cnt, &size);
    papp->data[0] = cnt % 256;
    papp->data[1] = cnt / 256;
    app_frm_normal((unsigned char *)papp, 2);
    return 0;
}
static int appgb_get_task_list(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned short tid, tbuf[15];
    unsigned char num;

    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len + 3))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    if (papp->data[2] > 15)
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    tid = papp->data[0] + papp->data[1] * 256;
    num = ses_get_task_list(tid, papp->data[2], tbuf);
    papp->afn = 0x02;
    papp->di[0] = 0x04;
    papp->di[1] = 0x02;
    papp->di[2] = 0x04;
    papp->di[3] = 0xE8;
    papp->data[0] = num;
    papp->data[1] = 0;
    memcpy(&papp->data[2], tbuf, num * 2);
    app_frm_normal((unsigned char *)papp, 2 + num * 2);
    return 0;
}
static int appgb_get_task_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned short t;
    unsigned char buf[0x100 + MINLEN];
    struct task_buf_info *p;
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    struct app_data_nw *q = (struct app_data_nw *)buf;
    struct task_frm_info *ptask = (struct task_frm_info *)q->data;
    if (frm->len != (MINLEN + nw_addr_len + 2))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    t = papp->data[0] + papp->data[1] * 256;
    if ((p = ses_find_task(t)) == NULL)
    {
        app_frm_negate(E_NO_TASK);
        return 0;
    }

    memcpy(q->data, (unsigned char*)&p->frm.id, p->frm.len + TASK_FRM_DEFAULT_LEN);

    q->afn = 0x02;
    q->di[0] = 0x05;
    q->di[1] = 0x02;
    q->di[2] = 0x04;
    q->di[3] = 0xE8;
    memmove(&q->data[5 + IDLEN], &q->data[5], p->frm.len + TASK_FRM_DEFAULT_LEN - 5);
    if (p->pri_chang == 1)//�������ݱ�ʶ���ȼ����ı䣬��ȡ��ʱ�������⴦��
    {
        q->data[2] &= ~0x0F;
        q->data[2] |= p->pre_pri;
    }
    q->data[3] = 0x01;
    q->data[4] = 0x00;
    memcpy(&q->data[5], p->add, IDLEN);
    app_frm_normal((unsigned char *)q, p->frm.len + TASK_FRM_DEFAULT_LEN + IDLEN);
    return 0;
}

static int appgb_get_task_cap(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned short cnt, size, cap;
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    ses_get_task_info(&cnt, &size);
   // cap = (TASK_BUF_SIZE - size) / 24;
    cap = (TASK_BUF_SIZE - size) / (24+6+2);

    if ((cnt + cap) > MAX_CHK_TASK_NUM)
    {
        if (cnt < MAX_CHK_TASK_NUM)
          cap = MAX_CHK_TASK_NUM - cnt;
        else
          cap = 0;
    }
    papp->data[0] = cap % 256;
    papp->data[1] = cap / 256;
    app_frm_normal((unsigned char *)papp, 2);
    return 0;
}
static int appgb_add_broad_task(struct afn_desc_nw *self, struct frame_nw *frm)
{
    app_frm_negate(E_OTHER);
    return 0;

}
void nw_task_start()
{
    // nw_task.sta = NW_TASK_RUN;
    restart_flag = 1;
    if (rf_set_begin() == 0 && rf_ctrl_work() == 0)
    {
        app_frm_confirm(2, last_nw_frame_sno); /* wait 2s */
        //rt_selfchk();
    }
    else
        app_frm_negate(err_rt2gb(rf_geterr())); /* negative frame */

    // return 0;

}
static int appgb_start_task(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != MINLEN)
    {
        app_frm_negate(E_WRONGFORMAT);
        return 0;
    }
#if 0
    if (get_nw_task_sta == NW_TASK_RUN && (_rtparas.state & STASTMASK) == STARUN)
    {
        app_frm_confirm(2, last_nw_frame_sno);
        return 0; //Ҫ��Ҫ����������ط���ȷ��
    }
#endif
    nw_task_start();

    return 0;
}
void nw_task_stop()
{
    // nw_task.sta = NW_TASK_PAUSE;
    if (rf_ctrl_stop() == 0)
    {
        app_frm_confirm(5, last_nw_frame_sno); /* wait 2s */
        //  return 0;
    }
    else
    {
        app_frm_negate(err_rt2gb(rf_geterr())); /* negative frame */
        //  return -1;
    }

}
int nw_report_wkstate()
{
    unsigned char buf[0x100];
    struct frame_nw *p = (struct frame_nw *)&buf;
    struct app_data_nw *q = (struct app_data_nw *)p->data;

    /* ��֯376.2���� */
    p->head = 0x68;
    p->dir = 1;
    p->prm = 1;
    p->addr = 0;
    p->ver = 0;
    p->rsv = 0;
    q->afn = 0x05;
    q->di[0] = 0x04;
    q->di[1] = 0x05;
    q->di[2] = 0x05;
    q->di[3] = 0xE8;

    app_set_frm_sno(q, 1);
    app_set_frm_tail(p, MINLEN);

    rf_write(buf, MINLEN, 0);
    report = 1;
    return 0;

}
int nw_report_task_state(unsigned short task_id, unsigned char *add, unsigned char sta)
{
    unsigned char buf[0x100];
    struct frame_nw *p = (struct frame_nw *)&buf;
    struct app_data_nw *q = (struct app_data_nw *)p->data;
    struct report_task_status *psta = (struct report_task_status *)q->data;
    /* ��֯376.2���� */
    p->head = 0x68;
    p->dir = 1;
    p->prm = 1;
    p->addr = 0;
    p->ver = 0;
    p->rsv = 0;
    q->afn = 0x05;
    q->di[0] = 0x05;
    q->di[1] = 0x05;
    q->di[2] = 0x05;
    q->di[3] = 0xE8;

    psta->id = task_id;
    memcpy(psta->add, add, IDLEN);

    psta->sta = sta;
#if 0
    if (sta == TASK_STATUS_OTHER)
    {
        set_mt_task_fail_times(add, 1);
    }
#endif
    app_set_frm_sno(q, 1);
    app_set_frm_tail(p, MINLEN + sizeof(struct report_task_status));

    rf_write(buf, p->len, 0);
    report = 1;
    return 0;
}
int report_task_fail(unsigned char *aid,unsigned int sn, int code)
{
    unsigned char tappid[IDLEN];
    unsigned char aidnull[IDLEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    unsigned int tid;
    if (0 == memcmp(aid, aidnull, IDLEN))
    {
        return -1;
    }
    get_nw_task_appid(sn, tappid);
    if (0 != memcmp(aid, tappid, IDLEN))
    {
        return -1;
    }

    tid = get_nw_task_id(sn);
    if (_rtparas.dcviv != TYPE53)
      {
        id_bintobcd(tappid);
        reverse(tappid, IDLEN);
      }
    
    nw_report_task_state(tid, tappid, code);
    return 0;


  //  del_cur_task(sn);
}


static int appgb_halt_task(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    //unsigned char tappid[IDLEN];
    if (frm->len != MINLEN)
    {
        app_frm_negate(E_WRONGFORMAT);
        return 0;
    }
    nw_task_stop();
   // set_nw_task_sta(NW_TASK_PAUSE);

#if 0
    if (nw_task.tid != TASK_ID_INVALID) //���ĸ������ȼ����񣬵��ǵ�ǰ������ִ�е�����
    {
        report_task_fail_del_task(TASK_STATUS_OTHER);
    }
#endif
    return 0;
}
static int appgb_get_vid_ver(struct afn_desc_nw *self, struct frame_nw *frm)
{
    // unsigned char time[6];
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    const unsigned char version_word[] = "SETR", pver_word[] = "ESRT";

    if ((MINLEN + 4) == frm->len && memcmp(&papp->data[0], pver_word, 4) == 0)
    {
#if 0
        get_compile_info(&time[0]);
        papp->data[4] = time[3];
        papp->data[5] = time[4];
        papp->data[6] = time[5];
#endif
        papp->data[4] = RT_INT_VERDATA;
        papp->data[5] = RT_INT_VERDATA >> 8;
        papp->data[6] = RT_INT_VERDATA >> 16;

    }
    else
        if ((MINLEN + 0) == frm->len)
        {
            papp->data[6] = RT_VERDATA >> 16;
            papp->data[5] = RT_VERDATA >> 8;
            papp->data[4] = RT_VERDATA;
        }
        else
        {
            app_frm_negate(E_LENGTH);
            return 0;
        }
    memcpy(&papp->data[0], (unsigned char *)version_word, 4);
    papp->data[7] = (unsigned char)(RT_VERSION & 0xff);
    papp->data[8] = (unsigned char)(RT_VERSION >> 8);

    app_frm_normal((unsigned char *)papp, 9);
    return 0;
}
static int appgb_get_rt_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *app = app_get_app(frm, nw_addr_len);
    int t;
    int datalen;
    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    app->afn = 0x03;
    app->di[0] = 0x02;
    app->di[1] = 0x03;
    app->di[2] = 0x00;
    app->di[3] = 0xE8;
    memcpy(&app->data[0], (unsigned char *)rt_info_nw, sizeof(rt_info_nw));

    rf_get_jzqid_nw(app->data + 6, &datalen);
    //  for (int i = 0; i < datalen; ++i)
    //      app->data[6 + i] = bintobcd(app->data[6 + i]);

    t = _rtparas.mtnum;
    app->data[14] = t & 0xff;
    app->data[15] = t >> 8;

    app_frm_normal((unsigned char *)app, sizeof(rt_info_nw));

    return 0;
}

static int appgb_get_mnode_addr(struct afn_desc_nw *self, struct frame_nw *frm)
{
    int datalen = IDLEN;
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    rf_get_jzqid_nw(papp->data, &datalen);

    //for (int i = 0; i < datalen; ++i)
    //  papp->data[i] = bintobcd(papp->data[i]);

    app_frm_normal((unsigned char *)papp, 6);
    return 0;
}
static int appgb_get_overtime(struct afn_desc_nw *self, struct frame_nw *frm)
{
    //int pos;
    struct app_data_nw *app = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + 7 + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    app->afn = 0x03;
    app->di[0] = 0x04;
    app->di[1] = 0x03;
    app->di[2] = 0x04;
    app->di[3] = 0xE8;
    app->data[8] = app->data[6];
    //db_find(AID, app->data, &pos);
    // app->data[6] = ram_var[pos].hop * 1;
    app->data[6] = 0; //�˴���ʱд0�������������ٸģ�������
    app->data[7] = 0;

    app_frm_normal((unsigned char *)app, 9);
    return 0;
}
static int appgb_anode_count(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    int num = get_gdnode_cnt(0);
    papp->data[0] = num;
    papp->data[1] = (num >> 8);

    app_frm_normal((unsigned char *)papp, 2);

    return 0;
}


static int appgb_gdnode_count(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    int num = get_gdnode_cnt(1);
    papp->data[0] = num;
    papp->data[1] = (num >> 8);

    app_frm_normal((unsigned char *)papp, 2);

    return 0;
}

static int appgb_get_gdnode_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
  unsigned int a_count = 0;

  unsigned char mtinfo_len;
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

  if (frm->len != (MINLEN + 3 + nw_addr_len))
  {
    app_frm_negate(E_LENGTH);
    return 0;
  }

  //start_num = ((unsigned int)papp->data[1] << 8) + papp->data[0];
  a_count = papp->data[2];
  if (a_count > 20)
  {
    app_frm_negate(E_INVALID_DATA);
    return 0;
  }

  papp->afn = 0x03;
  papp->di[0] = 0x0A;
  papp->di[1] = 0x03;
  papp->di[2] = 0x04;
  papp->di[3] = 0xE8;


  if (rf_get_nw_mtinfo(papp->data, &papp->data[3], &mtinfo_len, 1) < 0)
  {
    app_frm_negate(E_INVALID_DATA);
    return -1;
  }
  papp->data[2] = mtinfo_len / GDIDLEN;

  //extern unsigned int mtnum_f;
  int num = get_gdnode_cnt(1);
  papp->data[0] = num;
  papp->data[1] = (num >> 8);

  app_frm_normal((unsigned char *)papp, mtinfo_len + 3);

  return 0;
}

static int appgb_get_node_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
  unsigned int a_count = 0;

  unsigned char mtinfo_len;
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

  if (frm->len != (MINLEN + 3 + nw_addr_len))
  {
    app_frm_negate(E_LENGTH);
    return 0;
  }

  //start_num = ((unsigned int)papp->data[1] << 8) + papp->data[0];
  a_count = papp->data[2];
  if (a_count > 20)
  {
    app_frm_negate(E_INVALID_DATA);
    return 0;
  }

  papp->afn = 0x03;
  papp->di[0] = 0x06;
  papp->di[1] = 0x03;
  papp->di[2] = 0x04;
  papp->di[3] = 0xE8;


  if (rf_get_nw_mtinfo(papp->data, &papp->data[3], &mtinfo_len, 0) < 0)
  {
    app_frm_negate(E_INVALID_DATA);
    return -1;
  }
  papp->data[2] = mtinfo_len / IDLEN;

  //extern unsigned int mtnum_f;
  int num = get_gdnode_cnt(0);
  papp->data[0] = num;
  papp->data[1] = (num >> 8); 

  app_frm_normal((unsigned char *)papp, mtinfo_len + 3);

  return 0;
}


static int appgb_get_reg_state(struct afn_desc_nw *self, struct frame_nw *frm)
{

    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }
    extern int get_node_reg_sta();
    if (get_node_reg_sta())
    {
        papp->data[0] = 1;
    }
    else
    {
        papp->data[0] = 0;
    }
    app_frm_normal((unsigned char *)papp, 1);

    return 0;

}


static int appgb_anode_relay_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
    //int   num = 0;
    struct mtinfo *mt = NULL;
    struct mtinfo *mt_v = NULL;
    struct rpinfo *rp;
    int datalen = 6;
    unsigned char aid[6];
    unsigned char sinkid[2];
    unsigned short t = 0; 
    struct app_data_nw *app = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + 6 + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    if (is_data_all_same(&app->data[0], IDLEN, 0x99))
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }
    app->afn = 0x03;
    app->di[0] = 0x08;
    app->di[1] = 0x03;
    app->di[2] = 0x04;
    app->di[3] = 0xE8;
    memcpy(&aid[0], &app->data[0], 6);

    for (int i = 0; i < IDLEN; ++i) aid[i] = bcdtobin(aid[i]);

    if ((mt = db_find(aid)) == NULL)
    {
        app_frm_negate(E_NO_METERNO);
        return 0;
    }

    rp = db_getfrp(mt);
    if (rp && ((mt->node.viv & NNDMASK) != 0x03))
    {
        if ((mt = db_find(&rp->rpid[0])) == NULL)
        {
            app_frm_negate(E_OTHER);
            return 0;
        }
        else
        {
            if ((mt->node.sno[1] == 0x00) && (mt->node.sno[0] == 0x7D))
            {
                rf_get_jzqid_nw(&app->data[6], &datalen);
            }
            else
            {
                memcpy(&app->data[6], &mt->node.id, IDLEN);
                for (int i = 0; i < IDLEN; ++i) app->data[6 + i] = bintobcd(app->data[6 + i]);
            }
        }

        app->data[12] = (rp->node.rsv1 & SIGMASK)*2;//0~31`
//      if ((rp->node.succtms + rp->node.failtms) > 0)
//      {
//          app->data[12] = rp->node.succtms * 31 / (rp->node.succtms + rp->node.failtms);
//      }
        //�ŵ�������ʱͨ�����ַ�������
    }
    else if (mt->fsid != 0xFFFF && ((mt->node.viv & NNDMASK) != 0x03)) 
    {
      t = nl_get_panid();
      sinkid[0] = (t & 0xFF) % 0x63;
      sinkid[1] = ((t >> 8) & 0xFF) % 0x63; 
      if (mt->fsid == (sinkid[1] * 256 + sinkid[0])) 
      {
        rf_get_jzqid_nw(&app->data[6], &datalen);
      }
      else
      {
        mt_v = db_vsid(mt->fsid);
        memcpy(&app->data[6], &mt_v->node.id, IDLEN);
        for (int i = 0; i < IDLEN; ++i)
          app->data[6 + i] = bintobcd(app->data[6 + i]);
      }
      app->data[12] = mt->signal;
    }
    else
    {
      memset(&app->data[6], 0x00, IDLEN);
      app->data[12] = 0; 
    }
    //��û�и��ڵ��ʱ�򣬴˴�����������
    app_frm_normal((unsigned char *)app, 13);
    return 0;

}

static int appgb_get_pri_tmout(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *app = app_get_app(frm, nw_addr_len);
    unsigned int t0, t1, t2, t3;
    //int i = 0;
    struct nw_pri_tmout *ptm = (struct nw_pri_tmout *)app->data;
    app->afn = 0x03;
    app->di[0] = 0x0B;
    app->di[1] = 0x03;
    app->di[2] = 0x00;
    app->di[3] = 0xE8;

    get_task_pri_tmout(&t0, &t1, &t2, &t3);

    ptm->tm = t0;
    ptm = (struct nw_pri_tmout *)ptm->data;
    ptm->tm = t1;
    ptm = (struct nw_pri_tmout *)ptm->data;
    ptm->tm = t2;
    ptm = (struct nw_pri_tmout *)ptm->data;
    ptm->tm = t3;


    app_frm_normal((unsigned char *)app, 8);
    return 0;



}
static int appgb_get_node_phs(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct mtinfo *mt = NULL;
   // struct rpinfo *rp;
   // int datalen = 6;
    unsigned char aid[6],taid[6];
    unsigned char info[255];
    int num;

    memset(info, 0x00, sizeof(info));
    struct app_data_nw *app = app_get_app(frm, nw_addr_len);
    struct node_phs *pnode = (struct node_phs *)info;
   // struct phs_batch *pbatch = (struct phs_batch *)app->data;

    num = app->data[0];

    if (frm->len != (MINLEN + 1 + num*IDLEN))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    app->afn = 0x03;
    app->di[0] = 0x0C;
    app->di[1] = 0x03;
    app->di[2] = 0x04;
    app->di[3] = 0xE8;

    app->data[0] = num;

    for (int j = 0; j < num; j++)
    {
        memcpy(&aid[0], &app->data[1 + j * IDLEN], IDLEN);
        memcpy(&taid[0], &app->data[1 + j * IDLEN], IDLEN);
        for (int i = 0; i < IDLEN; ++i) aid[i] = bcdtobin(aid[i]);

        if ((mt = db_find(aid)) == NULL)
        {
            memcpy(pnode->id, taid, IDLEN);
            pnode->phs_val = PHS_VAL_UN;
            pnode->phs_para = PHS_PARA_UNKOWN;
            pnode->pro = PHS_PRO_UN;
        }
        else
        {
            memcpy(pnode->id, taid, IDLEN);
            pnode->phs_val = (mt->node.phase & NPAMASK) >> 6;
            if (pnode->phs_val == 1)
            {
                pnode->phs_val = PHS_VAL_A;
            }
            else if (pnode->phs_val == 2)
            {
                pnode->phs_val = PHS_VAL_B;
            }
            else if (pnode->phs_val == 3)
            {
                pnode->phs_val = PHS_VAL_C;
            }
            else
            {
                pnode->phs_val = PHS_VAL_UN;
            }
            pnode->phs_para = PHS_PARA_SUR;
            pnode->pro = (mt->node.attr & NPROMASK)>>1;
            if (pnode->phs_val == PHS_VAL_UN)
            {
                pnode->phs_para = PHS_PARA_UNKOWN;
              //  pnode->pro = PHS_PRO_UN;
            }

        }
        pnode = (struct node_phs *)pnode->data;
    }

    memcpy(&app->data[1], info, num * 8);

    app_frm_normal((unsigned char *)app, num * 8+1);
    return 0;
}
static int appgb_get_batch_phs(struct afn_desc_nw *self, struct frame_nw *frm)
{
   // struct mtinfo *mt = NULL;
   // struct rpinfo *rp;
   // int datalen = 6;
    //unsigned char aid[6], taid[6];
    unsigned char info[255];
    //int pos;
    unsigned char mtinfo_len;
    memset(info, 0x00, sizeof(info));
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
   // struct node_phs *pnode = (struct node_phs *)info;

   // pos = papp->data[0];

    if (frm->len != (MINLEN + 3))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    papp->afn = 0x03;
    papp->di[0] = 0x0D;
    papp->di[1] = 0x03;
    papp->di[2] = 0x04;
    papp->di[3] = 0xE8;

    if (rf_get_nw_mt_phs(papp->data, &papp->data[3], &mtinfo_len) < 0)
    {
        app_frm_negate(E_INVALID_DATA);
        return -1;
    }
    papp->data[2] = mtinfo_len / 8;

    //extern unsigned int mtnum_f;
    int num = get_gdnode_cnt(0);
    papp->data[0] = num;
    papp->data[1] = (num >> 8); 

    app_frm_normal((unsigned char *)papp, mtinfo_len + 3);

    return 0;
}

static int gdafn_get_area_indb(struct afn_desc_nw *self, struct frame_nw *frm)
{
   // struct mtinfo *mt = NULL;
   // struct rpinfo *rp;
   // int datalen = 6;
    //unsigned char aid[6], taid[6];
    unsigned char info[255];
    //int pos;
    unsigned char mtinfo_len;
    memset(info, 0x00, sizeof(info));
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
   // struct node_phs *pnode = (struct node_phs *)info;

   // pos = papp->data[0];

    if (frm->len != (MINLEN + 3))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    papp->afn = 0x03;
    papp->di[0] = 0x0E;
    papp->di[1] = 0x03;
    papp->di[2] = 0x04;
    papp->di[3] = 0xE8;

    if (rf_get_nw_area_indb(papp->data, &papp->data[3], &mtinfo_len) < 0) 
    {
        app_frm_negate(E_INVALID_DATA);
        return -1;
    }
    papp->data[2] = mtinfo_len / 7;

    int num = get_gdnode_cnt(0);
    papp->data[0] = num;
    papp->data[1] = (num >> 8); 

    app_frm_normal((unsigned char *)papp, mtinfo_len + 3);

    return 0;
}

static int gdafn_get_area_outdb(struct afn_desc_nw *self, struct frame_nw *frm)
{
   // struct mtinfo *mt = NULL;
   // struct rpinfo *rp;
   // int datalen = 6;
    //unsigned char aid[6], taid[6];
    unsigned char info[255];
    //int pos;
    unsigned char mtinfo_len;
    memset(info, 0x00, sizeof(info));
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
   // struct node_phs *pnode = (struct node_phs *)info;

   // pos = papp->data[0];

    if (frm->len != (MINLEN + 3))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    papp->afn = 0x03;
    papp->di[0] = 0x0F;
    papp->di[1] = 0x03;
    papp->di[2] = 0x04;
    papp->di[3] = 0xE8;

    papp->data[2] = 0;

    //extern unsigned int mtnum_f;
    papp->data[0] = 0;
    papp->data[1] = 0;

    app_frm_normal((unsigned char *)papp, mtinfo_len + 3);

    return 0;
}



static int appgb_set_mnode_addr(struct afn_desc_nw *self, struct frame_nw *frm)
{
    //unsigned char  i;
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + IDLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    /* ���ڵ��ַ������ȫ00��ȫ99 */
    if (is_data_all_same(&papp->data[0], IDLEN, 0x00) || is_data_all_same(&papp->data[0], IDLEN, 0x99))
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    if (set_jzq_id(papp->data, IDLEN) == 0)
        app_frm_confirm(1, last_nw_frame_sno); /* wait 1s */;

    return 0;
}




static int appgb_add_node(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned int i, len;//, ret;
    struct app_data_nw *papp;

    papp = app_get_app(frm, nw_addr_len);

    len = frm->len - MINLEN;
    if (0 == len)
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    len -= 1;
    if (len % 6)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }
    if (papp->data[0] > 20)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    for (int i = 0; i < papp->data[0]; ++i)
    {
        reverse(papp->data + i * IDLEN + 1, IDLEN);
        if (is_allbcd(papp->data + i * IDLEN + 1, IDLEN) != 0 || (MeterID_IsBroadcast(papp->data + i * IDLEN + 1) == 1)) 
        {
            app_frm_negate(E_INVALID_DATA);
            return 0;
        }

        if (rf_set_addmt_nw(papp->data + i * IDLEN + 1, 0) != 0)
        {
            app_frm_negate(err_rt2gb(rf_geterr()));
            return 0;
        }
    }
    app_frm_confirm(0, last_nw_frame_sno);

    int state = rt_newdb();
    if(state == 1)
    {
        _rtparas.dpsk = 0x00;
        _rtparas.dpsk |= DPSKFORCE;
      //  _rtparas.dbfirst = 0; //only when first or para init is reset to 0
    }

    if ((_share.conswitch & 0x01) == 0 && (_share.flswitch & 0x01) == 1)
    {
        _rtparas.dpsk = 0x00;
    }

    return 0;
}

static int appgb_add_gdnode(struct afn_desc_nw *self, struct frame_nw *frm)
{
  unsigned int i, len; //, ret;
  struct app_data_nw *papp;

  papp = app_get_app(frm, nw_addr_len);

  len = frm->len - MINLEN;
  if (0 == len)
  {
    app_frm_negate(E_LENGTH);
    return 0;
  }

  len -= 1;
  if (len % 18)
  {
    app_frm_negate(E_INVALID_DATA);
    return 0;
  }
  if (papp->data[0] > 20)
  {
    app_frm_negate(E_INVALID_DATA);
    return 0;
  }

  for (int i = 0; i < papp->data[0]; ++i)
  {
    reverse(papp->data + i * GDIDLEN + 1, IDLEN);
    if (is_allbcd(papp->data + i * GDIDLEN + 1, IDLEN) != 0 || (MeterID_IsBroadcast(papp->data + i * GDIDLEN + 1) == 1)) 
    {
      app_frm_negate(E_INVALID_DATA);
      return 0;
    }

    if (rf_set_addmt_nw(papp->data + i * GDIDLEN + 1, 1) != 0) 
    {
      app_frm_negate(err_rt2gb(rf_geterr()));
      return 0;
    }
  }
  app_frm_confirm(0, last_nw_frame_sno);

 

  int state = rt_newdb();
  if (state == 1)
  {
    _rtparas.dpsk = 0x00;
    _rtparas.dpsk |= DPSKFORCE;
    //  _rtparas.dbfirst = 0; //only when first or para init is reset to 0
  }

  if ((_share.conswitch & 0x01) == 0 && (_share.flswitch & 0x01) == 1)
  {
    _rtparas.dpsk = 0x00;
  }

  return 0;
}


static int appgb_del_node(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned int i, len;//, err = 0;
    unsigned char taskAppId[IDLEN];
    unsigned char tmpId[IDLEN];

    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    len = frm->len - MINLEN;

    if (papp->data[0] > 16)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    if (0 == len)
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    len -= 1;
    if (len % 6)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    len /= 6;
    for (i = 0; i < len; i++)
    {
        reverse(papp->data + i * IDLEN + 1, IDLEN);
        if (is_allbcd(papp->data + i * IDLEN + 1, IDLEN) != 0)
        {
            app_frm_negate(E_INVALID_DATA);
            return 0;
        }
        if (rf_set_delmt_nw(papp->data + i * IDLEN + 1, 0) != 0)
        {
            app_frm_negate(err_rt2gb(rf_geterr()));
            return 0;
        }
        else
        {
            memcpy(tmpId, papp->data + i * IDLEN + 1, IDLEN);
            id_bcdtobin(tmpId);
            get_nw_task_appid(TASK_EXE_RT, taskAppId);

            if (0 == memcmp(tmpId, taskAppId, IDLEN))//ɾ���Ľڵ㣬��������ִ������Ľڵ�
            {
            app_frm_negate(E_OTHER);
            return 0;
#if 0
                id_bintobcd(tmpId);
                //reverse(nw_task.appid, IDLEN);
                nw_report_task_state(nw_task.tid, nw_task.appid, TASK_STATUS_OTHER);
                memcpy(nw_task.appid, taskAppId, IDLEN);
                del_cur_task();
#endif
            }
        }
    }

    app_frm_confirm(0, last_nw_frame_sno);
    return 0;

}

static int appgb_del_gdnode(struct afn_desc_nw *self, struct frame_nw *frm)
{
    unsigned int i, len;//, err = 0;
    unsigned char taskAppId[IDLEN];
    unsigned char tmpId[IDLEN];

    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    len = frm->len - MINLEN;

    if (papp->data[0] > 16)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    if (0 == len)
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    len -= 1;
    if (len % 18)
    {
        app_frm_negate(E_INVALID_DATA);
        return 0;
    }

    len /= 18;
    for (i = 0; i < len; i++)
    {
        reverse(papp->data + i * GDIDLEN + 1, IDLEN);
        if (is_allbcd(papp->data + i * GDIDLEN + 1, IDLEN) != 0)
        {
            app_frm_negate(E_INVALID_DATA);
            return 0;
        }
        if (rf_set_delmt_nw(papp->data + i * GDIDLEN + 1, 1) != 0)
        {
            app_frm_negate(err_rt2gb(rf_geterr()));
            return 0;
        }
        else
        {
            memcpy(tmpId, papp->data + i * GDIDLEN + 1, IDLEN);
            id_bcdtobin(tmpId);
            get_nw_task_appid(TASK_EXE_RT, taskAppId);

            if (0 == memcmp(tmpId, taskAppId, IDLEN))//ɾ���Ľڵ㣬��������ִ������Ľڵ�
            {
            app_frm_negate(E_OTHER);
            return 0;
#if 0
                id_bintobcd(tmpId);
                //reverse(nw_task.appid, IDLEN);
                nw_report_task_state(nw_task.tid, nw_task.appid, TASK_STATUS_OTHER);
                memcpy(nw_task.appid, taskAppId, IDLEN);
                del_cur_task();
#endif
            }
        }
    }

    app_frm_confirm(0, last_nw_frame_sno);
    return 0;

}





static int appgb_allow_event(struct afn_desc_nw *self, struct frame_nw *frm)
{
    int addr_len = 0;

    addr_len = app_get_frm_addr_len(frm);
    struct app_data_nw *papp = app_get_app(frm, addr_len);


    if ((addr_len + MINLEN + 1) == frm->len)
    {
        if (papp->data[0] == 1)
        {
            _rtparas.wkstate |= RPTSWION;
        }
        else if (papp->data[0] == 0)
        {
            _rtparas.wkstate &= ~RPTSWIMASK;
        }
        else
        {
            app_frm_negate(E_INVALID_DATA);
            return 0;
        }
        app_frm_confirm(0, last_nw_frame_sno);
        return 0;
    }

    app_frm_negate(E_LENGTH);
    return 0;

}

unsigned char appgb_reg_v = 0;  /* 1��ִ��5����0��ִ��4�� */
static int appgb_activate_anode_reg(struct afn_desc_nw *self, struct frame_nw *frm)
{
    /* afn = 11,fn = 5, active meter to register */
    unsigned int time;

     appgb_reg_v = 1;  /* ��ִ��V��ע�� */
    time = 150 / 4; //�ݶ�2.5h
//    memset(&mt_up, 0x00, sizeof(struct node_mtup));
    if (rf_autoreg(time) < 0)
    {
        app_frm_negate(E_OTHER);
        return -1;
    }
    _rtparas.wkstate |= REGSWION;

    app_frm_confirm(60 + 5, last_nw_frame_sno);
    return 0;

}
extern unsigned char flag_reg_v;
static int appgb_stop_anode_reg(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return 0;
    }

    ses_set_search_time(0);  /* V�����ѱ�ʱ�� */
    _rtparas.wkstate &= ~REGSWIMASK;
    _rtparas.state &= ~STARMASK;
    _task.flag = TSNO;
    set_rts_value(CHN_38_1, 1);
    flag_reg_v = 0;
    appgb_reg_v = 1;
    app_frm_confirm(0, last_nw_frame_sno);

    return 0;
}
int nw_report_event_new(unsigned char *mtid, unsigned char *data, int datalen, unsigned char event)
{
    assert(mtid);
    assert(data);

    int len;

    if ((_rtparas.wkstate & RPTSWIMASK) != RPTSWION)
    {
        return 0;
    }

    unsigned char t[0x100];
    struct frame_nw *p = (struct frame_nw *)&t;
    struct app_data_nw *q = (struct app_data_nw *)&p->data[IDLEN * 2];

    /* ��֯376.2���� */
    p->head = 0x68;
    p->dir = 1;
    p->prm = 1;
    p->addr = 1;
    p->ver = 0;
    p->rsv = 0;

    memcpy(&p->data[0], mtid, IDLEN);
    id_bintobcd(&p->data[0]);
    reverse(&p->data[0], 6); //�˴���ַ��Ҫ����
    rf_get_jzqid_nw(&p->data[IDLEN], &len);
    // id_bintobcd(&p->data[IDLEN]); //�˴�������������
//reverse(&p->data[IDLEN], IDLEN); //�˴���ַ��Ҫ����

    q->afn = 0x05;
    q->di[0] = 0x02;
    q->di[1] = 0x05;
    q->di[2] = 0x05;
    q->di[3] = 0xE8;

    q->data[0] = orgframe645(mtid, data, datalen, &q->data[1]);

    app_set_frm_sno(q, get_frm_up_sn());
    app_set_frm_tail(p, MINLEN + IDLEN * 2 + 1 + q->data[0]);

    rf_write(t, p->len, 0);
    report = 1;
    return 0;
}
int nw_report_node_new(unsigned char *mtid, unsigned char *cid, unsigned char pro)
{
    unsigned int pos;
    unsigned char t[0x100];
    unsigned char id[IDLEN];
    struct frame_nw *p = (struct frame_nw *)&t;
    struct app_data_nw *q = (struct app_data_nw *)&p->data[0];

    if ((_rtparas.wkstate & REGSWIMASK) != REGSWION) /*���عر����ϱ�*/
        return 0;
#if 0
    for (int k = 0; k < IDLEN; ++k) 
      {
        id[k] = bintobcd(mtid[k]);   //����
      }
    for (pos = 0; pos < MAX_NODE; pos++)
      {
        if (memcmp(id, mt_up.aid_table[pos].node,IDLEN) == 0)
        {
            return 0;
        }
      }
    memcpy(mt_up.aid_table[mt_up.size].node, id, IDLEN);
    mt_up.size++;
#endif   
    for (int k = 0; k < IDLEN; ++k) id[k] = bintobcd(mtid[k]);   //����ַ
    if (memcmp(id, cid, IDLEN) == 0)
    {
        cid = NULL;
    }

    set_mt_pro(mtid, 1, pro);

    /* ��֯376.2���� */
    p->head = 0x68;
    p->dir = 1;
    p->prm = 1;
    p->addr = 0;
    p->ver = 0;
    p->rsv = 0;
    q->afn = 0x05;
    q->di[0] = 0x03;
    q->di[1] = 0x05;
    q->di[2] = 0x05;
    q->di[3] = 0xE8;
    q->data[0] = 1;
    // reverse(id, IDLEN);
    memcpy(&q->data[1], id, IDLEN);

    app_set_frm_sno(q, 1);
    app_set_frm_tail(p, MINLEN + 1 + IDLEN);
    rf_write(t, p->len, 0);
    report = 1;
    return 0;
}
int appgb_broad(unsigned char *frm, unsigned char len, unsigned int timeout)
{
    unsigned int time = 0;
    //int t_len = 0;
    int dlen = 0;
    unsigned char type = 0x02; //������Ĭ����07Э��
    printf_s("*************gb_broad******************\n");
    memset(&brdinfo, 0x00, sizeof(struct gbbrd_info));


    //���������ʱ���Ѿ��ж�645��������Ͳ��ظ��ж���
#if 0
    if ((t_len = is_valid645(frm, len)) < 0)
    {
        return -1;
    }

    len -= t_len;
#endif
    brdinfo.appdata[0] = frm[DTCTLPOS];
    if ((dlen = frm[DTCTLPOS + 1]) >= 65)
    {
        return -1;
    }
    for (int i = 0; i < dlen; ++i) brdinfo.appdata[i + 1] = frm[DTCTLPOS + 2 + i] - 0x33;
    brdinfo.len = ++dlen;

    time = 12;

    if ((rf_ctrl_startbrd() != 0))
    {
        return -1;
    }

    brdinfo.curtick = rf_currtick();

    if (brdinfo.len)
    {
        if (rf_start_broadcast(&brdinfo.appdata[0], brdinfo.len, type, time) < 0)
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }


    return 0;
}

unsigned char flag_broad_v = 0;    /* 1��ִ��5����0��ִ��4�� */
int appgb_broad_v(unsigned char *frm, unsigned char len, unsigned int timeout)
{
    memset(&brdinfo_v, 0x00, sizeof(struct gbbrd_info_v));


    //���������ʱ���Ѿ��ж�645��������Ͳ��ظ��ж���
#if 0
    if ((t_len = is_valid645(frm, len)) < 0)
    {
        return -1;
    }

    len -= t_len;
#endif
    if ((len >= 80) || (len <= 0))
    {
        return -1;
    }
    
    brdinfo_v.len = len;
    memcpy(brdinfo_v.appdata, frm, len);

    if ((rf_ctrl_startbrd() != 0))
    {
        return -1;
    }

//     brdinfo_v.curtick = rf_currtick();
    
    flag_broad_v = 1;
    if (local_viv_swi != 1)
    {
        ses_set_broadtime(); 
    }
    return 0;
}

extern void init_update_info(void);
int check_update_nw_start(unsigned char *pframe)
{

    struct _update_frame_nw_start *pf = (struct _update_frame_nw_start *)pframe;
    if (0x00 == pf->info)
    {
        init_update_info();
        return (0);  //�����װ����
    }
    else if (0x01 == pf->info)
    {
        if (pf->size > 250000)
        {
            return (-1);
        }
        return (0);
    }
    else
    {
        return (-1);
    }
}

/* ����ȫ��67�� */
static int appgb_start_update(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  struct _update_frame_nw *pnw;
  
  pnw = (struct _update_frame_nw *)&papp->data[0];
  
  if (frm->len != (MINLEN + nw_addr_len + sizeof(struct _update_frame_nw_start)))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  
  memset(&update_nw, 0x00, sizeof(struct _update_frame_nw));
  memset(&content_nw, 0x00, sizeof(struct _update_content_nw));
  
  if (check_frame_nw(pnw) < 0)
    {
      app_frm_negate(E_INVALID_DATA);
      return 0;
    }
  
  app_frm_confirm(0, last_nw_frame_sno); /* ���б���Ϊȷ�ϨM���ϱ��� */

  return 0;
}

static int appgb_update_file(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  struct _update_content_nw *pnw;
 
  pnw = (struct _update_content_nw *)&papp->data[0];
  
  if (frm->len != (MINLEN + nw_addr_len + sizeof(struct _update_content_nw) - 1 + pnw->file_seglen + 2))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  
  if (check_content_nw(pnw) < 0)
    {
      app_frm_negate(E_INVALID_DATA);
      return 0;
    }
  
  set_update_blk_nw(pnw);
  
  app_frm_confirm(0, last_nw_frame_sno); /* ���б���Ϊȷ�ϨM���ϱ��� */

  return 0;
}

static int appgb_get_update_info(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  
  if (frm->len != (MINLEN + nw_addr_len))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  
  papp->data[0] = update_nw.file_statue;  /* �ļ����� */
  papp->data[1] = update_nw.file_id;      /* �ļ� ID */
  memcpy(&papp->data[2], update_nw.dst, 6);//memcpy(&papp->data[2], jzq_address, 6); /* Ŀ�ĵ�ַ */
  papp->data[8] = update_nw.file_seg & 0xFF; /* �ļ��ܶ��� n 2bytes*/
  papp->data[9] = update_nw.file_seg >> 8;
  memcpy(&papp->data[10], (unsigned char *)&update_nw.file_len, 4); /* �ļ���С */
  papp->data[14] = update_nw.file_crc & 0xFF;    /* �ļ���У�� */
  papp->data[15] = update_nw.file_crc >> 8;
  papp->data[16] = content_nw.file_segnum & 0xFF;//papp->data[16] = update_info.blk_no & 0xFF;    /* �ѳɹ������ļ����� m */
  papp->data[17] = content_nw.file_segnum >> 8;//papp->data[17] = update_info.blk_no >> 8;
  
  app_frm_normal((unsigned char *)papp, 18);

  return 0;
}

static int appgb_get_process(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  
  if (frm->len != (MINLEN + nw_addr_len))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  
  if (content_nw.file_segnum >= (update_nw.file_seg - 1))  /* ȡֵ��Χ 0 �� n-1(n Ϊ�ļ��ܶ���) */
    {
      papp->data[0] = 0;  /* Ŀǰֻ�ж�·�� */
      papp->data[1] = 0;
    }
  else
    {
      papp->data[0] = 1; /* û����� */
      papp->data[1] = update_nw.file_id;
    }
  papp->data[2] = 0x0;  /* ·�����Ĭ��Ϊ0 */
  papp->data[3] = 0x0;
  
  app_frm_normal((unsigned char *)papp, 4);

  return 0;
}


static int appgb_get_fail_node(struct afn_desc_nw *self, struct frame_nw *frm)
{
  /* ���е��� E8 04 07 05�����ز�ѯ�ļ�����ʧ�ܽڵ� */
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  
  if (frm->len != (MINLEN + nw_addr_len + 3))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  papp->data[0] = 0;  /* ·�����û�нڵ�ĸ��� */
  papp->data[1] = 0;
  papp->data[2] = 0;
  
  papp->di[0] = 0x05;  /* ������и����в�һ�� */
  papp->di[1] = 0x07;
  papp->di[2] = 0x04;
  papp->di[3] = 0xE8;
  
  app_frm_normal((unsigned char *)papp, 3);
  return 0;
}

static int appgb_custom(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    app_frm_type = papp->data[1]; //����Э���������
    app_frm_confirm(0, last_nw_frame_sno);
    return 0;
}
static int appgb_set_mode(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len + 1))
    {
        app_frm_negate(E_LENGTH);
        return -1;
    }


    if (rf_set_rdswitch(papp->data) != 0)
    {
        app_frm_negate(GBERR_OTHER);
        return -1;
    }
    app_frm_confirm(0, last_nw_frame_sno);
    return 0;

}
static int appgb_get_mode(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
    int dlen;

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return -1;
    }

    if (rf_get_rdswitch(papp->data, &dlen) != 0)
    {
        app_frm_negate(GBERR_OTHER);
        return -1;
    }

    app_frm_normal((unsigned char *)papp, 1);

    return 0;
}

static int appgb_set_switch_mode(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

  if (frm->len != (MINLEN + nw_addr_len + 1))
    {
      app_frm_negate(E_LENGTH);
      return -1;
    }
  
  if (papp->data[0] == 1)  //��1Ϊ����״̬������֮��ֻ��43��̽;��2Ϊ������״̬
    {
      if (local_viv_swi != 1)  /* ��Ҫд��eeprom */
        {
          local_viv_swi = 1;
          eep_write(e2rom_addr(viv_switch), &local_viv_swi, e2rom_len(viv_switch));
        }
    }
  else if (papp->data[0] == 2)
    {
      if (local_viv_swi == 1)
        {
          local_viv_swi = 2;
          eep_write(e2rom_addr(viv_switch), &local_viv_swi, e2rom_len(viv_switch));
        }
    }
  else
    app_frm_negate(E_INVALID_DATA);
    
  app_frm_confirm(0, last_nw_frame_sno);
  return 0;
}

static int appgb_get_switch_mode(struct afn_desc_nw *self, struct frame_nw *frm)
{
    struct app_data_nw *papp = app_get_app(frm, nw_addr_len);

    if (frm->len != (MINLEN + nw_addr_len))
    {
        app_frm_negate(E_LENGTH);
        return -1;
    }

    //��1Ϊ����״̬������֮��ֻ��43��̽;��2Ϊ������״̬
    if (local_viv_swi == 1)
        papp->data[0] = 1;
    else
        papp->data[0] = 2;

    app_frm_normal((unsigned char *)papp, 1);
    return 0;
}


static int afn_test(struct afn_desc_nw *self, struct frame_nw *frm)
{
  struct app_data_nw *papp = app_get_app(frm, nw_addr_len);
  unsigned char buf[0x100];
  unsigned int len = 0;
  struct task_buf_info *p = (struct task_buf_info *)buf; 
  int start = 0;

  if (frm->len != (MINLEN + 2 + papp->data[1] + nw_addr_len))
    {
      app_frm_negate(E_LENGTH);
      return 0;
    }
  rt_test.time = 10 * 60 * 1000;

  if (papp->data[0] == 1)
    rt_test.chn = CHN_38_1; 
  else if (papp->data[0] == 2)
    rt_test.chn = CHN_38_2;
  else if (papp->data[0] == 3)
    rt_test.chn = CHN_38_3;
  else
    rt_test.chn = CHN_38_1;
  

  if ((start = get_645_frame(&papp->data[2], papp->data[1])) >= 0)
  {
      if (start)
      {
          papp->data[1] -= start;
          memmove(&papp->data[2], &papp->data[2 + start], papp->data[1]);
      }
      if (is_data_all_same(&papp->data[3], IDLEN, 0x99)) //�㲥��Ӧ����Ҫ��Ӧ
      {
          app_frm_negate(E_WRONGFORMAT);
          return 0;
      }

      memcpy(p->add, &papp->data[3], IDLEN);
      p->pro = DLT64507;
  }
  else
  {
      p->pro = DLT188;
  }
   
  p->frm.id = 0;
  p->frm.pri = 3;
  p->frm.rep = 1;
  p->frm.len = papp->data[1];
  p->frm.time = 30;

  memcpy(p->frm.buf, &papp->data[2], papp->data[1]);

  

  if (ses_add_task(p) < 0)
     app_frm_negate(E_TASK_BUF_FULL);

  restart_flag = 1;  //����ģʽ���Զ���������

  local_viv_swi = 2;
  return 0;
}

struct afn_desc_nw app_api[] =
{
    { RT_REQ, 0x00, 0xE8010001, appgb_ackdn },
    { RT_REQ, 0x00, 0xE8010002, appgb_negdn },

    { RT_ANS, 0x01, 0xE8020101, appgb_hardinit },
    { RT_ANS, 0x01, 0xE8020102, appgb_parainit },
    { RT_ANS, 0x01, 0xE8020103, appgb_taskinit },

    { RT_ANS, 0x02, 0xE8020201, appgb_add_task },
    { RT_ANS, 0x02, 0xE8020202, appgb_del_task },
    { RT_ANS, 0x02, 0xE8000203, appgb_get_task_num },
    { RT_ANS, 0x02, 0xE8030204, appgb_get_task_list },
    { RT_ANS, 0x02, 0xE8030205, appgb_get_task_info },
    { RT_ANS, 0x02, 0xE8000206, appgb_get_task_cap },
    { RT_ANS, 0x02, 0xE8020207, appgb_add_broad_task },
    { RT_ANS, 0x02, 0xE8020208, appgb_start_task },
    { RT_ANS, 0x02, 0xE8020209, appgb_halt_task },

    { RT_ANS, 0x03, 0xE8000301, appgb_get_vid_ver },
    { RT_ANS, 0x03, 0xE8000302, appgb_get_rt_info },
    { RT_ANS, 0x03, 0xE8000303, appgb_get_mnode_addr },
    { RT_ANS, 0x03, 0xE8030304, appgb_get_overtime },
    { RT_ANS, 0x03, 0xE8000305, appgb_anode_count },
    { RT_ANS, 0x03, 0xE8030306, appgb_get_node_info },
    { RT_ANS, 0x03, 0xE8000307, appgb_get_reg_state },
    { RT_ANS, 0x03, 0xE8030308, appgb_anode_relay_info },
    { RT_ANS, 0x03, 0xE8000309, appgb_gdnode_count },
    { RT_ANS, 0x03, 0xE803030A, appgb_get_gdnode_info },
    { RT_ANS, 0x03, 0xE800030B, appgb_get_pri_tmout },
    { RT_ANS, 0x03, 0xE803030C, appgb_get_node_phs },
    { RT_ANS, 0x03, 0xE803030D, appgb_get_batch_phs },
    { RT_ANS, 0x03, 0xE803030E, gdafn_get_area_indb},
    { RT_ANS, 0x03, 0xE803030F, gdafn_get_area_outdb},

    { RT_ANS, 0x04, 0xE8020401, appgb_set_mnode_addr },
    { RT_ANS, 0x04, 0xE8020402, appgb_add_node },
    { RT_ANS, 0x04, 0xE8020403, appgb_del_node },
    { RT_ANS, 0x04, 0xE8020404, appgb_allow_event },
    { RT_ANS, 0x04, 0xE8020405, appgb_activate_anode_reg },
    { RT_ANS, 0x04, 0xE8020406, appgb_stop_anode_reg },
    { RT_ANS, 0x04, 0xE8020407, appgb_add_gdnode },
    { RT_ANS, 0x04, 0xE8020408, appgb_del_gdnode},
    //  { RT_REQ, 0x05, 0xE8050501, appgb_report_data },
    //  { RT_REQ, 0x05, 0xE8050502, appgb_report_event },
    //  { RT_REQ, 0x05, 0xE8050503, appgb_report_node },
    // { RT_REQ, 0x05, 0xE8050504, appgb_report_reg_over },
    // { RT_REQ, 0x05, 0xE8050505, appgb_report_task_state },

    //  { RT_REQ, 0x06, 0xE8060601, appgb_router_get_time },

    { RT_ANS, 0x07, 0xE8020701, appgb_start_update },
    { RT_ANS, 0x07, 0xE8020702, appgb_update_file },
    { RT_ANS, 0x07, 0xE8000703, appgb_get_update_info },
    { RT_ANS, 0x07, 0xE8000704, appgb_get_process },
    { RT_ANS, 0x07, 0xE8030705, appgb_get_fail_node },


    { RT_ANS, 0xF0, 0xE802F001, appgb_custom },

    { RT_ANS, 0xF0, 0xE802F002, appgb_set_mode },
    { RT_ANS, 0xF0, 0xE802F003, appgb_get_mode },
	{ RT_ANS, 0xF0, 0xE802F004, afn_test},
    
    { RT_ANS, 0xF0, 0xE802F008, appgb_set_switch_mode },
    { RT_ANS, 0xF0, 0xE802F009, appgb_get_switch_mode },
#if 0
    //{ RT_ANS, 0xF0, 0xE802F004, appgb_set_debug },
    // { RT_ANS, 0xF0, 0xE802F005, appgb_output_debug },
    { RT_ANS, 0xF0, 0xE802F006, appgb_erase_flash }
    ,
    { RT_ANS, 0xF0, 0xE802F007, appgb_set_115200 }
    ,
#endif
};
static struct afn_desc_nw* app_find_api(unsigned char afn, unsigned int di)
{
    int i = 0;

    for (i = 0; i < (sizeof(app_api) / sizeof(app_api[0])); i++)
    {
        if ((afn == app_api[i].afn) && (di == app_api[i].di))
            break;
    }

    if (i >= (sizeof(app_api) / sizeof(app_api[0])))
        return NULL;

    return ((struct afn_desc_nw *)&app_api[i]);
}
int get_gw_dt_list(unsigned char d[])
{
    int i, dt = 0, t = d[0];

    for (i = 0; i < 8; i++)
    {
        if (t & 0x01)
        {
            dt = (unsigned int)(d[1] << 3) + i + 1;
        }

        t >>= 1;
    }

    return dt;
}
/*
�������ƣ� set_frame_head
�����������趨698֡ͷ
���룺  pframe ���趨֡��ccw ͨ�ŷ�ʽ
*/
void set_frame_gw_head(struct frame_gw_3762 *pframe, unsigned char ccw)
{
    pframe->start_flag = 0x68;
    pframe->dir = 1;
    pframe->prm = 0;
    pframe->comm_method = ccw;
}
void set_info_gw_default(unsigned char buf[], unsigned char ccw, unsigned char debug_info)
{
    struct info_up_gw *info_field = (struct info_up_gw *)buf;

    info_field->reserved0 = 0;
    info_field->reserved1 = 0;
    info_field->reserved2 = 0; // debug_info>>0x04;;
    info_field->com_module = 0;


    info_field->info_no5 = 0x00;
    info_field->event_flag = 0;
    info_field->sno = 0; //get_and_inc_sno();
                         //info_field->info_no6 = 0x00;

    info_field->last_ans_sig = 0;
    info_field->last_com_sig = 0;
    info_field->phase = 0x00;
    info_field->relay_level = debug_info & 0x0f;
    //info_field->meter_chn_sta = 0x04;
    info_field->meter_chn_sta = 0x00;
}
void set_info_gw_frame_sno(unsigned char buf[], unsigned char sno)
{
    struct info_up_gw *info_field = (struct info_up_gw *)buf;

    info_field->sno = sno;
}
void set_frame_gw_tail(struct frame_gw_3762 *pframe, unsigned short len)
{
    pframe->length = len;
    ((unsigned char *)pframe)[len - 2] = checksum(((unsigned char *)pframe) + 3, len - 5);
    ((unsigned char *)pframe)[len - 1] = 0x16;
}
int frame_gw_negate_send(unsigned char ccw, unsigned char e_code)
{
    unsigned char buf[0x20], frame[0x200];
    struct frame_gw_3762 *pframe = (struct frame_gw_3762 *)&buf[0];
    struct app_data_gw *papp = ((struct app_data_gw *)&pframe->user_data[6]);
    int frame_len;

    memset(&buf[0], 0x00, sizeof(buf));
    set_frame_gw_head(pframe, ccw);
    set_info_gw_default((unsigned char *)&pframe->user_data[0], 1, 0);
    set_info_gw_frame_sno(&pframe->user_data[0], last_gw_frame_sno);

    papp->afn = 0x00;
    papp->data_type[0] = 0x02;
    papp->data_type[1] = 0x00;

    papp->data_unit[0] = e_code;

    set_frame_gw_tail(pframe, FRMAE_DEFAULT_GW_LEN + 1);

    memcpy(&frame[0], &buf[0], buf[1]);
    frame_len = buf[1];
    rf_write(buf, FRMAE_DEFAULT_GW_LEN + 1, 0);

    return (FRMAE_DEFAULT_GW_LEN + 1);
}

int frame_gw_normal_send(unsigned char ccw, unsigned char user_data[], unsigned int len)
{
    unsigned char buf[0x200], frame[0x200];
    struct frame_gw_3762 *pframe = (struct frame_gw_3762 *)&buf[0];
    struct app_data_gw *papp = ((struct app_data_gw *)&pframe->user_data[6]);
    int frame_len;

    memset(&buf[0], 0x00, sizeof(buf));
    set_frame_gw_head(pframe, ccw);
    set_info_gw_default((unsigned char *)&pframe->user_data[0], ccw, 0);
    set_info_gw_frame_sno(&pframe->user_data[0], last_gw_frame_sno);

    len = len + FRMAE_DEFAULT_GW_LEN - 3;
    memcpy((unsigned char *)papp, &user_data[0], len);
    set_frame_gw_tail(pframe, len);

    memcpy(&frame[0], &buf[0], pframe->length);
    frame_len = pframe->length;

    rf_write(buf, frame_len, 0);
    return (len);
}
int afn_gw_set_update_data(struct frame_gw_3762 *pframe)
{
    unsigned int t;
    int addr_len;
    struct _update_frame_gw *pgw;
    struct info_down_gw *info_field = (struct info_down_gw *)pframe->user_data;
    addr_len = 0;

    struct app_data_gw *papp = ((struct app_data_gw *)&pframe->user_data[6 + addr_len]);

    pgw = (struct _update_frame_gw *)&papp->data_unit[0];

    if (pframe->length != (FRMAE_DEFAULT_GW_LEN + sizeof(struct _update_frame_gw) - 1 + pgw->data_len))
    {
        frame_gw_negate_send(pframe->comm_method, E_LENGTH);  //���ȴ���
        return (0);
    }

    if (check_update_frame(pgw) < 0)
    {
        frame_gw_negate_send(pframe->comm_method, E_INVALID_DATA);  //ֻ֧�ֱ�������
        return (0);
    }

    t = set_update_blk_data(pgw);

    memcpy(&papp->data_unit[0], (unsigned char *)&t, sizeof(t));
    frame_gw_normal_send(pframe->comm_method, (unsigned char *)papp, 4 + 3);

    return (0);
}
static void app_set_frm_auto_up(struct frame_nw *frm)
{
    frm->head = 0x68;
    frm->dir = 1;
    frm->prm = 1;
    frm->ver = 0;
    frm->rsv = 0;
}
int nw_report_data(unsigned int sn,unsigned char *mtid, unsigned char pro,unsigned char *data, unsigned char len)
{
    unsigned char frame[255];
    int dlen = 0;
    int datalen = 6;
    unsigned int tid;
    unsigned char rtDataItem[0x80];
    unsigned char taskDataItem[0x80];
    unsigned char itemLen;
    unsigned char errbuf1[] = { 0xC0, 0x01 }, errbuf2[] = { 0xC0, 0x02 }, errbuf3[] = { 0xC0, 0x03 };
    unsigned char denyCtrl07 = 0xD1;
    unsigned char denyCtrl97 = 0xC1;
    unsigned char binid[6];
    struct frame_nw *p = (struct frame_nw *)&frame;
    struct app_data_nw *papp = (struct app_data_nw *)&p->data[IDLEN * 2];
    struct mtinfo *mt;

#if 0
  unsigned char c1temp = 0xF2;
  send_uart_data_blocking(CHN_DM,&c1temp,1);
  send_uart_data_blocking(CHN_DM, data, len);
#endif
    memcpy(&p->data[0], mtid, 6);
    get_nw_task_appid(sn,binid);


    if (0 != memcmp(mtid, binid, IDLEN))
    {
//      if ((mt = db_find(mtid)) != NULL)
//      {
//          mt->node.envi |= NCMD1SUC;  //���Ըñ����г����������ݱ�ʶȫ��������ɱ�־��Ϊ��Ч
//      }
        return -1; //���յ����뵱ǰ�����Ĳ���ͬһ����ַ�����ϱ�
    }


    if (0 == memcmp(data, errbuf1, 2)
        || 0 == memcmp(data, errbuf2, 2)
        || 0 == memcmp(data, errbuf3, 2))
    {
        //   report_task_fail(TASK_EXE_HIGH, TASK_STATUS_NO_RES);
        return -2;
    }

    //extern int rf_getappd(unsigned char *data, unsigned char *dlen);
#if 1
    rf_getappd(rtDataItem, &itemLen);
    dlen = get_nw_task_dataitem(sn, taskDataItem);    

    if ((0 != memcmp(&rtDataItem[1], &taskDataItem[1], dlen - 1)) && (pro != 0) && (pro != 3))
    {

      return -1; //·�ɳ����ĺ͵�ǰ���������ݱ�ʶ��ͬ�����ϱ�
    }

//  c1temp = 0xF3;
//  send_uart_data_blocking(CHN_DM,&c1temp,1);
//  send_uart_data_blocking(CHN_DM, rtDataItem, itemLen);
#endif
    if (_rtparas.dcviv != TYPE53)
      {
        id_bintobcd(&p->data[0]);
        reverse(&p->data[0], 6);
      }

    rf_get_jzqid_nw(&p->data[IDLEN], &datalen);
    //id_bintobcd(&p->data[IDLEN]); //�˴�������������
    // reverse(&p->data[IDLEN], IDLEN);

    /* ��֯376.2���� */
    p->head = 0x68;
    p->dir = 1;
    p->prm = 1;
    p->addr = 1;
    p->ver = 0;
    p->rsv = 0;

    papp->afn = 0x05;
    papp->di[0] = 0x01;
    papp->di[1] = 0x05;
    papp->di[2] = 0x05;
    papp->di[3] = 0xE8;

    tid =  get_nw_task_id(sn);
    papp->data[0] = tid & 0xFF;
    papp->data[1] = tid >> 8;
    if (data != NULL && len > 0) //len=1,Ϊ�����֣����ǳ���Ϊ0
    {
        if (pro == 1 || pro == 2)
        {
            dlen = appgb_build_645cmd(mtid, data[0], data + 1, len - 1, &papp->data[3]);
        } else
        {
            dlen = len;
            memcpy(&papp->data[3], data, dlen);
        } 
	} 
	else //�����ݾ��ϱ�����ʧ��
    {
#if 0
        memcpy(bcdid, nw_task.appid, IDLEN);
        bin_to_bcd(bcdid, IDLEN);
        // reverse(bcdid, IDLEN);
        nw_report_task_state(nw_task.tid, bcdid, TASK_STATUS_NO_RES);
        report = 1;
        return 0;
#endif
        return -2;
    }
    papp->data[2] = dlen;
    app_set_frm_sno(papp, get_frm_up_sn());
    app_set_frm_tail(p, MINLEN + IDLEN * 2 + 3 + dlen);
#if 0
    for (int i = 0; i < 20; i++)
    {
        if (((frame[39+i]&0x0F) > 0x0C) || ((frame[39+i] & 0xF0) > 0XC0) )
        {
            unsigned char temp[]={0x55,0x55,0x55,0x55,0x55,0x55};
             send_uart_data_blocking(CHN_DM, temp, sizeof(temp));
        }
    }
    send_uart_data_blocking(CHN_DM, frame, p->len);
#endif
    rf_write(frame, p->len, 0);
    report = 1;
    //  ses_del_task(nw_task.tid); //Ӧ�õȵ��ϱ����յ�ȷ��֡����ɾ��������
    //init_nw_cur_task();



    return 0;


}



void nw_report_rt_info()
{
    unsigned char buf[0x100];
    int t;
    int datalen;
    struct frame_nw *p = (struct frame_nw *)buf;
    struct app_data_nw *app = app_get_app(p, 0);

    memset(buf, 0x00, sizeof(buf));
    app_set_frm_auto_up(p);
    p->addr = 0;
    app_set_frm_sno((struct app_data_nw *)&p->data[0], 0);

    app->afn = 0x03;
    app->di[0] = 0x02;
    app->di[1] = 0x03;
    app->di[2] = 0x00;
    app->di[3] = 0xE8;
    memcpy(&app->data[0], (unsigned char *)rt_info_nw, sizeof(rt_info_nw));

    rf_get_jzqid_nw(app->data + 6, &datalen);
    // for (int i = 0; i < datalen; ++i)
    //     app->data[6 + i] = bintobcd(app->data[6 + i]);

    t = _rtparas.mtnum;
    app->data[14] = t & 0xff;
    app->data[15] = t >> 8;
    app_set_frm_tail(p, sizeof(rt_info_nw) + MINLEN);
    rf_write(buf, p->len, 0);

}
static int nw_exact_645cmd(unsigned char fram[], int flen, unsigned char *buff, unsigned char *pro)
{
    int i, idx = 0, len;
    unsigned char id[IDLEN];

    while ((fram[idx] != 0x68) && (idx < flen))
    {
        idx++;
    }
    if (flen < (12 + idx)) 
	return -1;

    if (fram[idx] == 0xFE) 
	idx++;
    if (fram[idx++] != 0x68)
	 return -1;

    memcpy(id, &fram[idx], IDLEN);
    idx += IDLEN; 
    memcpy(buff, id, IDLEN);

    if (fram[idx++] != 0x68)
        return -1;

    buff[6] = fram[idx++];
    len = fram[idx++];

    if (2 == len)
    {
        *pro = DLT64597;
    }
    else if (4 == len)
    {
        *pro = DLT64507;
    }
    for (i = 0; i < len; i++) buff[7 + i] = fram[idx + i] - 0x33;

    len += 7; // id + ctrl

    return len;
}
int appgb_nw_dc(unsigned char proto, unsigned char add[], unsigned char *buf, unsigned char len, unsigned char exlen) /* send data to mtid directly */
{
    assert(buf);
    unsigned char data[255], pro, brdno[] = { 0x99, 0x99, 0x99, 0x99, 0x99, 0x99 };
    int dlen, idx;
    unsigned char wretlen;
    unsigned char aid[6];

    memcpy(aid, add, 6);
    if (callflag == 1) //����ӽڵ����
    {
        callmeter = 1;
        callflag = 0;
    }
    else
        callmeter = 0;

    _rtparas.dlytm &= ~0x01;
    if (proto == DLT64507)
    {
#if 0
        if ((dlen = nw_exact_645cmd(buf, len, data, &pro)) < 0)
        {
            app_frm_negate(GBERR_FORMAT);
            return -1;
        }

        /* rf_settask(); */
        if (memcmp(data, brdno, IDLEN) == 0) /* broad */
        {
            unsigned char jid[IDLEN];
            int idlen = 0;
            rf_getjid(jid, &idlen);
            rf_monit(jid, pro, data + IDLEN, dlen - IDLEN, 4);
            // rf_set_mntdlytm(dlytm);
            rf_set_mntdlytm(0);
            return 0;
        }
#endif

       // wretlen = 4;
        wretlen = exlen;
    }
    else
    {
        wretlen = 0;
    }
    id_bintobcd(aid);
    reverse(aid, IDLEN);
   // rf_monit(data, pro, data + IDLEN, dlen - IDLEN, 4);
    rf_monit(aid, proto, buf, len, wretlen);
    rf_set_mntdlytm(0);
        //rf_set_mntdlytm(dlytm);

    return 0;
}

int appgb_nw_dc_v(unsigned char proto, unsigned char add[], unsigned char *buf, unsigned char len, unsigned char exlen) /* send data to mtid directly */
{
    unsigned char wretlen;
    unsigned char aid[6];

    memcpy(aid, add, 6);
    _rtparas.dlytm &= ~0x01;
    wretlen = 0;
    

    setappd(3, buf, len, exlen);


    memset(&_task.minfo, 0, sizeof(struct mntinfo));
    memcpy(_task.minfo.id, aid, IDLEN);
    _rtparas.state &= ~STAMMASK;
    _rtparas.state |= STAMONIT;
  
  
    printf_s("\n****STAMONIT----ADD----appgb_nw_dc_v****\n");
  
    _task.minfo.state &= ~STIMASK;
    _task.minfo.state |= STINIT;
    

    rf_set_mntdlytm(0);

    return 0;
}

int app_frm_decode(unsigned char *buf)
{
    struct frame_nw *frm = (struct frame_nw *)buf;
    unsigned int afn, req_mask = 0;
    unsigned int di;
    unsigned char sum;
    struct afn_desc_nw *pafn_t = NULL;

    if (APP_FRM_NW == app_frm_type)
    {
        nw_addr_len = app_get_frm_addr_len(frm);
        afn = frm->data[nw_addr_len];
        app_set_last_frame_sno(frm->data[1 + nw_addr_len]);
        di = app_get_di(&frm->data[2 + nw_addr_len]);

        if (0x01 == frm->dir)
        {
            app_frm_negate(E_OTHER);
            return 0;
        }
        if (frm->ver != 0)
        {
            app_frm_negate(E_OTHER);
            return 0;
        }
        sum = buf[frm->len - 2];
        if (sum != checksum(&buf[3], frm->len - 5))
        {
            app_frm_negate(E_CHECKSUM);
            return 0;
        }

        if (PRM_REQ == frm->prm)
            req_mask = RT_ANS;
        else
            req_mask = RT_REQ;

        if (di == 0)
        {
            app_frm_negate(E_NO_INFOTYPE);
            return 0;
        }

        pafn_t = app_find_api(afn, di);

        if ((NULL == pafn_t) || (NULL == pafn_t->handle))
        {
            app_frm_negate(E_NO_INFOTYPE);
            return 0;
        }

        if (0x00 == (req_mask & pafn_t->prm))
        {
            if (RT_REQ == req_mask)
            {
                app_frm_negate(E_NO_INFOTYPE);
                return 0;
            }

            app_frm_negate(E_NO_INFOTYPE);
            return 0;
        }
        pafn_t->handle(pafn_t, frm);
    }
    else if (APP_FRM_GW == app_frm_type)
    {
        struct frame_gw_3762 *pframe = (struct frame_gw_3762 *)buf;
        struct info_down_gw *info_field = (struct info_down_gw *)pframe->user_data;
        unsigned int afn, dt;
        int addr_len = 0;

        last_gw_frame_sno = info_field->sno;
        if (pframe->comm_method <= 1)
        {
            if (1 == info_field->com_module)
            {
                addr_len = 12 + 6 * info_field->relay_level;
            }

            afn = pframe->user_data[6 + addr_len];
            dt = get_gw_dt_list(&pframe->user_data[7 + addr_len]);
            if (afn == 0x15 && dt == 0x01)
            {
                afn_gw_set_update_data(pframe);

            }
        }
        else if (pframe->comm_method == 7)
        {
            addr_len = 0;
            afn = pframe->user_data[6 + addr_len];
            dt = get_gw_dt_list(&pframe->user_data[7 + addr_len]);
        }

        return 0;
    }
    return 0;
}



int appgb_reg_data(unsigned char *mtid, unsigned char *data, int datalen, unsigned char event)
{

}

int appgb_reqbrd()
{
    if ((brdinfo.appdata[0] == 0x08) && (brdinfo.len == 0x07)
        && (rf_currtick() - brdinfo.curtick >= MINTICK))
        mdfappd(rf_currtick());

    if (brdinfo.start < 3)
    {
        brdinfo.start++;
        //rf_setappd(APPRDATA | TYPEFLAG, brdinfo.appdata, brdinfo.len, 0);
        rf_setappd_ex(APPRDATA | TYPEFLAG, DLT64507, brdinfo.appdata, brdinfo.len, 0);

        return -2;
    }
    else
    {
        brdinfo.start = 0;
        return -1;
    }
}

int appgb_reqdata(unsigned char *mtid)
{
    //����ֻ���鱨��ȥ������������ڹ㶫16��˵������Ҫ�˲���ֱ����Ϊ�鱨�ĳɹ���
    assert(mtid);
    unsigned char sno[2];
    if (rf_get_user(mtid, sno) != 0)
        return -1;
    
//     printf("\n****monitreq1****:  aid:");
//     unsigned char aid_tmp[IDLEN];
//     memcpy(aid_tmp, mtid, IDLEN);
//     id_bintobcd(aid_tmp);
//     reverse(aid_tmp, 6);
//     
//     for (int i = 0; i< IDLEN; i++)
//       {
//         printf_s("%02x ", aid_tmp[i]);
//       }
//     printf_s("\n");

    
    return 0;


    //return -1; //�Ҳ���
#if 0
    int ret;
    ret = get_read_from_task(mtid);

    if (ret == 0)
    {
        return 3; //�ҵ�������
    }
    else
    {
        return -1; //�Ҳ���
    }
#endif
}

int appgb_deny(unsigned char errcode)
{
    /* afn = 1,fn = 2, deny */

    return 0;
}
int appgb_cfm(unsigned short wait)
{
    return 0;
}
int appgb_reqdlytm(unsigned char *mtid)
{
    return 0;
}

void set_to_brd_phs_v(void)
{
  unsigned char buf_zeroA[] = {0x68, 0x99, 0x99, 0x99, 0x99, 0x99, 0x99, 0x68, 0x1F, 0x02, 0xE1, 0x73, 0xDB, 0x16};
  appgb_broad_v(buf_zeroA, sizeof(buf_zeroA), 0);  //timeû����
}
#if 0  //ͨ��V�������̷���
void set_to_brd_phs(void)
{
    unsigned int time = 0;
    memset(&brdinfo, 0x00, sizeof(struct gbbrd_info));
    brdinfo.appdata[0] = 0x1f;
    brdinfo.appdata[1] = 0xAE;
    brdinfo.appdata[2] = 0xC0;
    brdinfo.len = 3;

    time = 12;
    rf_ctrl_startbrd();
    brdinfo.curtick = rf_currtick();

    rf_start_broadcast(&brdinfo.appdata[0], brdinfo.len, 0x03, time);

}
#endif
/*v����غ�������***********************************/
void app_eventup(unsigned char *buf, unsigned char len)
{
//   assert(mtid);
//   assert(data);

   int len_tmp;

  if ((_rtparas.wkstate & RPTSWIMASK) != RPTSWION)
  {
      return;
  }

  int c;
  if ((c = get_645_frame(buf, len)) < 0)
    return;
  
  unsigned char t[0x100];
  struct frame_nw *p = (struct frame_nw *)&t;
  struct app_data_nw *q = (struct app_data_nw *)&p->data[IDLEN * 2];

  /* ��֯376.2���� */
  p->head = 0x68;
  p->dir = 1;
  p->prm = 1;
  p->addr = 1;
  p->ver = 0;
  p->rsv = 0;

//   memcpy(&p->data[0], mtid, IDLEN);
//   id_bintobcd(&p->data[0]);
//   reverse(&p->data[0], 6); //�˴���ַ��Ҫ����
  memcpy(&p->data[0], &buf[c + 1], IDLEN);
  rf_get_jzqid_nw(&p->data[IDLEN], &len_tmp);
  // id_bintobcd(&p->data[IDLEN]); //�˴�������������
//reverse(&p->data[IDLEN], IDLEN); //�˴���ַ��Ҫ����

  q->afn = 0x05;
  q->di[0] = 0x02;
  q->di[1] = 0x05;
  q->di[2] = 0x05;
  q->di[3] = 0xE8;
  
  q->data[0] = len;
  memcpy(&q->data[1], buf, len);

//   q->data[0] = orgframe645(mtid, data, datalen, &q->data[1]);

  app_set_frm_sno(q, get_frm_up_sn());
  app_set_frm_tail(p, MINLEN + IDLEN * 2 + 1 + q->data[0]);

  rf_write(t, p->len, 0);
  report = 1;
  return ;
}

void app_mt_up(unsigned char n, unsigned char *aid)
{
  unsigned int pos;
  unsigned char t[0x100];
  struct frame_nw *p = (struct frame_nw *)&t;
  struct app_data_nw *q = (struct app_data_nw *)&p->data[0];

  if ((_rtparas.wkstate & REGSWIMASK) != REGSWION) /*���عر����ϱ�*/
      return ;
  
  for (int i = 0; i < n; i++)
    {
      if (is_data_all_same(&aid[i*6], 6, 0xFF) || is_data_all_same(&aid[i*6], 6, 0x00))  /* ������Ч���ϱ� */
        return;
    }
  
  

  /* ��֯376.2���� */
  p->head = 0x68;
  p->dir = 1;
  p->prm = 1;
  p->addr = 0;
  p->ver = 0;
  p->rsv = 0;
  q->afn = 0x05;
  q->di[0] = 0x03;
  q->di[1] = 0x05;
  q->di[2] = 0x05;
  q->di[3] = 0xE8;
  q->data[0] = n;//1;
  // reverse(id, IDLEN);
  memcpy(&q->data[1], aid, n * IDLEN);//IDLEN);

  app_set_frm_sno(q, 1);
  app_set_frm_tail(p, MINLEN + 1 + n * IDLEN);
  rf_write(t, p->len, 0);
  report = 1;
  return ;
}

void app_power_eventup(unsigned char depth, unsigned char phase, unsigned char *buf, unsigned char len, unsigned char tq_state, unsigned short sid, unsigned char dc_sno)
{
  unsigned char tchar[6] = {0x66, 0x66, 0x66, 0x66, 0x66, 0x66}, aid_hash[IDLEN], event_type = 0;
  unsigned char t[0x100] = {0}, flag_indb = 0, flag_iscjq = 0;//, c;
  int c, pos = 0;
  struct frame_nw *p = (struct frame_nw *)&t;
  struct app_data_nw *q = (struct app_data_nw *)&p->data[IDLEN * 2];
  struct mtinfo * mtp = NULL;

  unsigned char mt_num = 0;

  if ((_rtparas.wkstate & RPTSWIMASK) != RPTSWION)  /* �ϱ��������� */
    {
        return;
    }

  if ((c = get_645_frame(buf, len)) < 0)
    return;
  
  memcpy(aid_hash, &buf[c+1], IDLEN);
  aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
  if ((mtp = db_find(aid_hash)) != NULL)  //if (db_find(AID, aid, &pos) == 0)
    flag_indb = 1;
  
  /* ��db����sid,����sidȷ���Ƿ��ǲɼ��� */
  if (1 != flag_indb)
    {
      if (1 == db_find_vsid(sid))  /* ֻ����V���Ĳɼ�����43�Ĳ�֧��ͣ���ϱ� */
        flag_iscjq = 1;
      else
        return;  /* �������ݿ���ʱ��֧�� */
    }
  
  /* ��ֹ��һ���ϵ�Ϊ0������²��������ϱ� */
  if (dc_sno < 7)  /* dc_snoȡ��-7 */
    dc_sno += 1;   /* 0-6���1-7 */
  else
    dc_sno = 0;    /* 7���0 */
  

  /* ͣ���ϱ�ȥ�ػ��� */
  if ((flag_indb == 1) && (flag_iscjq == 0))  /* ����ͣ���ϱ� */
    {
      //����Ҫ�жϰ汾
      unsigned char ver[3] = {0x0};
      ses_get_node_ver((mtp->attr >> 4) & 0x03, ver);
      
      printf_s("ver0:%02x, ver1:%02x  ver2:%02x\n", ver[0], ver[1], ver[2]);
      if ((ver[0] == 0x00) && (ver[1] == 0x22))
        {
          /* 1����ͨ�汾��ֻ��ͣ���ϱ�������Ӧ�ϱ��ı����¼���5�����ڷ��� */
          if (flag_indb)
            {
              if ((memcmp(mtp->node.id, aid_hash, 6) == 0) && ((mtp->powmt_on == 1)
              || (((get_sys_tick() - mtp->powmt_time) / 300000) < 1)))  /* ��ǰ�ϱ����Ŵ�ʱ��С��5���ӷ��� */
                return;
            }

          if (flag_indb)  /* �ϱ��ı���ʱ�� */
            {
              mtp->powmt_time = get_sys_tick();
              mtp->powmt_on = 1;
            }
        }
      else
        {
          /* 2��ȫ��汾(����ͣ���ϵ磬�β�): ͨ���������ȥ�� */
          /* ͣ���ϱ��¼���AA:�ϵ��¼� BB���β��·�DD:ͣ���¼� */
          if ((buf[26] == 0xBB) && (buf[27] == 0xBB) && ((mtp->swapmt2 >> 1) != dc_sno))
            {      
              mtp->swapmt2 = 0;
              mtp->swapmt2 |= 0x1;           /* ��־��Ҫ����*/
              mtp->swapmt2 |= (dc_sno << 1); /* ����㳭��� */
            }
          
          if ((buf[26] == 0xAA) && (buf[27] == 0xAA) && ((mtp->powmt2_on >> 1) != dc_sno))
            {
              mtp->powmt2_on = 0;
              mtp->powmt2_on |= 0x1;           /* ��־��Ҫ����*/
              mtp->powmt2_on |= (dc_sno << 1); /* ����㳭��� */
            }
          
          if ((buf[26] == 0xDD) && (buf[27] == 0xDD) && ((mtp->powmt2_off >> 1) != dc_sno))
            {
              mtp->powmt2_off = 0;
              mtp->powmt2_off |= 0x1;           /* ��־��Ҫ����*/
              mtp->powmt2_off |= (dc_sno << 1); /* ����㳭��� */
            }
        }

      //���ﲻ������,�������ط�����event_type = 1;  /* ��ʾ�����ͣ���¼� */
    }
#if 0  /* û������������� */
  if (flag_iscjq == 1)  /* �ɼ�����ͣ���ϱ� */
    {
      if (len < 22)  /* ���ĳ��ȹ��̣������ϱ�׼��ʽ */
        return;
      
      if ((c = get_645_frame(buf, len)) < 0)
        return;

      /* &buf[c + 1]�ǲɼ�����ַ */
      memcpy(aid_hash, &buf[c + 14], IDLEN);
      aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
      if ((mtp = db_find(aid_hash)) != NULL)  //if (db_find(AID, &buf[c + 14], &pos) >= 0)  /* �����ӵ��Ǳ���ַ */
        {
          /* ͣ���ϱ�ȥ�ػ��� */
          mt_num = (buf[9] - 4) / 6;
          for (int i = 0; i < mt_num; i++)
            {
              memcpy(aid_hash, &buf[c + 14 + 6*i], IDLEN);
              aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
              if ((mtp = db_find(aid_hash)) == NULL)  //if (db_find(AID, &buf[c + 14 + 6*i], &pos) < 0)
                return;
              
              if (buf[8] == 0x91)  /* �ϵ��¼� */
                {
                  event_type = 4;  /* 04H�����ɼ����ϵ磨��ַ�� */

                  if (((mtp->powcoll_on & 0x01) == 1) && ((mtp->powcoll_on >> 1) == dc_sno))
                    {
                      return;  /* 事件已经报过的不再上报了 */
                    }
                  else
                    {
                      mtp->powcoll_on |= 0x1;         /* 标志已经有过事件 */
                      mtp->powcoll_on |= (dc_sno << 1); /* 保存点抄序号 */
                      //��ʱ����flash  db_save_flash(pos);
                    }
                }
              
              if (buf[8] == 0x93)  /* ͣ���¼� */
                {
                  event_type = 3;  /* 03H�����ɼ���ͣ�磨��ַ�� */
                  
                  if (((mtp->powcoll_off & 0x01) == 1) && ((mtp->powcoll_off >> 1) == dc_sno))
                    {
                      return;  /* 事件已经报过的不再上报了 */
                    }
                  else
                    {
                      mtp->powcoll_off |= 0x1;         /* 标志已经有过事件 */
                      mtp->powcoll_off |= (dc_sno << 1); /* 保存点抄序号 */
                      //��ʱ����flash  db_save_flash(pos);
                    }
                }
            }
        }
      else  /* �����ӵ��ǲɼ�����ַ */
        {
          mt_num = (buf[9] - 4) / 6;
          
          memcpy(aid_hash, &buf[c + 1], IDLEN);
          aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�frm���������
          if ((mtp = db_find(aid_hash)) == NULL)  //if (db_find(AID, &buf[c + 1], &pos) < 0)
            return;
          
          if (buf[8] == 0x91)  /* �ϵ��¼� */
            {
              event_type = 4;  /* 04H�����ɼ����ϵ磨��ַ�� */

              if (((mtp->powcoll_off & 0x01) == 0) && ((mtp->powcoll_off >> 1) == dc_sno))  /* flash����Ĭ��Ϊ1����д0��ʾ��Ч */
                {
                  return;  /* 事件已经报过的不再上报了 */
                }
              else
                {
                  mtp->powcoll_on |= 0x1;         /* 标志已经有过事件 */
                  mtp->powcoll_on |= (dc_sno << 1); /* 保存点抄序号 */
                  //��ʱ����flash  db_save_flash(pos);
                }
            }
          
          if (buf[8] == 0x93)  /* ͣ���¼� */
            {
              event_type = 3;  /* 03H�����ɼ���ͣ�磨��ַ�� */
              
              if (((mtp->powcoll_off & 0x01) == 0) && ((mtp->powcoll_off >> 1) == dc_sno))
                {
                  return;  /* 事件已经报过的不再上报了 */
                }
              else
                {
                  mtp->powcoll_off |= 0x1;         /* 标志已经有过事件 */
                  mtp->powcoll_off |= (dc_sno << 1); /* 保存点抄序号 */
                  //��ʱ����flash  db_save_flash(pos);
                }
            }
        }
    }
#endif
  if (event_type == 0)
    return;
    
  /* ��֯376.2���� */
  p->head = 0x68;
  p->dir = 1;
  p->prm = 1;
  p->addr = 1;
  p->ver = 0;

  memcpy(&p->data[0], &buf[c + 1], IDLEN);
  memcpy(&p->data[6], _rtparas.jzqid_nw, IDLEN);
  
  q->afn = 0x05;
  q->di[0] = 0x02;
  q->di[1] = 0x05;
  q->di[2] = 0x05;
  q->di[3] = 0xE8;
  
  /* 01H ����ͣ���¼���02H�����ϵ��¼���03H����ģ�����¼�(�ɼ���û�аβ��¼�) */
  /* ������ֻ���ɼ��������������ط��ϱ� */
  q->data[0] = 1 + 6*mt_num;
  if (event_type >= 3)
    event_type -= 2;
  
  q->data[1] = event_type;  /* 01H����ͣ���¼�,02H�����ϵ��¼� */
  for (int i = 0; i < mt_num; i++)
    {
      memcpy(&q->data[2+i*6], &buf[c + 14 + 6*i], IDLEN);
    }
  app_set_frm_sno(q, 1);
  app_set_frm_tail(p, MINLEN + IDLEN * 2 + 1 + 1 + 6*mt_num); 
  
  rf_write(t, p->len, 0);
  report = 1;
  return ;
}

void app_mtpower_up(unsigned char aid_num, unsigned char *buf)
{
  unsigned char tchar[6] = {0x66, 0x66, 0x66, 0x66, 0x66, 0x66};
  unsigned char t[0x100] = {0};//, c;
  int c;
  struct frame_nw *p = (struct frame_nw *)&t;
  struct app_data_nw *q = (struct app_data_nw *)&p->data[IDLEN * 2];

  if ((_rtparas.wkstate & RPTSWIMASK) != RPTSWION)  /* �ϱ��������� */
    {
        return;
    }

  /* ��֯376.2���� */
  p->head = 0x68;
  p->dir = 1;
  p->prm = 1;
  p->addr = 1;
  p->ver = 0;

  memcpy(&p->data[0], buf, IDLEN);
  aid_645_tonormal(&p->data[0]);
  if (aid_num > 1)
    memset(&p->data[0], 0x99, IDLEN);
  memcpy(&p->data[6], _rtparas.jzqid_nw, IDLEN);
  
  q->afn = 0x05;
  q->di[0] = 0x02;
  q->di[1] = 0x05;
  q->di[2] = 0x05;
  q->di[3] = 0xE8;
  
  /* 01H ����ͣ���¼���02H�����ϵ��¼���03H����ģ�����¼�(2,3��ʱ��֧��) */

  q->data[0] = 1 + 6 * aid_num;  /* ���ĳ��� */
  q->data[1] = 1;  /* 01H ����ͣ���¼� */
  
  memcpy(&q->data[2], buf, IDLEN * aid_num);
  
  for (int i = 0; i < aid_num; i++)
    {
      aid_645_tonormal(&q->data[2 + IDLEN * i]);
    }
  
  app_set_frm_sno(q, 1);
  app_set_frm_tail(p, MINLEN + IDLEN * 2 + 2 + IDLEN * aid_num);
  
  rf_write(t, p->len, 0);
  report = 1;
  return ;
}

void app_power_up(unsigned char event_type, unsigned char aid_num, unsigned char *buf)
{
  unsigned char t[0x100] = {0};
  struct frame_nw *p = (struct frame_nw *)&t;
  struct app_data_nw *q = (struct app_data_nw *)&p->data[IDLEN * 2];
  
  if ((_rtparas.wkstate & RPTSWIMASK) != RPTSWION)  /* �ϱ��������� */
    {
        return;
    }

  /* 376.2Э�� */
  p->head = 0x68;
  p->dir = 1;
  p->prm = 1;
  p->addr = 1;
  p->ver = 0;

  memcpy(&p->data[0], buf, IDLEN);
  aid_645_tonormal(&p->data[0]);
  if (aid_num > 1)
    memset(&p->data[0], 0x99, IDLEN);
  memcpy(&p->data[6], _rtparas.jzqid_nw, IDLEN);
  
  q->afn = 0x05;
  q->di[0] = 0x02;
  q->di[1] = 0x05;
  q->di[2] = 0x05;
  q->di[3] = 0xE8;
  q->data[0] = 1 + 6 * aid_num;
  q->data[1] = event_type;  /* 01H ����ͣ���¼���2H�����ϵ��¼���3H����ģ�����¼� */
  
  memcpy(&q->data[2], buf, IDLEN * aid_num);
  
  for (int i = 0; i < aid_num; i++)
    {
      aid_645_tonormal(&q->data[2 + IDLEN * i]);
    }
  
  app_set_frm_sno(q, 1);

  app_set_frm_tail(p, MINLEN + IDLEN * 2 + 2 + IDLEN * aid_num);
  
  rf_write(t, p->len, 0);
  report = 1;
  return ;
}


void appgd_init()
{
  eep_read(e2rom_addr(viv_switch), &local_viv_swi, e2rom_len(viv_switch));//viv_switchҪ�ڳ�ʼ��ʱ������
  if (local_viv_swi != 1)
    local_viv_swi = 2;
}

void app_rt_test_tick()
{
  if(rt_test.time)
  {
    if(rt_test.time >= SYS_TICK_INTERVAL)
      rt_test.time -= SYS_TICK_INTERVAL;
    else
    {
      rt_test.time = 0;
      rt_test.chn = 0;
    }
  }
}


void app_debugup(unsigned char *frm, unsigned char len)
{
    unsigned char afn, dt, ccw, buf[0x200];
    int l = 1;
    int jzq_len = 0;
    unsigned char jzq_address[IDLEN];
    struct frame_gw_3762 *p = (struct frame_gw_3762 *)&buf[0];
    struct info_down_gw *info_field = (struct info_down_gw *)p->user_data;

    last_gw_frame_sno = info_field->sno; 
    
    unsigned int tick_count, to_delay = 0, t = 10, cnt = 0;
    rf_get_jzqid_nw(&jzq_address[0], &jzq_len);

    //���ǳ�����������?·��Ӧ��
    if (0 == frm[0] & 0x01)
        return;

    if (frm[0] & 0x08)
        l += 6;  //����?�����ں����ж�?��һ����Ҫ

    if (frm[0] & 0x02)
    {
        //�е�ַ�������
        if (memcmp(&frm[l], jzq_address, 6))
            return;

        l += 6;
    }
    else
    {
        //�޵�ַ��?�����ʱ��ظ�?��ʱ3s����
        tick_count = get_sys_tick();
        to_delay = 100 * ((tick_count / 10) % 100); //0 - 2500
    }

    ccw = frm[l++];
    //��������Ϊ376.2����?���㺯������
    if (len >= (l + 3))
    {
        memcpy(&p->user_data[6], &frm[l], len - l);
        p->length = FRMAE_DEFAULT_GW_LEN + len - l - 3;
        p->comm_method = ccw;
        memset(&p->user_data[0], 0x00, 6);
    }

    afn = frm[l++];
    dt = get_gw_dt_list(&frm[l]);

    l += 2;

    if (ccw == 0x01 && afn == 0x03 && dt == 0x04)
    {
        appchn = CHN_38_1;
        unsigned char tchar[5] = { 0x01, 0x02, 0x03, 0x04, 0x05 };
        struct app_data_gw *papp = (struct app_data_gw *)&p->user_data[6];

        if (p->length != (FRMAE_DEFAULT_GW_LEN))
        {
            app_frm_negate_gw(p->comm_method, E_LENGTH);
            return;
        }

        memcpy(&papp->data_unit[0], &jzq_address[0], 6);

        app_frm_normal_gw(p->comm_method, (unsigned char *)papp, 6 + 3);

        if (rt_test.time)
            sys_uart_write(CHN_DM, tchar, 5);

        return;
    }
    //��֧�ֵ�
    else
    {
        app_frm_negate_gw(p->comm_method, E_NO_INFOTYPE);
        appchn = CHN_DM;
        return;
    }
#if 0 //czz
    if((0 == frm[0] & 0x02) && (pafn_t->scope & PLC_AD_ONLY))
    {
        frame_negate_send(pframe->comm_method, E_WRONGFORMAT);
        set_comm_channel(UART_CHN_DM);
        return;
    }
#endif

    while ((t < to_delay) && (cnt < 30))
    {
        t = get_sys_tick() - tick_count;
        delay_ms(100);
        cnt++;   //��ֹ����
        watchdog();
    }

//  pafn_t->handle(pafn_t, p);
//�ָ�ΪĬ�ϼ���������
    appchn = CHN_DM;
}

static void app_debugdn(unsigned char *buf, unsigned char *data, int len, unsigned char ccw)
{
  ses_debugdn(buf, data, len, ccw);
}


static void app_set_frm_head_gw(struct frame_gw_3762 *frm, unsigned char ccw)
{
    frm->start_flag = 0x68;
    frm->dir = 1;
    frm->prm = 0;
    frm->comm_method = ccw;
}

static void app_set_info_default(unsigned char *buf, unsigned char ccw, unsigned char debug_info)
{
    struct info_up_gw *info_field = (struct info_up_gw *)buf;

    info_field->reserved0 = 0;
    info_field->reserved1 = 0;
    info_field->reserved2 = 0;
    info_field->com_module = 0;
    info_field->chn_id = 0;
    info_field->router = 0;

    info_field->info_no5 = 0;
    info_field->event_flag = 0;
    info_field->sno = 0;
    info_field->last_ans_sig = 0;
    info_field->last_com_sig = 0;
    info_field->phase = 0x00;
    info_field->relay_level = debug_info & 0x0f;
    info_field->meter_chn_sta = 0x00;
}


static void app_set_info_frm_sno(unsigned char *buf, unsigned char sno)
{
    struct info_up_gw *info_field = (struct info_up_gw *)buf;

    info_field->sno = sno;
}

static void app_send_data(unsigned char *buf, unsigned int len)
{
    sys_uart_write(CHN_DM, buf, len);
}



static struct app_data_gw* get_app_by_len(struct frame_gw_3762 *frm, unsigned char ccw, unsigned int len)
{
    int info_len = 6;

    if (0x07 == ccw)
        info_len = 6;

    return ((struct app_data_gw *)&frm->user_data[info_len + len]);
}


static int app_frm_normal_gw(unsigned char ccw, unsigned char *user_data, unsigned int len)
{
    unsigned char buf[0x200], frame[0x200];
    struct frame_gw_3762 *p = (struct frame_gw_3762 *)&buf[0];
    struct app_data_gw *papp = get_app_by_len(p, ccw, 0);
    int frame_len, tt = len;

    memset(&buf[0], 0x00, sizeof(buf));
    app_set_frm_head_gw(p, ccw);
    app_set_info_default((unsigned char *)&p->user_data[0], ccw, 0);
    app_set_info_frm_sno(&p->user_data[0],  last_gw_frame_sno); 

    len = len + FRMAE_DEFAULT_GW_LEN - 3;
    memcpy((unsigned char *)papp, &user_data[0], len);
    app_set_frm_tail((struct frame_nw *)p, len);

    if (CHN_38_1 == appchn)
    {
        app_debugdn(&frame[0], &papp->afn, tt, ccw);
        return 0;
    }
    else
    {
        memcpy(p, buf, p->length);
        frame_len = p->length;
    }
    app_send_data((unsigned char *)p, frame_len);
    return (len);
}



static int app_frm_confirm_gw(unsigned char ccw, unsigned int wait_time, unsigned char sno)
{
  unsigned char buf[0x20], frame[0x200];
  struct frame_gw_3762 *p =  (struct frame_gw_3762 *)buf;
  struct app_data_gw *papp = get_app_by_len(p, ccw, 0);
  int frame_len, added_len = 0;

  memset(&buf[0], 0x00, sizeof(buf));
  app_set_frm_head_gw(p, 1);
  app_set_info_default((unsigned char *)&p->user_data[0], 1, 0);
  app_set_info_frm_sno((unsigned char *)&p->user_data[0], sno);

  papp->afn = 0x00;
  papp->data_type[0] = 0x01;
  papp->data_type[1] = 0x00;

  if(wait_time)
    papp->data_unit[0] = 0xfe;
  else
    papp->data_unit[0] = 0xff;
  added_len = 2;
  memset(&papp->data_unit[1], 0xff, 1 + added_len);

  papp->data_unit[added_len + 2] = (unsigned char)(wait_time & 0xff);
  papp->data_unit[added_len + 3] = (unsigned char)(wait_time >>8);

  app_set_frm_tail((struct frame_nw *)p, FRMAE_DEFAULT_GW_LEN + 4 + added_len); 

  memcpy(p, buf, buf[1]);
  frame_len = buf[1];

  app_send_data((unsigned char *)p, frame_len);
  return (FRMAE_DEFAULT_GW_LEN + 4 + added_len);
}

static int app_frm_negate_gw(unsigned char ccw, unsigned char e_code)
{
  unsigned char buf[0x20], frame[0x200];
  struct frame_gw_3762 *p = (struct frame_gw_3762 *)&buf[0];
  struct app_data_gw *papp = get_app_by_len(p, ccw, 0);
  int len;

  memset(&buf[0], 0x00, sizeof(buf));

  app_set_frm_head_gw(p, 1);
  app_set_info_default((unsigned char *)&p->user_data[0], 1, 0);
  app_set_info_frm_sno(&p->user_data[0], last_gw_frame_sno);

  papp->afn = 0x00;
  papp->data_type[0] = 0x02;
  papp->data_type[1] = 0x00;
  papp->data_unit[0] = e_code;
  app_set_frm_tail((struct frame_nw *)p, FRMAE_DEFAULT_GW_LEN + 1); 
  memcpy(frame, buf, buf[1]);
  len = buf[1];

  app_send_data(frame, len);

  return (FRMAE_DEFAULT_GW_LEN + 1); 
}

