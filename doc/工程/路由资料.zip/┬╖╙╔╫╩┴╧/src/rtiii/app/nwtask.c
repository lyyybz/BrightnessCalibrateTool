
//-----------------�㶫2016Э����غ�������----------------------------
#include "stdio.h"
#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/app/nwtask.h"


#include "../include/db/db.h"
#include "../include/db/node.h"
#include "../include/rt/rtfuns.h"
#include "../include/rt/rtpara.h"
#include "appgb.h"
#include "router.h"

//#define TASK_DEFAULT_LEN    6


#define TASK_BUF_SIZE       0x1000
#define MAX_TASK_ID         0xEFFF
#define TASK_ID_INVALID     0xFFFF//����task id ��Χ0x0000-0xEFFF

#define TASK_TICK_8_MIN    (3*60)//����������8���ӽ���һ��

#define MIN_TASK_TIME       (20) //ѡ�������ʱ�򣬵�������ʣ��n��ʱ��������ѡ��
unsigned int task_tick = 60;


#define TMOUT_PRI0_DC   60
#define TMOUT_PRI1_DC   60
#define TMOUT_PRI2_DC   300
#define TMOUT_PRI3_DC   300
#define TMOUT_BRD       300
#define TMOUT_MINPRI_NUM 21   //��ʱʱ�������ǰ���20����ģ����ﰴ��21��
#define TMOUT_MAX   (60*60)//���ʱʱ��

static unsigned char task_buf[TASK_BUF_SIZE];
enum
{
    NW_TASK_PAUSE,
    NW_TASK_RUN,
};

struct task_nw_info nw_task[2]; //0 ����·������������ִ��
                                //1���ڸ߼��ģ����ȼ�Ϊ0 1���㲥��������������
extern struct rt_test_info rt_test;

static int chk_to_dc_v();
static int moitor_a_task(unsigned int tid);
static int moitor_a_task_v();
static int get_newest_node_task(void);
static int sel_task_to_exe(void);
static int trav_find_min_time(void);
static int is_have_high_task(unsigned char *buf);

static void init_task_buf(void)
{
    memset(task_buf, 0x00, sizeof(task_buf));
}


void init_nw_cur_task(unsigned int sn)
{
    nw_task[sn].valid = 0;
    nw_task[sn].pri = 4;
    nw_task[sn].time = 0;
    nw_task[sn].tid = TASK_ID_INVALID;
    memset(nw_task[sn].appid, 0x00, IDLEN);
    nw_task[sn].dlen = 0;
    nw_task[sn].pro = 0;
    memset(nw_task[sn].dataitem, 0x00, sizeof(nw_task[sn].dataitem));
}


int ses_get_task_info(unsigned short *cnt, unsigned short *size)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;

    *cnt = 0;
    *size = 0;
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            return 0;
        }
        *cnt += 1;
        *size += p->frm.len + TASK_DEFAULT_LEN;
        if (*size >= sizeof(task_buf))
            return 0;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
}
//��ȡ���ȼ���2��3����������
int ses_get_rt_task_info(unsigned short *cnt, unsigned short *size)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;

    *cnt = 0;
    *size = 0;
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            return 0;
        }
        if (p->frm.pri == TASK_PRI_2 || p->frm.pri == TASK_PRI_3)
        {
            *cnt += 1;
        }
        *size += p->frm.len + TASK_DEFAULT_LEN;
        if (*size >= sizeof(task_buf))
            return 0;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
}
int ses_add_task(struct task_buf_info *p)
{
    unsigned short cnt, size;

    ses_get_task_info(&cnt, &size);

    if (p->frm.len + TASK_DEFAULT_LEN > TASK_BUF_SIZE - size)
        return -1;
    p->valid = 1;
    p->cnt = MAX_EXE_TIMES;
    // memcpy(&task_buf[size], (unsigned char *)&p->id, p->len + TASK_DEFAULT_LEN);
    memcpy(&task_buf[size], (unsigned char *)p, p->frm.len + TASK_DEFAULT_LEN);

    return 0;
}

int ses_del_task(unsigned short tid)
{
    unsigned char f = 0;
    unsigned short cnt, size;
    unsigned int s;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    unsigned char aid[6];

    ses_get_task_info(&cnt, &size);
    s = p->frm.len + TASK_DEFAULT_LEN;
    for (int i = 0; i < cnt; i++)
    {
        if (p->frm.id == tid)
        {
            f = 1;

            memcpy(aid, p->add, 6);
            memmove(&p->add[0], (unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN, TASK_BUF_SIZE - s);
            memset(task_buf + TASK_BUF_SIZE - (p->frm.len + TASK_DEFAULT_LEN), 0x00, p->frm.len + TASK_DEFAULT_LEN);
            break;
        }
        s += p->frm.len + TASK_DEFAULT_LEN;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
    //�˴�Ӧ�ÿ�����ǰ�Ƿ����ڳ���������������ֹͣ����!!!!!!!!!!!!!!!!!!!1
    //ses_del_col_task_by_tid(id);
    if (nw_task[TASK_EXE_RT].tid == tid)
    {
        init_nw_cur_task(TASK_EXE_RT);

    }
    else if (nw_task[TASK_EXE_HIGH].tid == tid)
    {
        init_nw_cur_task(TASK_EXE_HIGH);
    }

    if (f == 0)
    {
        return -1;
    }
    else
    {
        if (0 == is_task_buf_has_mt(aid)) //���Ǹñ�������
        {
            clear_mt_cm1suc_flag(aid); //����ñ��ɹ���־����Ϊ�Գ���
        }
        else
        {

            set_mt_cm1suc_flag(aid);
        }
    }

    return 0;
}
void del_one_task(unsigned int tid, unsigned char add[])
{
    struct mtinfo *mt;
    unsigned char tmpid[6];

    memcpy(tmpid, add, IDLEN);
    ses_del_task(tid);

    id_bintobcd(tmpid);
    reverse(tmpid, 6);
    if (0 != is_task_buf_has_mt(tmpid)) //���񻺴����棬û�иñ���
    {
        id_bcdtobin(tmpid);
        reverse(tmpid, 6);
        if ((mt = db_find(tmpid)) != NULL)
        {
            mt->node.envi |= NCMD1SUC;  //��ǰ����û����db_write�ĵ���  //���Ըñ����г����������ݱ�ʶȫ��������ɱ�־��Ϊ��Ч
        }
    }

    reset_task_sec_tick();
}
void del_cur_task(unsigned int sn)
{
    del_one_task(nw_task[sn].tid, nw_task[sn].appid);

}
unsigned int ses_get_task_list(unsigned short tid, unsigned char num, unsigned short *buf)
{
    unsigned int size = 0, ret = 0;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;

    buf[0] = 0xFFFF;
    while (1)
    {
        //if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        if (p->frm.id >= tid)
        {
            for (int i = 0; i < 15; i++)
            {
                if (p->frm.id < buf[i])
                {
                    memmove(&buf[i + 1], &buf[i], 30 - (i + 1) * 2);
                    buf[i] = p->frm.id;
                    ret += 1;
                    break;
                }
            }
        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
    return (num > ret ? ret : num);
}

struct task_buf_info* ses_find_task(unsigned short tid)
{
    int size = 0;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    while (1)
    {
        //if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        if (p->frm.id == tid)
            return p;
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
    return NULL;
}

void get_nw_task_appid(unsigned int sn, unsigned char *id)
{
    memcpy(id, nw_task[sn].appid, IDLEN);
}
void set_nw_task_appid(unsigned int sn, unsigned char *id)
{
    memcpy(nw_task[sn].appid, id, IDLEN);
}
unsigned int get_nw_task_id(unsigned int sn)
{
    return nw_task[sn].tid;
}
int get_nw_task_dataitem(unsigned int sn, unsigned char data[])
{
    memcpy(data, nw_task[sn].dataitem, nw_task[sn].dlen);
    return nw_task[sn].dlen;
}
static int is_cur_taskid_running(unsigned int sn, unsigned short tid)
{
    int t = 0;
    if (tid == nw_task[sn].tid)
        t = 1;
    return t;
}
void init_nw_task_info()
{
    init_task_buf();
    for (int i = 0; i < TASK_EXE_HIGH + 1; i++)
    {
        memset((unsigned char *)&nw_task[i], 0x00, sizeof(struct task_nw_info));
        init_nw_cur_task(i);
        nw_task[i].sta = NW_TASK_PAUSE;
    }

}

static int chk_to_dc_v()
{
  return moitor_a_task_v();
}

static int chk_to_brd_phs(void)
{
    if ((_rtparas.sndphs & PHSNEEDSMASK) == PHSNEEDSND)
    {
        _rtparas.sndphs &= ~PHSNEEDSMASK;
        _rtparas.sndphs &= ~PHSSINGMASK;
        _rtparas.sndphs |= PHSSNDING;
        set_to_brd_phs_v();
        return 0;
    }
    return -1;
}
static int chk_to_dc_task(void)
{
    if (_rtparas.dctask == 1)
    {
        if (sel_task_to_exe() >= 0)
        {
            task_tick = get_monitor_time();
            if (_rtparas.dcnum > 0)
            {
                _rtparas.dcnum--;
            }
            _rtparas.dcmin = DCTASK_TIMEOUT; //
            return 0;
        }
        if (_rtparas.dcnum == 0 || _rtparas.cyctime == 0)
        {
            _rtparas.dctask = 0;
        }
        return -1;
    }
    return -1;
}
static void chk_to_flood_save(void)
{
    if (_rtparas.flsave == 1)
    {
        db_flush();
        _rtparas.flsave = 0;
    }
}


static int get_vir_high_pri(unsigned char *buf)
{

    int size = 0;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;

    while (1)
    {
        if (0 == p->valid)
            break;
        if ((p->frm.pri == TASK_PRI_1)
            && p->pri_chang == 1
            && !is_cur_taskid_running(TASK_EXE_HIGH, p->frm.id))
        {
            memcpy(buf, (unsigned char *)p->add, p->frm.len + TASK_DEFAULT_LEN);

            return 0;
        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();

    }
    return -1;
}

/*
ֻ������������
1�� ���ȼ�Ϊ0 1��
2���㲥��
3��Ŀ�ı������ڱ�������
*/
extern unsigned char local_viv_swi;

void nw_deal_high_task()
{
    unsigned char buf[0x100];
    unsigned char find = 2;
    struct task_buf_info *q = (struct task_buf_info *)buf;
    unsigned char aid[IDLEN];
    unsigned char frmuplen = 0;
    if ((_rtparas.state & STAMMASK) == STAMONIT
        || (_rtparas.state & STABMASK) == STABROAD
        || (_rtparas.state & STASTMASK) != STARUN)
    {
        return;
    }

    if (is_have_high_task(buf) < 0)
    {
      if (chk_to_dc_v() >= 0)
        {
          return;
        }
      _rtparas.dcviv = TYPE43;

      #if 0
      if (chk_to_brd_phs() >= 0)
        {
            return;
        }
      #endif

        if (chk_to_dc_task() >= 0)
        {
            return;
        }
        if (get_vir_high_pri(buf) >= 0)
        {
            find = 0;
        }

    }
    else
    {
        find = 0;
    }
    chk_to_flood_save();//����56ģʽ��ʱ�򣬱���ڵ������


    /* ���û�������ִ��, �˳� */
    if (find == 2)
    {
        return;
    }

    if (find == 0 )
    {
        int viv = 0;
        struct mtinfo *mtp;
        memcpy(aid, q->add, IDLEN);
        aid_645_tohash(aid);
        if ((mtp = db_find(aid)) != NULL)
          {
            if (local_viv_swi != 1 &&((mtp->node.viv & NNDMASK) == NND53 
                || ((mtp->node.viv & NNDMASK) == NND55 && (((mtp->node.viv & NETMASK) >> 2) == 0x01))))
              viv = 1;
            else
              viv = 2;

            if (local_viv_swi == 1) 
            {
                viv = 0; 
            }
          }
        else
        {
            if (local_viv_swi == 1)
            {
                viv = 0;
            }
            else
              viv = 2;//�ǵ����еı�����2�Σ�һ�ΰ���5��һ�ΰ���3��
        }
          
        if (q->frm.pri < nw_task[TASK_EXE_HIGH].pri) //���ҵ��������ȼ�����
        {
            /* ��Ҫ����1�������費��Ҫת�� 2�����data�����費��Ҫ��� */
            if (is_data_all_same(q->add, IDLEN, 0x99) && (q->frm.rep == 0)) /* �㲥 */
            {
                init_nw_cur_task(TASK_EXE_HIGH);
                nw_task[TASK_EXE_HIGH].valid = 1;
                nw_task[TASK_EXE_HIGH].pri = q->frm.pri;
                nw_task[TASK_EXE_HIGH].tid = q->frm.id;

                memcpy(aid, q->add, IDLEN); //���������ַ
                                            //id_bcdtobin(aid);
                                            //reverse(aid, IDLEN);�㲥�ľͲ�ת��ΪBIN�ˣ�ֱ����
                set_nw_task_appid(TASK_EXE_HIGH, aid);

                if (0 != appgb_broad_v(q->frm.buf, q->frm.len, q->frm.time))
                {
                    id_bintobcd(nw_task[TASK_EXE_HIGH].appid);
                    reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
                    nw_report_task_state(nw_task[TASK_EXE_HIGH].tid, nw_task[TASK_EXE_HIGH].appid, TASK_STATUS_DATA_ERR);
                    ses_del_task(nw_task[TASK_EXE_HIGH].tid);
                    init_nw_cur_task(TASK_EXE_HIGH);

                }

                return;
            }

            if (is_data_all_same(q->add, IDLEN, 0x99) == 0)   /* �㳭 */
            {
                //ses_dc(q->len, q->buf);
                nw_task[TASK_EXE_HIGH].valid = 1;
                nw_task[TASK_EXE_HIGH].pri = q->frm.pri;
                nw_task[TASK_EXE_HIGH].tid = q->frm.id;
                nw_task[TASK_EXE_HIGH].time = q->frm.time;
                nw_task[TASK_EXE_HIGH].pro = q->pro;
                memcpy(nw_task[TASK_EXE_HIGH].appid, q->add, IDLEN); //���������ַ
                

                printf_s("\nnw_deal_high_task current aid is:  ");
                for(int i = 0; i< IDLEN; i++)
                  {
                    printf_s("%02x ",nw_task[TASK_EXE_HIGH].appid[i]);
                  }
                printf_s("\n");
              
                if (viv == 1 || (viv == 2))  /* ��V���� */
                  nw_task[TASK_EXE_HIGH].pro = DLT698;  /* V�����ڲ���ʱ����698.45���� */
              
                if ((nw_task[TASK_EXE_HIGH].pro == DLT64507) || (nw_task[TASK_EXE_HIGH].pro == DLT64597))
                {
                    id_bcdtobin(nw_task[TASK_EXE_HIGH].appid);  /* 43����Ҫת������ */
                    reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
                  
                    frmuplen = 0;//get_frame645_up_len(q->frm.buf);
                    nw_task[TASK_EXE_HIGH].dataitem[0] = q->frm.buf[8];
                    nw_task[TASK_EXE_HIGH].dlen = q->frm.buf[8 + 1] + 1; //���Ͽ�����

                    for (int i = 1; i < nw_task[TASK_EXE_HIGH].dlen; ++i) nw_task[TASK_EXE_HIGH].dataitem[i] = q->frm.buf[8 + 1 + i] - 0x33;

                }
                else
                {
                    /* V��������Ҫת������ */
                    nw_task[TASK_EXE_HIGH].dlen = q->frm.len;
                    memcpy(nw_task[TASK_EXE_HIGH].dataitem, q->frm.buf, q->frm.len);

                }

                rf_set_appd_bk(nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen);
                // appgb_nw_dc(q->buf, q->len);
                if (viv == 0)
                  {
                    id_bcdtobin(nw_task[TASK_EXE_HIGH].appid);  /* 43����Ҫת������ */
                    reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN); 
                    _rtparas.dcviv = TYPE43;
                    appgb_nw_dc(nw_task[TASK_EXE_HIGH].pro, nw_task[TASK_EXE_HIGH].appid, nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen, frmuplen);
                  }
                else
                  {
                    if (viv == 1)
                      _rtparas.dcviv = TYPE53; 
                    else
                      _rtparas.dcviv = TYPE53_43; 

                    int len = 0;

                    unsigned char frm[1000]; 
                    memcpy(frm, q->frm.buf, q->frm.len); 
                    len = q->frm.len;
                    if (q->pro == 0x00) /*͸��Э��,���ڵ���û������*/
                    {
                      if (local_viv_swi != 1 && ((mtp->node.viv & NNDMASK) == NND53
                                                 || ((mtp->node.viv & NNDMASK) == NND55 && (((mtp->node.viv & NETMASK) >> 2) == 0x01))))
                      {
                        /*����9e����*/

                        memset(frm, 0x00, sizeof(frm));
                        len = ses_set_item_trans(nw_task[TASK_EXE_HIGH].appid, q->frm.buf, q->frm.len, &frm[0]); 
                        nw_task[TASK_EXE_HIGH].dlen = len;
                        
                      }
                      else
                      {
                        /*����̽��*/

                        reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN); 
                        memset(frm, 0x00, sizeof(frm));
                        len = detectmt(nw_task[TASK_EXE_HIGH].appid, frm); 
  
                        if (len == 0)   /*��̽���б�����*/
                        {

                          reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
                          memset(frm, 0x00, sizeof(frm));
                          len = ses_set_item_trans(nw_task[TASK_EXE_HIGH].appid, q->frm.buf, q->frm.len, &frm[0]);

                          nw_task[TASK_EXE_HIGH].dlen = len; 
                        }
                        else
                        {
                          appgb_nw_dc_v(02, q->add, frm, len, frmuplen);

                          id_bintobcd(nw_task[TASK_EXE_HIGH].appid);
                          reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN); 
                          nw_report_task_state(nw_task[TASK_EXE_HIGH].tid, nw_task[TASK_EXE_HIGH].appid, TASK_STATUS_DATA_ERR);
                          ses_del_task(nw_task[TASK_EXE_HIGH].tid);
                          init_nw_cur_task(TASK_EXE_HIGH); 
                          return;
                        }

                      }
                    }
                    appgb_nw_dc_v(q->pro, q->add, frm, len, frmuplen); 
                  }
                
                if (mtp != NULL)
                  mtp->dctype++;
                return;
            }
        }
    }
    return;
}

//�����������Զ����������ȼ���2��3�ı�
int is_task_buf_has_mt(unsigned char bcdid[])
{
    int size = 0;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    while (1)
    {
        if (0 == p->valid)
            break;
        if (p->valid
            && 0 == memcmp(p->add, bcdid, 6)
            && (p->frm.pri == TASK_PRI_2 || p->frm.pri == TASK_PRI_3))
        {
            return 0;
        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
    return -1;
}
//Ѱ���Ƿ��������ĸ����ȼ�����
static int is_have_high_task(unsigned char *buf)
{
    int find = -1;
    int size = 0;
    unsigned char pri = 4;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;

    if (_share.conswitch & 0x01) //����ʽ��������ֻѡ�� 0 ��1�����ȼ�ִ��
    {
        while (1)
        {
            if (0 == p->valid)
                break;
            if (p->pri_chang == 0
                && p->frm.pri < pri
                && (p->frm.pri <= TASK_PRI_1)
                && !is_cur_taskid_running(TASK_EXE_HIGH, p->frm.id))
            {
                memcpy(buf, (unsigned char *)p->add, p->frm.len + TASK_DEFAULT_LEN);
                pri = p->frm.pri;
                find = 0;
                
                if (pri == TASK_PRI_0) //������ȼ�����û��Ҫ����������
                {
                    return find;
                }
            }
            size += p->frm.len + TASK_DEFAULT_LEN;
            if (size >= sizeof(task_buf))
                break;
            p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
            watchdog();
        }
        return find;
    }
    else//56ģʽѰ�����е�
    {
        while (1)
        {
            if (0 == p->valid)
                break;
            if (p->frm.pri < pri
                && (p->frm.pri <= TASK_PRI_3)
                && !is_cur_taskid_running(TASK_EXE_HIGH, p->frm.id))
            {
                memcpy(buf, (unsigned char *)p->add, p->frm.len + TASK_DEFAULT_LEN);
                pri = p->frm.pri;
                find = 0;
                if (pri == TASK_PRI_0) //������ȼ�����û��Ҫ����������
                {
                    return find;
                }
            }
            size += p->frm.len + TASK_DEFAULT_LEN;
            if (size >= sizeof(task_buf))
                break;
            p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
            watchdog();
        }
        return find;
    }

   // return find;
}

void clear_task_mt_cmd1suc()
{
    unsigned char aid[6];
    struct mtinfo *mt;
    int size = 0;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    while (1)
    {
        if (0 == p->valid)
            break;
        if (p->valid && 0 == is_data_all_same(p->add, 6, 0x99))
        {
            memcpy(aid, p->add, 6);
            id_bcdtobin(aid);
            if ((mt = db_find(aid)) != NULL)
            {
                mt->node.envi &= ~NCMD1MASK;  //��ǰ����û����db_write�ĵ���
            }

        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
}


/*·���������볭����������������ȡ�������ͬʱ����������*/
int get_read_from_task(unsigned char binid[])
{

    // unsigned char data[255];
    unsigned char bcdid[6];
    int find = 0;
    // int dlen = 0;
    // struct mtinfo *mt;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    unsigned int tid;

    printf_s("\n****get_read_from_task****\n");
  
    memcpy(bcdid, binid, 6);
    id_bintobcd(bcdid);
    reverse(bcdid, 6);
    while (1)
    {
        if (0 == p->valid)
            break;
        if (p->valid && 0 == memcmp(p->add, bcdid, 6) )
        {
            find = 1;
            break;

        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    //if ((t_len = is_valid645(&para[pos + 2], para[pos + 1])) < 0)
    //    return -1;

    if (find)
    {
        if (p->cnt > 0)
        {
            p->cnt--;
        }
        if (p->cnt == 0)
        {
            memcpy(bcdid, p->add, IDLEN);
            tid = p->frm.id;
            del_one_task(tid, bcdid);
            nw_report_task_state(tid, bcdid, TASK_STATUS_NO_RES);

            return rf_setappd(APPRCFM, NULL, 0, 0);;
        }

        nw_task[TASK_EXE_RT].valid = 1;
        nw_task[TASK_EXE_RT].pro = p->pro;
        nw_task[TASK_EXE_RT].pri = p->frm.pri;
        nw_task[TASK_EXE_RT].tid = p->frm.id;
        nw_task[TASK_EXE_RT].time = p->frm.time;

        memcpy(nw_task[TASK_EXE_RT].appid, p->add, IDLEN); //���������ַ
        id_bcdtobin(nw_task[TASK_EXE_RT].appid);
        reverse(nw_task[TASK_EXE_RT].appid, IDLEN);

        if (nw_task[TASK_EXE_RT].pro == DLT64507)
        {
            nw_task[TASK_EXE_RT].dataitem[0] = p->frm.buf[8];
            nw_task[TASK_EXE_RT].dlen = p->frm.buf[8 + 1] + 1; //���Ͽ�����

            for (int i = 1; i < nw_task[TASK_EXE_RT].dlen; ++i) nw_task[TASK_EXE_RT].dataitem[i] = p->frm.buf[8 + 1 + i] - 0x33;
        }
        else
        {
            nw_task[TASK_EXE_RT].dlen = p->frm.len;
            memcpy(nw_task[TASK_EXE_RT].dataitem, p->frm.buf, p->frm.len);

        }


        return rf_setappd_ex(APPRDATA | TYPEFLAG, nw_task[TASK_EXE_RT].pro, nw_task[TASK_EXE_RT].dataitem, nw_task[TASK_EXE_RT].dlen, 0);

        // return rf_setappd(APPRDATA | TYPEFLAG, nw_task[TASK_EXE_RT].dataitem, nw_task[TASK_EXE_RT].dlen, 0);

    }
    else
    {
        return rf_setappd(APPRCFM, NULL, 0, 0);;
    }
    _rtparas.dlytm &= ~0x02;
    _rtparas.dlytm &= ~0x08;
    rf_setdlytm(0);
}

//��������ѡȡ�������µ�·��ȥִ��
// >=0 task id
// <0 all task have no valid road
static int get_newest_node_task(void)
{
    unsigned int tick = 0;
    unsigned int taskid = 0xFFFF;
    unsigned char bcdid[6];

    struct mtinfo *mt;
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    while (1)
    {
        if (0 == p->valid)
            break;
        if (p->valid && (p->frm.pri == TASK_PRI_2 || p->frm.pri == TASK_PRI_3 || (p->pri_chang == 1 && p->frm.pri == TASK_PRI_1)))
        {
            memcpy(bcdid, p->add, 6);
            id_bcdtobin(bcdid);
            reverse(bcdid, IDLEN);
            if ((mt = db_find(bcdid)) != NULL)
            {
                if (mt->rdtick >=tick)//�������ʣ����·���ģ�Ҳȥ����
                {
                    tick = mt->rdtick;
                    taskid = p->frm.id;
                }

//              if (p->frm.time <= MIN_TASK_TIME) //This task res time is too samll need to exe
//              {
//                  tick = TICK_NEWEST;
//                  taskid = p->frm.id;
//                  break;
//              }
            }
            else //���ڵ����ı���ֱ����ȡ����ȥ����
            {
                tick = TICK_NEWEST;
                taskid = p->frm.id;
                break;
            }

        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            break;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }


   // if (tick > 0 && taskid != 0xFFFF)
    if (taskid != 0xFFFF)
    {
        return taskid;
    }

    return -1;

}


static int sel_task_to_exe(void)
{
    int tid;
    //unsigned char aid[IDLEN];
    unsigned char exeflag = 0;

    if ((_rtparas.state & STASTMASK) != STARUN)
    {
        return -1;
    }
    if ((_rtparas.state & STAMMASK) == STAMONIT
        || (_rtparas.state & STABMASK) == STABROAD)
    {
        return -1;
        // exeflag = 1;
    }


    if ((tid = get_newest_node_task()) >= 0 && exeflag == 0)
    {
        moitor_a_task(tid);
        return 0;
    }
    //  else if ((tid = get_min_tick_task(aid)) >= 0)
    //  {
    //
    //      nw_report_task_state(tid, aid, TASK_STATUS_NO_RES);//�˴�����1����ֹ·�ɼ���������·���ı�
    //      ses_del_task(tid);
    //
    //  }

    return -1;
}

//01234567890
unsigned short table_sec[] = { 220, 200, 180, 150, 140, 120, 100, 70, 70, 60, 50 };
int get_monitor_time()
{
    int rat;
    int time;//, ttime;
    rat = get_suc_mt_ratio();
    if (rat < sizeof(table_sec))
    {
        time = table_sec[rat];
    }
    else
    {
        time = TASK_TICK_8_MIN;
    }
#if 0
    if ((ttime = trav_find_min_time()) >= 0)
    {
        if (ttime < time) //when task min time is samll than tick,then use task time
        {
            time = ttime; //to avoid task over time
        }
    }
    //��������sel_task_to_exeǰ����ȡ��Чtick�ڼ���ʼ��tmpͨ�������»�ȡ������Ч��·��
#endif
    return time;

}
void reset_task_sec_tick()
{
    task_tick = get_monitor_time();
}
void flood_sec_tick(void)
{
    if ((_share.conswitch & 0x01) == 0) //���ֲ�ʽ
    {
        if (_rtparas.floodtick > 0)
        {
            _rtparas.floodtick--;

        }
        else
        {
            _rtparas.flsave = 1;
            _rtparas.dbfirst = 0;
            _rtparas.floodtick = FLOODSAVE;
        }
    }
}
void nw_task_sec_tick(void)
{
    unsigned short cnt, size;
    int tid;
    unsigned char aid[IDLEN];

    ses_get_task_info(&cnt, &size);
    flood_sec_tick();
    snd_phs_tick();

    alloc_a_timer(TIMER_GDTASK_TICK, 1000, 1000, nw_task_sec_tick);

    if (cnt > 0 && (_rtparas.state & STASTMASK) == STARUN)
    {
        nw_task_tick();
        #if 0
        if (find_task_time_little(&tid, aid) >= 0) //����tick--��ͬʱ��������ִ��ʱ�� ���ٵ�
        {
            //  task_tick = get_monitor_time();
            if (_rtparas.dctask == 1)//����һ�ֽ�����ĵ㳭�ڼ䣬����ĳЩ����ʱ�䵽�ˣ���ֱ�ӷ�������ʱ
            {
                nw_report_task_state(tid, aid, TASK_STATUS_OTHER); //�˴�����FF���ò���ִ��

                ses_del_task(tid);
            }
            else
            {
                moitor_a_task(tid);
            }
            return;
        }
        #endif

        if (task_tick > MIN_TASK_TIME) //Ԥ��ʱ�������ִ�У���ִֹ��ʱ�䣬�����ϱ�����ʧ�ܣ�����������
        {
            task_tick--;

        }
        else
        {
            if (sel_task_to_exe() >= 0)
            {
                task_tick = get_monitor_time();
            }
            else
            {
                task_tick += 10; //δ�õ�ִ�У��ӳ�10s���ٴβ鿴�Ƿ����ִ��
            }

            return;
        }

    }


}



static int moitor_a_task(unsigned int tid)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    int find = 0;
    unsigned char frmuplen = 0;
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            return -1;
        }
        if (p->frm.id == tid)
        {
            find = 1;
            break;

        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return -1;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    if (nw_task[TASK_EXE_RT].valid == 1 && tid == nw_task[TASK_EXE_RT].tid) //����ִ��rt����
    {
        return -1;
    }

    if (find)
    {
        nw_task[TASK_EXE_HIGH].valid = 1;
        nw_task[TASK_EXE_HIGH].pro = p->pro;
        nw_task[TASK_EXE_HIGH].pri = p->frm.pri;
        nw_task[TASK_EXE_HIGH].tid = p->frm.id;
        nw_task[TASK_EXE_HIGH].time = p->frm.time;

        memcpy(nw_task[TASK_EXE_HIGH].appid, p->add, IDLEN); //���������ַ
        id_bcdtobin(nw_task[TASK_EXE_HIGH].appid);
        reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);

        if (nw_task[TASK_EXE_HIGH].pro == DLT64507)
        {
            frmuplen = 0;//get_frame645_up_len(p->frm.buf);
            nw_task[TASK_EXE_HIGH].dataitem[0] = p->frm.buf[8];
            nw_task[TASK_EXE_HIGH].dlen = p->frm.buf[8 + 1] + 1; //���Ͽ�����

            for (int i = 1; i < nw_task[TASK_EXE_HIGH].dlen; ++i) nw_task[TASK_EXE_HIGH].dataitem[i] = p->frm.buf[8 + 1 + i] - 0x33;
        }
        else
        {
            nw_task[TASK_EXE_HIGH].dlen = p->frm.len;
            memcpy(nw_task[TASK_EXE_HIGH].dataitem, p->frm.buf, p->frm.len);
        }
        rf_set_appd_bk(nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen);
        //appgb_nw_dc(p->buf, p->len);

        appgb_nw_dc(nw_task[TASK_EXE_HIGH].pro, nw_task[TASK_EXE_HIGH].appid, nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen, frmuplen);

        return 0;
    }

    return -1;

}

static int moitor_a_task_v()
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    int find = 0;
    unsigned char frmuplen = 0;
    struct mtinfo *mtp;
    unsigned char aid[6];
    int len = 0;
    unsigned char frm[255];
    while (1)
    {
        if (0 == p->valid)
        {
            return -1;
        }
        memcpy(aid, p->add, IDLEN);
        aid_645_tohash(aid);
        if (rt_test.time)
          {
            find = 1;

            break;
          }
        if ((mtp = db_find(aid)) != NULL)
          {
            if (local_viv_swi != 1 && ((mtp->node.viv & NNDMASK) == NND53 
              || ((mtp->node.viv & NNDMASK) == NND55 && (((mtp->node.viv & NETMASK) >> 2) == 0x01))
              || ((mtp->node.viv & NNDMASK) != NND43 && (mtp->dc_v == 0)))) /* δ֪ */

              {
                find = 1;

                mtp->dc_v = 1;
                mtp->trycnt++;
                break;
              }
          }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return -1;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    if (find)
    {  

        nw_task[TASK_EXE_HIGH].valid = 1;
        nw_task[TASK_EXE_HIGH].pro = p->pro;
        nw_task[TASK_EXE_HIGH].pri = p->frm.pri;
        nw_task[TASK_EXE_HIGH].tid = p->frm.id;
        nw_task[TASK_EXE_HIGH].time = p->frm.time;

        memcpy(nw_task[TASK_EXE_HIGH].appid, p->add, IDLEN); //���������ַ
#if 0 /* 53ϵͳ���õ�ַת�� */
        id_bcdtobin(nw_task[TASK_EXE_HIGH].appid);
        reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
#endif
        
        if (p->pro == 0x00) /*͸��Э��,���ڵ���û������*/
        {
          if (local_viv_swi != 1 && ((mtp->node.viv & NNDMASK) == NND53
              || ((mtp->node.viv & NNDMASK) == NND55 && (((mtp->node.viv & NETMASK) >> 2) == 0x01))))
          {
            /*����9e����*/
            memset(frm, 0x00, sizeof(frm));
            len = ses_set_item_trans(p->add, p->frm.buf, p->frm.len, &frm[0]);
            nw_task[TASK_EXE_HIGH].dlen = len;
          }
          else
          {
            /*����̽��*/
           reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN); 
            memset(frm, 0x00, sizeof(frm));
            len = detectmt(p->add, frm); 
            if (len == 0)   /*��̽���б�����*/
            {
              reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
              memset(frm, 0x00, sizeof(frm));
              len = ses_set_item_trans(nw_task[TASK_EXE_HIGH].appid, p->frm.buf, p->frm.len, &frm[0]);
              nw_task[TASK_EXE_HIGH].dlen = len;
            }
            else
            {
                appgb_nw_dc_v(02, p->add, frm, len, frmuplen);

               id_bintobcd(nw_task[TASK_EXE_HIGH].appid);
               reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
               nw_report_task_state(nw_task[TASK_EXE_HIGH].tid, nw_task[TASK_EXE_HIGH].appid, TASK_STATUS_DATA_ERR);
               ses_del_task(nw_task[TASK_EXE_HIGH].tid);
               init_nw_cur_task(TASK_EXE_HIGH);
               return 0;
            }
          }
        }
        else
        {
          len = p->frm.len;
          memcpy(frm, p->frm.buf, len);
          nw_task[TASK_EXE_HIGH].dlen = p->frm.len;
        }
        memcpy(nw_task[TASK_EXE_HIGH].dataitem, frm, len);
        rf_set_appd_bk(nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen);
        _rtparas.dcviv = TYPE53; 
        appgb_nw_dc_v(nw_task[TASK_EXE_HIGH].pro, nw_task[TASK_EXE_HIGH].appid, nw_task[TASK_EXE_HIGH].dataitem, nw_task[TASK_EXE_HIGH].dlen, frmuplen);

        return 0;
    }

    return -1;

}

static int trav_find_min_time(void)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    int find = 0;
    int time = 0xFFFF;
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        if (p->frm.time < time)
        {
            time = p->frm.time;
            find = 1;
        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return -1;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    if (find == 1)
    {
        if (time > MIN_TASK_TIME) //res time to exe task
        {
            //time -= MIN_TASK_TIME;
        }
        return time;
    }
    return -1;
}
////����tick--��ͬʱ��������ִ��ʱ�� ���ٵ�

void nw_task_tick(void)
{

    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;

    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        if (p->frm.time > 0)
        {
            p->frm.time--; //task tick
        }
        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }
    return;


}
int find_task_time_little(int *tid, unsigned char *aid)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    int find = 0;
 //   unsigned char aid[IDLEN];
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        if (nw_task[TASK_EXE_HIGH].valid == 1
            && nw_task[TASK_EXE_HIGH].tid == p->frm.id)
        {}
        else
        {
            if (p->frm.time < MIN_TASK_TIME)
            {
                *tid = p->frm.id;
                memcpy(aid, p->add, IDLEN);
                find = 1;
                break;
            }
            #if 0
            if (p->frm.time < MIN_TASK_TIME)
            {
                *tid = p->frm.id;
                memcpy(aid, p->add, IDLEN);
                find = 2;
                break;
            }
            #endif

        }

        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return -1;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    if (find == 1)
    {
        if (nw_task[TASK_EXE_HIGH].valid == 0) //������ִ�еĽ�������
        {
            return 0;
        }
    }
    if (find == 1 || find == 2)
    {
        if (nw_task[TASK_EXE_HIGH].valid == 1 && nw_task[TASK_EXE_HIGH].tid == *tid)
        {
            return -1;
        }
        else
        {
            nw_report_task_state(*tid, aid, TASK_STATUS_OTHER); //�˴�����FF��ʱ��̫���ˣ��ò���ִ��
            ses_del_task(*tid);
            // task_tick = get_monitor_time();
            return -1;
        }
    }
    return -1;
}

int get_task_pri_tmout(unsigned int *pri0, unsigned int *pri1, unsigned int *pri2, unsigned int *pri3)
{
    struct task_buf_info *p = (struct task_buf_info *)task_buf;
    int size = 0;
    //int find = 0;
    int tpri0 = 0, tpri1 = 0, tpri2 = 0, tpri3 = 0;
    int tmout_minpri01,tmout_minpri23;

    //unsigned char aid[IDLEN];
    while (1)
    {
        // if (p->id == 0)
        if (0 == p->valid)
        {
            break;
        }
        //find = 1;
        if (p->frm.pri == TASK_PRI_0 || p->frm.pri == TASK_PRI_1)
        {
            if (is_data_all_same(p->add, IDLEN, 0x99))
            {
                tpri0 += TMOUT_BRD;
            }
            else
            {
                tpri0 += TMOUT_PRI0_DC;
            }
        }
        else
        {
            tpri2 += TMOUT_PRI2_DC;
        }

        size += p->frm.len + TASK_DEFAULT_LEN;
        if (size >= sizeof(task_buf))
            return -1;
        p = (struct task_buf_info *)((unsigned char *)p + p->frm.len + TASK_DEFAULT_LEN);
        watchdog();
    }

    tmout_minpri01 = TMOUT_PRI0_DC * TMOUT_MINPRI_NUM;
    tmout_minpri23 = TMOUT_PRI2_DC * TMOUT_MINPRI_NUM;


    if (tpri0 < tmout_minpri01)
    {
        tpri0 = tmout_minpri01;
    }
    if (tpri2 < tmout_minpri23)
    {
        tpri2 = tmout_minpri23;
    }

    if (tpri0 > TMOUT_MAX)
    {
        tpri0 = TMOUT_MAX;
    }
    if (tpri2 > TMOUT_MAX)
    {
        tpri2 = TMOUT_MAX;
    }

    *pri0 = tpri0;
    *pri1 = tpri0;
    *pri2 = tpri2;
    *pri3 = tpri2;
    return 0;



}
void get_nwtask_tic_aid(unsigned short *tid, unsigned short *time,unsigned char *aid)
{
    *tid = nw_task[0].tid;
    memcpy(aid, nw_task[0].appid, IDLEN);
    *time = nw_task[0].time;
}

void refresh_task_appid()
{

    id_bcdtobin(nw_task[TASK_EXE_HIGH].appid);  /* 43����Ҫת������ */
    reverse(nw_task[TASK_EXE_HIGH].appid, IDLEN);
}

unsigned char dect_seq = 0;

int detectmt(unsigned char *aid, unsigned char *frm)
{

  unsigned char frame[10 * 18 + 4], buf1[8 * 18 + 5], num = 0, num1 = 0, maxnum = 8;
  unsigned char data[5] = { 0x11, 0x01, 0x02, 0x03, 0x04 };
  memset(buf1, 0x00, sizeof(buf1));
  memcpy(buf1, data, 5);
  struct mtinfo mt, *rmt;
  unsigned char gd_aid[6];
  int i, idamt = 0, idx = 0;
  unsigned short addr, end;
  int frame_len = 0;
  int seq = dect_seq;


  /*��ӳ���б�*/
  addr = DBBEGIN;
  end = DBEND;
  while (addr < end)
  {
    db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
    if ((mt.node.attr & CELLMASK) == MTFLAG)
    {
      if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
          && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
      {
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        continue;
      }

      if ((rmt = db_find(mt.node.id)) == NULL)
      {
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        continue;
      }

      if ((idamt >= seq) && (((rmt->node.viv & TYPEMASK)>> 3) == TYPEGDNODE)) 
      {

        memcpy(gd_aid, rmt->node.id, IDLEN); 
        id_bintobcd(gd_aid); 
        reverse(gd_aid, IDLEN); 
        memcpy(&buf1[6 + num1 * 18], gd_aid, IDLEN); 
        memcpy(&buf1[6 + num1 * 18 + IDLEN], rmt->node.gdid, GDIDLEN - IDLEN); 
        num1++;
        seq++;
        if (num1 >= maxnum)
          break;
      }
      ++idamt;
    }
    else
      if ((mt.node.attr & CELLMASK) == RPFLAG)
        break;
    if (idamt >= _rtparas.mtnum)
      break;

    addr += CELL * MTCN; /* idnode occupy 2 database cell */
    watchdog();
  }


  if (num1 == 0)
    return 0;

  if (num1 > 0)
  {

    buf1[5] = num1;
    dect_seq = seq;
    id_bcdtobin(aid);
    frame_len = orgframe645(aid, buf1, (18 * num1) + 6, frame);
    /*5��������ȥ*/

    for (int i = 0; i < frame_len; i++)
      {
        printf_s("%02x", frame[i]);
      }

    memcpy(frm, frame, frame_len);
  }
  return frame_len;
}


void nw_dectmt(void)
{
  unsigned char aid[6] = {0x00, 0x00, 0x00, 0x00,  0x00, 0x11};
  unsigned char frm[255];
  unsigned int len = 0;
  int i = 0;
  len = detectmt(aid, &frm[0]); 

  for (i = 0; i < len; i++)
  {
    printf_s("%02x ", frm[i]);
  }
  printf_s("\n");

}


int ses_set_item_trans(unsigned char *aid, unsigned char *buf, unsigned short len, unsigned char *frm_item)
{
  unsigned char frm[512] = {0x00}, aidlen = 0;
  struct dlms_head *dlmshead = (struct dlms_head *)frm;
  unsigned short crc = 0, offset = 0;
  
  memset(frm, 0x0, sizeof(frm));
  dlmshead->code = 0x9E;
  dlmshead->ctrl = 0x00;  /* ���б���,��Ҫ�ظ�,���������չ������ */

  //dlmshead->data[0] = 0x01;  /* ����Э��������1?EXTC?��չ������?�ɱ䳤;�ݶ�����0ռ��1�ֽ�,ELEN?EXTC���ܳ���?����ELEN?,1�ֽ�? */
  aidlen = IDLEN;//return;
  
  dlmshead->data[offset++] = aidlen - 1;   /* AIDL=0x05?AID������5+1=6 */
  memcpy(&dlmshead->data[offset], aid, aidlen);  /* �������� */
  offset+=aidlen;
  unsigned short data_len = 0;
  dlmshead->data[offset++] = (unsigned char )len;
  dlmshead->data[offset++] = (unsigned char )(len >> 8);
  data_len = len;//dlmshead->data[3 + aidlen] * 256 + dlmshead->data[2 + aidlen];
  memcpy(&dlmshead->data[offset], buf, len);
  offset+=len;
  crc = crc16_soft(&dlmshead->code, offset + 2);
  dlmshead->data[offset] = crc % 256;
  dlmshead->data[offset+1] = crc / 256;
  offset+=2;
  memcpy(frm_item, frm, offset + 2);
  return (offset + 2);
  ses_set_item(&dlmshead->code, offset+2);
}
