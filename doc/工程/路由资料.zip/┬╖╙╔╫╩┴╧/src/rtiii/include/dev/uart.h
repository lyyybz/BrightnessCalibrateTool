/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: uart.h
 *
 * Description: General UART control module
 *
 * Version: v1.0
 * Time:    2009-12-11
 *
 */

#ifndef USRT_H
#define USRT_H

#ifdef _LINUXPC
#include <unistd.h>
#include <fcntl.h>
#else
#include <dev_ctrl.h>
#endif

/* 
 * Function:   Open uart
 * Parameters: uartno   - Uart serial no
 *             baudrate - Baud rate
 *             databits - Bit of per character occupied 
 *             stopbits - The number of stop bit
 *             parity   - Even or odd verify
 * Return:     Nonezero if the operation succesful,or -1 if an error occurs
 *
 */
int uart_open(size_t uartno, size_t baudrate, size_t databits, size_t stopbits, 
	      unsigned char parity);

/* 
 * Function:   Read from uart
 * Parameters: fd     - File descriptor
 *             buff   - Storage location of data  
 *             rbytes - Bytes to be readed
 * Return:     Bytes of actually read
 *
 */
size_t uart_read(int fd, unsigned char *buff, size_t rbytes);

/*
 * Function:   Write to uart
 * Parameters: fd     - File descriptor
 *             buff   - Pointer to data to be written
 *             wbytes - Bytes to be written
 * Return:     Bytes of actually write
 *
 */
size_t uart_write(int fd, unsigned char *buff, size_t wbytes);

/*
 * Function:   Close uart
 * Parameters: fd - File descriptor
 * Return:     Zero if operation successful,or -1 if an error occurse
 *
 */
int uart_close(int fd);

#ifdef _LINUXPC 

void mdelay(unsigned int m);
unsigned int get_cts_value(unsigned int chn);
void set_rts_value(unsigned int chn, unsigned int value);
#endif

#endif
