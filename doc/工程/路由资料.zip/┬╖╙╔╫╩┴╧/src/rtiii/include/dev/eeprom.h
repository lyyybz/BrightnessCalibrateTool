/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.	
 *
 * File name: eeprom.h
 *
 * Description: eeprom driver
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#ifndef EEPROM_H
#define EEPROM_H

/*
 * Function:   Initialize eeprom and format 
 * Parameters: None
 * Return:     None
 *
 */
void eeprom_init();

/*
 * Function:   Write to eeprom
 * Parameters: addr -  eeprom address
 *             src  -  Pointer to data to be writen
 *             rbytes - bytes to be writen 
 * Return:     Bytes - bytes of actually write
 *
 */
size_t eeprom_write(ADDRESS addr, unsigned char *dest, size_t wbytes);

/*
 * Function:   Read from eeprom
 * Parameters: dest   - EEPROM address
 *             source - Storage location of read data
 *             rbytes - Bytes to be readed
 * Return:     Bytes of actually read
 *
 */
size_t eeprom_read(ADDRESS addr, unsigned char *src, size_t rbytes);

#endif
