/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: appgb.h
 *
 * Description:  Implementation of Route Application between Router and DM.
 *               GB376.2
 *
 * Version: v1.0
 * Time:    2010-02-06
 *
 */

#include "apprt.h"
#ifndef APPGB_H
#define APPGB_H

#define IDLEN 6
#define SNOLEN 2
#define RTSTARTCH           0x68
#define RT_ANS     0x01
#define RT_REQ     0x02

#define PRM_REQ   0x01
#define PRM_ANS   0x00

//#define TASK_STATUS_SUC      0x00
//#define TASK_STATUS_NO_RES   0x01
//#define TASK_STATUS_DATA_ERR 0x02
//#define TASK_STATUS_OTHER    0xFF

#pragma pack(1)

struct appgb_ctrl
{
    unsigned char dir;
    unsigned char prm;
    unsigned char comm;
};

struct appgb_info
{
    unsigned char rplevl; /* rp level */
    unsigned char fcomm;  /* communicate module flag */
    unsigned char froute; /* route flag */
    unsigned char exptlen;
    unsigned char mscnt;  /* messeng cnt*/
    unsigned char endf;
    unsigned char event;
};

struct appgb_addr
{
    unsigned char num;
    unsigned char id[16][6];
};

struct appgb_para
{
    struct appgb_ctrl ctrl;
    struct appgb_info info;
    struct appgb_addr addr;
    unsigned char afn;
    unsigned char fn;
};


//----------------------------------�㶫2016Э����ؽṹ��

#define E_OVER_TIME     0
#define E_INVALID_DATA  1
#define E_LENGTH        2
#define E_CHECKSUM      3
#define E_NO_INFOTYPE   4
#define E_WRONGFORMAT   5
#define E_REPEAT_METER  6
#define E_NO_METERNO    7
#define E_NO_APP_ANS    8
#define E_TASK_FAIL     9
#define E_TASK_BUF_FULL 13
#define E_TASK_REPEAT   15
#define E_NO_TASK       16
#define E_OTHER         255

#define MAX_NODE            1000   /* �����������㶫1000 */

struct frame_gw_3762
{
    unsigned char start_flag; //��ʼ�ַ�
    unsigned short length; //֡����

    unsigned char comm_method:6; //ͨ�ŷ�ʽ
    unsigned char prm:1; //������־λ
    unsigned char dir:1; //���䷽��λ

    unsigned char user_data[1]; //�û�����
};
//698�û����ݽṹ
struct app_data_gw
{
    unsigned char afn;  //Ӧ�ù�����
    unsigned char data_type[2];  //���ݵ�Ԫ��ʶ
    unsigned char data_unit[1];  //������
};
//gw 3762����֡��ʽ
struct info_down_gw
{

    unsigned char router:1;  //·�ɱ�ʶ
    unsigned char acc_node:1;  //�����ڵ�
    unsigned char com_module:1;  //ͨ��ģ���־
    unsigned char conflict_det:1;  //��ͻ���
    unsigned char relay_level:4;  //�м̼���

    unsigned char chn_id:4;  //�ŵ���ʶ
    unsigned char err_corr_id:4;   //���������־

    unsigned char reply_bytes;  //Ԥ��Ӧ���ֽ�

    unsigned short bps;  //ͨ�Ų�����

    //unsigned char info_no6;  //����
    unsigned char sno;
};
struct info_up_gw
{
    unsigned char router:1; //·�ɱ�־
    unsigned char reserved0:1;  //����
    unsigned char com_module:1;  //ͨ��ģ���־
    unsigned char reserved1:1;  //����
    unsigned char relay_level:4; //�м̼���

    unsigned char chn_id:4;  //�ŵ���ʶ
    unsigned char reserved2:4;  //����

    unsigned char phase:4; //����
    unsigned char meter_chn_sta:4;  //���ͨ������

    unsigned char last_com_sig:4; //ĩ��Ӧ���ź�Ʒ��
    unsigned char last_ans_sig:4; //ĩ�������ź�Ʒ��

    //unsigned char info_no5;  //����
    unsigned char event_flag:1;
    unsigned char info_no5:7;

    unsigned char sno;
    //unsigned char info_no6;  //����
};
struct frame_nw
{
    unsigned char head;
    unsigned short len;

    unsigned char rsv:3;
    unsigned char ver:2;
    unsigned char addr:1;
    unsigned char prm:1;
    unsigned char dir:1;

    unsigned char data[1];
};
struct _update_frame_nw_start
{
    unsigned char info;
    unsigned char id;    //�ļ�ID
    unsigned char add[6]; //Ŀ�ĵ�ַ
    unsigned short num;   //�ļ��ܶ���
    unsigned int size;   //�ļ���С
    unsigned short crc16;
    unsigned char time_out;
};
struct chk_file_info
{
    unsigned char fileInfo;
    unsigned char id;
    unsigned char add[6];
    unsigned short segNum;
    unsigned int size;
    unsigned short crc;
    unsigned short rcv;
};
struct chk_file_process
{
    unsigned char process;
    unsigned char id;
    unsigned short num;
};

struct chk_fail_node_dw
{
    unsigned short sn;
    unsigned char num;
};
struct chk_fail_node_up
{
    unsigned short node_num;
    unsigned char num;
    unsigned char data[1];
};
struct afn_desc_nw
{
    unsigned char prm:2;
    unsigned char afn;
    unsigned int di;
    int ( *handle )(struct afn_desc_nw *self, struct frame_nw *pframe);
};
struct app_data_nw
{
    unsigned char afn;
    unsigned char sno;
    unsigned char di[4];
    unsigned char data[1];
};

struct report_task_status
{
    unsigned short id;
    unsigned char add[6];
    unsigned char sta;
};

struct nw_pri_tmout
{
    unsigned short tm;
    unsigned char data[1];
};
struct node_phs
{
    unsigned char id[IDLEN];
    unsigned char phs_val:3;
    unsigned char phs_para:2;
    unsigned char pad:3;
    unsigned char pro;
    unsigned char data[1];
};


struct phs_batch
{
    unsigned short pos;
    unsigned char num;
};

struct node_up
{
    unsigned char node[6];
};

struct node_mtup
{
    unsigned short size;
    struct node_up aid_table[1];
};

struct gbbrd_info_v
{
    unsigned char appdata[80];  /* V����Ҫ��������645���� */
    unsigned char len;
//     unsigned char start;
//     unsigned int curtick;
//     unsigned int ms;
};

struct rt_test_info
{
  unsigned char chn;
  unsigned int time;
};

/*
 * Function:   request for  content of monit
 * Parameters: mtid    - pointer to current meter id
 *             phase   - phase of meter
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int appgb_reqdata(unsigned char *mtid);
int appgb_reqbrd();
/*
 * Function:   Data frame reported to DM
 * Parameters: mid - meter id
 *             appd - Data be sended
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int appgb_data(unsigned char *mtid, unsigned char *data, int datalen, unsigned char event);

int appgb_data_new(unsigned char *mtid, unsigned char *data, int datalen, unsigned char event);

/*
 * Function:   register id frame reported to DM
 * Parameters: mid - meter id
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int nw_report_event_new(unsigned char *mtid, unsigned char *data, int datalen, unsigned char event);
int nw_report_data(unsigned int sn, unsigned char *mtid, unsigned char pro, unsigned char *data, unsigned char len);
int report_task_fail(unsigned char *aid, unsigned int sn, int code);

/*
 * Function:   Confirm frame to DM
 * Parameters: wait - time to wait to send next command
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int appgb_cfm(unsigned short wait);

/*
 * Function:   Deny frame to DM
 * Parameters: errcode - error code
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int appgb_deny(unsigned char errcode);

/*
 * Function:   Response of monit
 * Parameters: data - application data
 *             len  - Data be sended
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int appgb_comm_data(unsigned char *mtid, unsigned char pro, unsigned char *data, unsigned char len);

int app_frm_check(unsigned char *buf, int len, unsigned char *frm, int *del);
int app_frm_decode(unsigned char *buf);
void nw_report_rt_info();
int nw_report_wkstate();
int nw_report_node_new(unsigned char *mtid, unsigned char *cid, unsigned char pro);
int nw_report_task_state(unsigned short task_id, unsigned char *add, unsigned char sta);
int nw_report_wkstate();
int appgb_nw_dc(unsigned char proto, unsigned char add[], unsigned char *buf, unsigned char len,unsigned char exlen);
int appgb_nw_dc_v(unsigned char proto, unsigned char add[], unsigned char *buf, unsigned char len,unsigned char exlen);
int appgb_build_645cmd(const unsigned char *meter, unsigned char ctrl, unsigned char *data, int dlen, unsigned char *buff);
int appgb_broad(unsigned char *frm, unsigned char len, unsigned int timeout);
void set_to_brd_phs(void);
void set_to_brd_phs_v(void);
void app_eventup(unsigned char *buf, unsigned char len);
void app_mt_up(unsigned char n, unsigned char *aid);
void app_power_eventup(unsigned char depth, unsigned char phase, unsigned char *buf, unsigned char len, unsigned char tq_state, unsigned short sid, unsigned char dc_sno);
void appgd_init();
#endif
