/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: app.h
 *
 * Description:  Abstract layer between router and application.
 *
 * Version: v1.0
 * Time:    2010-1-28
 *
 */

#ifndef APP_H
#define APP_H

#define IDLEN 6

#define DBPBEGIN 0xFF00 /* begin address of parameters */
#define DBPEND   0xFFE0 /* end address of parameters */

enum
  {
    INFIDLE   = 0x01, /* information: route idle */
    INFCHPATH = 0x02, /* information: change monit path */
    INFBRDSTA = 0x04, /* information: broad operation start */
    INFBRDEND = 0x05, /* information: broad operation end */
  };

enum
  {
    ERRNODIR = 0x19, /* no effect direct */
    ERRIDFAIL = 0x13, /* ����ָ��IDʧ�� */
  };

enum
{
    RQPWD   = 0x00,
    RQWMODE = 0x01,
    RQBRDC  = 0x02, /* request for broad content */
    RQMNTC  = 0x03, /* request for monit content */
    RQDLYTM = 0x05,
};

/*
 * Function:   register frame reported to DM
 * Parameters: mid - meter id
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int app_regup(unsigned char *mid);
int app_regup_new(unsigned char *mtid, unsigned char *cid, unsigned char pro);

/*
 * Function:   warning frame reported to DM
 * Parameters: mid - meter id
 *             data - Data be sended
 *             len  - length of data
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int app_warnup(unsigned char *mid, unsigned char *data, int datalen);

int app_warnup_new(unsigned char *mid, unsigned char *data, int datalen);

/*
 * Function:   Data frame reported to DM
 * Parameters: mid - meter id
 *             appd - Data be sended
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int app_data(unsigned char *mid, unsigned char *data, int datalen,unsigned char pro, unsigned char event);

/*
 * Function:   Response frame to DM
 * Parameters: data    - response data
 *             datalen - Length of data
 * Return:     Zero if response successfully, or -1 if an error occurs
 */
int app_res(unsigned char *data, int datalen);

int app_gbcomm(unsigned char *mtid, unsigned char pro, unsigned char *data, int datalen);

/*
 * Function:   Organize information frame
 * Parameters: data    - Information
 *             datalen -  Length of informatin
 * Return:     Zero if send successfully, or -1 if an error occurs
 * Remark:
 */
int app_info(unsigned char *data, int datalen);

/*
 * Function:   Organize error frame
 * Parameters: data    - Information of error
 *             datalen -  Length of informatin
 * Return:     Zero if send successfully, or -1 if an error occurs
 * Remark:
 */
int app_err(unsigned char *data, int datalen);

/*
 * Function:   Organize confirm frame
 * Parameters: data    -  none
 * Return:     Zero if send successfully, or -1 if an error occurs
 * Remark:
 */
int app_cfm();
/*
 * Function:   request for content
 * Parameters: type  - type of request: RQBRDC or RQMNTC
 *             cnt   - if type = RQBRDC, cnt is request times
 *             mt    - if type = RQMNTC, mt is pointer to current meter id
 * Return:     Zero if success, or -1 if an error occurs
 *
 */
int app_request(unsigned char type, unsigned char cnt, unsigned char *mt);

/*
 * Function:   Check pwd and wmode req succ?
 * Parameters: none
 * Return:     Zero if success, or -1 if not succ
 *
 */
int app_pwd();

/*
 * Function:    decode frame that received from comm
 * Parameters: frame - pointer of message
 *             len - length of frame
 * Return:     none
 *
 */
int app_decode(unsigned char *frame, int len);

/*
 * Function:   plc38 debug
 * Parameters: ccw   - mode
 *             frame - frame to plc38
 *             len   - Length of frame
 * Return:     Zero if success, or -1 if an error occurs
 */
int app_debug(unsigned char *frame, int len, unsigned char ccw);
int app_gbbroad_over();
#endif
