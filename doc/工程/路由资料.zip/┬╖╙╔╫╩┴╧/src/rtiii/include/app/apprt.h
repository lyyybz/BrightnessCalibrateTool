/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: apprt.h
 *
 * Description:  Implementation of Route Application between Router and DM.
 *
 * Version: v1.0
 * Time:    2010-1-22
 *
 */

#ifndef APPRT_H
#define APPRT_H
#define MAX_NODE 1000   /* �㶫��Ҫ��1000 */

enum
  {
    RTFTERROR    = 0x80,   /* Error frame type */
    RTFTINST     = 0x40,   /* Instruction frame type */
    RTFTRESPONSE = 0x20,   /* Response frame type */
    RTFTMIDDLE   = 0x21,   /* Response middle frame type, end with confirm frame */
    RTFTREQUIRE  = 0x10,   /* Require frame type */
    RTFTINFO     = 0x08,   /* Information frame type */
    RTFTDATA     = 0x04,   /* Data frame type,direct read correctly */
    RTFTEDATA    = 0x05,   /* Data frame type,direct read error */
    RTFTREPDATA  = 0x06,   /* Data frame type,read from repeater correctly */
    RTFTREPEDATA = 0x07,   /* Data frame type,read from repeater error */
  };

enum
  {
    RTSPWD    = 0x00,
    RTSWMODE  = 0x01,
    RTSSUCC   = 0x02, 
  };

int apprt_find(unsigned char *frame, int len);

/*
 * Function:   Check frame from DM
 * Parameters: frame - Frame from DM
 *             len   - Length of frame
 * Return:     begin - The begin index of valid frame 
 *             end   - The last index of valid frame
 * Remark:     Zero if check successfully, or -1 if no valid frame
 */
int apprt_check(unsigned char *frame, int len, int *begin, int *end);

/*
 * Function:   Build frame to DM
 * Parameters: type - Frame type
 *             opt  - Instrct type or information type
 *             data - Frame data
 *             datalen - Length of data     
 * Return:     frame - Frame sended to DM
 *             framelen - Length of frame
 *             Zero if build successfully, or -1 if an error occurs
 */
int apprt_build(unsigned char type, unsigned char opt, unsigned char *data, int datalen,
		unsigned char *frame, int *framelen);

/*
 * Function:   Process the getting command from DM
 * Parameters: opt     - Instruct type
 *             data    - Instruct parameter
 *             datalen - Length of parameter
 * Return:     Zero if process successfully, or -1 if an error occurs
 */
int apprt_get(unsigned char opt, unsigned char *data, int datalen);

/*
 * Function:   Response frame to DM
 * Parameters: type    - response type
 *             data    - response data
 *             datalen - Length of data
 * Return:     Zero if response successfully, or -1 if an error occurs
 */
int apprt_res(unsigned char type, unsigned char *data, int datalen);

/*
 * Function:   Transport data
 * Parameters: opt     - transport type
 *             data    - transport parameter
 *             datalen - Length of parameter
 * Return:     Zero if process successfully, or -1 if an error occurs
 */
int apprt_trans(unsigned char opt, unsigned char *data, int datalen);

/*
 * Function:   active report frame to DM
 * Parameters: mid - meter id
 *             data    - transport parameter
 *             datalen - Length of parameter
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int apprt_report(unsigned char *mtid, unsigned char *data, int datalen);

/*
 * Function:   Data frame reported to DM
 * Parameters: mid - meter id
 *             appd - Data be sended
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int apprt_data(unsigned char *mid, unsigned char *data, int datalen);

/*
 * Function:   Organize information frame 
 * Parameters: opt - Information type
 * Return:     Zero if send successfully, or -1 if an error occurs
 * Remark:     
 */
int apprt_info(unsigned char opt);

/*
 * Function:   Error frame reported to DM
 * Parameters: errcode - error code
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int apprt_err(unsigned char errcode);

/*
 * Function:   confirm frame reported to DM
 * Parameters: none
 * Return:     Zero if send successfully, or -1 if an error occurs
 */
int apprt_sendack();

/*
 * Function:   request for  pwd
 * Parameters: none
 * Return:     Zero if success, or -1 if an error occurs
 *
 */
int apprt_reqpwd();

/*
 * Function:   request for  wmode
 * Parameters: none
 * Return:     Zero if success, or -1 if an error occurs
 *
 */
int apprt_reqwmode();

/*
 * Function:   request for  content of broad
 * Parameters: cnt   - count of requestion
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int apprt_reqbrd(unsigned char cnt);

/*
 * Function:   request for  content of monit
 * Parameters: mt    - pointer to current meter id 
 *             cnt   - count of requestion
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int apprt_reqmnt(unsigned char *mt, unsigned char cnt);

/*
 * Function:   Decode frame that received from dm  
 * Parameters: frame - pointer of message
 *             len   - length of frame
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
// int apprt_proc(unsigned char *frame, int len);

unsigned char apprt_get_pwdwmode();
#endif
