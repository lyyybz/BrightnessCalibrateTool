/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: db.h
 *
 * Description: rt data manager
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#ifndef DB_H
#define DB_H

#include <stdio.h>
#include "node.h"
#include "../tool/ague.h"

#define EMPFLAG  0xFF
#define EMPADDR  0xFFFF
#define MTFLAG   0x80
#define RPFLAG   0x40
#define CELLMASK 0xC0
#define CELL     8
#define MTCN  (sizeof(struct mtnode) / CELL)
#define RPCN  (sizeof(struct rpnode) / CELL)

#define DBBEGIN  0x0000 /* begin address of database */
#define DBEND    0xFF00 /* end address of database */
#define DBPBEGIN 0xFF00 /* begin address of parameters */
#define DBPEND   0xFFE0 /* end address of parameters */
#define DBFAULT  0xFEE0 - 0x80
#define DBSHARE  0xFFE0 /* share parameter address */
#define DBRTMD   0xFFE6 /* router mode */
#define MDTYPE   0xAA
#define MDRT1    0x01
#define MDRT2    0x02
#define MDRT3    0x03
#define MDRT4    0x04
#define MDRTV    0x05
#define MDRTIII  0xFC

#define RTSTA_INIT  0x11
#define RTSTA_BKING  0x22
#define RTSTA_BKED  0x33

#define RTSTA_IV_BKING  0x66
#define RTSTA_IV_BKED 0x77
#define RTSTA_IV_III_FORMAT 0x88
#define RTSTA_IV_III_END 0x99

#define DBBKBEGIN 0xA000/* begin address of backup */
#define DBBKSTATE 0xFFF6

#define IDLEN    6 /* node id length */
#define SNOLEN   2 /* meter sno length */
#define EIDLEN   5      /* 8 */

#define FLOODSAVE  (60*60*2)
#define SNDPHSTIME  (60*60)     /*����?��1?2��?��??��?????����??��?2?��a3?1y2^16*/
#define seterr(errno) (db_seterr(errno), -1)
#define MAX_NUM_ONCE 20 /* ��ȡ�ӽڵ���Ϣ��, ÿ������ȡ�ĸ��� */

enum
  {
    DBERR_MALLOC   = 0x01, /* malloc return NULL */
    DBERR_REEPROM  = 0x03, /* read eeprom error */
    DBERR_MTEXIST  = 0x0D, /* meter already exsit */
    DBERR_NOTHISMT = 0x0E, /* meter does not exsit */
    DBERR_MTMOF    = 0x10, /* meter storage overflow */
    DBERR_BM       = 0xA0, /* blanker manager error */
  };

enum
  {
    CHAN_RT1  = 0x00, /* channel one of router for traverse id table */
    CHAN_RT2  = 0x01, /* channel two of router for traverse id table */
    CHAN_RT3  = 0x02, /* channel three of router for traverse id table */
    CHAN_TMP  = 0x03, /* channel of temp for traverse id table  */
    CHAN_TMP1  = 0x04, /* channel of temp for traverse id table,only use in mnt  */
    CHAN_TDEF = 0x04, /* default pattern for traversal,skip invalid repeater */
    CHAN_TALL = 0x05, /* traverse all items in table */
  };

extern unsigned char mtivd[IDLEN];
extern unsigned char sinksno[SNOLEN], sinkidno[IDLEN], broadsno[SNOLEN],
                     broadidno[IDLEN], dispidno[IDLEN], dispbdidno[IDLEN], dispbdidsno[SNOLEN];

/*
 * Function:   Initialize database
 * Parameters: None
 * Return:     Zero is already initialize, -1 new EEPROM
 *
 */
int db_init();

/*
 * Function:   Initialize structure of database
 * Parameters: None
 * Return:     None
 *
 */
void db_build();

/*
 * Function:   Destroy database
 * Parameters: None
 * Return:     None
 * Remark:     Only destroy structure in ram
 *
 */
void db_destroy();

/*
 * Function:   Format database
 * Parameters: None
 * Return:     None
 *
 */
void db_format();

/*
 * Function:   Check db_unit is empty or not
 * Parameters: None
 * Return:     0 - empty, -1 - not empty
 *
 */
int db_unit_empty(ADDRESS addr);

/*
 * Function:   Read from database
 * Parameters: dest   - address
 *             source - Storage location of read data
 *             rbytes - Bytes to be readed
 * Return:     Bytes of actually read
 *
 */
int db_read(ADDRESS addr, unsigned char *dest, size_t len);

/*
 * Function:   Write to database
 * Parameters: addr -  address
 *             src  -  Pointer to data to be writen
 *             rbytes - bytes to be writen
 * Return:     Bytes - bytes of actually write
 *
 */
int db_write(ADDRESS addr, unsigned char *src, size_t len);

/*
 * Function:   Set database error code
 * Parameters: errno - error code
 * Return:     Error code
 *
 */
int db_seterr(int errno);

/*
 * Function:   Get database error code
 * Parameters: None
 * Return:     Error code
 *
 */
int db_geterr();

/*
 * Function:   Find block of meter node
 * Parameters: mtid - Meter id
 * Return:     Pointer to the storage of meter, NULL if find failure
 *
 */
struct mtinfo * db_find(const unsigned char *mtid);

/*
 * Function:   Find block of meter node
 * Parameters: mtid - Meter serial no
 * Return:     Pointer to the storage of meter, NULL if find failure
 *
 */
struct mtinfo * db_find_sno(unsigned char *mtsno);

/*
 * Function:   ADD meter OPTION
 * Parameters: mtptr - meter info
 * Return:     Zero if ADD success, or -1 if an error occurs
 *
 */
int db_addmt(struct mtinfo *mtptr);

/*
 * Function:   Delete meter from eeprom
 * Parameters: mtid - meter id
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int db_delmt(unsigned char *mtid);

/*
 * Function:   Clear all mt new mask
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int db_clrall_newmtmask();

/*
 * Function:   Append repeater node in meter relay table
 * Parameters: mtid - Meter id
 *             rprtr - Pointer to storage of repeater info
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int db_appendrp(const unsigned char *mtid, const struct rpinfo *rpptr);

/*
 * Function:   Insert repeater node in meter relay table
 * Parameters: mtid - Meter id
 *             rprtr - Pointer to storage of repeater info
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int db_insertrp(const unsigned char *mtid, const struct rpinfo *rpptr);

/*
 * Function:   Updata database
 * Parameters: none
 * Return:     none
 *
 */
void db_flush();

/*
 * Function:   Initalize travsersal parameter
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     None
 * Remark:     Each channel is independent
 *
 */
void db_trav_reset(size_t chan);

/*
 * Function:   Initalize repeater travsersal parameter
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     None
 * Remark:     Each channel is independent
 *
 */
void db_trav_rpreset(size_t chan);

/*
 * Function:   Get the next meter of route database
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     Pointer to the storage of meter, NULL if traverse finished
 * Remark:     Each channel is independent
 *
 */
struct mtinfo * db_trav_mtnext(size_t chan);

/*
 * Function:   Get the next repeater in meter's relay table
 * Parameters: chan - Number of channel to traverse hash table
 *             pattern - Traverse pattern for repeater table
 *                       CHAN_TDEF: skip invalid repeater
 *                       CHAN_TALL: traverse all,until next pointer is NULL
 * Return:     Pointer to storage of repeater, NULL if traverse finished
 * Remark:     Each channel is independent
 *
 */
struct rpinfo * db_trav_rpnext(size_t chan, int pattern);

/*
 * Function:   Get the first repeater
 * Parameters: mtptr - Meter Info Pointer
 * Return:     Pointer to the storage of repeater, NULL if traverse finished
 *
 */
struct rpinfo * db_getfrp(struct mtinfo *mtptr);

/*
 * Function:   Delete repeater of node
 * Parameters: mtid - Meter ID
 *             rpid - Repeater ID
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int db_delrp(unsigned char *mtid, unsigned char *rpid);

/*
 * Function:   Find repeater of node
 * Parameters: mtid - Meter ID
 *             rpid - Repeater ID
 * Return:     Pointer of repeater
 *
 */
struct rpinfo *db_findrp(unsigned char *mtid, unsigned char *rpid);

/*
 * Function:   Find position of Meter
 * Parameters: str - Meter ID
 *             len - Length of Meter ID
 * Return:     position of Meter
 *
 */
int db_find_pos(const unsigned char *str, size_t len);

/*
 * Function:   Get hash table
 * Parameters: NULL
 * Return:     Pointer to the hash table
 *
 */
struct hmtcell ** db_get_idtab();

/**************67db����*****************/
int db_regnum_53();
int db_find_vsid(unsigned short sid);
struct mtinfo* db_vsid(unsigned short sid);
#endif
