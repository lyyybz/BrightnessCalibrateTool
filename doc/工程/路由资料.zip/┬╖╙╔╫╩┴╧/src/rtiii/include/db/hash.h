/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: hash.h
 *
 * Description: Ram structure of router database
 *              The optimization for search routing table.
 *
 * Version: v1.0
 * Time:    2009-12-02
 * 
 */ 

#ifndef HASH_H
#define HASH_H

#pragma pack(1)

struct hmtcell
{
  struct mtinfo hcell;
  struct hmtcell *next;
};

struct hrpcell
{
  struct rpinfo hcell;
  struct hrpcell *next;
};

struct mt_vfy
{
  size_t pos;
  size_t index;
  unsigned char mtid[6];
};

/*
 * Function:   Initialize hash table
 * Parameters: None
 * Return:     None
 *
 */
void hash_init();

/*
 * Function:   Build hash table
 * Parameters: None
 * Return:     None
 *
 */
void hash_build();

/*
 * Function:   Destroy hash table
 * Parameters: None
 * Return:     None
 *
 */
void hash_destroy();

/*
 * Function:   Find block of meter node
 * Parameters: mtid - Meter id
 * Return:     Pointer to the storage of meter, NULL if find failure
 *
 */
struct mtinfo * hash_find(const unsigned char *mtid);

/*
 * Function:   Find block of meter node
 * Parameters: mtid - Meter serial no
 * Return:     Pointer to the storage of meter, NULL if find failure
 *
 */
struct mtinfo * hash_find_sno(unsigned char *mtsno);

/*
 * Function:   Add meter node in hash table
 * Parameters: nodeptr - Pointer to storage of new meter node
 * Return:     Zero if add success, or -1 if an error occurs
 * Note:       Doesn't judgment repeat meter
 *
 */
int hash_addmt(const struct mtinfo *mtptr);

/*
 * Function:   Delete meter node in hash table
 * Parameters: mtid - Meter id
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int hash_delmt(const unsigned char *mtid);

/*
 * Function:   Append repeater node in hash table
 * Parameters: mtid - Meter id
 *             rprtr - Pointer to storage of repeater info
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int hash_appendrp(const unsigned char *mtid, const struct rpinfo *rpptr);

/*
 * Function:   Insert repeater node in hash table
 * Parameters: mtid - Meter id
 *             rprtr - Pointer to storage of repeater info
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int hash_insertrp(const unsigned char *mtid, const struct rpinfo *rpptr);

/*
 * Function:   Delete one of the repeaters which belong to meter node in hash table
 * Parameters: mtid - Meter id
 *             rpid - Repeater id
 * Return:     Zero if delete success, or -1 if an error occurs
 *
 */
int hash_delrp(const unsigned char *mtid, const unsigned char *rpid);

/*
 * Function:   Step up the repeater to be the first
 * Parameters: mtid - Meter id
 *             rprtr - Pointer to storage of repeater info
 * Return:     Zero if top up success, or -1 if an error occurs
 *
 */
int hash_toprp(const unsigned char *mtid, const struct rpinfo *rpptr);

/*
 * Function:   Initalize travsersal parameter, pointe to begin of hash table
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     None
 * Remark:     Each channel is independent
 *
 */
void hash_trav_reset(size_t chan);

/*
 * Function:   Initalize repeater travsersal parameter
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     None
 * Remark:     Each channel is independent
 *
 */
void hash_trav_rpreset(size_t chan);

/*
 * Function:   Get the next meter of route database
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     Pointer to the storage of meter, NULL if traverse finished
 * Remark:     Each channel is independent
 *
 */
struct mtinfo * hash_trav_mtnext(size_t chan);

/*
 * Function:   Get the next repeater in meter's relay table
 * Parameters: chan - Number of channel to traverse hash table
 *             pattern - Traverse pattern for repeater table
 *                       CHAN_TDEF: skip invalid repeater
 *                       CHAN_TALL: traverse all,until next pointer is NULL
 * Return:     Pointer to storage of repeater, NULL if traverse finished
 * Remark:     Each channel is independent
 *
 */
struct rpinfo * hash_trav_rpnext(size_t chan, int partten);

/*
 * Function:   Get the first repeater
 * Parameters: mtptr - Meter Info Pointer
 * Return:     Pointer to the storage of repeater, NULL if traverse finished
 *
 */
struct rpinfo * hash_getfrp(struct mtinfo *mtptr);

/*
 * Function:   Find repeater of meter
 * Parameters: mtid - Meter ID
 *             rpid - Repeater ID
 *             rpptr - Pointer of repeater information
 * Return:     Pointer to the storage of repeater, NULL if find fail
 *
 */
struct rpinfo *hash_findrp(const unsigned char *mtid, const unsigned char *rpid);

/*
 * Function:   Find position of Meter
 * Parameters: str - Meter ID
 *             len - Length of Meter ID         
 * Return:     position of Meter
 *
 */
int hash_find_pos(const unsigned char *str, size_t len);

/*
 * Function:   Get hash table
 * Parameters: NULL         
 * Return:     Pointer to the hash table
 *
 */
struct hmtcell ** get_idtab();

#endif
