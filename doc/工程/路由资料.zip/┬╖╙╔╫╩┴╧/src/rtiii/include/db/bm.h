/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved.
 *
 * File name: bm.h
 *
 * Description: blank manager        
 *
 * Version: v1.0
 * Time:    2009-12-02
 *
 */

#ifndef BM_H
#define BM_H

#pragma pack(1)

struct blanker
{
  struct blanker *next;
  unsigned short addr;
  unsigned short num;
};

enum blanktype
{
  NODE = 0x00,
  RELAY = 0x01
};

/*
 * Function:   Blank initialization by reading data from eeprom
 * Parameters: void
 * Return:     0 - success, other - fail
 * Remark:     Blank information is stored by means of a linked list.
 *
 */
int bm_init();

/*
 * Function:   Get the empty address from blank linked list
 * Parameters: typevalue - node address or relay address
 *             num       - how many units(8 bytes)
 *             addrptr   - returned address
 * Return:     0 - success, other - fail
 * Remark:     If node - get the address from the top.
 *             If relay - get the address from the bottom.
 *
 */
int bm_get(enum blanktype typevalue, unsigned short num, unsigned short *addrptr);

/*
 * Function:   Delete some blank
 * Parameters: addr - the begin address to be deleted
 *             num  - the number of blank to be deleted
 * Return:     0 - success, other - fail
 * Remark:     The blank can be deleted partly or totally.
 *
 */
int bm_del(unsigned short addr, unsigned short num);

/*
 * Function:   Add several blank
 * Parameters: addr - the begin address to be added
 *             num  - the number of blank to be added
 * Return:     zero - success, other - fail
 * Remark:     The blank can be added before or after the header of the linked list.
 *
 */
int bm_add(unsigned short addr, unsigned short num);

/*
 * Function:   Print the blank information
 * Parameters: void
 * Return:     0 - success, other - fail
 * Remark:     For debug
 *
 */
int bm_print();

/*
 * Function:   Clear the blank information
 * Parameters: void
 * Return:     0 - success, other - fail
 * Remark:     
 *
 */
void bm_clear();

#endif
