/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved.
 *
 * File name: debug.h
 *
 * Description: Some debug functions
 *              Function working when macro "_DEBUG" had defined
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#ifndef DEBUG_H
#define DEBUG_H

/* #include <fcntl.h> */

//#define _DEBUG    /* Debug key */
//#define _LINUXPC /* Program run environment */
//#define NDEBUG   /* Disable macro assert */

#ifdef _LINUXPC
#define EEPROM "eeprom"
#endif

/*
 * Function:   Hex string convert to ascii string,then output
 *             For instance: 0x01,0x02,0x03,0x04 ==> "01 02 03 04"
 * Parameters: title  - Some info for hex string, may be NULL
 *             cmd    - Hex string
 *             cmdlen - Hex string length
 * Return:     None
 *
 */
void dbg_prtcmd(const char *title, const unsigned char *cmd, size_t cmdlen);

/*
 * Function:   Print debug info,simulate "printf" that in C library
 * Parameters: fmt - Parameter list
 * Return:     None
 *
 */

void dbg_printf(const char *fmt, ...);

#endif
