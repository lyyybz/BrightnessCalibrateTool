/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: toolfun.h
 *
 * Description: Tool functions kit
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#ifndef TOOLFUN_H
#define TOOLFUN_H

#include "ague.h"
#include <time.h>

#define ID_LENGTH               6       // ��ID�ĳ���
#define                 BCD2BIN(x)                              ((((x)>>4)*10)+((x) & 0x0F))
#define                 BIN2BCD(x)                              ((((unsigned char)(x)/10)<<4)+((unsigned char)(x) % 10))
#define bcdtobin(c) (((c >>4) *10) + ((c) & 0x0F))
#define bintobcd(c) ((((unsigned char)(c)/10)<<4)+((unsigned char)(c) % 10))

#define max(a, b) ((a) > (b) ? (a) : (b))
#define min(a, b) ((a) < (b) ? (a) : (b))

#define offset(obj_type, mber) ((size_t) &((obj_type *) 0)->mber)
#define size(obj_type, mber)   (sizeof(((obj_type *) 0)->mber))

/*
 * Function:   Ascii string convert to bcd string
 * Parameters: src    - Ascii string
 *             alen   - Ascii string length
 *             dest   - Bcd string save buffer
 * Return:     Bytes of actually converted, bcd string length
 * Remark:     Parameter alen is the ascii string length,use "strlen" function to 
 *             calculate string length if alen equal to zero.
 *
 */
size_t atobcd(const char *src, size_t alen, unsigned char *dest);

/*
 * Function:   Bcd string convert to ascii string
 * Parameters: src    - Bcd string
 *             bcdlen - Bcd string length
 *             dest   - Ascii string save buffer
 * Return:     Bytes of actually converted, ascii string length
 *
 */
size_t bcdtoa(const unsigned char *src, size_t bcdlen, char *dest);

/*
 * Function:   Reverse string
 * Parameters: buff    - String
 *             bufflen - String length
 * Return:     None
 *
 */
void reverse(unsigned char *buff, size_t bufflen);

/*
 * Function:   Swap two character content
 * Parameters: c1 - Point to a character
 *             c2 - Point to a character
 * Return:     None
 *
 */
void swap(unsigned char *c1, unsigned char *c2);

/*
 * Function:   Get local time and compress to bcd string save in indicated buffer
 * Parameters: buff - Bcd time string storage location
 * Return:     None
 *
 */
void getbcdtm(unsigned char *buff);

/*
 * Function:   Set local time
 * Parameters: buf - Bcd time string storage location(YYMMDDHHMMSS)
 * Return:     Zero if operation success,or -1 if an error occurs
 *
 */
int setbcdtm(const unsigned char *buf);

/*
 * Function:   Get total second from 1900
 * Parameters: None
 * Return:     second
 *
 */

time_t getcurrtime();

/*
 * Function:   Get total second from 1900
 * Parameters: hour - hour
 *             min  - minute
 * Return:     second
 *
 */
time_t gettime(size_t hour, size_t min);

/*
 * Function:   convert bcd id to bin id, and reverse
 * Parameters: id - convert id
 * Return:     none
 *
 */
void id_bcdtobin(unsigned char id[]);

/*
 * Function:   convert bin id to bcd id, and reverse
 * Parameters: id - convert id
 * Return:     none
 *
 */
void id_bintobcd(unsigned char id[]);
unsigned char checksum (const unsigned char *data, int len);
unsigned char checkxor (const unsigned char *data, int len);
void bcd_to_bin(unsigned char s[], unsigned int len);
void bin_to_bcd(unsigned char s[], unsigned int len);
void order_reverse(void *buff,  int len);
#endif
