
#ifndef AGUE_H
#define AGUE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "debug.h"
#include "dev_ctrl.h"
#include "update.h"

typedef unsigned short ADDRESS;



#endif
