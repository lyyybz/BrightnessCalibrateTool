/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: rterrs.h
 *
 * Description:  Error code of route
 *
 * Version: v1.0
 * Time:    2010-2-2
 *
 */
 
#ifndef RTERRS_H
#define RTERRS_H

#define seterrno(errno) (rf_seterr(errno), -1)

enum
  {
    RTFERR_FLEN    = 0x00, /* frame length error */
    RTFERR_SUM     = 0x01, /* sum  */
    RTFERR_XOR     = 0x02, /* xor */
    RTFERR_FRAM    = 0x03, /* fram */  
    RTFERR_CONFUS  = 0x04, /* data confusion */
    RTFERR_MINLEN  = 0x05, /* length is shorten */
    RTFERR_NOTCMD  = 0x06, /* not command frame */
    RTFERR_ASCII   = 0x07, /* ASCII cmd bytes error */
    RTFERR_CMDLEN  = 0x08, /* length of command error */
    RTFEER_CMDNOT  = 0x09, /* command not surport */
    RTFERR_CMDCONT = 0x0A, /* content of command frame error */
    RTFERR_NORES   = 0x0B, /* no response from PLC38-III */
    RTFERR_SYSRUN  = 0x0C, /* system is running */
    RTFERR_IDEXST  = 0x0D, /* meter already existed */
    RTFERR_IDNOT   = 0x0E, /* meter not exist */
    RTFERR_IDMAX   = 0x0F, /* number of meter equal to max */
    RTFERR_EEPFUL  = 0x10, /* eeprom not have spase */
    RTFERR_IDNUM0  = 0x11, /* number of meter equal to 0 */
    RTFERR_TMOUT   = 0x12, /* time out */
    RTFERR_IDFAIL  = 0x13, /* access the id failly */
    RTFERR_FRM     = 0x14, /* command error with PLC38-III */
    RTFERR_SOH     = 0x15, /* not found SOH with PLC38-III */
    RTFERR_STXETX  = 0x16, /* STX or ETX with PLC38-III */
    RTFERR_DATA    = 0x17, /* data overflow with PLC38-III */
    RTFERR_BCC     = 0x18, /* BCC error with PLC38-III  */
    RTFERR_NOMETER = 0x19, /* no validate meter that can be accessed directly */
    RTFERR_NOSELMT = 0x20, /* no selected meter */
    RTFERR_SINKID  = 0x30, /* sink id error */
    RTFERR_RAMFUL  = 0x31, /* ram not have spase */
  }; 

enum
  {
    GBERR_TIMEOUT = 0x00,
    GBERR_DATA    = 0x01,
    GBERR_LEN     = 0x02,
    GBERR_CS      = 0x03,
    GBERR_DT      = 0x04,
    GBERR_FORMAT  = 0x05,
    GBERR_IDEXIST = 0x06,
    GBERR_IDNO    = 0x07,
    GBERR_MCU     = 0x08,
    GBERR_BUSY    = 0x09,
    GBERR_NSUPPORT = 0x0A,
    GBERR_OTHER   = 0xFF,
  };

/*
 * Function:   Set error code
 * Parameters: errno    - Error code
 * Return:     Zero if set success, or other if an error occurs
 * Remark:     
 */
int rf_seterr(int errno);

/*
 * Function:   Get error code
 * Parameters: None
 * Return:     Error code
 * Remark:     
 */
int rf_geterr();

#endif
