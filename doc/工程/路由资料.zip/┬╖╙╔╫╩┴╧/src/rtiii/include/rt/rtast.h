/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rtast.h
 *
 * Description: Router assist funcation interface
 *
 * Version: v1.0
 * Time:    2010-1-13
 *
 */

#ifndef RTAST_H
#define RTAST_H

#define THRESH_DPSK 90

#define MINRANDOM 8
#define MAXHOPTM  8000
#define MAXBRDTM  3000
#define TRANBIT   25

#define  EXRUNTIMER 0x04
#define  REGTIMER 0x01
#define  SENDTNO5TIMER  0x11      //����TNO5ɾ���� ��ʱ��
#define  HARDRESTE 0X03
//#define  MAXFHOP 0x07
#define  MAXFHOP     (max(_rtparas.maxround,_rtparas.maxfhround)+2)
#define  MAXFLOODHOP 0x07
#define  DEFLOODHOP   3 //Ĭ�ϵķ������� ÿ�μ�2���7

#define   TNO6_MAX_TASK_NUMBER    15 // ��ͬʱִ�еĲ���������������
#define MAX_PARALLEL_MINUTES    1020    //�����������ʱ��(����)

enum stageinfo
  {
    S0 = 0x00,
    S1 = 0x01,
    S2 = 0x02,
    S3 = 0x03,
    S4 = 0x04,
    S5 = 0x05,
    S6 = 0x06,
    S7 = 0x07,
    S8 = 0x08,
  };

enum
  {
    REPORT_PLC = 0x00,
    REPORT_APP = 0x01,
  };

struct rtreport
{
  unsigned char state;
  unsigned int  left;
  unsigned int  idletm;
  unsigned char count;
  unsigned char sno;
  unsigned char buf[0x400];
  unsigned int len;
  struct para_report report;
};

extern unsigned char _testdata[3];
extern struct rtreport _rtreport;
extern struct para_report _report645;
extern unsigned char channel38;
/*
 * Function:   get system tick
 * Parameters: None
 * Return:     current tick
 *
 */
unsigned int currtick();

/*
 * Function:   Get current app type
 * Parameters: None
 * Return:     app type
 * Remark:
 */
unsigned char get_apptype();

/*
 * Function:   Set app type
 * Parameters: apptype - app type
 * Return:     NULL
 * Remark:
 */
int set_apptype(unsigned char apptype);

/*
 * Function:   Request pwd and wmode
 * Parameters: none
 * Return:     NULL
 * Remark:
 */
void req_pwdwmode();

/*
 * Function:   Get num of touch meter
 * Parameters: None
 * Return:     num of touch meter
 * Remark:
 */
unsigned char touchnum();

/*
 * Function:   Save meter breakpoint
 * Parameters: mt - Pointer to operate meter
 * Return:     None
 * Remark:
 */
void saveposition(struct mtinfo *mt);

/*
 * Function:   Step to next stage
 * Parameters: None
 * Return:     None
 * Remark:
 */
void nextstage();

/*
 * Function:   Step to next round or stage
 * Parameters: None
 * Return:     None
 * Remark:
 */
void rtnext();

/*
 * Function:   Organize path
 * Parameters: rp - Begin with reapter
 * Return:     Zero if success, or other if an error occurs
 * Remark:
 */
int ploughpath(struct rpinfo *rp);

/*
 * Function:   Reverse nds
 * Parameters: list - Nds content to be reversed
 * Return:     None
 * Remark:
 */
void ndsrevers(struct ndscont *list);

/*
 * Function:   Get max number of list task
 * Parameters: spara - Stage parameter
 * Return:     Zero if success, or other if an error occurs
 * Remark:
 */
int list_maxnode(enum stageinfo spara);

/*
 * Function:   Process touch information in list
 * Parameters: famt - Father node of meters in list
 * Return:     None
 * Remark:
 */
void touchmt(struct mtinfo *famt);

/*
 * Function:   Organize path in task2 frame
 * Parameters: famt - father node of meters
 * Return:     None
 * Remark:
 */
int task2nds(struct mtinfo *mt);

/*
 * Function:   Gain random number
 * Parameters: None
 * Return:     Random number
 * Remark:
 */
int gainrand();

/*
 * Function:   Implementation of monit flow
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
int monittask();

/*
 * Function:   Clear meter list in task
 * Parameters: None
 * Return:     None
 * Remark:
 */
void mlist_clear();

/*
 * Function:   Add one meter to meter list
 * Parameters: id - meter id
 *             idlen - Length of id
 * Return:     None
 * Remark:
 */
void mlist_add(unsigned char *id, unsigned char idlen);

/*
 * Function:   Monit task include broad operation
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
int rt_mntbrd();

/*
 * Function:  Check monit meter is in database, or not
 * Parameters: meter id
 * Return:     0 if meter in database, -1 if not
 * Remark:
 */
int rt_chkmntid(unsigned char *mtid);

/*
 * Function:   Monit task from application layer
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
int rt_appmnt();

/*
 * Function:   Monit task from application layer direct to 38
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
int rt_appmnt_38();

/*
 * Function:   Monit process from application layer
 * Parameters: None
 * Return:     None
 * Remark:
 */
int app_mntprocess();

/*
 * Function:   Route confirm stage0
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage0();

/*
 * Function:   Route confirm stage1
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage1();

/*
 * Function:   Route study stage2
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage2();

/*
 * Function:   Route study stage3
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage3();

/*
 * Function:   Route study stage4
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage4();

/*
 * Function:   Route optimize stage5
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage5();

/*
 * Function:   Route optimize stage6
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage6();

/*
 * Function:   Route optimize stage7
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage7();

/*
 * Function:   Route optimize stage8
 * Parameters: None
 * Return:     None
 * Remark:
 */
void stage8();

/*
 * Function:   get id of jizhongqi
 * Parameters: id - Pointer to return content
 * Return:     Zero if success, or other if an error occurs
 * Remark:
 */
int rt_jzqid(unsigned char *id);


/*
 * Function:   send report data to dm
 * Parameters: report
 * Return:     Zero if success, or other if an error occurs
 * Remark:
 */
int report_up(struct para_report *report);

/*
 * Function:   node auto register
 * Parameters: None
 * Return:     None
 * Remark:
 */
void rt_autoreg();

/*
 * Function:   get mode of 38 sink
 * Parameters: None
 * Return:     mode of 38 sink
 * Remark:
 */
int rt_sink38mode();

/*
 * Function:   set sink of 38;
 * Parameters: None
 * Return:     None
 * Remark:
 */
void rt_setsink38();

/*
 * Function:   router debug
 * Parameters: frame - debug data
 *             len   - Length of the frame
 *             ccw   - mode
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 */
int rt_debug(unsigned char *frame, int len, unsigned char ccw);

/*
 * Function:   floodtask
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
//int floodtask();

/*
 * Function:   setmode_iv
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
int setmode_iv();

/*
 * Function:   switch_iii
 * Parameters: None
 * Return:     Zero if monit task is excuted, or other if monit task is over
 * Remark:
 */
//int switch_iii();

/*
 * Function:   judge new database
 * Parameters: None
 * Return:     Zero if database not new, or 1 if is new
 * Remark:
 */
int rt_newdb();

/*
 * Function:   get current opt id
 * Parameters: None
 * Return:     Zero if get success, or 1 is fail
 * Remark:
 */
int get_curid(unsigned char *id);

int get_dlytm(unsigned int *dlytm);
int get_node_reg_sta();
int is_all_nds_43(void);
void chk_to_set_dpsk_mode(unsigned int num43, unsigned int all);
/******************7���м�*************************/
void stage9();
int s9_monittask();
int s9_ploughpath(struct mtinfo *mtptr);


void rt_stop_mnt(void);
void rt_stop_brd(void);
void clear_rtparas_para(void);
void add_task_setmtitem(unsigned char *bcdid, unsigned char len, unsigned char pro, unsigned char *data, unsigned char datalen);

void Tno6TaskTimer();
unsigned char getNewTno6Sno(unsigned int taskMinutes, enum ParallelTaskType);
int getTno6TaskType(int sno);
int rt_mntplc_update_iv(unsigned char *aid, unsigned char *frm, unsigned char len);
int rt_mntplc_update_v(unsigned char *aid, unsigned char *frm, unsigned char len);
int set_dcv_to_dciv();
#endif
