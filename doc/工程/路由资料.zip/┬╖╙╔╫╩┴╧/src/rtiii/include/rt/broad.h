/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: broad.h
 *
 * Description:  Common function of route for application
 *
 * Version: v1.0
 * Time:    2010-1-29
 *
 */
 
#ifndef BROAD_H
#define BROAD_H

/*
 * Function:   Initialize of broad task 
 * Parameters: None
 * Return:     None
 * Remark:     
 *
 */
void broad_init();

/*
 * Function:   process broad task 
 * Parameters: None
 * Return:     None
 * Remark:     
 *
 */
void broad();

#endif

