/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rt.h
 *
 * Description: Router funcation interface
 *
 * Version: v1.0
 * Time:    2009-12-21
 *
 */

#ifndef RT_H
#define RT_H

#define BUFLEN 0x200

#pragma pack(1)

enum
  {
    REPOIDLE   = 0x00, /* report channel for idle */
    REPODIR    = 0x01, /* report channel for no direct error */
    REPORELAX  = 0x02, /* report channel for relax time */
    REPORESUME = 0x03, /* report channel for monitor resume time */
  };

enum
  {
    CBPLCMASK = 0x80, /* mask of plc frame flag */
    CBPLC     = 0x80,
    CBDMMASK  = 0x08, /* mask of dm frame flag */
    CBAPD     = 0x08,
  };

enum                  /*mode of plc buffer*/
  {
    PLCNORMAL = 0x00,
    PLCACTIVE = 0x01,
    PLCSKID   = 0x02,
    PLCCFM    = 0x03,
    PLCRPT    = 0x04,
    PLCEMP    = 0xEE, /*empty current messege*/
    PLCERR    = 0xFF,
  };
enum
{
    FRMFFMASK = 0x40,      /*flood fail mask,�ϴ�ʹ�÷ֲ�ʽ�㳭ʧ�ܣ���λ��ֱ��ʹ��fsk*/
    FRMFFAIL = 0x40,     /*�Ƿ�ʹ�÷ֲ�ʽʧ�ܣ�ǿ��ʹ��fsk*/

    FRMTVMASK  = 0x20,      /*�б������ɹ���ģ���ס�ɹ������ʣ��㳭ʱ��ǿ��ʹ�ø�ģʽ*/
    FRMTVALID  = 0x20,      /*ǿ��ʹ��λ�Ƿ���Ч*/
    FRMTMMASK  = 0x10,
    FRMTFSK = 0x00,        /*FSK*/
    FRMTDPSK = 0x10,       /*DPSK��*/
    FRMLISTMASK = 0x06,    /* list �еĽڵ�*/
    FRMLISTUNK  =0x00,     /*list δ֪*/
    FRMLISTN43 = 0x02,     /*list ��43*/
    FRMLIST43 = 0x04,      /*list 43*/
    FRMLISTVMASK = 0x08,     /*list mask valid flag,1 valid,0 invalid*/
    FRMLISTVAL = 0x08,     /*1 valid,0 invalid*/
};
struct commbuf
{
  unsigned char flag; /* flag of buffer status */
                      /* bit7: 1 - plc buffer has a frame, 0 - empty */
                      /* bit3: 1 - dm buffer has a frame, 0 - empty */
  struct
  {
    int len;
    unsigned char buf[BUFLEN];
    unsigned char mode; /* bit7: 1 - 645 frame, 0 - 9F frame*/
  } plc, dm;
};

struct run_info
{
  unsigned short assocnum;
  unsigned short succnum;
  unsigned short lvl[16];
};

extern struct commbuf _commbuf; /* global parameter */

/*
 * Function:   Router initialize
 * Parameters: None
 * Return:     None
 *
 */
void rt_init();

/*
 * Function:   Automatic router running
 * Parameters: None
 * Return:     None
 *
 */
void rt_autorun();

/*
 * Function:   router report
 * Parameters: chan  - channel for report
 *             times - reprot times
 * Return:     None
 *
 */
void rt_report(int chan, int times);

/*
 * Function:   send mode of router
 * Parameters: None
 * Return:     None
 *
 */
void rt_sendmode();

#endif

