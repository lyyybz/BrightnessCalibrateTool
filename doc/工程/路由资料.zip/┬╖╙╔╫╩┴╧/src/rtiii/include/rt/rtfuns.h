/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: rtfuns.h
 *
 * Description:  Common function of route for application
 *
 * Version: v1.0
 * Time:    2010-1-25
 *
 */

#ifndef RTFUNS_H
#define RTFUNS_H

#define TYPEFLAG 0x80
#define DMMD_SUC 0x01 /* _combuf.dm.mode */


enum
{
    APPRCFM = 0x00, /* application confirm */
    APPRDATA = 0x01, /* application data*/
    APPRFAIL = 0x02, /* application fail*/
};

enum
{
    PHS_PARA_SUR = 0,
    PHS_PARA_NOTSUR = 1,
    PHS_PARA_UNKOWN = 2,
};
enum
{
    PHS_VAL_UN = 0,
    PHS_VAL_A = 1,
    PHS_VAL_B = 2,
    PHS_VAL_C = 4,
    PHS_VAL_ALL = 0x0F,
};
enum
{
    PHS_PRO_UN = 0,
    PHS_PRO_97 = 1,
    PHS_PRO_07 = 2,
    PHS_PRO_188 = 3,
};

struct commdata
{
    unsigned char *data;
    int datalen;
};

/*
 * Function:   set mode of _combuf.dm
 * Parameters: mode
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_setdmmode(unsigned char mode);

/*
 * Function:   Write data to 38 com
 * Parameters: buf      - Pointer to data to be writen
 *             wbytes   - bytes to be writen
 *             t_wait   - Max waiting time(ms)
 * Return:     Zero if get success, or other if an error occurs
 * Remark:
 */
int rf_write38(unsigned char *buf, size_t wbytes, size_t t_wait);

/*
 * Function:   Write data to dm com
 * Parameters: buf      - Pointer to data to be writen
 *             wbytes   - bytes to be writen
 *             t_wait   - Max waiting time(ms)
 * Return:     Zero if get success, or other if an error occurs
 * Remark:
 */
int rf_write(unsigned char *buf, size_t wbytes, size_t t_wait);

/*
 * Function:   Get version of router
 * Parameters: None
 * Return:     data - version of router
 *             datalen - bytes of version
 * Remark:
 */
int rf_get_ver(unsigned char *data, int *datalen);
int rf_get_pvergb(unsigned char *data, int *datalen);

/*
 * Function:   Get last program time
 * Parameters: None
 * Return:     data - last program time of router
 *             datalen - bytes of last program time
 * Remark:
 */
int rf_get_prgtm(unsigned char *data, int *datalen);

/*
 * Function:   Get meter number
 * Parameters: data - mt amount
 *             datalen - bytes of mt amtount
 * Return:     Meter number in router
 * Remark:
 */
int rf_get_amount(unsigned char *data, int *datalen);

/*
 * Function:   Initialize traverse channel of meter
 * Parameters: None
 * Return:     None
 * Remark:
 */
void rf_init_mttrav();

/*
 * Function:   Get meter infomation
 * Parameters: mtid  - Meter id
 * Return:     phase - Phase of meter
 *             depth - Depth of meter
 * Remark:     Zero if get success, or other if an error occurs
 */
int rf_get_mt(const unsigned char *mtid, unsigned char *phase, unsigned char *depth);

/*
 * Function:   Get some meter infomation
 * Parameters: mtid  - Meter id
 * Return:     phase - Phase of meter
 *             depth - Depth of meter
 * Remark:     Zero if get success, or other if an error occurs
 */
int rf_get_mtinfo(unsigned char *mtid, unsigned char *phase, unsigned char *depth);
int rf_get_nw_mtinfo(unsigned char *para, unsigned char *buff, unsigned char *len, unsigned char type);
int rf_get_nw_mt_phs(unsigned char *para, unsigned char *buff, unsigned char *len);
/*
 * Function:   Initialize traverse channel of repeater
 * Parameters: mtid - Meter id
 * Return:     Zero if initialize success, or other if an error occurs
 * Remark:
 */
int rf_init_rptrav(const unsigned char *mtid, unsigned char *phase, unsigned char *depth);

/*
 * Function:   Get next repeater of appointed meter
 * Parameters: None
 * Return:     rpid  - Repeater id
 *             phase - Phase of repeater
 *             depth - Depth of repeater
 * Remark:     Zero if get success, or other if no more repeater
 */
int rf_get_rpinfo(unsigned char *rpid, unsigned char *phase, unsigned char *depth);

/*
 * Function:   Get scan level of router
 * Parameters: None
 * Return:     Scan level
 * Remark:
 */
unsigned char rf_get_slevel();

/*
 * Function:   Get max hops of router
 * Parameters: None
 * Return:     Max hops
 * Remark:
 */
unsigned char rf_get_maxrd();

/*
 * Function:   Get work mode of router
 * Parameters: None
 * Return:     Work mode
 * Remark:
 */
unsigned char rf_get_wrkmd();

/*
 * Function:   Get run mode of router
 * Parameters: chan - Number of channel to traverse hash table
 * Return:     Run mode
 * Remark:
 */
unsigned char rf_get_runmd();

/*
 * Function:   Get work number of router
 * Parameters: None
 * Return:     Work times
 * Remark:
 */
unsigned char rf_get_wrkno();

/*
 * Function:   Get stage of router
 * Parameters: None
 * Return:     Stage information
 * Remark:
 */
unsigned char rf_get_stage();

/*
 * Function:   Get extended work mode
 * Parameters: None
 * Return:     Extended work mode
 * Remark:
 */
unsigned char rf_get_extdmd();

/*
 * Function:   Get currently reading meter id
 * Parameters: data - id buff
 *             datalen - pointer to len
 * Return:     Currently reading meter id
 * Remark:
 */
int rf_get_curid(unsigned char *data, int *datalen);

/*
 * Function:   Get untouched meter number
 * Parameters: None
 * Return:     Untouched meter number
 * Remark:
 */
int rf_get_untouchnum(unsigned char *data, int *datalen);

/*
 * Function:   Get untouched meter id orderly
 * Parameters: None
 * Return:     mtid - untouched meter id
 * Remark:     Zero if get success, or other if no more untouched meter
 */
int rf_get_untouchid(unsigned char *data, int *datalen);

/*
 * Function:   Get concentrator id
 * Parameters: None
 * Return:     Concentrator id
 * Remark:
 */
int rf_get_sinkid(unsigned char *data, int *datalen);

/*
 * Function:   Get sequence number of meter
 * Parameters: mtid - meter id
 * Return:     sno  -  sequence number
 * Remark:     Zero if get success, or other if one error occurs
 */
int rf_get_sno(const unsigned char *mtid, unsigned char *sno);

/*
 * Function:   Get meter id by sequence number
 * Parameters: sno  -  sequence number
 * Return:     mtid - meter id
 * Remark:     Zero if get success, or other if one error occurs
 */
int rf_get_id(unsigned char *sno, unsigned char *mtid);

/*
 * Function:   Get user filed of meter node
 * Parameters: mtid - meter id
 * Return:     user - point to user
 * Remark:     Zero if get success, or other if one error occurs
 */
int rf_get_user(unsigned char *mtid, unsigned char *user);

/*
 * Function:   Send data to one meter
 * Parameters: mtid -  Meter id
 *             data - Data to be sended
 *             datalen - Length of data
 * Return:     Zero if send successfully, or other if one error occurs
 * Remark:
 */
int rf_monit(unsigned char *mtid, unsigned char pro, unsigned char *data, int datalen, unsigned char wretlen);
void rf_set_mntdlytm(unsigned char dlytm);

/*
 * Function:   Get test command
 * Parameters: None
 * Return:     data - test command of router
 *             datalen - bytes of test command
 * Remark:
 */
void rf_get_testcmd(unsigned char *data, int *datalen);

/*
 * Function:   Get program version of gb protocol
 * Parameters: None
 * Return:     data - program version
 *             datalen - bytes of program version
 * Remark:
 */
int rf_get_vergb(unsigned char *data, int *datalen);

/*
 * Function:   Get concentrator id of gb protocol(6 bytes)
 * Parameters: None
 * Return:     data - concentrator id
 *             datalen - bytes of concentrator id
 * Remark:
 */
int rf_get_jzqid(unsigned char *data, int *datalen);

/*
 * Function:   set appd of struct task
 * Parameters: type   - type of appliction frame:APPRCFM or APPRDATA
 *             data   - application data
 *             dlen   - length of application data
 *             wbytes - length of data that expected to return
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_setappd_ex(unsigned char type, unsigned char pro, unsigned char *data, unsigned int dlen, unsigned char wbytes);
int rf_setappd(unsigned char type, unsigned char *data, unsigned int dlen, unsigned char wbytes);
void rf_setdlytm(unsigned char dlytm);

/*
 * Function:   set pwd and wmode
 * Parameters: type   - type of appliction frame:PWD or WMODE
 *             data   - application data
 *             dlen   - length of application data
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_setpwdwmode(unsigned char type, unsigned char *data, unsigned char dlen);

/*
 * Function:   Set rtfuns error code
 * Parameters: errno - error code
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_seterr(int errno);

/*
 * Function:   Get rfuns error code
 * Parameters: none
 * Return:     Error code
 */
int rf_geterr();

/*
 * Function:   Send data to PLCi38 directly
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_comm38(unsigned char *data, int datalen);

/*
 * Function:   delete all meter in database
 * Parameters: node
 * Return:    Zero if delete success, or -1 if an error occurs
 */
int rf_set_clrmt();
int rf_set_clrmt_nw();
/*
 * Function:   clear success flag of all meter
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_clrsucf();

/*
 * Function:   ADD meter OPTION
 * Parameters: mtid - pointer to meter id
 * Return:     Zero if success, or -1 if an error occurs
 */
int rf_set_addmt_rt(unsigned char *mtid);

/*
 * Function:   ADD meter OPTION
 * Parameters: mtid - pointer to meter id
 *             mtid - pointer to user sno
 * Return:     Zero if success, or -1 if an error occurs
 */
int rf_set_addmt_gb(unsigned char *mtid, unsigned char *sno, unsigned char pro);
int rf_set_addmt_newgb(unsigned char *mtid, unsigned char pro);

/*
 * Function:   Delete meter OPTION
 * Parameters: mtptr - meter info
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_delmt(unsigned char *mtid);

/*
 * Function:   modify meter id
 * Parameters: newid - meter id after modify
 *             oldid - meter id before modify
 * Return:     Zero if success, or -1 if an error occurs
 */
int rf_set_mdfid(unsigned char *newid, unsigned char *oldid);

/*
 * Function:   Insert repeater node in meter relay table
 * Parameters: mtid  - pointer to meter id
 *             rprtr - Pointer to repeater id
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_inserp(unsigned char *mtid, unsigned char *rpid);

/*
 * Function:   set scan level
 * Parameters: sleve - scan level
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_slev(unsigned char slevel);

/*
 * Function:   adjust work break to begin
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_begin();

/*
 * Function:   set work mode
 * Parameters: wrkmd - work mode
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_wrkmd(unsigned char wrkmd);

/*
 * Function:   set test command
 * Parameters: data - test commad
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_test(unsigned char *data);

/*
 * Function:   Random set sink id
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_randsinkid();

/*
 * Function:   set sink id
 * Parameters: sink - pointer to sink id
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_sinkid_v(unsigned char *sink);

/*
 * Function:   adjust run mode
 * Parameters: mode - run mode
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_runmd(unsigned char mode);

/*
 * Function:   set extend run mode
 * Parameters: mode - extend run mode
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_exmd(unsigned char mode);

/*
 * Function:   set id of  jzq
 * Parameters: id - pointer to id of jzq
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_set_jzqid(unsigned char *id);
int rf_set_jzqid_nw(unsigned char *id);
/*
 * Function:   set mode of  router
 * Parameters: mode - mode of router
 * Return:     Zero if set success, or -1 if an error occurs
 */
int rf_set_rtmd(unsigned char mode);

/*
 * Function:  change phase
 * Parameters: phase - phase
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_ctrl_chgphs(unsigned char phase);

/*
 * Function:   start work of router
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_ctrl_work();

/*
 * Function:   stop work of router
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_ctrl_stop();

/*
 * Function:   start broad OPTION
 * Parameters: none
 * Return:     Zero if delete success, or -1 if an error occurs
 */
int rf_ctrl_startbrd();

/*
 * Function:   Get meter number of protocol GB
 * Parameters: data - mt amount
 *             datalen - bytes of mt amtount
 * Return:     Meter number in router
 * Remark:
 */
int rf_get_mtamtgb(unsigned char *data, unsigned char *len);

/*
 * Function:   Get run state of protocol GB
 * Parameters: data - run state
 *             len - bytes of run state
 * Return:     Zero if get success, or -1 if an error occurs
 */
int rf_get_runstate(unsigned char *data, unsigned char *len);

/*
 * Function:   Get untouched meter id orderly of protocol GB
 * Parameters: usno - user sno
 * Return:     mtid - untouched meter id
 *             phase - phase of meter
 *             depth - depth of meter
 * Remark:     Zero if get success, or other if no more untouched meter
 */
int rf_get_untouchidgb(unsigned char *para, unsigned char *buff, unsigned char *len);

/*
 * Function:   get mt info by user sno
 * Parameters: usno - user sno
 * Return:     mtid - untouched meter id
 *             phase - phase of meter
 *             depth - depth of meter
 * Remark:     Zero if get success, or -1 if an error occurs
 */
int rf_get_mtinfogb(unsigned char *para, unsigned char *buff, unsigned char *len);

/*
 * Function:   hardware reset
 * Parameters: None
 * Return:     Zero if reset success, or -1 if an error occurs
 */
int rf_reset(unsigned char second);

/*
 * Function:   get system tick
 * Parameters: second -  delay time
 * Return:     current tick
 */
unsigned int rf_currtick();

/*
 * Function:   get concentrator id in nds
 * Parameters: None
 * Return:     jid - concentrator id in nds
 *             idlen - length of concentrator id in nds
 */
int rf_getjid(unsigned char *jid, int *idlen);

/*
 * Function:   set broad flag in monit task
 * Parameters: None
 * Return:
 */
void rf_setbrd();

/*
 * Function:   reset task information
 * Parameters: None
 * Return:
 */
void rf_settask();

/*
 * Function:   rt_setbrd
 * Parameters: t, switch
 * Return:
 */
void rt_setbrd(unsigned char t);


/*
 * Function:   rt_getbrd
 * Parameters: none
 * Return:     switch
 */
unsigned char rt_getbrd();

/*
 * Function:   start auto register task
 * Parameters: left - life of task
 * Return:     Zero if get success, or -1 if an error occurs
 */
int rf_autoreg(unsigned int left);

/*
 * Function:   send frame of test
 * Parameters: time - time of test
 * Return:     Zero if get success, or -1 if an error occurs
 */
int rf_testiv(unsigned char time);

/*
 * Function:   get mode of router
 * Parameters: mode - point to mode
 * Return:     Zero if get success, or -1 if an error occurs
 */
int rf_get_rtmd(unsigned char *mode);

/*
 * Function:   prepare to work in exmode
 * Parameters: time - time of work
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_exprewrk(unsigned int time);

/*
 * Function:   get state of exmode
 * Parameters: state - pointer to state
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_get_exsta(unsigned char *state);

/*
 * Function:   set state of exmode
 * Parameters: state - state of new exmode
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_set_exsta(unsigned char state);

/*
 * Function:   start work in exmode
 * Parameters: none
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_exwork();


/*
 * Function:   check if rt running or stop
 * Parameters: none
 * Return: 0 stop
 */
int rf_isstop();

/*
 * Function:   add meter in exmode
 * Parameters: id  -  pointer to meter
 *             num -  number of meter
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_exaddmt(unsigned char ( *id )[6], unsigned int num);

/*
 * Function:   hardreset
 * Parameters: none
 * Return: Zero if get success, or -1 if an error occurs
 */
int rf_hardinit();

int rf_start_broadcast(unsigned char data[], int data_len, unsigned char type, int time);

int rf_get_e2md(unsigned char *mode);

/*
 * Function:   rt_selfchk
 * Parameters: none
 * Return: none
 */
void rt_selfchk();

int rf_get38info(unsigned char *send, unsigned char slen, unsigned char *recv, unsigned char *rlen);

int rf_comm38_645(int fd, unsigned char *send, size_t slen, unsigned char *recv, size_t *rlen);

void rf_set_srelay(unsigned char srelay);

int rf_get_srelay();

int rf_set_dispflag();

int rf_set_dispbd();

int rf_set_rdswitch(unsigned char *data);

int rf_get_rdswitch(unsigned char *data, int *len);

int rf_get_rtmd_external(unsigned char *mode);
int rf_get_jzqid_nw(unsigned char *data, int *datalen);
// int rf_set_newgb(unsigned char newgb);
int rf_getappd(unsigned char *data, unsigned char *dlen);
void rf_set_appd_bk(unsigned char *data, unsigned int dlen);
void set_mt_cm1suc_flag(unsigned char bcdid[]);
void clear_mt_cm1suc_flag(unsigned char bcdid[]);
int get_suc_mt_ratio();
void node_rd_min_tick(void);
int get_vlaid_tick_num(int tick);
int rf_set_slev_nw(unsigned char slevel);
int rf_set_delmt_nw(unsigned char *mtid, unsigned char type);
int is_mlist_all43(struct mtlist *mlist, int num);
void chek_list_set_modu(int val);
void snd_phs_tick(void);
void set_mt_pro(unsigned char *id, unsigned char type, unsigned char pro);
int is_node_need_phs_brd(void);
int is_node_v_phs_brd(void);
int get_cur_cyc_dctime(void);
void chk_to_fast_task_stage(void);
void fast_task_tick(void);
void set_mt_task_fail_times(unsigned char bcdid[], unsigned char type);
int is_mt_report_failed(unsigned char bcdid[]);
#endif

