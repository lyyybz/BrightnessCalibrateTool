/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rtparas.h
 *
 * Description: Router parameters declaration
 *
 * Version: v1.0
 * Time:    2009-12-15
 *
 */

#ifndef RTPARAS_H
#define RTPARAS_H

#include "../db/db.h"
#pragma pack(1)

enum /* constant definition */
{
    MAXHOPS = 0x1F,
    NORANDOM = 0x08,
    MAXWRKSNO = 0x0F,
    MAXWRKTMS = 0x08,
    MAXREGSNO = 0x0F,
};

enum
{
    MODENOR = 0x01, /* normal work mode */
    RUNMDRMASK = 0x80, /* mask of report flag */
    RUNMDRPT = 0x80,
};

enum
{
    STASMASK = 0x80, /* mask of all sno state */
    STAALLSNO = 0x80,
    STABMASK = 0x40, /* mask of broad operation */
    STABROAD = 0x40,
    STAMMASK = 0x20, /* mask of monitor operation */
    STAMONIT = 0x20,
    STASTMASK = 0x10, /* mask of router run flag */
    STARUN = 0x10,
    STABMMASK = 0x08, /* mask of monitor operation��In the broad process */
    STABMONIT = 0x08,
    STARMASK = 0x04, /* mask of node register */
    STAREG = 0x04,
    STAPMASK = 0x02, /* mask of active report */
    STARPT = 0x02
};

enum              /*_rtparas.wkstate*/
{
    DISPBDMASK = 0x04, /* mask of display broad*/
    DISPBROAD = 0x04,
    ZJREGMASK = 0x08,
    ZJREG = 0x08,
    RPTSWIMASK = 0x10, /*�ϱ���������*/
    RPTSWION = 0x10,
    REGSWIMASK = 0x20, /*�ϱ���������*/
    REGSWION = 0x20,
    RDOVERMASK = 0x40, /*���������ϱ�����, 1 - �Ѿ��ϱ���0 - δ�ϱ�*/
    RDOVER = 0x40
};

enum
{
    OLD_GBPRO = 0xFF,
    NEW_GBPRO = 0x11,
};
enum
{
    PHSNEEDSMASK = 0x01, /*���˷�����λ������*/
    PHSNEEDSND = 0x01,
    PHSSINGMASK = 0x02, /*��ǰ���ڷ�����λ*/
    PHSSNDING = 0x02,
};
struct rtpara   /* ���0xE0 */
{
    unsigned char slevel; /* scan level */
    unsigned char wrkno;  /* work serial NO */
    unsigned char sinkid[2]; /* router address */
    unsigned char minsno[2]; /* min meter serial NO */
    unsigned char maxsno[2]; /* max meter serial NO */
    unsigned char apptype;   /* protocol 7E or GB */
    unsigned char jzqid[6]; /* id of jzq in 376.2 protocol */
    unsigned char jzqid_nw[6]; /*nw �ⲿ�����ڵ��ַ BIN����*/
    unsigned char flag_setid;
    unsigned char regsno;   /* sno of auto register */
    unsigned char brdclose; /* switch of broad organize */
    unsigned char areset; /* auto reset times */
    unsigned char eepend; /* eeprom storge end flag */

    /* below parameter in eeprom */
    unsigned char stage; /* stage of route run time */
    /* begin at 0 */
    unsigned char round; /* round = depth + 1 */
    /* begin at 1 */
    unsigned char phase; /* phase of route run time */
    unsigned char state; /* route state */
    /* bit7: all meter sno set, 1 - yes, 0 - no */
    /* bit6: is broad operation, 1 - yes, 0 - no */
    /* bit5: is monitor operation, 1 - yes, 0 - no */
    /* bit4: router run, 1 - yes, 0 - no */
    /* bit3: is monitor operation in broad, 1 - yes, 0 - no */
    /* bit2: auto register task, 1 - yes, 0 - no */
    /* bit1: active report task, 1 - yes, 0 - no */
    unsigned char maxround; /* max round knowledge in local database */
    unsigned char minround; /* min round knowledge in local database */
    unsigned short mtnum;   /* meter number in database */
    unsigned short succnum; /* success meter number */
    unsigned short cmd1num; /*���б����㳭�ɹ��������¼������ʱ�򣬻Ὣ��Ӧ����cmd1suc����*/
    unsigned short dev43num; /*43�豸�ڵ���ռ������*/
    unsigned char dpsk;    /*can use dpsk to read */
    /*bit 0  1 is force to use dbpsk only when database is new*/
    /*bit 1  1 is nodes 43 ratio is greater than 90%*/
    /*bit 2  1 is nds all 43 and  nodes 43 ratio greater than 90%*/
    unsigned char dbfirst; /* 0 is first 1 is not first*/
    unsigned char maxfhround;       /*��󷺺�㼶*/
    unsigned char wrktms; /* work times */
    unsigned char runmd;  /* system run mode */
    /* bit7: report flag */
    unsigned char exmd;   /* extend run mode */
    unsigned char wrkmd;  /* work mode */
    unsigned char cycle;  /* work cycle number */
    unsigned char curid[6]; /* currently reading meter */
    unsigned int extime; /* time of runing in exmode*/
    unsigned char exstate; /* state in exmode */
    unsigned char flood;
    unsigned char srelay; /*seven relay */
    unsigned char wkstate; /* bit0: work flag, 1 - working, 0 - stop work */
    /* bit1: get mtinfo system, 1 - new, 0 - old*/
    /* bit2: disp  broad, 1 - yes, 0 - no*/
    /* bit3: zhejiang soubiao, 1 - yes, 0 - no*/
    /* bit4: report switch, 1 - yes, 0 - no*/
    /* bit5: reg switch, 1 - yes, 0 - no*/
    /* bit6: chaobiao rpt, 1 - has report, 0 - not report*/
    unsigned char stagectl;
    unsigned char dlytm;  /*bit 0:1 - mntplc is dlytm, 0 - not*/
    /*bit 1: 1 - auto plc is dlytm, 0 -not*/
    /*bit 2: 1 - mntplc need req dlytm, 0 - not*/
    /*bit 3: 1 - auto plc need req dlytm, 0 - not*/
    unsigned char datainit;
    unsigned char flsave;
    unsigned short floodtick; //flood save tick 2 hour,save one time
    unsigned char sndphs; /*������λ�ı�־ bit 0,ʱ�䵽����Ҫ������λ*/
    /*bit1 ���ڷ�����λ     */
    unsigned short sndphstick; /*���͹㲥��λ��ʱ��*/
    unsigned char dctask; /*ÿ�ֽ�������ʼ���룬�㳭ģʽ��*/
    unsigned char dcmin; /*ÿִ��һ�����񣬶��Ὺ����ʱ������ʱ���������0��˵����Ȼ�п���ִ��������������·�����������򽫴˽׶ν���*/
    unsigned short dcnum;
    unsigned short cyctime; /*���ֵĺ�ʱ min*/
    unsigned char dcviv; /* ��ǰ�ü����ĵ㳭 */
};
#define DCTASK_TIMEOUT 8
#define GDIDLEN 18
#define MAX_FAST_STAGETIME (60+30)//����ִ�н׶����������ʱ��
struct share
{
    unsigned char jzqid[6];
    unsigned char wkmd;
    unsigned char blank1;
    unsigned char blank2;
    unsigned char cstate;
    unsigned char blank3;
    unsigned char upara;
    unsigned char blank5[1];
    unsigned char mode_state;     /*����Ӧģʽ�л�״̬*/
    unsigned char rt_ctrl;        /*bit0 1 - ����Ӧģʽ��0 - �̶�ģʽ*/
    /*bit1 1 - ����Ӧģʽ��0 - �̶�ģʽ*/
    unsigned char version;
    unsigned char blank4[1];
    unsigned char overtime;
    unsigned char conswitch;   /*bit 0 ���أ�
                                 bit 1��0,td,1,zcp;
                                 bit 4��0,III����3.5�������,1,IV��;
                                 bit5,0,fsk,1,dpsk*/
    unsigned char flswitch;
    unsigned char plswitch;
    unsigned char dlswitch;
    unsigned char state;
    unsigned char flag;  /* 43ԭϵͳû��ʹ�ã��ĳɴ�def_mode������0x55��0x57���Լ���������ģʽ�� */
    unsigned char newcmp[8];
};

struct gb_message
{
    unsigned char gbmamt;  /*�յ��ı���������ͷ5����������3��һ��������Ϊ����Э��*/
    unsigned char gbmcnt;  /*���б������к�*/
    unsigned char gblast; /*��һ�α������к�*/
    unsigned char gbequ;  /*���б������к�һ�µı�������*/
    unsigned char lastAFN; /*��һ�����ĵ�AFN*/
    unsigned char lastFFN; /*��һ�����ĵ�FFN*/
};

enum
{
    STATE_INIT = 0x00,
    STATE_WKING = 0x01,
    STATE_PAUSE = 0x02,
    STATE_CONFM = 0x03,
};

enum
{
    NORMASK = 0x01, /* mask of allow user sno repreat */
    NORALLOW = 0x00,
    INOMASK = 0x02, /* mask of read mt info by internal sno */
    INOALLOW = 0x00,
};

struct ndscont
{
    unsigned char num;
    unsigned char all43;
    struct
    {
        unsigned char len;  /* id length */
        unsigned char id[IDLEN];
    } nds[32];
};

enum
{
    APDMASK = 0x80, /* mask of application data */
    APDATA = 0x80,
    APCMASK = 0x40, /* mask of application confirm */
    APCCFM = 0x40,
    APFMASK = 0x20, /* mask of application read fail */
    APFAIL = 0x20,
    PTMASK = 0x0F, /* mask of data protocol */
};
enum
{
    DPSKFMASK = 0x01, /*mask of force to use dpsk mode*/
    DPSKFORCE = 0x01, /*force to use dpsk mode*/
    DPSKRMASK = 0x02, /*mask of ratio is enough*/
    DPSKRATIO = 0x02, /*num 43 ratio is enough*/
    DPSKCMASK = 0x04, /*mask of can use dpsk mode*/
    DPSKCAN = 0x04, /*can to use dpsk mode*/

};
struct appdata
{
    unsigned char protype; /* protocol type */
    /* bit7: application data */
    /* bit6: application confirm */
    /* bit5~bit4: reserve */
    /* bit3~bit0: protocol type */
    unsigned char wretlen; /* expect reply length */
    unsigned int dlytm;
    unsigned char datalen; /* application data length */
    unsigned char data[255];
    unsigned char item[5];
    unsigned char itemlen;
};

enum
{
    LSMASK = 0x30, /* mask of monitor state */
    LINIT = 0x00,
    LREQ = 0x10,
    LPLC = 0x20,
    LRET = 0x30,
    LDLYTM = 0x40,
    LTMASK = 0x80, /* mask of touch flag */
    LTOUCH = 0x80,
    LOMASK = 0x40, /* mask of operate flag */
    LOPRT = 0x40,
    LLMASK = 0x0F, /* mask of id length */

    OPTNEXIST = 0x80, /* meter not in data base */
    OPTCMD1 = 0x40, /* cmd = 1 */
    OPTDEFAPP = 0x20, /* appdata = default item */
    OPTPCHK = 0x10, /* command of phase check */
    OPTDPSK = 0x08,

    LISTTMASK = 0xC0, /*list node type mask*/
    LISTTUNKNOW = 0x00, /*list node type unkonw*/
    LISTTN43 = 0x40, /*list node type is not 43*/
    LISTT43 = 0x80, /*list node type is  43*/
};
enum
{
    LASTMVMASK = 0x20,
    LASTMVALID = 0x20,
    LASTDMASK = 0x10, //DPSk method read
    LASTDPSK = 0x10, //DPSk method read                   //
};

struct monitinfo
{
    unsigned char num;
    struct
    {
        unsigned char state; /* bit7: in database - 0, not - 1 */
        /* bit6: 1 - (cmd = 1), 0 - (cmd != 1) */
        /* bit5: 1 - cmd = 6 && app = default */
        /* bit4: 1 - is phase check, 0 - not */
        unsigned char reqcnt; /* request count, used in broad operation */
        unsigned char failcnt; /* count of continuous failure */
        unsigned char retcnt; /* count of return data */
        unsigned char dlytm; /*0x00 - dont request dlytm, 0x01 - request*/
        unsigned char id[IDLEN];
        struct mtinfo *mt;
    } opt;

    struct mtlist
    {
        unsigned char state; /* node state*/
        /* bit7: touch flag, 1 - success, 0 - not */
        /* bit6: operate flag, 1 - already operating, 0 - not yet */
        /* bit5~bit4: monitor state :01 - request item, 10 - plc monitor, 11 - return data */
        /* bit3~bit0: id length */
        unsigned char state2; /* bit0 : 0 - not dlytm process, 1 - dlytm process*/
        /* bit2~bit3 : 0 - unkonw, 1 - type not 43,2 -type is 43*/
        /*bit 4,1 last suc is dpsk,last suc is fsk*/
        /*bit 5,1 bit 4 is valid*/
        unsigned char id[IDLEN];
        unsigned char sno[SNOLEN];
    } list[32];
};

enum
{
    STIMASK = 0x80,
    STINIT = 0x00,
    STMNT = 0x80,
    STBMASK = 0x40, /* mask of broad operation */
    STBROAD = 0x40,
    ST38MASK = 0x20,    /*mask of 38 comm flag*/
    ST38COMM = 0x20,
    STDISPMASK = 0x10,  /*mask of display comm flag*/
    STDISPCOMM = 0x10,
    STDLYTMMASK = 0x08,
    STDLYTM = 0x08,
};

struct mntinfo
{
    unsigned char state; /* monitor state */
    /* bit7: 0 - uninit struct, 1 - monitor */
    /* bit6: 1 - broad flag */
    /* bit5: 1 - 38 comm flag*/
    unsigned char id[IDLEN];
};

enum
{
    TTMASK = 0x80, /* mask of task type */
    TTAPD = 0x80,
    TTPLC = 0x00,
    TSMASK = 0x60, /* mask of task state */
    TSNO = 0x00,
    TSRUN = 0x20,
    TSFAIL = 0x40,
    TSSUCC = 0x60,
    TSFLOODRMASK = 0x01,
    TSFLOODRCV = 0x01,
};
enum
{
    MFMASK = 0x80, /*�㳭ʱ����flood�ı�־*/
    MFLOOD = 0x80,
    MFDMASK = 0x0F, /*flood��������*/
};
enum
{
    RMNTCNTMASK = 0x0F,
    RMNTMASK = 0x30,
    RMNT3 = 0x10,
    RMNTFLOOD = 0x20,
};
struct ntask
{
    unsigned char item[5];
    unsigned char itemlen;
};
struct task
{
    unsigned char flag; /* flag information of state */
    /* bit7: task type, 1 - application task, 0 - plc task */
    /* bit6~bit5: state of task, 00 - no task, 11 - task success,
01 - task run, 10 - task failure */
    /* bit4~bit0: reserve */
    unsigned int start; /* task start time */
    unsigned int wait;  /* task wait time */
    unsigned char cnt;  /* task run times */
    unsigned char flood; /*bit 7 flood flag */
    /*bit 4 5 6  reserved*/
    /*bit 0~bit 3 flood depth */
    unsigned char fdepth; /*cur flood depth*/
    unsigned char remnt;  /* �����쳣���⣬���ܵ����ٴΰ�����һ��·���������ط�,bit 4 ����ʽ�ط���bit5,�ֲ�ʽ�ط�*/
    unsigned char dcseq;
    unsigned char dcsucc; /* reserve */
    //unsigned char rsv[5]; /* reserve */
    struct appdata appd;  /* application data */
    struct monitinfo ml;
    struct mntinfo minfo;
    unsigned char info[32]; /* flexible task information */
};

enum
{
    S0TMASK = 0xE0, /* mask of task type */
    S0TINIT = 0x00,
    S0TSHT = 0x40,
    S0TCFM = 0x80,
    S0TTANS = 0x20,
    S0MMASK = 0x10, /* mask of monitor operate */
    S0MONIT = 0x10,
};

struct stage0 /* stage0 necessary run parameter in task */
{
    unsigned char info;    /* bit7~bit6: task type, 000 - uninit struct,
                  001 - trans, 010 - shorten, 100 - confirm */
    /* bit4: monitor operate, 1 - yes, 0 - no */
    /* bit3~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
    struct rpinfo *farp;   /* current repeater pointer */
};

enum
{
    S1TMASK = 0x80, /* mask of task type */
    S1TINIT = 0x00,
    S1TNDS = 0x80,
    S1MMASK = 0x40, /* mask of monitor operate */
    S1MONIT = 0x40,
};

struct stage1 /* stage1 necessary run parameter in task */
{
    unsigned char info;    /* bit7: task type, 1 - organize nds, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    /* bit5~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
    struct rpinfo *farp;   /* current repeater pointer */
};

enum
{
    S2NMASK = 0xC0, /* mask of network mode */
    S2NINIT = 0x00,
    S2NLIST = 0x40,
    S2NBRD = 0x80,
    S2MMASK = 0x20, /* mask of monitor mode */
    S2MONIT = 0x20,
    S2CMASK = 0x0F, /* mask of list count */
    S2COTHER = 0x03, /* other case, two times */
    S2CFIRST = 0x09, /* first run, nine times */
    S2FMASK = 0x10, /* mask of first run */
};

struct stage2 /* stage2 necessary run parameter in task */
{
    unsigned char info;  /* bit7~bit6: network mode, 00 - uninit struct,
                01 - list, 10 - broadcast */
    /* bit5: monitor operate, 0 - not, 1 - yes */
    /* bit4: first run, 0 - not, 1 - yes */
    /* bit3~bit0: list times, 00 - not building */
    struct mtinfo *famt; /* network organizer */
    unsigned char listnum; /* number of list/broadcast network */
    unsigned char actmode; /* action mode of broadcast network */
    unsigned char rsv[4];  /* reserve */
    unsigned char touchnum; /* capture number */
};

enum
{
    S3TMASK = 0x80, /* mask of task type */
    S3TINIT = 0x00,
    S3TLIST = 0x80,
    S3MMASK = 0x40, /* mask of monitor operate */
    S3MONIT = 0x40,
    S3SMASK = 0x20, /* mask of same father */
    S3SFAMT = 0x20,
};

struct stage3 /* stage3 necessary run parameter in task */
{
    unsigned char info;  /* bit7: task type, 1 - list, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    struct mtinfo *famt; /* network organizer */
    struct mtinfo *listmt; /* list network meter */
    unsigned char rsv[5];  /* reserve */
};

enum
{
    S4TMASK = 0x80, /* mask of task type */
    S4TINIT = 0x00,
    S4TLIST = 0x80,
    S4MMASK = 0x40, /* mask of monitor operate */
    S4MONIT = 0x40,
};

struct stage4 /* stage4 necessary run parameter in task */
{
    unsigned char info;  /* bit7: task type, 1 - list, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    struct mtinfo *famt; /* network organizer */
    struct mtinfo *listmt; /* list network meter */
    unsigned char rsv[5];  /* reserve */
};

enum
{
    S6TMASK = 0x80, /* mask of task type */
    S6TINIT = 0x00,
    S6TNDS = 0x80,
    S6MMASK = 0x40, /* mask of monitor operate */
    S6MONIT = 0x40,
};

struct stage6 /* stage6 necessary run parameter in task */
{
    unsigned char info;    /* bit7: task type, 1 - organize nds, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    /* bit5~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
};

enum
{
    S7TMASK = 0x80, /* mask of task type */
    S7TINIT = 0x00,
    S7TNDS = 0x80,
    S7MMASK = 0x40, /* mask of monitor operate */
    S7MONIT = 0x40,
};

struct stage7 /* stage7 necessary run parameter in task */
{
    unsigned char info;    /* bit7: task type, 1 - organize nds, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    /* bit5~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
};

enum
{
    S8TMASK = 0x80, /* mask of task type */
    S8TINIT = 0x00,
    S8TNDS = 0x80,
    S8MMASK = 0x40, /* mask of monitor operate */
    S8MONIT = 0x40,
};

struct stage8 /* stage8 necessary run parameter in task */
{
    unsigned char info;    /* bit7: task type, 1 - organize nds, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    /* bit5~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
};

enum
{
    S9TMASK = 0xE0, /* mask of task type */
    S9TINIT = 0x00,
    S9TNDS = 0x20,
    S9MMASK = 0x10, /* mask of monitor operate */
    S9MONIT = 0x10,
};

struct stage9 /* stage8 necessary run parameter in task */
{
    unsigned char info;    /* bit7: task type, 1 - organize nds, 0 - uninit struct */
    /* bit6: monitor operate, 1 - yes, 0 - no */
    /* bit5~bit0: reserve */
    struct mtinfo *destmt; /* destination meter pointer */
};
struct appdata_bk
{
    unsigned char itelLen;
    unsigned char itemBk[255];
};
extern struct gb_message gbmessage;
extern struct rtpara _rtparas;  /* global parameter */
extern struct share _share;     /* global parameter */
extern struct ndscont _ndscont; /* global parameter */
extern struct task _task;       /* global parameter */
extern struct ntask _ntask;       
extern unsigned char _nl_type;
extern unsigned char _last_sndtype; /*0 is fsk ,1 is dpsk*/
#endif
