/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: plcnl.h
 *
 * Description: net layer interface
 *
 * Version: v1.0
 * Time:    2009-12-19
 *
 */

#ifndef PLCNL_H
#define PLCNL_H

#pragma pack(1)

#define BITTASK2 0x80
#define BITORDER 0X40
#define BITMNT1 0x20
#define BITTKN1 0x10
#define TNO5 0xA0
#define TNO5_NEW 0xB0
#define TNO6 0xC0
#define TNO0 0x00
#define _TNO6 0xE0
#define TNO7 0xE0
#define CTL_43_CMD      0x31

enum
  {
    NLT_NORMAL = 0x00,
    NLT_ERROR  = 0x01,
    NLT_WARN   = 0x02,
    NLT_ZERO   = 0x10,
    NLT_PARL   = 0x11,
    NLT_QPARL  = 0x12,
    NLT_HANDSHAKE = 0x2F,
    NLT_CONFIRM = 0x7F,
    NLT_SKID   = 0xFC,
    NLT_RAND   = 0xFD,
    NLT_NMONIT = 0xFE,
    NLT_MONIT  = 0xFF,
    NLT_IVDOWN = 0xA0,
    NLT_IVUP = 0xA1,
    NLT_LINFO = 0x35,
  };

struct para_report
{
  unsigned char type;
  unsigned char id[6];
  unsigned char tplen;
  unsigned char tp[255]; /*c L data*/
};

struct broad_para
{
  struct ndscont *nds; /* path of dest node */
  unsigned char flag; /* BITTASK | BITORDER | BITMNT1 | BITTKN1 */
  unsigned char vnum; /* visit number */
  unsigned char type; /* action */
  unsigned char range[4]; /* order range */
};

struct rtinfo
{
  unsigned char phase;
  unsigned char dev43;
  unsigned char strong;
  unsigned char setsno;
};

struct nl_frm_info
{
	unsigned char start_flag;
	unsigned short len;
	unsigned char ctrl;
  unsigned char info[2];
	unsigned char data[1];
};

enum
  {
    PMNTMASK = 0x01, /* mask of mnt parameter */
    PARAMNT  = 0x01,
    PTKNMASK = 0x02, /* mask of tkn parameter */
    PARATKN  = 0x02,
    PNSMASK  = 0x04, /* mask of not set sno parameter */
    PARANS   = 0x04,
    PASWMASK = 0x08, /* mask of asw parameter */
    PARAASW  = 0x08,
  };

enum
  {
    TASK2_JUDGE = 0x00,
    TASK2_REAL  = 0x01,
  };

enum
{
    NT_UNKNOWN = 0,  /* node type is unknow*/
    NT_METER,        /* node type is meter*/
    NT_CJQ,          /* node type is collector*/
    NT_485,          /* node type is 485 meter*/
    NT_PLC_RELAY,    /* node type is plc relay*/
    NT_WRL_RELAY,    /* node type is wirless relay*/
    NT_DIS_TERM,     /* node type is display term*/
    NT_JZQ,          /* node type is JZQ*/
};

enum
{
  PLC_DC,  /* �㳭 */
  PLC_UPDATE = 0x01,  /* �ڵ����� */
};

typedef	struct
{
 unsigned char noc:2;
 unsigned char cmf:1;
 unsigned char cmd0:1;
 unsigned char apv:2;
 unsigned char tpv:2;
 unsigned char flag:4;
 unsigned char cmd1:4;
 unsigned char data[1];
}STRU_TPL_CMD1;

struct info_frame_iv_up {
    unsigned char res1:4;     //����
    unsigned char ver:4;      //�汾��

    unsigned char rssiv;      //
    unsigned char l_delay;    //���ƫ����ֽ�
    unsigned char h_delay;    //���ƫ����ֽ�
//��·������ֲ���
    unsigned char code:2;    //
    unsigned char phase:2;
    unsigned char power:2;
    unsigned char res5:2;

    unsigned char intlv:1;
    unsigned char compress:1;
    unsigned char res7:1;
    unsigned char frt:2;
    unsigned char speed:3;

    unsigned char link_old:1;
    unsigned char fsk:1;
    unsigned char zero_point:1;
    unsigned char modu_dpsk:1;
    unsigned char link_new:1;
    unsigned char false_send:1;
    unsigned char dtime_43:1;
    unsigned char zcp_43:1;

    unsigned char signal:4;
    unsigned char d_phase:2;
    unsigned char res10:2;
};

struct info_frame_iv_down {
    unsigned char res1:2;     //����
    unsigned char send_on:1;  //��������
    unsigned char send_dir:1; //��������״̬
    unsigned char ver:4;      //�汾��

    unsigned char res2;
    unsigned char res3;
    unsigned char res4;
//��·������ֲ���
    unsigned char code:2;
    unsigned char phase:2;
    unsigned char power:2;
    unsigned char res5:2;

    unsigned char intlv:1;
    unsigned char compress:1;
    unsigned char res7:1;
    unsigned char frt:2;
    unsigned char speed:3;

    unsigned char link_old:1;
    unsigned char fsk:1;
    unsigned char zero_point:1;
    unsigned char modu_dpsk:1;
    unsigned char link_new:1;
    unsigned char false_send:1;
    unsigned char dtime_43:1;
    unsigned char zcp_43:1;

    unsigned char signal:4;
    unsigned char d_phase:2;
    unsigned char res10:2;
};

typedef	struct
{
  unsigned char noc:2;
  unsigned char cmf:1;
  unsigned char cmd0:1;
  unsigned char apv:2;
  unsigned char tpv:2;
  unsigned char data[1];
}STRU_TPL_CMD0;

enum ParallelTaskType {ShouJiJieDian = 1, LiXingChaoBiao, GuangBoChaoBiao,
                       StartBroadCast, ZhuDongZhuCe, BingXingXueXi, TaiQuPanDuan, Routine_IV};

int plc_comm_645(int fdsno, unsigned char *send, size_t slen, unsigned char *recv, size_t *rlen);

/*
 * Function:   Write data to com
 * Parameters: fd       - file descriptor of com
 *             buf      - Pointer to data to be writen
 *             wbytes   - bytes to be writen
 *             t_wait   - Max waiting time(ms)
 * Return:     bytes of actually write if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_rtwrite(int fd, unsigned char *buf, size_t wbytes, size_t t_wait);

/*
 * Function:   Get random from PLCi38
 * Parameters: rate     -
 *             *random  - Return the random
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_getrandom(unsigned char rate, unsigned char *random);

int nl_getlinfo(unsigned char *para, unsigned char len, unsigned char *recv, unsigned char *rlen);

/*
 * Function:   Get retrun length of 645 data item
 * Parameters: itmestr[] -  dataitem
 *             len       -  length of dataitem
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
unsigned char nl_itemlen(unsigned char *itemstr, unsigned char len);

/*
 * Function:   judge appdata is phase check cmd or not
 * Parameters: *app      - pointer to appdata
 * Return:     Zero if is phase check cmd, or -1 if not
 * Remark:
 *
 */
int nl_phasecmd(struct appdata *app);

/*
 * Function:   Organize  get node's parent(cmd = 1) frame
 * Parameters:  *nds     - path of node
 *              flag     - if BITMNT1 or BITTKN1 set 1, in frame MNT = 1 or TKN = 1
 *              msg      - return frame
 *              len      - length of frame
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_parent(struct ndscont *nds, unsigned char flag, unsigned char *msg, size_t len);

/*
 * Function:    Process  frame of parent info
 * Parameters: *msg      -  the organized frame
 *             len       -  length of frame
 *             strglvl  - Strong level and phase information
 * Return:     Zero if success or -1 if an error occurs
 * Remark:
 *
 */
int nl_parentprocess(unsigned char *msg, size_t len, struct rtinfo *strglvl);

/*
 * Function:   Organize broad task2 frame
 * Parameters: para      - parameter of broad task2
 *             msg       - return organized frame
 *             len       - length of frame
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_broadtask2(struct broad_para *para, unsigned char *msg,size_t len);

/*
 * Function:    Process broad task frame
 * Parameters: *msg      - frame
 *             len       - length of frame
 *             *touch_num- return touch number
 *             list[]    - return meter list
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_broadprocess(unsigned char *msg, size_t len, unsigned char *touch_num, struct mtlist *list);

/*
 * Function:    Process paralle task frame
 * Parameters: *frame    - frame
 *             len       - length of frame
 *             report    - return info
 * Return:     Zero if success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_paraprocess(unsigned char *frame, int len, struct para_report *report);

/*
 * Function:   Organize the frame which is sended to PLCi38
 * Parameters: type     - Transport type
 *             data     - Transport data
 *             datalen  - Length of transport data
 *             frame    - Return the frame to be sended to PLCi38
 *             framelen - Return the length of the frame
 * Return:     Zero if organize success, or -1 if an error occurs
 * Remark:
 */
int nl_frm38(unsigned char type, unsigned char *data, int datalen, unsigned char *frame, int *framelen, unsigned char upd_flag);

/*
 * Function:   Decode frame which is from PLCi38
 * Parameters: frame    - The frame from PLCi38
 *             framelen - Length of the frame
 * Return:     Zero if decrypt success, or -1 if an error occurs
 * Remark:
 */
int nl_frm38_decode(unsigned char *frame, int *len);

/*
 * Function:   Encrypt frame which is send to PLCi38
 * Parameters: frame    - The frame from PLCi38
 *             framelen - Length of the frame
 * Return:     Zero if decrypt success, or -1 if an error occurs
 * Remark:
 */
int nl_frm38_encrypt(unsigned char *frame, int framelen);

/*
 * Function:   Decrypt frame which is from PLCi38
 * Parameters: frame    - The frame from PLCi38
 *             framelen - Length of the frame
 * Return:     Zero if decrypt success, or -1 if an error occurs
 * Remark:
 */
int nl_frm38_decrypt(unsigned char *frame, int framelen);

/*
 * Function:   Convert 38frame to net layer frame
 * Parameters: frame    - The frame from PLCi38 which has been decrypted
 *             framelen - Length of the frame
 * Return:     Zero if convert success, or -1 if an error occurs
 * Remark:
 */
int nl_frm38_2nl(unsigned char *frame, int framelen);

/*
 * Function:   Organize the frame which is to read one meter
 * Parameters: appd     - Application data
 *             mnttkn   - bit0: Actively option, bit1: Extended actively option, bit2: read without setting sno
 *             sno      - sequence number
 *             frame    - Return the frame organized
 *             framelen - Return the length of the frame
 * Return:     Zero if organize success, or -1 if an error occurs
 * Remark:
 */
int nl_monittask1(struct appdata *appd, unsigned char mnttkn, unsigned char *sno, unsigned char *frame, int *framelen);

/*
 * Function:   Process frame which is the response of the monit
 * Parameters: frame    - The frame of the response
 *             framelen - Length of the frame
 *             strglvl  - Strong level and phase information
 *             appd     - Return the application data
 * Return:     Zero if process success, or -1 if an error occurs
 * Remark:
 */
int nl_monitprocess(unsigned char *frame, int framelen, struct appdata *appd, struct rtinfo *strglvl);


int nl_floodprocess(unsigned char *frame, int framelen, struct appdata *appd, unsigned char *depth);
int nl_IVfloodprocess(unsigned char *frame, int framelen, struct appdata *appd, unsigned char *depth);

/*
 * Function:   Organize network in form of list
 * Parameters: round    - round of task2 sender
 *             visitlist- Node list to be organized
 *             listnum  - Return the number of the visitlist
 *             frame    - Return the frame of the task
 *             framelen - Return the length of the frame
 *             type     - organize type: judge or realy organize
 * Return:     Zero if organize success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_listtask2(size_t round, struct mtlist *mlist, unsigned char *listnum, unsigned char *frame,
                 int *framelen, unsigned char type);

/*
 * Function:   Process the frame which is the response of the list network
 * Parameters: listnum  - Number of the visitlist
 *             frame    - The frame of the response
 *             framelen - Length of the frame
 *             mlist    - Node list to be organized
 * Return:     Zero if process success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_listprocess(unsigned char listnum, unsigned char *frame, int framelen, struct mtlist *mlist);

/*
 * Function:   Organize register frame
 * Parameters: sno      - sno of register task
 *             time     - life
 *             tp       - transport layter
 *             tplen    - length of transport layter
 *             msg -    - Return the frame of the task
 *             len      - Return length of the frame
 * Return:     Zero if organize success, or -1 if an error occurs
 * Remark:
 *
 */
int nl_regtask(unsigned char sno, unsigned char time, unsigned char *tp, int tplen, unsigned char *msg,
               int *len);

/*
 * Function:   Organize debug frame
 * Parameters: ccw     - mode
 *             data    - debug data
 *             datalen - Length of data
 *             frame   - The frame of netlink
 *             len     - Length of the frame
 * Return:     Zero if organize success, or -1 if an error occurs
 * Remark:
 */
int nl_dbgtask(unsigned char ccw, unsigned char *data, int datalen, unsigned char *frame, int *len);


int nl_floodtask(unsigned char buf[], unsigned char id[], int depth, struct appdata *appd);

int nl_IVfloodtask(unsigned char buf[], unsigned char id[], int depth, struct appdata *appd);

int rf_start_broadcast(unsigned char data[], int data_len, unsigned char type, int time);

/*
 * Function:   Decode frame which is from PLCi38
 * Parameters: frame    - The frame from PLCi38
 *             len - Length of the frame
 * Return:     Zero if decrypt success, or -1 if an error occurs
 * Remark:
 */
int plc_decode(unsigned char *frame, int len, unsigned char phase);

int nl_paratask(unsigned char buf[], unsigned int time, unsigned char data[], int data_len, unsigned char type);

int nl_paratask_read(unsigned char buf[], unsigned int time, unsigned char data[], int data_len, unsigned char type);

int dispnl_monittask1(struct appdata *appd, unsigned char cmd, unsigned char mnttkn,
                      unsigned char *sno, unsigned char *frame, int *framelen);

int dispnl_monitprocess(unsigned char *frame, int framelen, struct appdata *appd, struct rtinfo *strglvl);

int s9nl_monittask1(struct appdata *appd, unsigned char mnttkn, unsigned char *sno, unsigned char *frame, int *framelen);

/* V���鱨�ĺ��� */
int nl_fill_frm(unsigned char ctrl, unsigned char *info, unsigned char *buf, int len);
int nl_floodtask_update(unsigned char buf[], unsigned char *aid, unsigned char *frm, int depth, unsigned char update_len);

#endif

