/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage7.c
 *
 * Description: Route study stage2
 *
 * Version: v1.0
 * Time:    2010-10-16
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

static int s8_over();
static int s8ctrl; /* flood process control */
#if 0
void stage8()
{
  struct stage8 *s8p = (struct stage8 *) _task.info;
  
  if((_share.flswitch & 0x01) == 0x00)  /*���鿪�عر�*/
  {
    nextstage();
    return;
  }
  if (s8ctrl != 0 && s8ctrl % 5 != 0)
  {
    ++s8ctrl;
    nextstage();
    return;
  }

  if ((s8p->info & S8TMASK) == S8TINIT)/* Initalize */
    {
      if (s8_over() == 0)
        {
          nextstage();
          return;
        }
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s8p->info &= ~S8TMASK;
      s8p->info |= S8TNDS;
    }
  
  if ((s8p->info & S8MMASK) == S8MONIT) /* monit */
    {
      if (floodtask() == 0)
	return;
      s8p->info &= ~S8MMASK;
      _task.flag = TSNO;	    
    }
  
  while ((s8p->destmt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if ((s8p->destmt->node.sno[0] & NNEWMASK) == 0)
      continue; /* VIII success */
//    if (s8p->destmt->node.succhops & NFSUC)
//      continue; /* already success */
    if ((s8p->destmt->node.envi & NPRTMASK) == NPIRATE)
      continue; /* pirate chip */
     
    _task.flag &= ~TSMASK;
    s8p->info |= S8MONIT;
    memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    _task.ml.list[0].state = (IDLEN | LTOUCH);
    memcpy(_task.ml.list[0].id, s8p->destmt->node.id, IDLEN); 
    _task.ml.list[0].sno[0] = s8p->destmt->node.envi & NFHMASK;
    if (_task.ml.list[0].sno[0] > MAXFHOP)
      _task.ml.list[0].sno[0] = MAXFHOP;
    _task.ml.list[0].sno[1] = MAXFHOP;
   
    return;
  }
  
  ++s8ctrl;
  nextstage();
}
#endif
static int s8_over()
{
  extern unsigned char plc_new;
  struct mtinfo *mt;
  unsigned int sucnum, rate;
  
  db_trav_reset(CHAN_TMP);
  
  if (plc_new == 0 || _rtparas.runmd == MDRTIII)
    return 0;
  
  sucnum = 0;
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    /*succ and IV meter*/
    if ((mt->node.succhops & NSUCC) && (mt->node.attr & NMMASK) != NMTIV)
      return 0;
    if ((mt->node.attr & NMMASK) == NMTIV)
      ++sucnum;
  }
  
  /*IV mt rate > 70%*/
  rate = 100 * sucnum / _rtparas.mtnum;
  if(rate < 70)
    return 0;
  return -1;
}
