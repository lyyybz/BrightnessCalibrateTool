/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage7.c
 *
 * Description: Route study stage2
 *
 * Version: v1.0
 * Time:    2010-10-16
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

//#define MAXFHOP 0x04

static int s7_over();
#if 0
void stage7()
{
  struct stage7 *s7p = (struct stage7 *) _task.info;
  
  if ((s7p->info & S7TMASK) == S7TINIT)/* Initalize */
    {            
      if (s7_over() == 0)
        {
          nextstage();
          return;
        }  
      _rtparas.flood = 1;
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s7p->info &= ~S7TMASK;
      s7p->info |= S7TNDS;
    }
  
  if ((s7p->info & S7MMASK) == S7MONIT) /* monit */
    {
      if (floodtask() == 0)
	return;
      s7p->info &= ~S7MMASK;
      _task.flag = TSNO;	    
    }
  
  while ((s7p->destmt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if ((s7p->destmt->node.sno[0] & NNEWMASK) == 0)
      continue; /* VIII success */
    if (s7p->destmt->node.succhops & NFSUC)
      continue; /* already success */
    if ((s7p->destmt->node.envi & NPRTMASK) == NPIRATE)
      continue; /* pirate chip */
     
    _task.flag &= ~TSMASK;
    s7p->info |= S7MONIT;
    memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    _task.ml.list[0].state = (IDLEN | LTOUCH);
    memcpy(_task.ml.list[0].id, s7p->destmt->node.id, IDLEN); 
    _task.ml.list[0].sno[0] = s7p->destmt->node.envi & NFHMASK;
    if (_task.ml.list[0].sno[0] > MAXFHOP)
      _task.ml.list[0].sno[0] = MAXFHOP;
    _task.ml.list[0].sno[1] = MAXFHOP;
   
    return;
  }
  
  nextstage();
}
#endif
static int s7_over()
{
  struct mtinfo *mt;
  unsigned char suc = 0;
    
  db_trav_reset(CHAN_TMP);
  
  if (_rtparas.runmd == MDRTIII)
    return 0;
  
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    if ((mt->node.sno[0] & NNEWMASK) == 0)
      return 0;
    if (mt->node.succhops & NFSUC) 
      suc = 1;
  }
  
  if (suc == 0) /* not meter of successful flooding */
    return 0;
  
  return -1;
}
