/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage0.c
 *
 * Description: Route confirm stage0
 *
 * Version: v1.0
 * Time:    2010-1-12
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/rt/rt.h"

static void s0_init(struct stage0 *s0p);
static void s0_shorten(struct stage0 *s0p);
static void s0_confirm(struct stage0 *s0p);
static void s0_trans(struct stage0 *s0p);

void stage0()
{
  struct stage0 *s0p = (struct stage0 *) _task.info;

  if ((s0p->info & S0TMASK) == S0TINIT) /* Initalize */
    {
      //printf_s("stage 0: S0TINIT!\n");
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s0_init(s0p);
    }

  if ((s0p->info & S0MMASK) == S0MONIT) /* monit */
    {
      if (monittask() == 0)
  return;
      s0p->info &= ~S0MMASK;
      _task.flag = TSNO;
    }

  if ((s0p->info & S0TMASK) == S0TSHT)
    s0_shorten(s0p);

  if ((s0p->info & S0TMASK) == S0TCFM)
    s0_confirm(s0p);

  if ((s0p->info & S0TMASK) == S0TTANS)
    s0_trans(s0p);
}

static void s0_init(struct stage0 *s0p)
{
  int state = rt_newdb();
#if 0
  if ( _rtparas.dbfirst == 0)
  {
      _rtparas.dpsk  = 0x00;
      _rtparas.dpsk |= DPSKFORCE;
      _rtparas.dbfirst = 1; //only when first or para init is reset to 0
  }else
  {
      chk_to_set_dpsk_mode(_rtparas.dev43num, _rtparas.mtnum);
  }
#endif

  if (state == 1 && _rtparas.runmd != MDRTIII)
    {
      s0p->info = S0TTANS;
      return;
    }

  if ((_rtparas.slevel < 9 && _rtparas.maxround > 10) || (_rtparas.slevel > 8 && _rtparas.maxround > 13))
    s0p->info = S0TSHT;
  else
    s0p->info = S0TCFM;
}

static void s0next(struct stage0 *s0p)
{
  db_trav_reset(CHAN_RT1);
  memset(&_task, 0x00, sizeof(_task)); /* clear task */
  if (_rtparas.round > _rtparas.maxround || _rtparas.round > MAXHOPS)
    {
      s0p->info &= ~S0TMASK;
      s0p->info |= S0TCFM;
      _rtparas.round = 0x01;
    }
  else
    ++_rtparas.round;
}

extern unsigned char local_viv_swi;
static void s0_shorten(struct stage0 *s0p)
{
  //printf_s("stage 0: shorten!\n");
  for (; ;)
    {
      if (s0p->destmt == NULL) /* next mt */
  {
    if ((s0p->destmt = db_trav_mtnext(CHAN_RT1)) == NULL)
      break;
  }
  //ע��==��!=���ȼ�����&&��||
      if ((s0p->destmt->node.succhops & NSMASK) == NSUCC
          || (local_viv_swi != 1 && (s0p->destmt->node.viv & NNDMASK) == NND53)
          || (((s0p->destmt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)) /* success meter */
  {
    s0p->destmt = NULL;
    continue;
  }

  saveposition(s0p->destmt);

      /* plough nds */
      struct rpinfo *rp;
      while (rp = db_trav_rpnext(CHAN_RT1, CHAN_TDEF))
  {
    memset(&_ndscont, 0x00, sizeof(_ndscont));
    if (ploughpath(rp) == 0)
      {
        if (_ndscont.num == _rtparas.round) /* nds match with depth */
    {
      s0p->farp = rp;
      ndsrevers(&_ndscont);

      memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
      if (s0p->destmt->node.sno[0] & NNEWMASK)
        {
          _task.ml.list[0].state = (IDLEN | LTOUCH); /* save to task.list */
          memcpy(_task.ml.list[0].id, s0p->destmt->node.id, IDLEN);
        }
      else
        {
          _task.ml.list[0].state = (SNOLEN | LTOUCH);
          memcpy(_task.ml.list[0].id, s0p->destmt->node.sno, SNOLEN);
        }

      _task.flag &= ~TSMASK;
      s0p->info |= S0MONIT;
#ifdef _DEBUG
      //printf("stage0 short M\n"); /* for test !! */
#endif
      return;
    }
      }
    /* continue, look for another path */
  }

      s0p->destmt = NULL; /* no more rp, next meter */
    }

  s0next(s0p);
}

static int cfmnext(struct stage0 *s0p)
{
  struct mtinfo *mt;

  while (_rtparas.stage == 0)
    {
      while ((mt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if (((mt->node.succhops & NSMASK) != NSUCC ||
              (mt->node.envi & NCMD1MASK) != NCMD1SUC)
        && (mt->node.succhops & NHMASK) == _rtparas.round
        && (mt->node.viv & NNDMASK) != NND53
        && ((mt->node.viv & TYPEMASK) >> 3) != TYPEGDNODE)
      {
        s0p->destmt = mt;
        saveposition(mt);
        return 0;
      }
  }
      rtnext();
    }
  return -1;
}

static void s0_confirm(struct stage0 *s0p)
{
  struct rpinfo *rp;
  //printf_s("stage 0: confirm!\n");
  if ((_task.flag & TSMASK) == TSRUN)
    return;
  while (1)
    {
      if (s0p->destmt == NULL && cfmnext(s0p) != 0)
  return;
      memset(&_ndscont, 0x00, sizeof(_ndscont));
      if ((rp = db_getfrp(s0p->destmt)) && (ploughpath(rp) == 0x00))
  {
    ndsrevers(&_ndscont); /* need this step */
    _task.flag &= ~(TSMASK | TTMASK);
    s0p->info |= S0MONIT;
    memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    if (s0p->destmt->node.sno[0] & NNEWMASK)
      {
        _task.ml.list[0].state = IDLEN + LTOUCH;
        memcpy(_task.ml.list[0].id, s0p->destmt->node.id, IDLEN);
      }
    else
      {
        _task.ml.list[0].state = SNOLEN + LTOUCH;
        memcpy(_task.ml.list[0].id, s0p->destmt->node.sno, SNOLEN);
      }
          s0p->destmt = NULL;
#ifdef _DEBUG
    //printf("stage0 M\n"); /* for test !! */
#endif
    return;
  }
      s0p->destmt = NULL;
    }
}

static void s0_trans(struct stage0 *s0p)
{
  //printf_s("stage 0: trans!\n");
   while ((s0p->destmt =  db_trav_mtnext(CHAN_RT1)) != NULL)
  {
     if ((s0p->destmt->node.sno[0] & NNEWMASK) == 0
         || (local_viv_swi != 1 && (s0p->destmt->node.viv & NNDMASK) == NND53)
         ||(((s0p->destmt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)) 
      continue;

    _task.flag &= ~TSMASK;
    s0p->info |= S0MONIT;
    memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    _task.ml.list[0].state = (IDLEN | LTOUCH);
    memcpy(_task.ml.list[0].id, s0p->destmt->node.id, IDLEN);

    memset(&_ndscont, 0x00, sizeof(_ndscont));
    memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
    _ndscont.nds[_ndscont.num++].len = SNOLEN;

    return;
  }

  nextstage();
}
