/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage2.c
 *
 * Description: Route study stage2
 *
 * Version: v1.0
 * Time:    2010-1-12
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

#define TNOMASK 0xE0
#define CMDMASK 0xE0

extern int fd;

static void s2_listinit(struct stage2 *s2p);
static void s2_list(struct stage2 *s2p);
static void s2_broad(struct stage2 *s2p);
static void s2_brdinit(struct stage2 *s2p);
static int broadover(unsigned char first);

void stage2()
{
  struct stage2 *s2p = (struct stage2 *) _task.info;

  if ((s2p->info & S2NMASK) == S2NINIT)/* Initalize */
    {
      //printf_s("stage 2: S2NINIT!\n");
      db_trav_reset(CHAN_RT1);
      if (_rtparas.round == 1)
        s2_listinit(s2p);
      else
        s2_brdinit(s2p);
    }

  if (_rtparas.stage != S2)
    return;

  if (_rtparas.round == 0x01)
    {
      s2p->info &= ~S2NMASK;
      s2p->info |= S2NLIST;
      s2_list(s2p);
    }
  else
    {
      //printf_s("stage 2: S2NBRD!%02x\n", (s2p->info & S2NMASK));
      if ((s2p->info & S2NMASK) == S2NBRD)
        s2_broad(s2p);
    }
}


/***********************************broad task***********************************************/
static void s2_brdinit(struct stage2 *s2p)
{
  unsigned char first = s2p->info & S2FMASK;
  struct mtinfo *mt;

  memset(&_task, 0x00, sizeof(struct task));
  while ((mt = db_trav_mtnext(CHAN_RT1)) != NULL)
    {
      if ((mt->node.succhops & NHMASK) == 1 && (mt->node.succhops & NSMASK) == NSUCC)
    {
      s2p->famt = mt;
      break;
    }
    }

  if (s2p->famt == NULL && _rtparas.runmd == MDRTIII)
    {
      rt_report(REPODIR, 18); /* send error to dm */
      return;
    }

  if (broadover(first) == 0 )
    nextstage();
  else
    s2p->info = S2NBRD | first;
}

static int broadover(unsigned char first)
{
  //assert(_rtparas.mtnum > 0);
  if(_rtparas.mtnum == 0)
  {
    return -1;
  }
  int rate = 100 * (_rtparas.mtnum - _rtparas.succnum) / _rtparas.mtnum;

//  if (_rtparas.brdclose == 1 && _rtparas.runmd != MDRTIII)
  if (_rtparas.brdclose == 1)
    return 0;

  if ((_rtparas.mtnum - _rtparas.succnum) < 12)
    return 0;

  if (first)
    {
      if (rate < 16)
    return 0;
    }
  else
    {
      if (rate < 25)
    return 0;
    }
  return -1;
}

static int broadnext(struct stage2 *s2p)
{
  unsigned char first = s2p->info & S2FMASK;

  memset(s2p, 0x00, sizeof(struct stage2));
  _task.flag = TSNO;

  if (broadover(first) == 0)
    {
      nextstage();
      return 0;
    }

  while (_rtparas.stage == S2)
    {
      while ((s2p->famt = db_trav_mtnext(CHAN_RT1)) != NULL)
    {
      if (((s2p->famt->node.succhops & NHMASK) == _rtparas.round - 1) &&
          ((s2p->famt->node.succhops & NSMASK) == NSUCC))
        {
          saveposition(s2p->famt);
          s2p->info |= S2NBRD + first; /* broad */
          return 0;
        }
    }
      rtnext();
      watchdog();
    }
  return 0;
}

static int nextaction(struct stage2 *s2p)
{
  _task.flag = TSNO;
  if (++s2p->actmode > 0x02)
    return -1;
  return 0;
}

static unsigned char broadvnum()
{
  unsigned short failnum = _rtparas.mtnum - _rtparas.succnum;

  assert (failnum > 0);
  if ( failnum == 1)
    return 2;
  else if (failnum <= 4)
    return 4;
  else if (failnum <= 8)
    return 8;
  else if ((_rtparas.slevel > 4) && (failnum > 255))
    return 16;

  return 8;
}

static void broadtype(struct broad_para *para, struct stage2 *s2p)
{
  para->flag = BITTKN1 | BITMNT1;
  para->vnum = broadvnum();

  para->type = ((_rtparas.wrkno << 4) & 0xF0) | 0x08; /* work num check */
  if ((_rtparas.state & STASMASK) == STAALLSNO)
    {
      para->flag |= BITORDER;
      para->type |= 0x04;
      memcpy(&para->range[0], &_rtparas.minsno, SNOLEN);
      memcpy(&para->range[2], &_rtparas.maxsno, SNOLEN);
    }

  assert (s2p->actmode < 3);
  switch (s2p->actmode)
    {
    case 0:
      para->type |=  0x01;
      break;
    case 1:
      break;
    case 2:
      para->type |=  0x02;
      break;
    }
  para->nds = &_ndscont;
}

static int s2_broadtask(struct stage2 *s2p)
{
  struct broad_para para;
  unsigned char msg[255], frame[255];
  int len = sizeof(frame);

  if (task2nds(s2p->famt) != 0x00)
    return -1;

  broadtype(&para, s2p);
  if (nl_broadtask2(&para, msg, sizeof(msg)) != 0x00)
    return -1;
  nl_frm38(NLT_NORMAL, msg, msg[0] + 1, frame, &len, PLC_DC);
  nl_rtwrite(fd, frame, len, 0);
  /* set _task.start and _task.endt */

  _task.flag &= ~(TSMASK | TTMASK);
  _task.flag |= TSRUN | TTPLC;
  _task.start = currtick();

  size_t n = para.vnum / 2 & MAXHOPS;
  _task.wait = ((n == 0 ? 1 : n) + _rtparas.round) * (MAXHOPTM / 2);

  return 0;
}

static int s2_broadprocess(struct stage2 *s2p)
{
  if ((_task.flag & TSMASK) == TSSUCC)
    {
      memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
      if (nl_broadprocess(_commbuf.plc.buf, (_commbuf.plc.buf[0] & 0x3F) + 1,
              &_task.ml.num, _task.ml.list) != 0)
    return -1;
      if (_task.ml.num == 0x00)
    return nextaction(s2p);
      else
    {

      touchmt(s2p->famt); /* append repead */
      s2p->info |= S2MONIT; /* monit */
      _task.flag = TSNO;
      return 0;
    }
    }
  return -1;
}

static void s2_broad(struct stage2 *s2p)
{
  if ((_task.flag & TSMASK) == TSRUN)
    return;

  if ((s2p->info  & S2MMASK) == S2MONIT) /* monit */
    {
      if (monittask() == 0)
    return;
      s2p->info &= ~S2MMASK;
      _task.flag &= ~(TSMASK | TTMASK);
    }

  while ((s2p->info & S2NMASK) == S2NBRD && (s2p->info & S2MMASK) == 0 ) /* broad */
    {
      if ((_task.flag & TSMASK) == TSNO)
    {
      if (s2_broadtask(s2p) == 0)
        break;
      broadnext(s2p); /* exception occured */
    }
      else
    {
      if (s2_broadprocess(s2p) != 0) /*if 0: next action or start monit */
        broadnext(s2p);
    }
    }
}

/***********************************list task***********************************************/

static int s2_listprocess(struct stage2 *s2p)
{
  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (nl_listprocess(_task.ml.num, _commbuf.plc.buf, (_commbuf.plc.buf[0] & 0x3F) + 1, _task.ml.list) != 0)
        return -1;
      if (touchnum() == 0)
        return 0;

      struct mtinfo *mtp = NULL;
      if (mtp = db_find(sinkidno))
    touchmt(mtp);

      _ndscont.num--;
      s2p->info &= ~S2MMASK;
      s2p->info |= S2MONIT;
      _task.cnt = 0;

      return 0;
    }

  return -1;
}

static void nds_clear()
{
  memset(&_ndscont, 0x00, sizeof(_ndscont));
}

static void nds_add(unsigned char *mtid, unsigned char idlen)
{
  memcpy(_ndscont.nds[_ndscont.num].id, mtid, idlen);
  _ndscont.nds[_ndscont.num].len = idlen;
  ++_ndscont.num;
}

static void s2_nextlist(struct stage2 *s2p)
{
  unsigned char list_num = s2p->info & S2CMASK; /* --repeat count */
  --list_num;
  s2p->info &= ~S2CMASK;
  s2p->info |= list_num;
  db_trav_reset(CHAN_RT1);
}

extern unsigned char local_viv_swi;
static int s2_addlist(struct stage2 *s2p)
{
  if (s2p->famt == NULL)
    return -1;
  if ((s2p->famt->node.succhops & NHMASK) > 2
      || ((s2p->famt->node.succhops & NSMASK) == NSUCC
          && (s2p->famt->node.envi & NCMD1MASK) == NCMD1SUC)
      || (local_viv_swi != 1 && (s2p->famt->node.viv & NNDMASK) == NND53)
      || (((s2p->famt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE))  /* depth > 2, ignore */
    return -1;

  memcpy(_task.ml.list[_task.ml.num].sno, s2p->famt->node.sno, SNOLEN);
 // _task.ml.list[_task.ml.num].state2 |= (s2p->famt->node.phase & NPDTMASK);
#if 0
  if ((_rtparas.state & STASMASK) == STAALLSNO) /* all sno */
    mlist_add(s2p->famt->node.sno, SNOLEN);
  else
#endif
    mlist_add(s2p->famt->node.id, IDLEN);

  return 0;
}

static void s2_listtask2(struct stage2 *s2p)
{
  unsigned char frame[255], temp[255];
  int framelen = 255, templen = 255;
  unsigned char maxnum = list_maxnode(S2);
  struct monitinfo *mlp = &_task.ml;

  nds_clear(); /* nds */
  nds_add(sinksno, SNOLEN);
  nds_add(broadsno, SNOLEN);

  //printf_s("\n****s2_listtask2****    net_assoication\n");
  
  mlist_clear();
  s2_addlist(s2p); /* add last one *//* famt:the last meter added to list */

  for (; ;)
    {
      s2p->famt = db_trav_mtnext(CHAN_RT1);
      if (s2p->famt == NULL) /* no meter */
    {
          s2_nextlist(s2p);
      break;
    }
      else
    {
          if (s2_addlist(s2p) != 0)
        continue;
      framelen = 255;
      int ret = nl_listtask2(_rtparas.round, mlp->list, &mlp->num, frame, &framelen, TASK2_JUDGE);
      assert(ret == 0);

      if (mlp->num == maxnum && framelen <= 62) /* reach maxnum */
        {
          s2p->famt = NULL;
          break;
        }
      else if (framelen > 62) /* overflow, back to the last state */
        {
          --_task.ml.num;
          break;
        }
          else if (mlp->num >= 32)
          {
          s2p->famt = NULL;
          break;
          }
      /* continue, add next */
    }
    }

  if (mlp->num > 0) /* send */
    {
      framelen = 255;
      int ret = nl_listtask2(_rtparas.round, mlp->list, &mlp->num, frame, &framelen, TASK2_REAL);
      assert(ret == 0);

#if 1
      ret = is_mlist_all43(mlp->list, mlp->num);
      chek_list_set_modu(ret);
#endif
      nl_frm38(NLT_NORMAL, frame, framelen, temp, &templen, PLC_DC);
      if (nl_rtwrite(fd, temp, templen, 0) != 0)
    {
      _task.flag &= ~TSMASK;
      _task.flag |= TSNO;
      return;
    }

      s2p->info &= ~S2MONIT; /* make sure not monit */
      _task.flag &= ~(TSMASK | TTMASK);
      _task.flag |= TSRUN | TTPLC;
      _task.start = currtick();

      size_t n = mlp->num / 2 & MAXHOPS;
      _task.wait = ((n == 0 ? 1 : n) + _rtparas.round) * (MAXHOPTM / 2);
    }
}

static void nextround()
{
  _task.flag = TSNO;  /* clear task */
  db_trav_reset(CHAN_RT1);
  ++_rtparas.round;
}

static void s2_list(struct stage2 *s2p)
{
  if ((s2p->info & S2MMASK) == S2MONIT) /* monit */
    {
      if (monittask() == 0)
    return;

      s2p->info &= ~S2MONIT;
      _task.flag &= ~(TSMASK | TTMASK);
    }

  if ((s2p->info & S2NMASK) == S2NLIST ) /* list */
    {
      if ((_task.flag & TSMASK) == TSRUN)
    return;
      if ((_task.flag & TSMASK) == TSNO)
    {
      if (s2p->info & S2CMASK)  /* build list */
        s2_listtask2(s2p);
      else
        {
          s2p->info &= ~(S2NMASK | S2MMASK);
          nextround();
        }
          return;
    }

      s2_listprocess(s2p); /* task succ, process */
      _task.flag &= ~(TSMASK | TTMASK);
      _task.flag |= TSNO;
    }
}

static void s2_listinit(struct stage2 *s2p)
{
  int state = rt_newdb();

  memset(&_task, 0x00, sizeof(struct task));

  if (_rtparas.maxround == 0 && state == 1)
    s2p->info |= (S2CFIRST | S2FMASK);   /* first run, three times */
  else
    s2p->info |= S2COTHER; /* default, one time */
  s2p->famt = NULL;
}

