/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: broad.c
 *
 * Description: Route confirm stage0
 *
 * Version: v1.0
 * Time:    2010-1-12
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/app/app.h"

static unsigned char round;
/* broad init */
static void broadopt();
static struct mtinfo* broadnext();

void broad_init()
{
  struct mtinfo *mt;
  
  db_trav_reset(CHAN_RT3);
  while ((mt = db_trav_mtnext(CHAN_RT3)) != NULL)
    mt->node.envi &= ~NBROAD;  //��ǰ����û����db_write�ĵ���
    
  round = 0;
  _rtparas.state |= STABROAD;
  _rtparas.state &= ~STABMMASK;
  db_trav_reset(CHAN_RT3);
}

void broad()
{
  if ((_rtparas.state & STABMMASK) == STABMONIT) /* monit */
    {
      if (monittask() == 0)
        return;

      _rtparas.state &= ~STABMMASK;
      _task.flag = TSNO;      
    }  
  if ((_rtparas.state & STABMMASK) == 0)
    broadopt();
}

static struct mtinfo* broadnext()
{
  struct mtinfo *mt, *mtp;
  struct rpinfo *rp;
  
  if (round == 0)
    {
      unsigned char sno[2] = {0x7d, 0x00};
      unsigned char info = INFBRDSTA;
      app_info(&info, sizeof(info));
      if ((mt = db_find_sno(sno)) != NULL)
  return mt;
    }
  
  while (round <= _rtparas.maxround)
    {
      while ((mt = db_trav_mtnext(CHAN_RT3)) != NULL)
  {
    if ((mt->node.succhops & NHMASK) == round)
      {
        if ((rp = db_getfrp(mt)) == NULL || (mtp = db_find(rp->rpid)) == NULL) 
    continue;
        if ((mtp->node.envi & NBMASK) == NBROAD)
    continue;
        mtp->node.envi |= NBROAD;  //��ǰ����û����db_write�ĵ���
        return mt;
      }
  }
      db_trav_reset(CHAN_RT3);
      if (round == _rtparas.maxround - 1)
  round = _rtparas.maxround;
      else
  round += 2;
    }
  
  unsigned char info = INFBRDEND;
  app_info(&info, sizeof(info));/* send massage to dm, broad end */
  _rtparas.state &= ~(STABMASK | STABMMASK);
  _rtparas.wkstate &= ~ DISPBDMASK;
  memset(_task.ml.list, 0x00, sizeof(_task.ml.list));        
  round = 0;
  
  return NULL;
}

static void broadopt()
{
  struct rpinfo *rp;
  struct mtinfo *mt;

  while (1)
    {
      if ((mt = broadnext()) == NULL)
      {
          if ((_rtparas.sndphs & PHSSINGMASK) == PHSSNDING)
          {
              _rtparas.sndphs &= ~PHSSINGMASK;//��λ
          }
          else
          {
              app_gbbroad_over();
          }
          return;
      }

      memset(&_ndscont, 0x00, sizeof(_ndscont));
      if (round == 0)
  round += 2;
      else if ((rp = db_getfrp(mt)) == NULL || ploughpath(rp) != 0x00)
  continue;
      
      ndsrevers(&_ndscont); /* need this step */
      _task.flag &= ~TSMASK;
      _rtparas.state |= STABMONIT;
      assert((mt->node.sno[0] & NNEWMASK) == 0);
      memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
      _task.ml.list[0].state = SNOLEN + LTOUCH;
      memcpy(_task.ml.list[0].id, mt->node.sno, SNOLEN);
      
      return;
    }
}
