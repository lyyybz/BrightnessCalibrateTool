/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage6.c
 *
 * Description: Route study stage2
 *
 * Version: v1.0
 * Time:    2010-10-16
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

static int effictrl; /* flood process control */

//static int s6_over();
#if 0
void stage6()
{
  struct stage6 *s6p = (struct stage6 *) _task.info;
 
  if (effictrl != 0 && effictrl % 5 != 0)
    {
      ++effictrl;
      nextstage();
      return;
    }

  if ((s6p->info & S6TMASK) == S6TINIT)/* Initalize */
    {            
      /*
      if (s6_over() == 0)
        {
          nextstage();
          return;
        }
      */
      _rtparas.flood = 0;
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s6p->info &= ~S6TMASK;
      s6p->info |= S6TNDS;
    }
  
  if ((s6p->info & S6MMASK) == S6MONIT) /* monit */
    {
      if (floodtask() == 0)
	return;
      s6p->info &= ~S6MMASK;
      _task.flag = TSNO;	    
    }
  
  while ((s6p->destmt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if ((s6p->destmt->node.sno[0] & NNEWMASK) == 0)
      continue; /* VIII success */
    if ((s6p->destmt->node.envi & NPRTMASK) == NPIRATE)
      continue; /* pirate chip */
    
    _task.flag &= ~TSMASK;
    s6p->info |= S6MONIT;
    memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    _task.ml.list[0].state = (IDLEN | LTOUCH);
    memcpy(_task.ml.list[0].id, s6p->destmt->node.id, IDLEN); 
    _task.ml.list[0].sno[0] = 0x00;
    _task.ml.list[0].sno[1] = 0x00;
   
    return;
  }
  
  ++effictrl;
  nextstage();
}
#endif
#if 0
static int s6_over()
{
  struct mtinfo *mt;
  
  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    if ((mt->node.sno[0] & NNEWMASK) == 0)
      return -1;
  }
  return 0;
}
#endif