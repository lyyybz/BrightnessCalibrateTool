/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rtfuns.c
 *
 * Description: Route study stage2
 *
 * Version: v1.0
 * Time:    2010-1-25
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/dev/eeprom.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/rt/broad.h"
#include "../include/rt/rterrs.h"
#include "../include/rt/rtfuns.h"
#include "../include/db/hash.h"
#include "router.h"

#pragma pack(1)

#ifdef _LINUXPC
static int fd_dm = 3;
#else
static int fd_dm = CHN_DM;
#endif

#define MAXMTNUM 1000   /* �����������㶫1000 */
#define MAXMTNO 0x6F
#define MAXSLE 16
/* type of requst option */
#define REQPWD   0x01
#define REQWMODE 0x02

/*************�����Ǽ���ⲿeeprom�ģ�������Բ�����ռ�***************/
// #define E2ROM_START 0x0000
// #define E2ROM_SIZE  0x10000

static char pwd[] = "Eastsoft";

extern int fd;
static const char _Version[] = "Router-III 2010-012"; /* old ver - debug, even ver - release */
static const unsigned char m_char[][3] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
static const unsigned char m_num[][2] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"};
static const unsigned char dctime[11] = {5, 5, 10, 10, 15, 15, 20, 20, 30, 30,30};//min
static int rf_incrsno();
static int rf_stage0();
static struct mtinfo * rf_findmt_usno(unsigned char *usno);
static int get_compile_info(unsigned char time[]);
static void rf_stopreg();
static void exwork_timer();
static void stop_parabroad();

static unsigned char stage = 0;
static unsigned char round = 1;
static unsigned char monitbrd = 0;
static unsigned char hardinit = 0;

extern struct appdata_bk _appdata_bk;

int rf_setdmmode(unsigned char mode)
{
  _commbuf.dm.mode = mode;
  return 0;
}

int rf_write38(unsigned char *buf, size_t wbytes, size_t t_wait)
{
  assert(buf);

  return nl_rtwrite(CHN_38_1, buf, wbytes, t_wait);
}

int rf_write(unsigned char *buf, size_t wbytes, size_t t_wait)
{
  assert(buf);

  unsigned char ccw = 0, frame[255], msg[255];
  int len = 0, msglen;

  if (channel38)
  {
    channel38 = 0;
    if (buf[0] != 0x68 || wbytes < 15)
      return -1;
    ccw = buf[3] & 0x3F;
    nl_dbgtask(ccw, buf + 10, wbytes - 12, frame, &len);
    nl_frm38(NLT_PARL, frame, len, msg, &msglen, PLC_DC);
    return  nl_rtwrite(CHN_38_1, msg, msglen, t_wait);
  }

  return nl_rtwrite(fd_dm, buf, wbytes, t_wait);
}

void rf_init_mttrav()
{
  db_trav_reset(CHAN_TMP);
}

int rf_get_ver(unsigned char *data, int *datalen)
{
  assert(data);

  memcpy(data, _Version, sizeof(_Version));
  *datalen =  sizeof(_Version) - 1;

  return 0;
}

static int bcdtostr(unsigned char bcd, unsigned char *str)
{
  str[0] = ((bcd >> 4) & 0x0F) + '0';
  str[1] = (bcd & 0x0F) + '0';
  return 2;
}

int rf_get_prgtm(unsigned char *data, int *datalen)
{
  assert(data);

  unsigned char date[6], prgtime[] = "2010-03-06 11:34";

  get_compile_info(date);
  bcdtostr(date[5], &prgtime[2]);
  bcdtostr(date[4], &prgtime[5]);
  bcdtostr(date[3], &prgtime[8]);
  bcdtostr(date[2], &prgtime[11]);
  bcdtostr(date[1], &prgtime[14]);
  memcpy(data, prgtime, sizeof(prgtime));
  *datalen =  sizeof(prgtime) - 1;

  return 0;
}

int rf_get_amount(unsigned char *data, int *datalen)
{
  data[0] = _rtparas.mtnum >> 8;
  data[1] = _rtparas.mtnum;
  *datalen = sizeof(_rtparas.mtnum);
  return 0;
}

int rf_get_mt(const unsigned char *mtid, unsigned char *phase, unsigned char *depth)
{
    assert(mtid && phase && depth);
    struct mtinfo *mtp = db_find(mtid);

    if (mtp == NULL)
        return seterrno(RTFERR_IDNOT);

    *phase = (mtp->node.phase & NPAMASK) >> 6;
    *depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;

    return 0;
}
#define MAXRDAMT 16
int rf_get_nw_mtinfo(unsigned char *para, unsigned char *buff, unsigned char *len, unsigned char type)
{
    struct mtinfo mt, *rmt;
    struct
    {
        unsigned char id[6];
        unsigned char gd_mid[12]; 
    }gdmtinfo[MAXRDAMT];
 
    struct
    {
      unsigned char id[6];
    }mtinfo[MAXRDAMT]; 

    int usno, amt, i, idamt = 0, idx = 0;
    unsigned short addr, end;

    *len = 0x00;
    usno = para[0] + (para[1] << 8);

    if (usno > _rtparas.mtnum)                               /*��Ŵ�1��ʼ*/
        return 0;
    amt = para[2];
    if (amt > MAXRDAMT)
        amt = MAXRDAMT;
    memset(mtinfo, 0x00, sizeof(mtinfo));

    addr = DBBEGIN;
    end = DBEND;
    while (addr < end)
    {
        db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
        if ((mt.node.attr & CELLMASK) == MTFLAG)
        {
            if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
                && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
            {
                addr += CELL * MTCN; /* idnode occupy 2 database cell */
                continue;
            }

            if (idamt >= usno)
            {
                if ((rmt = db_find(mt.node.id)) == NULL)
                {
                    addr += CELL * MTCN; /* idnode occupy 2 database cell */
                    continue;
                }
                            
                if (type == 1) 
                 {
                   if (((rmt->node.viv & TYPEMASK) >> 3) != TYPEGDNODE)
                     {
                       addr += CELL * MTCN; /* idnode occupy 2 database cell */
                       continue; 
                     }
                  }
                 else if (type == 0) 
                  {
                    
                    if (((rmt->node.viv & TYPEMASK) >> 3) != TYPENODE)
                      {
                        addr += CELL * MTCN; /* idnode occupy 2 database cell */
                        continue;
                      }
                   }

                if (type == 1)
                {
                  memcpy(gdmtinfo[idx].id, rmt->node.id, IDLEN);
                  id_bintobcd(gdmtinfo[idx].id); 
                  memcpy(gdmtinfo[idx].gd_mid, rmt->node.gdid, GDIDLEN - IDLEN);
                  reverse(gdmtinfo[idx++].id, IDLEN);
                }
                else
                {
                  memcpy(mtinfo[idx].id, rmt->node.id, IDLEN);
                  id_bintobcd(mtinfo[idx].id);
                  reverse(mtinfo[idx++].id, IDLEN); 
                }
            }
            ++idamt;

        }
        else if ((mt.node.attr & CELLMASK) == RPFLAG)
            break;
        if (idamt >= _rtparas.mtnum)
            break;
        if (idx >= amt)
            break;
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        watchdog();
    }

    for (i = 0; i < idx; i++)
    {
      if (type == 1)
      {
        memcpy(&buff[*len], &gdmtinfo[i], GDIDLEN);
        *len += GDIDLEN;
      }
      else
      {
        memcpy(&buff[*len], mtinfo[i].id, IDLEN);
        *len += IDLEN; 
      }
    }
    return 0;
}


int get_gdnode_cnt(unsigned char type)
{
    struct mtinfo mt, *rmt; 
    int idamt = 0;
    unsigned short addr, end;
    addr = DBBEGIN;
    end = DBEND;
    int gd_cnt = 0, node_cnt = 0;
    while (addr < end)
    {
        db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
        if ((mt.node.attr & CELLMASK) == MTFLAG)
        {
            if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
                && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
            {
                addr += CELL * MTCN; /* idnode occupy 2 database cell */
                continue;
            }

            if ((rmt = db_find(mt.node.id)) == NULL)
              {
                    addr += CELL * MTCN; /* idnode occupy 2 database cell */
                    continue;
              }
                            
              if (type == 1) 
                {
                   if (((rmt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)
                     {
                       gd_cnt++;
                     }
                 }
              else if (type == 0) 
                {
                    
                    if (((rmt->node.viv & TYPEMASK) >> 3) == TYPENODE)
                      {
                        node_cnt++;
                      }
                 }
            ++idamt;
        }
        else if ((mt.node.attr & CELLMASK) == RPFLAG)
            break;
        if (idamt >= _rtparas.mtnum)
            break;
 
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        watchdog();
    }
  
    if (type == 1)
      return gd_cnt;
    else
      return node_cnt;
}

int rf_get_nw_mt_phs(unsigned char *para, unsigned char *buff, unsigned char *len)
{
    struct mtinfo mt, *rmt;
    struct
    {
        unsigned char id[6];
        unsigned char phs_val:3;
        unsigned char phs_para:2;
        unsigned char pad:3;
        unsigned char pro;
    } mtinfo[MAXRDAMT];
    int usno, amt, i, idamt = 0, idx = 0;
    unsigned short addr, end;

    *len = 0x00;
    usno = para[0] + (para[1] << 8);

    if (usno > _rtparas.mtnum-1)                               /*��Ŵ�0��ʼ*/
        return 0;
    amt = para[2];
    if (amt > MAXRDAMT)
        amt = MAXRDAMT;
    memset(mtinfo, 0x00, sizeof(mtinfo));

    addr = DBBEGIN;
    end = DBEND;
    while (addr < end)
    {
        db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
        if ((mt.node.attr & CELLMASK) == MTFLAG)
        {
            if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
                && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
            {
                addr += CELL * MTCN; /* idnode occupy 2 database cell */
                continue;
            }
            if (idamt >= usno)
            {
                if ((rmt = db_find(mt.node.id)) == NULL)
                {
                    addr += CELL * MTCN; /* idnode occupy 2 database cell */
                    continue;
                }

                if (((rmt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE) 
                {
                  addr += CELL * MTCN; /* idnode occupy 2 database cell */
                  continue; 
                }

                memcpy(mtinfo[idx].id, rmt->node.id, IDLEN);
                id_bintobcd(mtinfo[idx].id);
                reverse(mtinfo[idx].id, IDLEN);

                mtinfo[idx].phs_val = (rmt->node.phase & NPAMASK) >> 6;
                if (mtinfo[idx].phs_val == 1)
                {
                    mtinfo[idx].phs_val = PHS_VAL_A;
                }
                else if (mtinfo[idx].phs_val == 2)
                {
                    mtinfo[idx].phs_val = PHS_VAL_B;
                }
                else if (mtinfo[idx].phs_val == 3)
                {
                    mtinfo[idx].phs_val = PHS_VAL_C;
                }
                else
                {
                    mtinfo[idx].phs_val = PHS_VAL_UN;
                }
                mtinfo[idx].phs_para = PHS_PARA_SUR;
                mtinfo[idx].pro = (rmt->node.attr & NPROMASK) >> 1;
                //mtinfo[idx].pro = (mt.node.attr & NPROMASK) >> 1;
                if (mtinfo[idx].phs_val == PHS_VAL_UN)
                {
                    mtinfo[idx].phs_para = PHS_PARA_UNKOWN;
                 //   mtinfo[idx].pro = PHS_PRO_UN;
                }
                idx++;
            }
            ++idamt;

        }
        else if ((mt.node.attr & CELLMASK) == RPFLAG)
            break;
        if (idamt >= _rtparas.mtnum)
            break;
        if (idx >= amt)
            break;
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        watchdog();
    }

    for (i = 0; i < idx; i++)
    {
        memcpy(&buff[*len], mtinfo[i].id, 8);
        *len += 8;
    }
    return 0;
}

int rf_get_nw_area_indb(unsigned char *para, unsigned char *buff, unsigned char *len)
{
    struct mtinfo mt, *rmt;
    struct
    {
        unsigned char id[6];
        unsigned char area_result;
    } mtinfo[MAXRDAMT];
    int usno, amt, i, idamt = 0, idx = 0;
    unsigned short addr, end;

    *len = 0x00;
    usno = para[0] + (para[1] << 8);

    if (usno > _rtparas.mtnum-1)                               /*��Ŵ�0��ʼ*/
        return 0;
    amt = para[2];
    if (amt > MAXRDAMT)
        amt = MAXRDAMT;
    memset(mtinfo, 0x00, sizeof(mtinfo));

    addr = DBBEGIN;
    end = DBEND;
    while (addr < end)
    {
        db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
        if ((mt.node.attr & CELLMASK) == MTFLAG)
        {
            if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
                && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
            {
                addr += CELL * MTCN; /* idnode occupy 2 database cell */
                continue;
            }
            if (idamt >= usno)
            {
                if ((rmt = db_find(mt.node.id)) == NULL)
                {
                    addr += CELL * MTCN; /* idnode occupy 2 database cell */
                    continue;
                }


                if (((rmt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)
                {
                  addr += CELL * MTCN; /* idnode occupy 2 database cell */
                  continue;
                }

                memcpy(mtinfo[idx].id, rmt->node.id, IDLEN);
                id_bintobcd(mtinfo[idx].id);
                reverse(mtinfo[idx].id, IDLEN);

                if (rmt->dc_succ_rate >= 80) 
                  mtinfo[idx].area_result = 0;
                else if (rmt->dc_succ_rate > 50)
                  mtinfo[idx].area_result = 3;
                else
                  mtinfo[idx].area_result = 1;

                idx++;
            }
            ++idamt;

        }
        else if ((mt.node.attr & CELLMASK) == RPFLAG)
            break;
        if (idamt >= _rtparas.mtnum)
            break;
        if (idx >= amt)
            break;
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        watchdog();
    }

    for (i = 0; i < idx; i++)
    {
        memcpy(&buff[*len], mtinfo[i].id, 7);
        *len += 7;
    }
    return 0;
}




int rf_get_mtinfo(unsigned char *mtid, unsigned char *phase, unsigned char *depth)
{
  assert(mtid && phase && depth);
  struct mtinfo *mtp = db_trav_mtnext(CHAN_TMP);
  if (mtp == NULL)
    return seterrno(RTFERR_IDNOT);

  memcpy(mtid, mtp->node.id, IDLEN);
  id_bintobcd(mtid);
  *phase = (mtp->node.phase & NPAMASK) >> 6;
  *depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;

  return 0;
}

int rf_init_rptrav(const unsigned char *mtid, unsigned char *phase, unsigned char *depth)
{
  unsigned char id[6];

  memcpy(id, mtid, IDLEN);
  id_bcdtobin(id);
  db_trav_reset(CHAN_TMP);
  struct mtinfo *mtp;
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if (memcmp(mtp->node.id, id, IDLEN) == 0)
        {
          *phase = (mtp->node.phase & NPAMASK) >> 6;
    *depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;
          return 0;
        }
    }
  return -1;
}

int rf_get_rpinfo(unsigned char *rpid, unsigned char *phase, unsigned char *depth)
{
  assert(rpid && phase && depth);
  struct mtinfo *mtp;
  struct rpinfo *rp;
  while (1)
    {
      rp = db_trav_rpnext(CHAN_TMP, CHAN_TDEF);
      if(rp == NULL)
  break;

      mtp = db_find(rp->rpid);
      if (mtp != NULL && memcmp(rp->rpid, sinkidno, IDLEN) != 0)
  {
    memcpy(rpid, mtp->node.id, IDLEN);
          id_bintobcd(rpid);
    *phase = (mtp->node.phase & NPAMASK) >> 6;
          if(*phase == 3)
            *phase = 4;
          *phase |= (mtp->node.attr & NPROMASK) << 2;
    *depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;

          if(_share.version == OLD_GBPRO)
            *phase &= 0x07;
    return 0;
  }
    }

  return -1;
}

unsigned char rf_get_slevel()
{
  return _rtparas.slevel;
}

unsigned char rf_get_maxrd()
{
  return MAXHOPS;
}

unsigned char rf_get_wrkmd()
{
  return 1;
  //  return _rtparas.wrkmd;
}

unsigned char rf_get_runmd()
{
  return _rtparas.runmd;
}

unsigned char rf_get_wrkno()
{
  return _rtparas.wrkno;
}

unsigned char rf_get_stage()
{
  return _rtparas.stage;
}

unsigned char rf_get_extdmd()
{
  return _rtparas.exmd;
}

int rf_get_curid(unsigned char *data, int *datalen)
{
  memcpy(data, _rtparas.curid, IDLEN);
  id_bintobcd(data);
  *datalen = IDLEN;
  return  0;
}

int rf_get_untouchnum(unsigned char *data, int *datalen)
{
  db_trav_reset(CHAN_TMP);
  struct mtinfo *mtp;
  unsigned short num = 0;

  while (1)
    {
      mtp = db_trav_mtnext(CHAN_TMP);
      if(mtp == NULL)
        break;
      if ((mtp->node.sno[0] & NNEWMASK) && (mtp->node.succhops & NFSUC) == 0)
  ++num;
    }

  data[0] = num >> 8;
  data[1] = num;
  *datalen = sizeof(num);
  return 0;
}

int rf_get_untouchid(unsigned char *data, int *datalen)
{
  assert(data);

  struct mtinfo *mtp;
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if ((mtp->node.sno[0] & NNEWMASK) && (mtp->node.succhops & NFSUC) == 0)
  {
    memcpy(data, mtp->node.id, IDLEN);
          id_bintobcd(data);
          *datalen = IDLEN;
    return 0;
  }
    }

  return -1;
}

int rf_get_sinkid(unsigned char *data, int *datalen)
{
  memcpy(data, _rtparas.sinkid, sizeof(_rtparas.sinkid));
  *datalen = sizeof(_rtparas.sinkid);
  return 0;
}

int rf_get_sno(const unsigned char *mtid, unsigned char *sno)
{
  assert(mtid && sno);
  unsigned char id[IDLEN];

  memcpy(id, mtid, IDLEN);
  id_bcdtobin(id);
  struct mtinfo *mtp = db_find(id);
  if (mtp == NULL)
    return -1;

  memcpy(sno, mtp->node.sno, SNOLEN);
  sno[0] &= ~NNEWMASK;

  return 0;
}

int rf_get_id(unsigned char *sno, unsigned char *mtid)
{
  assert(mtid && sno);
  struct mtinfo *mtp = db_find_sno(sno);
  if (mtp == NULL)
    return -1;

  memcpy(mtid, mtp->node.id, IDLEN);
  id_bintobcd(mtid);
  return 0;
}

void setappd(unsigned char pro, unsigned char *data, int datalen, unsigned char wretlen)
{
  _task.appd.itemlen = 0;
  memset(_task.appd.item, 0x00, sizeof(_task.appd.item));
  _task.appd.protype = pro;
  _task.appd.datalen = datalen;
  memcpy(_task.appd.data, data, datalen);

  if (pro == 0x02 || pro == 0x01) //07Э��
  {
    for (int i = 1; i < datalen; ++i)
      _task.appd.data[i] += 0x33;
  }
    if (_task.appd.datalen < 6)
  {
     _task.appd.itemlen = _task.appd.datalen;
     memcpy(_task.appd.item, _task.appd.data, datalen );
  }
  _task.appd.wretlen = wretlen;
}

int rf_monit(unsigned char *mtid, unsigned char pro, unsigned char *data, int datalen, unsigned char wretlen)
{
    assert(mtid);
    if (datalen > 0)
        assert(data);
    unsigned char id[IDLEN], state = monitbrd;

    rf_stopreg();

    monitbrd = 0;
    memcpy(id, mtid, IDLEN);
    if (memcmp(id, sinkidno, IDLEN) == 0)
    {
        setappd(pro, data, datalen, wretlen);
        rt_mntbrd();
        return 0;
    }
    id_bcdtobin(id);
    reverse(id, IDLEN);
    if (rt_chkmntid(id) != 0)
        return 0;

    setappd(pro, data, datalen, wretlen);
    memset(&_task.minfo, 0, sizeof(struct mntinfo));
    memcpy(_task.minfo.id, id, IDLEN);
    if (state != 0)
        _task.minfo.state |= STBROAD;
    _rtparas.state &= ~STAMMASK;
    _rtparas.state |= STAMONIT;
    
    printf_s("\n****STAMONIT----ADD----rf_monit****\n");
    
    _task.minfo.state &= ~STIMASK;
    _task.minfo.state |= STINIT;

    return 0;
}

void rf_set_mntdlytm(unsigned char dlytm)
{
    _task.minfo.state &= ~STDLYTMMASK;
    _rtparas.dlytm &= ~0x04;
    if (dlytm != 0)
    {
        _task.minfo.state |= STDLYTM;
        _rtparas.dlytm |= 0x04;
    }
}

void rf_get_testcmd(unsigned char *data, int *datalen)
{
    assert(data);

    memcpy(data, &_testdata[1], sizeof(_testdata) - 1);
    reverse(data, sizeof(_testdata) - 1);
    for (int i = 0; i < sizeof(_testdata) - 1; ++i)
        data[i] -= 0x33;
    *datalen =  sizeof(_testdata) - 1;
}

int rf_comm38(unsigned char *data, int datalen)
{
    assert(data);

    rf_stopreg();

    _task.flag = TSRUN | TTPLC;
    _task.minfo.state &= ~ST38MASK;
    _task.minfo.state |= ST38COMM;
    _rtparas.state &= ~STAMMASK;
    _rtparas.state |= STAMONIT;
  
    printf_s("\n****STAMONIT----ADD----rf_comm38****\n");

    _task.start = currtick();
    _task.wait = 24000;
    nl_rtwrite(fd, data, datalen, 0);
    return 0;
}

int rf_setappd_ex(unsigned char type, unsigned char pro, unsigned char *data, unsigned int dlen, unsigned char wbytes)
{
    _task.appd.itemlen = 0;
    memset(_task.appd.item, 0x00, sizeof(_task.appd.item));
    if ((type & TYPEFLAG) || ((_task.flag & TSRUN) && (_task.flag & TTAPD)))
    {
        type &= ~TYPEFLAG;

        if (type == APPRCFM)
            _task.appd.protype = APCCFM;
        else if (type == APPRFAIL)
            _task.appd.protype = APCCFM | APFAIL;
        else
        {
            if (dlen > sizeof(_task.appd.data))
                return -1;
            _task.appd.protype = (APDMASK | pro);
            memcpy(_task.appd.data, data, dlen);
            if (pro == 0x01 || pro == 0x02) //����698��������
            {
                for (int i = 1; i < dlen; ++i)
                    _task.appd.data[i] += 0x33;
            }

            _task.appd.datalen = dlen;
            _task.appd.wretlen = wbytes;
            memcpy(_appdata_bk.itemBk, data, dlen);
            _appdata_bk.itelLen = dlen;
             if (_task.appd.datalen < 6)
               {
                 _task.appd.itemlen = _task.appd.datalen;
                 memcpy(_task.appd.item, _task.appd.data, _task.appd.datalen );
               }
        }
        return 0;
    }

    return -1;
}
int rf_setappd(unsigned char type, unsigned char *data, unsigned int dlen, unsigned char wbytes)
{
   _task.appd.itemlen = 0;
   memset(_task.appd.item, 0x00, sizeof(_task.appd.item));
  if ((type & TYPEFLAG) || (( _task.flag & TSRUN) && ( _task.flag & TTAPD)))
    {
      type &= ~TYPEFLAG;

      if (type == APPRCFM)
      _task.appd.protype = APCCFM;
      else if (type == APPRFAIL)
        _task.appd.protype = APCCFM | APFAIL;
      else
  {
          if (dlen > sizeof (_task.appd.data))
            return -1;
         _task.appd.protype = APDMASK;
         memcpy(_task.appd.data, data, dlen);
          for (int i = 1; i < dlen; ++i)
            _task.appd.data[i] += 0x33;
          _task.appd.datalen = dlen;
         _task.appd.wretlen = wbytes;
         if (_task.appd.datalen < 6)
            {
                _task.appd.itemlen = _task.appd.datalen;
                memcpy(_task.appd.item, _task.appd.data, _task.appd.datalen );
            }
    memcpy(_appdata_bk.itemBk, data, dlen);
    _appdata_bk.itelLen = dlen;
  }
      return 0;
    }

  return -1;
}

void rf_setdlytm(unsigned char dlytm)
{
  _task.ml.opt.dlytm = dlytm;
  return;
}

int rf_setpwdwmode(unsigned char type, unsigned char *data, unsigned char dlen)
{
  if (type == REQPWD)
    {
      if (strlen(pwd) != dlen)
        return -1;
      if (memcmp(pwd, data, dlen) != 0)
        return -1;

      _task.flag = TSNO;
      return 0;
    }
  else if (type == REQWMODE)
    {
      if (dlen != 0x01)
        return -1;
      if (*data != MODENOR)
        return -1;
      _rtparas.wrkmd  = MODENOR;

      _task.flag = TSNO;
      return 0;
    }

  return -1;
}

//���������������������ʱ�򣬲����Ƿ�����ִ�г���
extern unsigned int flag_rf_set_clrmt_nw_eeprom;
int rf_set_clrmt_nw()
{

    if (rf_isstop() != 0)
    {
       rf_ctrl_stop();
    }


    db_destroy();
    db_format();
    db_build();
    memcpy(_rtparas.minsno, _rtparas.maxsno, SNOLEN);
    eeprom_write(DBPBEGIN + offset(struct rtpara, minsno), (unsigned char *)&_rtparas.minsno,
                 sizeof(_rtparas.minsno));
    
    flag_rf_set_clrmt_nw_eeprom++;

    _rtparas.maxround = 0;
    _rtparas.minround = 0;
    _rtparas.wrktms = 1;
    _rtparas.flood = 0;
    _rtparas.dbfirst = 0;

    rf_stage0();
    return 0;
}
#if 0
int rf_set_clrmt()
{
  if (_rtparas.runmd != MDRT2 && rf_isstop() != 0)
    return -1;

  db_destroy();
  db_format();
  db_build();
  memcpy(_rtparas.minsno, _rtparas.maxsno, SNOLEN);
  eeprom_write(DBPBEGIN + offset(struct rtpara, minsno), (unsigned char *)&_rtparas.minsno,
               sizeof(_rtparas.minsno));

  _rtparas.maxround = 0;
  _rtparas.minround = 0;
  _rtparas.wrktms = 1;
  _rtparas.flood = 0;
  rf_stage0();
  return 0;
}
#endif
int rf_set_clrrp()
{
  void db_clr_allrp();

  if (_rtparas.runmd != MDRT2 && rf_isstop() != 0)
    return -1;

  db_clr_allrp();
  _rtparas.maxround = 0;
  _rtparas.minround = 0;
  _rtparas.wrktms = 1;
  _rtparas.flood = 0;
  rf_stage0();
  _rtparas.datainit = 0xFA;
  return 0;
}

int rf_clrsucf()
{
  struct mtinfo *mt;

  db_trav_reset(CHAN_RT1);
  while ((mt = db_trav_mtnext(CHAN_RT1)) != NULL)
    mt->node.succhops &= ~(NSMASK + NRMASK); /* clear success and study flag*/  //��ǰ����û����db_write�ĵ���

  return 0;
}

static int rf_set_addmt(struct mtinfo *mtp)
{
  assert(mtp);
  int error;

  if (rf_isstop() != 0)
    return -1;

  rf_incrsno();
  memcpy(mtp->node.sno, _rtparas.maxsno, SNOLEN);  //��������д���
  mtp->node.sno[0] |= NNEWMASK;
  if (db_addmt(mtp) == 0)
    {
      /* rf_incrsno(); */
      rf_stage0();
      return 0;
    }

  error = db_geterr();

  if (error == DBERR_MTEXIST)
    return seterrno(RTFERR_IDEXST);
  if (error == DBERR_MTMOF)
    return seterrno(RTFERR_EEPFUL);
  else
    return seterrno(RTFERR_CONFUS);
}

//�������ӱ���ʱ�򣬲���Ҫ��ͣ�����Ȳ��������������ﲻ�ж��Ƿ�����ִ�г���
static int rf_set_addmt_nw_db(struct mtinfo *mtp)
{
    assert(mtp);
    int error;

    // if (rf_isstop() != 0)
//return -1;

    rf_incrsno();
    memcpy(mtp->node.sno, _rtparas.maxsno, SNOLEN);  //��������д���
    mtp->node.sno[0] |= NNEWMASK;
    if (db_addmt(mtp) == 0)
    {
        /* rf_incrsno(); */
         rf_stage0();
      //  mtp->node.envi |= NCMD1SUC; //Ĭ�ϲ�����
        return 0;
    }

    error = db_geterr();
   

    if (error == DBERR_MTEXIST)
        return seterrno(RTFERR_IDEXST);
    if (error == DBERR_MTMOF)
        return seterrno(RTFERR_EEPFUL);
    else
        return seterrno(RTFERR_CONFUS);
}
int rf_set_addmt_nw(unsigned char *mtid, unsigned char type)
{
    struct mtinfo mt;

    memset((unsigned char *)&mt, 0x00, sizeof(struct mtinfo));
    memcpy(mt.node.id, mtid, IDLEN);  //��ǰ����û����db_write�ĵ���
    id_bcdtobin(mt.node.id);
    if (memcmp(mt.node.id, _rtparas.jzqid_nw, IDLEN) == 0)
        return seterrno(RTFERR_IDEXST);
    // mt.node.attr |= ((pro & 0x03) << 1);
    mt.node.user1 = 0xFF;
    mt.node.user2 = 0xFF;

    
    mt.node.viv = 0xFF;
    if (type == 0x01)
    {
      mt.node.viv &= ~TYPEMASK;
      mt.node.viv |= (TYPEGDNODE << 3); 
      memcpy(mt.node.gdid, &mtid[6], GDIDLEN - 6);
    }
    else
    {
      mt.node.viv &= ~TYPEMASK;
      mt.node.viv |= (TYPENODE << 3);
    }

    return rf_set_addmt_nw_db(&mt);
}
int rf_set_addmt_gb(unsigned char *mtid, unsigned char *sno, unsigned char pro)
{
  assert(mtid && sno);

  struct mtinfo mt;

  if (rf_findmt_usno(sno)) /* sno exist */
    return seterrno(RTFERR_IDEXST);

  memset((unsigned char *)&mt, 0x00, sizeof(struct mtinfo));
  memcpy(mt.node.id, mtid, IDLEN);  //��ǰ����û����db_write�ĵ���
  id_bcdtobin(mt.node.id);
  if(memcmp(mt.node.id, _rtparas.jzqid, IDLEN) == 0)
    return seterrno(RTFERR_IDEXST);
  mt.node.attr |= ((pro & 0x03) << 1);  //��ǰ����û����db_write�ĵ���
  mt.node.user1 = sno[0];
  mt.node.user2 = sno[1];

  return rf_set_addmt(&mt);
}

int rf_set_addmt_newgb(unsigned char *mtid, unsigned char pro)
{
  struct mtinfo mt;

  memset((unsigned char *)&mt, 0x00, sizeof(struct mtinfo));
  memcpy(mt.node.id, mtid, IDLEN);  //��ǰ����û����db_write�ĵ���
  id_bcdtobin(mt.node.id);
  if(memcmp(mt.node.id, _rtparas.jzqid, IDLEN) == 0)
    return seterrno(RTFERR_IDEXST);
  mt.node.attr |= ((pro & 0x03) << 1);  //��ǰ����û����db_write�ĵ���
  mt.node.user1 = 0xFF;
  mt.node.user2 = 0xFF;

  return rf_set_addmt(&mt);
}

int rf_set_addmt_rt(unsigned char *mtid)
{
  assert(mtid);

  struct mtinfo mt;

  memset((unsigned char *)&mt, 0x00, sizeof(struct mtinfo));
  memcpy(mt.node.id, mtid, IDLEN);  //��ǰ����û����db_write�ĵ���
  id_bcdtobin(mt.node.id);
  mt.node.user1 = 0xFF;
  mt.node.user2 = 0xFF;

  return rf_set_addmt(&mt);
}

int rf_set_delmt(unsigned char *mtid)
{
  assert(mtid);
  unsigned char  type =1;

  int error;
  unsigned char id[6];

  if (rf_isstop() != 0)
    return -1;

  memcpy(id, mtid, IDLEN);
  id_bcdtobin(id);
  struct mtinfo *mtp;

  if ((mtp = hash_find(id)) == NULL)
    return seterrno(RTFERR_IDNOT);

  if (mtp)
  {
    if (type == 1)
    {
      if ((mtp->node.viv & TYPEMASK) != TYPEGDNODE) 
        return seterrno(RTFERR_IDNOT); 
    }
    else if (type == 0) 
    {
      if ((mtp->node.viv & TYPEMASK) != TYPENODE) 
        return seterrno(RTFERR_IDNOT);
    }
  }

  if (db_delmt(id) == 0)
    {
      rf_stage0();
      return 0;
    }

  error = db_geterr();
  if (error == DBERR_NOTHISMT)
    return seterrno(RTFERR_IDNOT);
  else
    return seterrno(RTFERR_CONFUS);
}
//����ɾ������ʱ�򣬲���Ҫ��ͣ�����Ȳ��������������ﲻ�ж��Ƿ�����ִ�г���
int rf_set_delmt_nw(unsigned char *mtid, unsigned char type)
{
    assert(mtid);

    int error;
    unsigned char id[6];

    //  if (rf_isstop() != 0)
    //   return -1;

    memcpy(id, mtid, IDLEN);
    id_bcdtobin(id);
    if (db_delmt(id) == 0)
    {

        // rf_stage0();
        return 0;
    }

    error = db_geterr();
    if (error == DBERR_NOTHISMT)
        return seterrno(RTFERR_IDNOT);
    else
        return seterrno(RTFERR_CONFUS);

}
int rf_set_mdfid(unsigned char *newid, unsigned char *oldid)
{
  assert(newid);
  assert(oldid);

  unsigned char oid[6];

  if (rf_isstop() != 0)
    return -1;

  memcpy(oid, oldid, IDLEN);
  id_bcdtobin(oid);

  if (db_find(oid) == NULL)
    return seterrno(RTFERR_IDNOT);
  if (db_delmt(oid) != 0)
    return seterrno(RTFERR_CONFUS);

  return rf_set_addmt_rt(newid);
}

int rf_set_inserp(unsigned char *mtid, unsigned char *rpid)
{
  assert(mtid);
  assert(rpid);

  struct mtinfo *rpmt, *mtp;
  struct rpinfo rp;
  unsigned char id[6], rid[6];

  if (rf_isstop() != 0)
    return -1;

  memcpy(id, mtid, IDLEN);
  id_bcdtobin(id);
  memcpy(rid, rpid, IDLEN);
  id_bcdtobin(rid);

  if (memcmp(id, rid, IDLEN) == 0)
    return seterrno(RTFERR_CMDCONT);

  if ((mtp = db_find(id)) == NULL)
    return seterrno(RTFERR_IDNOT);
  if ((rpmt = db_find(rid)) == NULL)
    return seterrno(RTFERR_IDNOT);
  if ((rpmt->node.sno[0] & NNEWMASK) || (mtp->node.sno[0] & NNEWMASK))
    return seterrno(RTFERR_CMDCONT);
  if ((rpmt->node.succhops & NHMASK) > _rtparas.maxround)
    return seterrno(RTFERR_CMDCONT);

  memset((unsigned char *)&rp, 0x00, sizeof(struct rpinfo));
  rp.addr = EMPADDR;
  memcpy(rp.rpid, rid, IDLEN);
  rp.node.idptr = mtp->addr;  //���û����

  if (db_insertrp(id, &rp) == 0)
    return 0;
  return seterrno(RTFERR_RAMFUL);
}

extern unsigned int flag_rf_set_slev_nw_eeprom;
int rf_set_slev_nw(unsigned char slevel)
{
    if (rf_isstop() != 0)
    {
        rf_ctrl_stop();

    }

    if (slevel == 0 || slevel > MAXSLE)
        return seterrno(RTFERR_CMDCONT);

    _rtparas.slevel = slevel;

    /* write slevel to eeprom */
    eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), (unsigned char *)&_rtparas.slevel,
                 sizeof(_rtparas.slevel));
    
    flag_rf_set_slev_nw_eeprom++;
    
    return 0;
}
#if 0
int rf_set_slev(unsigned char slevel)
{
  if (rf_isstop() != 0)
    return -1;

  if (slevel == 0 || slevel > MAXSLE)
    return seterrno(RTFERR_CMDCONT);

  _rtparas.slevel = slevel;

  /* write slevel to eeprom */
  eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), (unsigned char *)&_rtparas.slevel,
               sizeof(_rtparas.slevel));
  return 0;
}
#endif
int rf_set_begin()
{
  _rtparas.wrktms = 1;
  _rtparas.stagectl = 0;
  _rtparas.wkstate &=  ~RDOVERMASK;
  rf_stage0();

  return 0;
}

int rf_set_wrkmd(unsigned char wrkmd)
{
  if (rf_isstop() != 0)
    return -1;

  if (wrkmd != 1)
    return seterrno(RTFERR_CMDCONT);
  _rtparas.wrkmd = wrkmd;

  /* write work mode to eeprom */
  return 0;
}

int rf_set_test(unsigned char *data)
{
  assert(data);

  if (rf_isstop() != 0)
    return -1;

  memcpy(&_testdata[1], data, sizeof(_testdata) - 1);
  reverse(&_testdata[1],sizeof(_testdata) - 1);
  for (int i = 1; i < sizeof(_testdata); ++i)
    _testdata[i] += 0x33;

  return 0;
}
#if 0
int rf_set_randsinkid()
{
  unsigned char sink[2];

  if (rf_isstop() != 0)
    return -1;
#ifndef _LINUXPC
  srand(currtick());
#else
  srand(time(NULL));
#endif

  sink[0] = rand() % 0x63;
  sink[1] = rand() % 0x63;

  if (rf_set_sinkid(sink) < 0)
    return -1;

  _rtparas.minsno[0] = 0x01;
  _rtparas.minsno[1] = 0x00;
  eeprom_write(DBPBEGIN + offset(struct rtpara, minsno), (unsigned char *)&_rtparas.minsno,
               sizeof(_rtparas.minsno));

  _rtparas.maxsno[0] = 0x01;
  _rtparas.maxsno[1] = 0x00;
  eeprom_write(DBPBEGIN + offset(struct rtpara, maxsno), (unsigned char *)&_rtparas.maxsno,
               sizeof(_rtparas.maxsno));

  return rf_set_clrmt();
}
#endif
extern unsigned int flag_rf_set_sinkid_eeprom;
int rf_set_sinkid_v(unsigned char *sink)
{
    assert(sink);

    // if (rf_isstop() != 0)��������������
    //     return -1;

    if ((sink[0] == 0 && sink[1] == 0) || (sink[0] > 0x63) || (sink[1] > 0x63))
        return seterrno(RTFERR_CMDCONT);

    memcpy(_rtparas.sinkid, sink, SNOLEN);
    eeprom_write(DBPBEGIN + offset(struct rtpara, sinkid), (unsigned char *)&_rtparas.sinkid,
                 sizeof(_rtparas.sinkid));
    _rtparas.flag_setid = 0x7E; //�趨���ı�־��ͬ��һ������
    eeprom_write(DBPBEGIN + offset(struct rtpara, flag_setid), (unsigned char *)&_rtparas.flag_setid,
                 sizeof(_rtparas.flag_setid));
    
    flag_rf_set_sinkid_eeprom++;
    
    db_clrall_newmtmask();
    return 0;
}
#if 0
int rf_set_runmd(unsigned char mode)
{
  if (mode != 0x03 && mode != 0xFC)
    return seterrno(RTFERR_CMDCONT);

  return rf_set_rtmd(mode);
}
#endif
int rf_set_exmd(unsigned char mode)
{
  _rtparas.exmd = mode;
  return 0;
}

int rf_ctrl_chgphs(unsigned char phase)
{
  _rtparas.phase = phase;

  return 0;
}

extern unsigned int flag_rf_ctrl_work_eeprom;
int rf_ctrl_work()
{
 // if (_rtparas.mtnum == 0 )
  //  return seterrno(RTFERR_IDNUM0);

  rf_stopreg();
  stop_parabroad();

  if (hardinit == 1)
  {
    _rtparas.slevel |= 0x80;
    eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), &_rtparas.slevel, sizeof(_rtparas.slevel));

    flag_rf_ctrl_work_eeprom++;
    
    return 0;
  }
  if ((_rtparas.state & STASTMASK) == STARUN)
    return 0;

  _rtparas.state &= ~STASTMASK;
  _rtparas.state |= STARUN;
  
  printf_s("\n****STARUN----ADD----rf_ctrl_work****\n");

  _rtparas.stage = stage;
  _rtparas.round = round;

  rt_report(REPOIDLE, 0);
  rt_report(REPODIR, 0);
  rt_report(REPORELAX, 0);
  _rtparas.wrkmd &= ~RUNMDRMASK;

  return 0;
}

extern unsigned int flag_rf_ctrl_stop_eeprom;
int rf_ctrl_stop()
{
  rf_stopreg();

  if((_rtparas.state & STASTMASK) == STARUN)
  {
    stage = _rtparas.stage;
    round = _rtparas.round;
  }

  _rtparas.state &= ~STASTMASK;
  printf_s("\n****STARUN----CLEAR----rf_ctrl_stop****\n");

  if (_rtparas.slevel & 0x80)
    {
      _rtparas.slevel &= ~0x80;
      eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), &_rtparas.slevel, sizeof(_rtparas.slevel));
      
      flag_rf_ctrl_stop_eeprom++;
    }

  return 0;
}

int rf_ctrl_startbrd()
{
#if 0
  if (_rtparas.mtnum == 0 )
    return seterrno(RTFERR_IDNUM0);
#endif
  rf_stopreg();

  if (0 == _rtparas.flood)
    {
    broad_init();
    }

  return 0;
}

extern unsigned int flag_rf_incrsno_eeprom;
static int rf_incrsno()
{
  if (++_rtparas.maxsno[0] > MAXMTNO)
    {
      _rtparas.maxsno[0] = 0;
      if (++_rtparas.maxsno[1] > MAXMTNO)
  {
    _rtparas.maxsno[1] = 0;
    ++_rtparas.maxsno[0];
  }
    }

  eeprom_write(DBPBEGIN + offset(struct rtpara, maxsno), (unsigned char *)&_rtparas.maxsno,
               sizeof(_rtparas.maxsno));
  
  flag_rf_incrsno_eeprom++;
    
  return 0;
}
/*����Ҫ�����֧��BIN�룬���Ե�ǰ�ǰѼ��������õ�ֱ�������ҿ�ռ���£�����ͬ������������ʱ��ֱ����*/

extern unsigned int flag_rf_set_jzqid_nw_eeprom;
int rf_set_jzqid_nw(unsigned char *id)
{
    memcpy(_rtparas.jzqid_nw, id, sizeof(_rtparas.jzqid_nw));
    eeprom_write(DBPBEGIN + offset(struct rtpara, jzqid_nw), id,
                 sizeof(_rtparas.jzqid_nw));
  
    flag_rf_set_jzqid_nw_eeprom++;
  
    return 0;
}
extern unsigned int flag_rf_set_jzqid_eeprom;
int rf_set_jzqid(unsigned char *id)
{
  memcpy(_rtparas.jzqid, id, sizeof(_rtparas.jzqid));
  eeprom_write(DBPBEGIN + offset(struct rtpara, jzqid), id,
         sizeof(_rtparas.jzqid));

  eeprom_write(DBSHARE + offset(struct share, jzqid), _rtparas.jzqid, sizeof(_rtparas.jzqid));

  flag_rf_set_jzqid_eeprom++;
  
  memcpy(_share.jzqid, _rtparas.jzqid, IDLEN);
  return 0;
}

int rf_get_user(unsigned char *mtid, unsigned char *sno)
{
  assert(mtid);
  assert(sno);

  struct mtinfo *mtp = db_find(mtid);

  if (mtp == NULL)
    return -1;

  sno[0] = mtp->node.user1;
  sno[1] = mtp->node.user2;

  return 0;
}
#if 0
int rf_set_rtmd(unsigned char mode)
{
//  unsigned char c = mode;

  if (_rtparas.runmd != MDRT2 && rf_isstop() != 0)
    return -1;

//  _share.wkmd = mode;
//  eeprom_write(DBSHARE + offset(struct share, wkmd), &c, sizeof(c));
//  _share.state = RTSTA_INIT;
  _share.state = mode;
  eeprom_write(DBSHARE + offset(struct share, state), &_share.state, 1);

  return 0;
}
#endif
int rf_get_rtmd(unsigned char *mode)
{
  eeprom_read(DBSHARE + offset(struct share, wkmd), mode, 1);

  if (*mode == 0xFC)
    *mode = 0x03;
  return 0;
}

int rf_get_rtmd_external(unsigned char *mode)
{
  //eeprom_read(DBSHARE + offset(struct share, wkmd), mode, 1);
  eeprom_read(DBSHARE + offset(struct share, state), mode, 1);

  if (*mode == 0xFC)
    *mode = 0x03;
  else if(*mode == 0xFD)
    *mode = 0x02;
  else if(*mode == 0xFE)
    *mode = 0x01;
  if(*mode != 0x01 && *mode != 0x02 && *mode != 0x03 && *mode != 0x04 && *mode != 0x05)
    *mode = 0x01;
  return 0;
}

int rf_get_e2md(unsigned char *mode)
{
  eeprom_read(DBSHARE + offset(struct share, wkmd), mode, 1);

  return 0;
}

int rf_exprewrk(unsigned int time)
{
  rf_ctrl_stop();
  _rtparas.extime = time;
  _rtparas.exstate = 0x01;

 return 0;
}

int rf_get_exsta(unsigned char *state)
{
  *state = _rtparas.exstate;

  return 0;
}

int rf_set_exsta(unsigned char state)
{
  _rtparas.exstate = state;

  return 0;
}

int rf_exwork()
{
  _rtparas.state &= ~STASTMASK;
  _rtparas.state |= STARUN;
  
  printf_s("\n****STARUN----ADD----rf_exwork****\n");
  
  _rtparas.wrkmd &= ~RUNMDRMASK;

  alloc_a_timer(TIMER_EXRUNTIMER, 60000, 60000, exwork_timer);

  return 0;
}

static int mt_inbase(unsigned char *mtid, unsigned char (*base)[6], int num)
{
  for (int i = 0; i < num; ++i)
    {
      if (memcmp(mtid, base[i], IDLEN) == 0)
        return 1;
    }

  return 0;
}

int rf_exaddmt(unsigned char (*id)[6], unsigned int num)
{
  struct mtinfo *mtp;
  struct mtinfo mt;

  db_trav_reset(CHAN_TMP);
  while ((mtp = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if (mt_inbase(mtp->node.id, id, num) == 0)
        {
        db_delmt(mtp->node.id);
        watchdog();
        }
    }

  memset((unsigned char *)&mt, 0x00, sizeof(struct mtinfo));
  for (int i = 0; i < num; ++i)
  {
    memcpy(mt.node.id, id[i], IDLEN);  //��ǰ����û����db_write�ĵ���
    rf_set_addmt(&mt);
    watchdog();
  }

  return 0;
}

static void exwork_timer()
{
  if ((_rtparas.state & STASTMASK) != STARUN || _rtparas.runmd != 0x02)
    return;

  if (_rtparas.extime == 0 || --_rtparas.extime == 0)
    {
      stage = _rtparas.stage;
      round = _rtparas.round;
      _rtparas.state &= ~STASTMASK;
      printf_s("\n****STARUN----CLEAR----exwork_timer****\n");
    }
  else
    alloc_a_timer(TIMER_EXRUNTIMER, 60000, 60000, exwork_timer);

}

static int rf_stage0()
{
  stage = 0;
  round = 1;
  _rtparas.stage = 0;
  _rtparas.round = 1;

  /* clear meter sucsess flag */
  struct mtinfo *mt;
  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    mt->node.succhops &= ~NSUCC & ~NREACH;  //��ǰ����û����db_write�ĵ���
    mt->tmout_tims &= ~TTIMESMASK;
    mt->tmout_tims &= ~TTIMESTHMASK;
    mt->tmout_tims |= 0x01<<4;//��ʼ������ģ���һ����ֵΪ1����ʧ��1�κ󣬵ڶ��θñ��������Զ��������ȼ�
  //  mt->node.envi |= NCMD1SUC;//�����ģ���Ĭ�϶��ǳɹ���
    mt->node.envi &= ~NCMD1SUC;  //��ǰ����û����db_write�ĵ���
  }
 // clear_task_mt_cmd1suc();
  if(rt_sink38mode() != -1)
    memset((unsigned char *)&_task, 0x00, sizeof(_task));
  db_trav_reset(CHAN_RT1);
  db_trav_reset(CHAN_RT2);
  db_trav_reset(CHAN_RT3);

  /* clear report breakpoint */

  rt_report(REPOIDLE, 0);
  rt_report(REPODIR, 0);
  rt_report(REPORELAX, 0);

  return 0;
}

int rf_isstop()
{
//  if ((_rtparas.state & STASTMASK) == STARUN || (_rtparas.state & STARMASK) == STAREG)
  if ((_rtparas.state & STASTMASK) == STARUN)
    return seterrno(RTFERR_SYSRUN);
  return 0;
}

static int get_compile_info(unsigned char time[])
{
  unsigned char i, s[12];
  const unsigned char time_order[6] = {0, 1, 3, 4, 6, 7};

  memcpy(s, (unsigned char *)__DATE__ + 9, 2);
  memcpy(s + 4, (unsigned char *)__DATE__ + 4, 2);

  for(i = 0; i < 12; i++)
    {
      if(memcmp(m_char[i], (unsigned char *)__DATE__, 3) == 0)
  {
    memcpy(s + 2, (unsigned char *)m_num[i], 2);
    break;
  }
    }

  for(i = 0; i < 6; i++)
    {
      s[i + 6] = *((unsigned char  *)__TIME__ + time_order[i]);
    }

  for(i = 0; i < 12; i++)
    {
      s[i] -= '0';
    }

  for(i = 0; i < 6; i++)
    {
      time[i] = (s[2 * i]<<4) + s[2 * i + 1];
    }

  reverse(&time[0], 6);

  return(6);
}

int rf_get_vergb(unsigned char *data, int *datalen)
{
  data[0] = RT_VERDATA;
  data[1] = RT_VERDATA >> 8;
  data[2] = RT_VERDATA >> 16;
  data[3] = (unsigned char)(RT_VERSION & 0xff);
  data[4] = (unsigned char)(RT_VERSION >> 8);
  *datalen = 5;

  return 0;
}

int rf_get_pvergb(unsigned char *data, int *datalen)
{
  unsigned char time[6];

  get_compile_info(time);
  memcpy(data, &time[3], 3);
  data[3] = (unsigned char)(RT_VERSION & 0xff);
  data[4] = (unsigned char)(RT_VERSION >> 8);
  *datalen = 5;

  return 0;
}

int rf_get_jzqid(unsigned char *data, int *datalen)
{
  memcpy(data, _rtparas.jzqid, 6);
  *datalen = 6;

  return 0;
}

static struct mtinfo * rf_findmt_usno(unsigned char *usno)
{
  struct mtinfo *mtp;

  db_trav_reset(CHAN_TMP);
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if (mtp->node.user1 == usno[0] && mtp->node.user2 == usno[1])
        return mtp;
    }

  return NULL;
}

int rf_get_mtamtgb(unsigned char *data, unsigned char *len)
{
  int dlen = 0, max = MAXMTNUM;

  data[dlen++] = _rtparas.mtnum;
  data[dlen++] = (_rtparas.mtnum >> 8);
  data[dlen++] = max;
  data[dlen++] = (max >> 8);
  *len = dlen;
  return 0;
}



static int rf_insno_mtinfo(unsigned char *para, unsigned char *buff, unsigned char *len)
{
  struct mtinfo mt, *rmt;
  struct
  {
    unsigned char id[6];
    unsigned char phase;
    unsigned char depth;
    unsigned char pro;
    unsigned short int usno;
  } mtinfo[MAXRDAMT];
  int usno, amt, i, idamt = 0, idx = 0;
  unsigned short addr, end;

  *len = 0x00;
  usno = para[0] + (para[1] << 8);
  if(usno == 0)
    return -1;
  if(usno > _rtparas.mtnum)                               /*��Ŵ�1��ʼ*/
    return 0;
  usno -= 1;

  amt = para[2];
  if (amt > MAXRDAMT)
    amt = MAXRDAMT;
  memset(mtinfo, 0x00, sizeof(mtinfo));

  addr = DBBEGIN;
  end  = DBEND;
  while (addr < end)
    {
      db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
      if ((mt.node.attr & CELLMASK) == MTFLAG)
  {
          if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
    && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
          {
             addr += CELL * MTCN; /* idnode occupy 2 database cell */
             continue;
          }
          if(idamt >= usno)
          {
            if((rmt = db_find(mt.node.id)) == NULL)
            {
             addr += CELL * MTCN; /* idnode occupy 2 database cell */
             continue;
            }
             memcpy(mtinfo[idx].id, rmt->node.id, IDLEN);
             id_bintobcd(mtinfo[idx].id);
             reverse(mtinfo[idx].id, IDLEN);
             mtinfo[idx].phase = (rmt->node.phase & NPAMASK) >> 6;  //��ǰ����û����db_write�ĵ���
             if(mtinfo[idx].phase == 3)
                mtinfo[idx].phase = 4;
             mtinfo[idx].depth = (rmt->node.succhops & NHMASK) == 0 ? 0 : (rmt->node.succhops & NHMASK) - 1;
             mtinfo[idx].pro = (rmt->node.attr >> 1) & 0x03;
             mtinfo[idx++].usno = rmt->node.user1 + (rmt->node.user2 << 8);
          }
          ++idamt;
  }
      else if ((mt.node.attr & CELLMASK) == RPFLAG)
  break;
      if(idamt >= _rtparas.mtnum)
        break;
      if(idx >= amt)
        break;
      addr += CELL * MTCN; /* idnode occupy 2 database cell */
      watchdog();
    }

  for(i = 0; i < idx; i++)
  {
    memcpy(&buff[*len], mtinfo[i].id, IDLEN);
    *len += IDLEN;
    buff[(*len)++] = mtinfo[i].depth;
    buff[(*len)++] = mtinfo[i].phase | (mtinfo[i].pro << 3);
  }
  return 0;
}

int rf_get_mtinfogb(unsigned char *para, unsigned char *buff, unsigned char *len)
{
  struct mtinfo *mtp;
  struct
  {
    unsigned char id[6];
    unsigned char phase;
    unsigned char depth;
    unsigned short int usno;
  } mtinfo[MAXRDAMT];
  int usno, amt, idx = 0, i;

  if(_share.version == NEW_GBPRO)
    return rf_insno_mtinfo(para, buff, len);

  usno = para[0] + (para[1] << 8);
  amt = para[2];
  if (amt > MAXRDAMT)
    amt = MAXRDAMT;
  memset(mtinfo, 0x00, sizeof(mtinfo));

  db_trav_reset(CHAN_TMP);
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if (mtp->node.user1 + (mtp->node.user2 << 8) < usno)
        continue;

      for(i = 0; i < idx; i++)
        {
          if(mtp->node.user1 + (mtp->node.user2 << 8) < mtinfo[i].usno)
            break;
        }
      if(i >= MAXRDAMT)
        continue;
      for (int j = MAXRDAMT - 2; j >= i; j--)
        memcpy(&mtinfo[j + 1], &mtinfo[j], sizeof(mtinfo[0]));
      memcpy(mtinfo[i].id, mtp->node.id, IDLEN);
      id_bintobcd(mtinfo[i].id);
      reverse(mtinfo[i].id, IDLEN);
      mtinfo[i].phase = (mtp->node.phase & NPAMASK) >> 6;  //��ǰ����û����db_write�ĵ���
      if(mtinfo[i].phase == 3)
        mtinfo[i].phase = 4;
      mtinfo[i].depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;
      mtinfo[i].usno = mtp->node.user1 + (mtp->node.user2 << 8);

      ++idx;
      if(idx > amt)
        idx = amt;
    }

  *len = 0x00;
  for(i = 0; i < idx; i++)
    {
      memcpy(&buff[*len], mtinfo[i].id, IDLEN);
      *len += IDLEN;
      buff[(*len)++] = mtinfo[i].depth;
      buff[(*len)++] = mtinfo[i].phase;
    }

  return 0;
}

int rf_get_runstate(unsigned char *data, unsigned char *len)
{
  int dlen = 0;
  /*run state*/
  if ( ((_rtparas.state & STARUN) != 0x00) ||
      (_share.version == NEW_GBPRO && ((_rtparas.wkstate & REGSWIMASK) == REGSWION)
     && (_rtparas.state & STARMASK) == STAREG))
    data[dlen++] = (0x01 << 1);
  else
    data[dlen++] = 0x00;

  /*mt amt*/
  data[dlen++] = _rtparas.mtnum;
  data[dlen++] = (_rtparas.mtnum >> 8);
  /*succ amt*/
  data[dlen++] = _rtparas.succnum;
  data[dlen++] = (_rtparas.succnum >> 8);
  /*relay succ amt*/
  struct mtinfo *mt;
  int relay = 0;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if ((mt->node.succhops & NSMASK) == NSUCC && (mt->node.succhops & 0x0F) > 0x01)
  ++relay;
    }
  data[dlen++] = relay;
  data[dlen++] = (relay >> 8);
  /*work switch*/
  data[dlen] = 0x02;
  if((_share.plswitch & 0x01) == 0x00)
    data[dlen] = 0x00;
  dlen++;

  /*plc comm rate*/
  data[dlen++] = 0x4A;
  data[dlen++] = 0x01;

  /*depth*/
  data[dlen++] = 0;
  data[dlen++] = 0;
  data[dlen++] = 0;

  /*work step*/
  unsigned char step;
  if ((_rtparas.state & STAMMASK) == STAMONIT)
    step = 4;
  else if ((_rtparas.state & STABMASK) == STABROAD || (_rtparas.wkstate & 0x08))
    step = 5;
  else if ((_rtparas.state & STARMASK) == STAREG && _share.version == OLD_GBPRO)
    step = 6;
  else if ((_share.version == NEW_GBPRO && ((_rtparas.wkstate & REGSWIMASK) == REGSWION)
     && (_rtparas.state & STARMASK) == STAREG))
    step = 6;
  else if ((_rtparas.state & STASTMASK) == STARUN)
    step = 2;
  else
    step = 8;

  data[dlen++] = step;
  data[dlen++] = step;
  data[dlen++] = step;

  *len = 16;
  return 0;
}

int rf_get_new_untouchidgb(unsigned char *para, unsigned char *buff, unsigned char *len)
{
  struct mtinfo mt, *rmt;
  struct
  {
    unsigned char id[6];
    unsigned char phase;
    unsigned char depth;
    unsigned char pro;
    unsigned short int usno;
  } mtinfo[MAXRDAMT];
  int usno, amt, idx = 0, i, idamt = 0;
  unsigned short addr, end;

  usno = para[0] + (para[1] << 8);
  if(usno == 0)
    return -1;
  if(usno > _rtparas.mtnum)                               /*��Ŵ�1��ʼ*/
    return 0;
  usno -= 1;
  amt = para[2];
  if (amt > MAXRDAMT)
    amt = MAXRDAMT;

  memset(mtinfo, 0x00, sizeof(mtinfo));

  addr = DBBEGIN;
  end  = DBEND;
  while (addr < end)
    {
      db_read(addr, (unsigned char *)&mt.node, CELL * MTCN);  //ǰ���и�ֵ�����ø�
      if ((mt.node.attr & CELLMASK) == MTFLAG)
  {
          if (memcmp(mt.node.sno, sinksno, sizeof(mt.node.sno)) == 0
    && memcmp(mt.node.id, sinkidno, sizeof(mt.node.id)) == 0)
          {
             addr += CELL * MTCN; /* idnode occupy 2 database cell */
             continue;
          }
          if(idamt >= usno && (mt.node.sno[0] & NNEWMASK))
          {
            if((rmt = db_find(mt.node.id)) == NULL)
            {
             addr += CELL * MTCN; /* idnode occupy 2 database cell */
             continue;
            }
             memcpy(mtinfo[idx].id, rmt->node.id, IDLEN);
             id_bintobcd(mtinfo[idx].id);
             reverse(mtinfo[idx].id, IDLEN);
             mtinfo[idx].phase = (rmt->node.phase & NPAMASK) >> 6;  //��ǰ����û����db_write�ĵ���
             if(mtinfo[idx].phase == 3)
               mtinfo[idx].phase = 4;
             mtinfo[idx].depth = (rmt->node.succhops & NHMASK) == 0 ? 0 : (rmt->node.succhops & NHMASK) - 1;
             mtinfo[idx].pro = (rmt->node.attr >> 1) & 0x03;
             mtinfo[idx++].usno = rmt->node.user1 + (rmt->node.user2 << 8);
          }
          ++idamt;
  }
      else if ((mt.node.attr & CELLMASK) == RPFLAG)
  break;
      if(idamt >= _rtparas.mtnum)
        break;
      if(idamt >= usno + amt)
        break;
      if(idx >= amt)
        break;
      addr += CELL * MTCN; /* idnode occupy 2 database cell */
      watchdog();
    }

  *len = 0x00;
  for(i = 0; i < idx; i++)
  {
    memcpy(&buff[*len], mtinfo[i].id, IDLEN);
    *len += IDLEN;
    buff[(*len)++] = mtinfo[i].depth;
    buff[(*len)++] = mtinfo[i].phase | (mtinfo[i].pro << 3);
  }

  return 0;
}

int rf_get_untouchidgb(unsigned char *para, unsigned char *buff, unsigned char *len)
{
  struct mtinfo *mtp;
  struct
  {
    unsigned char id[6];
    unsigned char phase;
    unsigned char depth;
    unsigned char pro;
    unsigned short int usno;
  } mtinfo[MAXRDAMT];
  int usno, amt, idx = 0, i;

  if(_share.version == NEW_GBPRO)
    return rf_get_new_untouchidgb(para, buff, len);

  usno = para[0] + (para[1] << 8);
  amt = para[2];
  if (amt > MAXRDAMT)
    amt = MAXRDAMT;

  db_trav_reset(CHAN_TMP);
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if (mtp->node.user1 + (mtp->node.user2 << 8) < usno)
        continue;
      if ((mtp->node.sno[0] & NNEWMASK) == 0x00 || (mtp->node.succhops & NFSUC) )
        continue;

      for(i = 0; i < idx; i++)
        {
          if(mtp->node.user1 + (mtp->node.user2 << 8) < mtinfo[i].usno)
            break;
        }
      if(i >= MAXRDAMT)
        continue;
      for (int j = MAXRDAMT - 2; j >= i; j--)
        memcpy(&mtinfo[j + 1], &mtinfo[j], sizeof(mtinfo[0]));
      memcpy(mtinfo[i].id, mtp->node.id, IDLEN);
      id_bintobcd(mtinfo[i].id);
      reverse(mtinfo[i].id, IDLEN);
      mtinfo[i].phase = (mtp->node.phase & NPAMASK) >> 6;  //��ǰ����û����db_write�ĵ���
      if(mtinfo[i].phase == 3)
        mtinfo[i].phase = 4;
      mtinfo[i].depth = (mtp->node.succhops & NHMASK) == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;
      mtinfo[i].usno = mtp->node.user1 + (mtp->node.user2 << 8);

      ++idx;
      if(idx > amt)
        idx = amt;
    }

  *len = 0x00;
  for(i = 0; i < idx; i++)
    {
      memcpy(&buff[*len], mtinfo[i].id, IDLEN);
      *len += IDLEN;
      buff[(*len)++] = mtinfo[i].depth;
      buff[(*len)++] = mtinfo[i].phase;
    }

  return 0;
}

int rf_reset(unsigned char second)
{
#ifndef _LINUXPC
  mdelay(second * 1000);
  hard_reset();
#endif
  return 0;
}

int rf_hardinit()
{
  hardinit = 0x01;

  rf_ctrl_stop();

  alloc_a_timer(TIMER_HARDRESTE, 2000, 2000, hard_reset);
  return 0;
}

unsigned int rf_currtick()
{
  return currtick();
}

void rf_setbrd()
{
  monitbrd = 1;
}

void rf_settask()
{
  memset(&_task.minfo, 0, sizeof(struct mntinfo));
  _task.flag = TSNO;
  _task.cnt = 0;
}

int rf_getjid(unsigned char *jid, int *jlen)
{
  assert(jid);

  memcpy(jid, sinkidno, IDLEN);
  *jlen = IDLEN;
  return 0;
}

/*
1 �򿪣�0 �ر�
*/
#if 0
void rt_setbrd(unsigned char t)
{
  if(0 == t)
    t = 1;
  else
    t = 0;

  _rtparas.brdclose = t;

  eep_write(DBPBEGIN + offset(struct rtpara, brdclose), &_rtparas.brdclose, sizeof(_rtparas.brdclose));
  rf_set_begin();
}
#endif
unsigned char rt_getbrd()
{
  if(_rtparas.brdclose)
    {
    return(0);
    }

  return(1);
}

#if 0
static unsigned char get_regsno(int time)
{
  unsigned char t;
#if 0
  if (++_rtparas.regsno > MAXREGSNO)
    _rtparas.regsno = 1;
#endif
  t = getNewTno6Sno(time, ShouJiJieDian);

  if(0 == t)
    {
    return(0);
    }

  _rtparas.regsno = t;

  eeprom_write(DBPBEGIN + offset(struct rtpara, regsno), (unsigned char *)&_rtparas.regsno,
               sizeof(_rtparas.regsno));

  return _rtparas.regsno;
}
#endif
int rf_autoreg(unsigned int left)
{
  //if ((_rtparas.state & STARMASK) == STAREG)
  //  return -1;

  if((_share.plswitch & 0x01) == 0x00)  /*���п��عر�*/
      return -1;

  unsigned char t = 1;
  memset(&_rtreport, 0x00, sizeof(struct rtreport));
#if 0
  if(_share.version != NEW_GBPRO)
  {
    t = get_regsno(left * 4);

    if(0 == t)
    {
      return(-1);
    }
  }
#endif
  _rtreport.sno = t;
  _rtreport.left = left * 4;
  ses_set_search_time(left * 4 * 60);  /* ����ת����s */
  ses_reset_idle_time();
  _task.flag = TSNO;
  _rtparas.state &= ~STARMASK;
  _rtparas.state |= STAREG;

  return 0;
}

int rf_testiv(unsigned char time)
{
  unsigned char data[2], frame[255];
  int len;

  data[0] = 0x01;
  data[1] = time;
  nl_frm38(0x35, data, sizeof(data), frame, &len, PLC_DC);
  nl_rtwrite(CHN_38_1, frame, len, 0);

  return 0;
}

static void clr_broad_info(void)
{
    _rtparas.state &= (~STABROAD);
}

void clr_zjbroad_info(void)
{
    _rtparas.wkstate &= (~ZJREG);
}

int rf_start_broadcast(unsigned char data[], int data_len, unsigned char type, int time)
{
    int len, rtlen, i;
    unsigned char buf[0x100], rtframe[255];

    if((0 == _rtparas.flood) && (0x80 != type) && (0x81 != type))
      return(0);

    for(i = 1; i < data_len; i++)
      data[i] += 0x33;

    if(0x81 == type)
      len = nl_paratask_read(&buf[0], time, &data[0], data_len, type);
    else
      len = nl_paratask(&buf[0], time, &data[0], data_len, type);
    if(len < 0)
      return(-1);

    nl_frm38(NLT_PARL, &buf[0], len, rtframe, &rtlen, PLC_DC);
    nl_rtwrite(fd, rtframe, rtlen, 0);
    mdelay(800);
    nl_rtwrite(fd, rtframe, rtlen, 0);
    watchdog();
    mdelay(800);
    nl_rtwrite(fd, rtframe, rtlen, 0);

    if((0x80 != type) && (0x81 != type))
      {
      _rtparas.state |= STABROAD;
      alloc_a_timer(TIMER_DRD_OVER, 12 * 60000, 12 * 60000, clr_broad_info);
      }
     else if((0x80 == type) || (0x81 == type))
     {
      _rtparas.wkstate |= ZJREG;
      alloc_a_timer(TIMER_CLR_ZJBRD, time * 60000, time * 60000, clr_zjbroad_info); 
     }
    return(0);
}

extern unsigned char appgb_reg_v; 
extern unsigned char flag_reg_v; 
static void rf_stopreg()
{
  _task.flag = TSNO;
  ses_set_search_time(0);  /* V�����ѱ�ʱ�� */
  flag_reg_v = 0; 
  _rtparas.state &= ~STARMASK;
  _rtparas.state &= ~STAMMASK;
  appgb_reg_v = 1; 
  set_rts_value(CHN_38_1, 1);
}
static void stop_parabroad()
{
  if(_rtparas.flood)
  {
    del_a_timer(0x1000);
    _rtparas.state &= (~STABROAD);
  }
}

extern unsigned int flag_rf_areset_eeprom;
#if 0
static void rf_areset(unsigned char second)
{
  if (rf_isstop() != 0)
    {
      _rtparas.slevel |= 0x80; /* auot run after reset */
      eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), &_rtparas.slevel, sizeof(_rtparas.slevel));

      flag_rf_areset_eeprom++;
    }
  ++_rtparas.areset; /* auto reset times */
  eeprom_write(DBPBEGIN + offset(struct rtpara, areset), &_rtparas.areset, sizeof(_rtparas.areset));

    flag_rf_areset_eeprom++;
    
  rf_reset(second);

  return;
}
#endif
/**
�����Լ�һ��
����ֵ    0��û�д���
          -1������Ϣ��һ��
**/
int quick_self_check()
{
  struct mtinfo mt;
  unsigned short addr, end, id_repeat_num, index = 0;
  int bytepos = 0,bitpos = 0;
  struct hmtcell **idtab;
  struct hmtcell *p;
  unsigned char quick_sno[1600];

  memset(quick_sno, 0x00, 1600);
  addr = DBBEGIN;
  end  = DBEND;
  idtab = db_get_idtab();
  while (addr < end)
    {
      db_read(addr, (unsigned char *)&mt.node, CELL);  //ǰ���и�ֵ�����ø�
      if ((mt.node.attr & CELLMASK) == MTFLAG)
      {
        if (addr % 0x10 != 0x00) /* some error occur */
        {
          addr += CELL;
          continue;
        }
        db_read(addr + CELL, (unsigned char *)&mt.node + CELL, CELL);  //ǰ���и�ֵ�����ø�
        if(addr == DBBEGIN)
          if((memcmp(mt.node.id, sinkidno, IDLEN) !=0) || (memcmp(mt.node.sno, sinksno, SNOLEN) !=0))
            return -1;
        index = (mt.node.sno[1]) * 0x70 + (mt.node.sno[0] & 0x7F);
        bytepos = index / 8;
        bitpos = index % 8;
        if((mt.node.sno[1] == 0x00) && (mt.node.sno[0] == 0x7D))
        {
          if((quick_sno[1599] & (0x01<<7)) != 0)
            return -1;
          else
            quick_sno[1599] |= (0x01<<7);
        }
        else
        {
          if((quick_sno[bytepos] & (0x01<<bitpos)) !=0 )
            return -1;
          else
            quick_sno[bytepos] |= (0x01<<bitpos);
        }
      }
      else if ((mt.node.attr & CELLMASK) == RPFLAG)
        break;
      else
      {
        addr += CELL * MTCN; /* idnode occupy 2 database cell */
        watchdog();
        continue;
      }
      /* check ID */
     id_repeat_num = 0;
     size_t pos = db_find_pos(mt.node.id, IDLEN);
     for (p = idtab[pos]; p; p = p->next)
     {
       if (memcmp(p->hcell.node.id, mt.node.id, IDLEN) == 0)
       {
         id_repeat_num++;
         if(memcmp(p->hcell.node.sno, mt.node.sno, SNOLEN) != 0)
           return -1;
       }

       if(id_repeat_num >= 2)//�ñ����ڹ�ϣ���г��ֶ��
         return -1;
     }

     if(id_repeat_num == 0)//��ϣ����û�иñ�
       return -1;

     addr += CELL * MTCN; /* idnode occupy 2 database cell */
       watchdog();
    }
  if((quick_sno[1599] & (0x01<<7)) == 0)
    return -1;
  return 0;
}

int rf_get38info(unsigned char *send, unsigned char slen, unsigned char *recv, unsigned char *rlen)
{
 return nl_getlinfo(send, slen, recv, rlen);
}

int rf_comm38_645(int fd, unsigned char *send, size_t slen, unsigned char *recv, size_t *rlen)
{
 return plc_comm_645(fd, send, slen, recv, rlen);
}

void rf_set_srelay(unsigned char srelay)
{
  _rtparas.srelay = srelay;
}

int rf_get_srelay()
{
  return _rtparas.srelay;
}

int rf_set_dispflag()
{
  _task.minfo.state |= STDISPCOMM;
  return 0;
}

int rf_set_dispbd()
{
  _rtparas.wkstate |= DISPBROAD;
  return 0;
}

extern unsigned int flag_rf_set_rdswitch_eeprom;
int rf_set_rdswitch(unsigned char *data)
{
  int appgb_cfm(unsigned short wait);

  eeprom_write(DBSHARE + offset(struct share, flag), data, 1);//43Ĭ������ģʽ
  if ((data[0] != 0x55) && (data[0] != 0x57))  //��������ģʽֱ����eepromд
    return 0;
  
  _share.conswitch = 0x0c;
  _share.flswitch = 0x0c;
  _share.plswitch = 0x0c;

  if(*data & 0x01)                      /*����ʽ����*/
    _share.conswitch |= 0x01;

  if(*data & 0x02)
    _share.flswitch |= 0x01;

  if(*data & 0x04)
    _share.plswitch |= 0x01;

  if(*data & 0x08)
  {
    _share.conswitch |= 0x02;
    _share.plswitch |= 0x02;
    _share.flswitch |= 0x02;
  }

  if(*data & 0x80)
  {
    _share.conswitch |= 0x20;
    _share.plswitch |= 0x20;
    _share.flswitch |= 0x20;
  }

  if(*data & 0x10)
  {
    _share.conswitch |= 0x10;
    _share.plswitch |= 0x10;
    _share.flswitch |= 0x10;
  }

  if (*data & 0x20)//֮ǰ����ΪIII����4�����л����������ϵ��Ƿ���DPSK����
  {
      _share.flswitch |= 0x40;//��λΪ1������FSK����
  }
  else
  {
      _share.flswitch &= (~0x40); //��ΪΪ0��·������Ӧ����
  }
  if((*data & 0x40) == 0)
    _share.rt_ctrl |= 0x01;
  else
    _share.rt_ctrl &= ~0x01;
  eeprom_write(DBSHARE + offset(struct share, conswitch), &_share.conswitch, 1);
  eeprom_write(DBSHARE + offset(struct share, flswitch), &_share.flswitch, 1);
  eeprom_write(DBSHARE + offset(struct share, plswitch), &_share.plswitch, 1);
  eeprom_write(DBSHARE + offset(struct share, rt_ctrl), &_share.rt_ctrl, 1);
  
  flag_rf_set_rdswitch_eeprom++;

  /*ģʽ�л�*/
//if (*data & 0x20)
//{
//    appgb_cfm(3);
//    mdelay(200);
//    setmode_iv();  //delay 3.2s
//    reset_to_main();                      /*3-��������4-����*/
//
//    return 0;
//}

  appgb_cfm(0);
  return 0;
}

int rf_get_rdswitch(unsigned char *data, int *len)
{
  
  eeprom_read(DBSHARE + offset(struct share, flag), &data[0], 1);//43Ĭ������ģʽ
  if ((data[0] != 0x55) && (data[0] != 0x57))  //��������ģʽֱ�Ӵ�eeprom��
    {
      *len = 1;
      return 0;
    }
  
  data[0] = 0;
  if(_share.conswitch & 0x01)
    data[0] |= 0x01;

  if(_share.flswitch & 0x01)
    data[0] |= 0x02;

  if(_share.plswitch & 0x01)
    data[0] |= 0x04;

  if(_share.flswitch & 0x02)
    data[0] |= 0x08;

  if(_share.flswitch & 0x10)
    data[0] |= 0x10;
  if (0x40 == (_share.flswitch & 0x40))
  {
      data[0] |= 0x20;
  }
  if(is_rt_mode_fixed() >= 0)
    {
    data[0] |= 0x40;
    }

  if(_share.flswitch & 0x20)
    data[0] |= 0x80;
  
  *len = 1;

  return 0;
}
#if 0
int rf_set_newgb(unsigned char newgb)
{
    if (newgb != NEW_GBPRO && newgb != OLD_GBPRO)
        return -1;
    if ((_share.rt_ctrl & 0x02) == 0) /*Э��ģʽ������������*/
        return 0;
    if (_share.version == newgb)
        return 0;

    _share.version = newgb;
    eeprom_write(DBSHARE + offset(struct share, version), &_share.version, 1);
    return 0;
}
#endif
int rf_get_jzqid_nw(unsigned char *data, int *datalen)
{
    memcpy(data, _rtparas.jzqid_nw, 6);
    *datalen = 6;

    return 0;
}


int rf_getappd(unsigned char *data, unsigned char *dlen)
{
    *dlen = _appdata_bk.itelLen;
    memcpy(data, _appdata_bk.itemBk, _appdata_bk.itelLen);

    return _appdata_bk.itelLen;
}
void rf_set_appd_bk(unsigned char *data, unsigned int dlen)
{
    memcpy(_appdata_bk.itemBk, data, dlen);
    _appdata_bk.itelLen = dlen;
}

void set_mt_cm1suc_flag(unsigned char bcdid[])
{
    struct mtinfo *mt;
    unsigned char aid[6];
    memcpy(aid, bcdid, 6);
    id_bcdtobin(aid);

    if ((mt = db_find(aid)) != NULL)
    {
        if ((mt->node.succhops & NSMASK) == NSUCC)//ֻ�г����ɹ�����ɾ����ʱ��Ž�����Ҫ�����ı�־��1
        {
            mt->node.envi |= NCMD1SUC;  //��ǰ����û����db_write�ĵ���
        }
    }
}
void clear_mt_cm1suc_flag(unsigned char bcdid[])
{
    struct mtinfo *mt;
    unsigned char aid[6];
    memcpy(aid, bcdid, 6);
    id_bcdtobin(aid);
    reverse(aid, 6);
    if ((mt = db_find(aid)) != NULL)
    {
        mt->node.envi &= ~NCMD1SUC;  //��ǰ����û����db_write�ĵ���
    }
}
//type =0, ��1��type>0,����Ӧ�Ĵ���
void set_mt_task_fail_times(unsigned char bcdid[], unsigned char type)
{
    struct mtinfo *mt;
    unsigned char aid[6];
    memcpy(aid, bcdid, 6);
    id_bcdtobin(aid);
    reverse(aid, 6);
    if ((mt = db_find(aid)) != NULL)
    {
        if (type == 0)
        {
            if (mt->tmout_tims > 0)
            {
                mt->tmout_tims--;
            }
        }
        else
        {
            mt->tmout_tims += type;
        }
    }
}
int is_task_pri_need_higher(unsigned char bcdid[])
{
    struct mtinfo *mt;
    unsigned char aid[6];
    unsigned char thresh;
    memcpy(aid, bcdid, 6);
    id_bcdtobin(aid);
    reverse(aid, 6);
    if ((mt = db_find(aid)) != NULL)
    {
        thresh = (mt->tmout_tims & TTIMESTHMASK) >> 4;
        if ((mt->tmout_tims & TTIMESMASK) >= thresh)
        {
            mt->tmout_tims &= ~TTIMESMASK;
            mt->tmout_tims &= ~TTIMESTHMASK;
            mt->tmout_tims |= (TASK_TFTIMES<<4);//���˳�ʼ������ʱ����1�����涼��2��
            return 0;
        }
        else
        {
            return -1;
        }
    }
    return -1;
}


int get_suc_mt_ratio()
{
    int ratio = 0;
    int valnum = get_vlaid_tick_num(TICK_PASS_12H); //12Сʱ֮�ڵ�����
    if (_rtparas.mtnum > 0)
    {
        ratio = (valnum * 10) / _rtparas.mtnum;
    }

    return ratio;
}

void node_rd_min_tick(void)
{
    struct mtinfo *mt;

    db_trav_reset(CHAN_TMP);
    while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
        if (mt->rdtick > 0)
        {
            mt->rdtick--;
        }
        if ((mt->rdtick < TICK_PASS_12H) && _rtparas.dbfirst == 0)
        {
            mt->node.phase &= (~NPDTMASK);//clear dev type  //��ǰ����û����db_write�ĵ���
        }

    }
}

int get_vlaid_tick_num(int tick)
{
    int num = 0;
    struct mtinfo *mt;

    db_trav_reset(CHAN_TMP);
    while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
        if (mt->rdtick > tick)
        {
            num++;
        }
    }

    return num;
}

// -1 ,fsk  -2,unknow dpsk or fsk,0 dpsk
int is_mlist_all43(struct mtlist *mlist,int num)
{
    struct mtinfo *mt;
    unsigned char mnode[] = {0x7d, 0x00};
    unsigned char brd[] = {0x7f,0x00};


    for (int i = 0; i < num; i++)
    {
        if (mlist[i].state == SNOLEN)
        {
            if (0 == memcmp(mlist[i].id, mnode, SNOLEN)
                || 0 == memcmp(mlist[i].id, brd, SNOLEN))
            {
                continue;
            }

            mt = db_find_sno(mlist[i].id);
        }
        else if (mlist[i].state == IDLEN)
        {
            mt = db_find(mlist[i].id);
        }
        else
        {
            return  -1;
        }
        if (mt == NULL)
        {
            return -2;
        }

        if ((mt->node.phase & NPDTMASK) == NPDTUN)
        {
            return -2;
        }
        else if ((mt->node.phase & NPDTMASK) == NPDTN43)//must fsk
        {
            return -1;
        }
    }
    return 0;
}

void chek_list_set_modu(int val)
{
    _nl_type &= ~FRMLISTMASK; /*���list node type mask */
    _nl_type |= FRMLISTVAL;  /*LIST ��Ч*/
    if (val >= 0)
    {
        _nl_type |= FRMLIST43;
    }
    else if (val == -1)
    {
        _nl_type |= FRMLISTN43;
    }
    else if (val == -2)
    {
        _nl_type |= FRMLISTUNK;
    }
    return;
}
struct print_info
{
    unsigned char header[2];
    unsigned char rtstate;
    unsigned char stage;
    unsigned char stage_info;
    unsigned char stage_state;

    struct
    {
        unsigned char state; /* bit7: in database - 0, not - 1 */
        /* bit6: 1 - (cmd = 1), 0 - (cmd != 1) */
        /* bit5: 1 - cmd = 6 && app = default */
        /* bit4: 1 - is phase check, 0 - not */
        unsigned char reqcnt; /* request count, used in broad operation */
        unsigned char failcnt; /* count of continuous failure */
        unsigned char retcnt; /* count of return data */
        unsigned char dlytm; /*0x00 - dont request dlytm, 0x01 - request*/
        unsigned char id[IDLEN];
        struct mtinfo *mt;
    } opt;
    struct mtnode node;

    unsigned short tid;
    unsigned char t_id[IDLEN];
    unsigned short time;

};


void print_cur_task_info(void)
{
#if 0  
    unsigned char buf[255];
    struct mtnode *pnode;
    memset(buf, 0x00, sizeof(buf));
    struct print_info *pbuf = (struct print_info *)buf;

    pbuf->header[0] = 0xFE;
    pbuf->header[1] = 0xFE;
    pbuf->rtstate = _rtparas.state;
    stage = pbuf->stage = _rtparas.stage;
    pbuf->stage_info = _task.info[0];

    memcpy(&pbuf->opt.state, &_task.ml.opt.state, sizeof(pbuf->opt));
    memcpy(&pbuf->node.attr, pbuf->opt.mt, sizeof(struct mtnode));


    get_nwtask_tic_aid(&pbuf->tid, &pbuf->time,&pbuf->t_id);
    rf_write(buf, sizeof(struct print_info),0 );
#endif
}

void snd_phs_tick(void)
{
   #if 0
   extern unsigned char local_viv_swi;
   if (_rtparas.sndphstick > 0)
    {
       _rtparas.sndphstick--;
    }


    if ((_rtparas.sndphs & PHSSINGMASK) == PHSSNDING) 
    {
      if (_rtparas.sndphstick == 0) 
      {
        
        _rtparas.sndphstick = 60 * 60;
      }
      return;
    }

    if (_rtparas.sndphstick == 0)
    {
      _rtparas.sndphstick = SNDPHSTIME;
      if (((is_node_v_phs_brd() >= 0)) && (local_viv_swi != 1))
      {
        _rtparas.sndphs &= ~PHSNEEDSMASK;
        _rtparas.sndphs |= PHSNEEDSND;
      }
    }
    #endif
}

//���ñ���Լ���� type =0����ַΪbcd��type =1,��ַΪbin
void set_mt_pro(unsigned char *id,unsigned char type,unsigned char pro)
{
   // unsigned char nodepro;
    struct mtinfo *mt;
    unsigned char aid[IDLEN];

    memcpy(aid, id, 6);
    if (type == 0)
    {
        id_bcdtobin(aid);
        reverse(aid, 6);
    }
    if ((mt = db_find(aid)) != NULL)
    {
      //  nodepro = (mt->node.attr & NPROMASK)>>1;
      //  if (nodepro != PHS_PRO_188)//ֻ���·�188
        {
            mt->node.attr &= ~NPROMASK;  //��ǰ����û����db_write�ĵ���
            mt->node.attr |= pro << 1;
        }
    }
}
//0 need  -1 no
int is_node_need_phs_brd(void)
{
    struct mtinfo *mt;
    int ret = -1;

    db_trav_reset(CHAN_TMP);
    while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
        if ((mt->node.succhops & NSMASK) == NSUCC) //�����ɹ���������λ��Ϣ�����ڣ�������Ҫ���͹㲥��λ����
        {
            if ((mt->node.phase & NPAMASK) == 0) //��λ��Ϣ������
            {
                ret = 0;
                break;
            }
        }

    }
    return ret;

}

//0 need  -1 no
int is_node_v_phs_brd(void)
{
  struct mtinfo *mt;
  int ret = -1;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    if ((((mt->node.viv & NNDMASK) == NND53) || (mt->node.viv & NNDMASK) == NND55)) //�����ɹ���������λ��Ϣ�����ڣ�������Ҫ���͹㲥��λ����
    {
      if ((mt->node.phase & NPAMASK) == 0) //��λ��Ϣ������
      {
        printf_s("v dai no phase!!!\n");
        ret = 0;
        break;
      }
    }
  }
  return ret;

}

int get_cur_cyc_dctime(void)
{
    int rat = get_suc_mt_ratio();
    return dctime[rat];
}
void chk_to_fast_task_stage(void)
{
    _rtparas.dctask = 1;
    // _rtparas.dcmin = get_cur_cyc_dctime();
    _rtparas.dcnum = get_vlaid_tick_num(TICK_PASS_12H); //12Сʱ֮�ڵ�����();
    _rtparas.dcmin = DCTASK_TIMEOUT;
    _rtparas.cyctime = MAX_FAST_STAGETIME;

}
void fast_task_tick(void)
{
    if (_rtparas.dcmin > 0)
    {
        _rtparas.dcmin--;
    }
    if (_rtparas.cyctime > 0)
    {
        _rtparas.cyctime--;
    }
    if (_rtparas.dcmin == 0 || _rtparas.cyctime == 0)//������ʱ����������ʱ
    {
        _rtparas.dctask = 0;
        _rtparas.dcnum = 0;
    }
}

void set_iiireg_left(unsigned int time)
{
  _rtreport.left = time;
}
