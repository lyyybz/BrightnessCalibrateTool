/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage3.c
 *
 * Description: Route study stage3
 *
 * Version: v1.0
 * Time:    2010-1-12
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

#define MINRANDOM 8

extern int fd;

static void s3_list(struct stage3 *s3p);
static int listnext(struct stage3 *s3p);

extern unsigned char local_viv_swi;
void stage3()
{
  struct stage3 *s3p = (struct stage3 *) _task.info;

  if ((s3p->info & S3TMASK) == S3TINIT) /* Initalize */
    {
      //printf_s("stage 3: S3TINIT!\n");
      db_trav_reset(CHAN_RT1);
      db_trav_reset(CHAN_RT2);
      memset(&_task, 0x00, sizeof(struct task));
      listnext(s3p);
    }
  if ((s3p->info & S3TMASK) == S3TLIST) /* */
    s3_list(s3p);
}

static void mtlist_add(struct mtinfo *mt)
{
#if 0
  if ((_rtparas.state & STASMASK) == STAALLSNO)
    {
      memcpy(_task.ml.list[_task.ml.num].id, mt->node.sno, SNOLEN);
      _task.ml.list[_task.ml.num].state = SNOLEN;
    }
  else
#endif
    {
      memcpy(_task.ml.list[_task.ml.num].id, mt->node.id, IDLEN);
      _task.ml.list[_task.ml.num].state = IDLEN;
    }

  memcpy(_task.ml.list[_task.ml.num].sno, mt->node.sno, SNOLEN);
  ++_task.ml.num;

}

static int prechkmt(struct stage3 *s3p)
{
  struct rpinfo *rp;
  struct mtinfo *mt;

  s3p->info &= ~S3SMASK;
  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
       if ((mt->node.succhops & NSMASK) == NSUCC)
    continue;
      while ((rp = db_trav_rpnext(CHAN_TMP, CHAN_TDEF)) != NULL)
    {
      if (memcmp(rp->rpid, s3p->famt->node.id, IDLEN) == 0)
        {
          s3p->info |= S3SFAMT;
          return 0;
        }
    }
    }

  return -1;
}

static int chklistmt(struct mtinfo *mt,struct stage3 *s3p)
{
  struct rpinfo *rp;

  if ((mt->node.succhops & NSMASK) == NSUCC)
    return -1;
  if ((_rtparas.mtnum - _rtparas.succnum <= MINRANDOM) &&
      ((s3p->info & S3SMASK) == S3SFAMT))
    return 0;
  while ((rp = db_trav_rpnext(CHAN_RT2, CHAN_TDEF)) != NULL)
    {
      if (memcmp(rp->rpid, s3p->famt->node.id, IDLEN) == 0)
        return 0;
    }

  return -1;
}

static int nextgroup(struct stage3 *s3p)
{
  struct mtinfo *mt;
  unsigned char msg[255];
  int  maxnum = list_maxnode(S3), len, ret = 0;

  _task.flag = TSNO;
  memset(&_task.ml, 0x00, sizeof(_task.ml));
  if (s3p->listmt != NULL)
    {
      mtlist_add(s3p->listmt);
      s3p->listmt = NULL;
    }
  if (_rtparas.mtnum - _rtparas.succnum <= MINRANDOM)
    ret = prechkmt(s3p);
  while ((mt = db_trav_mtnext(CHAN_RT2)) != NULL && ret == 0)
    {
      if (chklistmt(mt, s3p) == 0)
    {
      mtlist_add(mt);
      len = sizeof(msg);
      int ret = nl_listtask2(_rtparas.round, _task.ml.list, &_task.ml.num, msg, &len, TASK2_JUDGE);
      assert (ret == 0);
      if (len > 62 || _task.ml.num > maxnum)
        {
          s3p->listmt = mt;
          _task.ml.num--;
          break;
        }
    }
    }
  if (_task.ml.num == 0)
    return -1;

  return 0;
}

static int listnext(struct stage3 *s3p)
{
  struct mtinfo *mtp = s3p->famt;

  memset(s3p, 0x00, sizeof(struct stage3));
  _task.flag = TSNO;

  if (_rtparas.round == 1)
    {
      if (mtp == NULL)
    {
      s3p->famt = db_find(sinkidno);
      if (task2nds(s3p->famt) == 0 && nextgroup(s3p) == 0)
        {
          s3p->info = S3TLIST; /* LIST */
          return 0;
        }
    }
      rtnext();
    }

  while (_rtparas.stage == S3)
    {
      while ((s3p->famt = db_trav_mtnext(CHAN_RT1)) != NULL)
    {
        if (((s3p->famt->node.succhops & NHMASK) == _rtparas.round - 1) &&
            ((s3p->famt->node.succhops & NSMASK) == NSUCC)
            || (local_viv_swi != 1 && (s3p->famt->node.viv & NNDMASK) != NND53)
            || (((s3p->famt->node.viv & TYPEMASK) >> 3) != NND53)) 
        {
          db_trav_reset(CHAN_RT2);
          if (task2nds(s3p->famt) == 0 && nextgroup(s3p) == 0)
        {
          s3p->info = S3TLIST; /* LIST */
          return 0;
        }
        }
      watchdog();
    }
      rtnext();
    }
  return 0;
}

static int s3_listtask(struct stage3 *s3p)
{
  unsigned char msg[255], frame[255];
  int len = sizeof(frame);
  int ret;

  assert(s3p->famt);
  saveposition(s3p->famt);

  if (nl_listtask2(_rtparas.round, _task.ml.list, &_task.ml.num, msg, &len, TASK2_REAL) != 0)
    return -1;
  ret = is_mlist_all43(_task.ml.list, _task.ml.num);
  chek_list_set_modu(ret);

  nl_frm38(NLT_NORMAL, msg, msg[0] + 1, frame, &len, PLC_DC);
  nl_rtwrite(fd, frame, len, 0);
  /* set _task.start and _task.endt */

  _task.flag &= ~(TSMASK | TTMASK);
  _task.flag |= TSRUN | TTPLC;
  _task.start = currtick();

  size_t n = _task.ml.num / 2 & MAXHOPS;
  _task.wait = ((n == 0 ? 1 : n) + _rtparas.round) * (MAXHOPTM / 2);

  return 0;
}

static int s3_listprocess(struct stage3 *s3p)
{
  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (nl_listprocess(_task.ml.num, _commbuf.plc.buf, (_commbuf.plc.buf[0] & 0x3F) + 1,
             _task.ml.list) != 0)
    return -1;
      if (touchnum() == 0x00)
    return nextgroup(s3p);
      else
    {
      touchmt(s3p->famt); /* append repead */
          if (_rtparas.round == 1)
            _ndscont.num--;
      s3p->info |= S3MONIT; /* monit */
      _task.flag = TSNO;
#ifdef _DEBUG
      printf("stage3 M\n"); /* for test !! */
#endif
      return 0;
    }
    }
  return -1;
}

static void s3_list(struct stage3 *s3p)
{
//  printf_s("stage 3: S3TLIST!\n");
  if ((_task.flag & TSMASK) == TSRUN)
    return;

  if ((s3p->info & S3MMASK) == S3MONIT) /* monit */
    {
      if (monittask() == 0)
    return;
      s3p->info &= ~S3MMASK;
      if (_rtparas.round == 1)
    task2nds(s3p->famt);
      if (nextgroup(s3p) != 0)
    listnext(s3p);
    }

  while ((s3p->info & S3TMASK) == S3TLIST && (s3p->info & S3MMASK) == 0 ) /* broad */
    {
      if ((_task.flag & TSMASK) == TSNO)
    {
      if (s3_listtask(s3p) == 0)
        {
#ifdef _DEBUG
          printf("stage3 list\n"); /* fot test !! */
#endif
          break;
        }
      listnext(s3p); /* not occur */
    }
      else
    {
      if (s3_listprocess(s3p) != 0) /* 0: next group or start monit */
        listnext(s3p);
    }
    }
}


