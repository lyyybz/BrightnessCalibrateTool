/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage1.c
 *
 * Description: Route confirm stage1
 *
 * Version: v1.0
 * Time:    2010-1-12
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

extern unsigned char local_viv_swi;
void stage1()
{
  struct stage1 *s1p = (struct stage1 *) _task.info;

  if ((s1p->info & S1TMASK) == S1TINIT)/* Initalize */
    {
      //printf_s("stage 1: S1TINIT!\n");
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s1p->info &= ~S1TMASK;
      s1p->info |= S1TNDS;
    }

  if ((s1p->info & S1MMASK) == S1MONIT) /* monit */
    {
//      printf_s("stage 1: S1MONIT!\n");
      if (monittask() == 0)
    return;
      s1p->info &= ~S1MMASK;
      _task.flag = TSNO;
    }
  //printf_s("stage 1: work!\n");
  struct mtinfo *mt = s1p->destmt;
  for (; ;)
    {
      if (s1p->destmt == NULL)
    {
      if ((mt = db_trav_mtnext(CHAN_RT1)) == NULL)
        break;
    }
      if ((mt->node.succhops & NSMASK) == NSUCC ||
          ((mt->node.succhops & NHMASK) != _rtparas.round)
          || (local_viv_swi != 1 && (mt->node.viv & NNDMASK) == NND53)
          || (((mt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)) 
    {
      s1p->destmt = NULL;
      continue; /* success meter */
    }
      s1p->destmt = mt;

      saveposition(mt);

      /* plough nds */
      struct rpinfo *rp;
      while ((rp = db_trav_rpnext(CHAN_RT1, CHAN_TDEF)) != NULL)
    {
      memset(&_ndscont, 0x00, sizeof(_ndscont));
      if (ploughpath(rp) == 0x00)
        {
          s1p->farp = rp;
          ndsrevers(&_ndscont);
          break;
        }
    }

      if (rp == NULL)
    s1p->destmt = NULL; /* next meter */
      else
    {
      _task.flag &= ~TSMASK;
      s1p->info |= S1MONIT;
      memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
      if (s1p->destmt->node.sno[0] & NNEWMASK)
        {
          _task.ml.list[0].state = (IDLEN | LTOUCH);
          memcpy(_task.ml.list[0].id, s1p->destmt->node.id, IDLEN);
        }
      else
        {
          _task.ml.list[0].state = (SNOLEN | LTOUCH);
          memcpy(_task.ml.list[0].id, s1p->destmt->node.sno, SNOLEN);
        }
#ifdef _DEBUG
      printf("stage1 M\n"); /* for test !! */
#endif
      break;
    }
    }

  if (s1p->destmt == NULL)
    rtnext();
}
