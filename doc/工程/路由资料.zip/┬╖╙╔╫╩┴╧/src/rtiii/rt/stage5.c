/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All rights reserved
 *
 * File name: stage5.c
 *
 * Description: Route optimize stage5
 *
 * Version: v1.0
 * Time:    2010-1-14
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rt.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"

#define MAXRPNUM 4
#define OVERRPNUM 5

static int stage5_0(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_1(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_2(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_3(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_4(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_50(unsigned char rpnum, struct rpinfo *rp, unsigned char *rpovernum, struct rpinfo *rpover[]);
static int stage5_51(struct mtinfo *mtp, unsigned char num, struct rpinfo *rp[]);
static int stage5_6(unsigned char rpnum, struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_7(struct mtinfo *mtp, struct rpinfo *rp);
static int stage5_8(struct mtinfo *mtp, struct rpinfo *rp);

extern unsigned int flag_stage5_eeprom;
void stage5()
{
  //printf_s("stage 5!\n");
  db_trav_reset(CHAN_RT3);  /* initialize */

  struct mtinfo *mtp = NULL;
  while (mtp = db_trav_mtnext(CHAN_RT3))
    {
      while (1)
	{
	  struct rpinfo *rpover[OVERRPNUM - MAXRPNUM], *rp; /* rp to random delete */
	  unsigned char rpnum = 0, rpovernum = 0, delflag = 1;
          
	  db_trav_rpreset(CHAN_RT3);
          for (; ;)
	    {
              delflag = 1;
	      if ((rp = db_trav_rpnext(CHAN_RT3, CHAN_TALL)) == NULL)
                {
                  delflag = 0;
                  break;
                }
	      
	      if (memcmp(rp->rpid, mtivd, IDLEN) == 0) /* invalid */
		{
		  if(stage5_0(mtp, rp) == 0) /* invalid && empty addr */
		    break;
		  continue;
		}
	      if (stage5_7(mtp, rp) == 0) /* mt = new meter, delete */
		break;
	      if (stage5_1(mtp, rp) == 0) /* rpid not exist, delete */
		break;
              if (stage5_8(mtp, rp) == 0) /* rp = new meter, delete */
		break;
	      if (stage5_2(mtp, rp) == 0) /* fail times > 16, delete */
		break;
	      if (stage5_3(mtp, rp) == 0) /* wrkno = 8, success times = 0, delete */
		break;
	      if (stage5_4(mtp, rp) == 0) /* rp.depth > node.depth + 1, delete */
		break;                

	      ++rpnum;
	      stage5_50(rpnum, rp, &rpovernum, rpover); /* save to rpover */
	      if (stage5_6(rpnum, mtp, rp) == 0) /* rp number > overrpnum, delete directly */
		break;
	    }
          
	  if (delflag == 0) /* over */
	    {
	      stage5_51(mtp, rpovernum, rpover); /* rp number > maxrpnum, random delete */
              if (rpnum == 0 && (mtp->node.sno[0] & NNEWMASK) == 0)
		{
		  mtp->node.succhops = 0x00;
		  mtp->node.sno[0] |= NNEWMASK; /* set new meter */
		  db_write(mtp->addr + offset(struct mtnode, succhops), &mtp->node.succhops,
			   sizeof(mtp->node.succhops));
		  db_write(mtp->addr + offset(struct mtnode, sno), mtp->node.sno, SNOLEN);
      
       flag_stage5_eeprom++;
      
		}
	      break;
	    }
	  /* continue, delete from head */
	}
      watchdog();
    }

  if(_rtparas.datainit == 0xFA)
  {
    db_flush();
    _rtparas.datainit = 0x00;
  }
  nextstage();
}

static int stage5_0(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);

  if (rp->addr == EMPADDR && memcmp(rp->rpid, mtivd, IDLEN) == 0) /* invalid && empty addr*/
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}

static int stage5_1(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);
  
  if (db_find(rp->rpid) == NULL)
    return db_delrp(mtp->node.id, rp->rpid); /* need to modify hash_delrp() if rp.addr is null */
  return -1;
}

static int s5_maxtms(unsigned char hops)
{
  if (hops <= 3)
    return 16;
  return 8;
}

static int stage5_2(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);
  struct mtinfo *rpp = db_find(rp->rpid);
  assert(rpp);
  
  unsigned char hops = (rpp->node.succhops & NHMASK);

  if (rp->node.failtms >= s5_maxtms(hops))
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}

static int stage5_3(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);

  if ((mtp->node.succhops & NHMASK) > 1 && _rtparas.wrktms == 8 && rp->node.succtms == 0)
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}

static int stage5_4(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);
  
  struct mtinfo *mt = db_find(rp->rpid);
  assert(mt);

  if ((mtp->node.succhops & NHMASK) + 1 < (mt->node.succhops & NHMASK))
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}

static int stage5_50(unsigned char rpnum, struct rpinfo *rp, unsigned char *rpovernum, struct rpinfo *rpover[])
{
  if (rpnum <= MAXRPNUM)
    return -1;
  if (rpnum <= OVERRPNUM && *rpovernum < OVERRPNUM - MAXRPNUM)
    {
      rpover[*rpovernum] = rp;  /* random delete, add to rpover */
      ++(*rpovernum);
    }

  return 0;
}

static int stage5_51(struct mtinfo *mtp, unsigned char num, struct rpinfo *rp[]) /* random delete */
{
  for (int i = num - 1; i >= 0; --i) /* from tail */
    {
      if (gainrand() < MINRANDOM * 2)
        db_delrp(mtp->node.id, rp[i]->rpid);
    }
  return 0;
}

static int stage5_6(unsigned char rpnum, struct mtinfo *mtp, struct rpinfo *rp)
{
  if (rpnum > OVERRPNUM)
    return db_delrp(mtp->node.id, rp->rpid);

  return -1;
}

static int stage5_7(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);

  if (mtp->node.sno[0] & NNEWMASK)
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}

static int stage5_8(struct mtinfo *mtp, struct rpinfo *rp)
{
  assert(mtp);
  assert(rp);
  
  struct mtinfo *mt = db_find(rp->rpid);
  assert(mt);
  
  if (mt->node.sno[0] & NNEWMASK)
    return db_delrp(mtp->node.id, rp->rpid);
  return -1;
}
