/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage9.c
 *
 * Description: Route confirm stage9
 *
 * Version: v1.0
 * Time:    2012-4-5
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/rt/rt.h"

static int s9next(struct stage9 *s9p);

void stage9()
{
  struct stage9 *s9p = (struct stage9 *) _task.info;
  
  if ((s9p->info & S9TMASK) == S9TINIT) /* Initalize */
    {
      db_trav_reset(CHAN_RT1);
      memset(&_task, 0x00, sizeof(_task));
      s9p->info &= ~S9TMASK;
      s9p->info |= S9TNDS;
    }

  if ((s9p->info & S9MMASK) == S9MONIT) /* monit */
    {
      if (s9_monittask() == 0)
	return;
      s9p->info &= ~S9MMASK;
      _task.flag = TSNO;
    }

  while (1)
  {
    if (s9p->destmt == NULL && s9next(s9p) != 0)
      return;
    memset(&_ndscont, 0x00, sizeof(_ndscont));
    if (s9_ploughpath(s9p->destmt) == 0x00)
    {
      _task.flag &= ~(TSMASK | TTMASK);
      s9p->info |= S9MONIT;
      memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
      _task.ml.list[0].state = IDLEN + LTOUCH;
      memcpy(_task.ml.list[0].id, s9p->destmt->node.id, IDLEN);
      s9p->destmt = NULL;
      
      return;
    }
    s9p->destmt = NULL;
  }
  
//  nextstage();
  
}

static int s9next(struct stage9 *s9p)
{
  struct mtinfo *mt;
  int num = 0;
  
  while ((mt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if ((mt->node.sno[0] & NNEWMASK) || (mt->node.succhops & NHMASK) == _rtparas.round )
    {
      s9p->destmt = mt;
      return 0;
    }
  }

  db_trav_reset(CHAN_RT1);
  while ((mt = db_trav_mtnext(CHAN_RT1)) != NULL)
  {
    if ((mt->node.succhops & NHMASK) == 0x01) /*ֱ������������1�򲻽����м̳���*/
      ++num;
  }
  
  s9p->info &= ~S9TMASK;
  if(num > 1)
    _rtparas.round = 1;
  else
  {
   ++_rtparas.round;
  if (_rtparas.round > _rtparas.maxround + 1 || _rtparas.round > 0x08)
    _rtparas.round = 1;
  }
  
  return -1;
}