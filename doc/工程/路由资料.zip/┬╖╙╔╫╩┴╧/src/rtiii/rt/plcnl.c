/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: nl.c
 *
 * Description: Network Layer
 *
 * Version: v1.0
 * Time:    2009-12-17
 *
 */

#include <time.h>
#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/eeprom.h"
#include "../include/dev/uart.h"
#include "../include/db/bm.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rt.h"
#include "../include/rt/rtast.h"
#include "shell.h"
#include "router.h"
#include "aupd.h"
#ifndef  _LINUXPC
#include "dev_ctrl.h"
#endif
#include "tp.h"
#include "nwtask.h"
#pragma pack(1)
struct net_msg_head
{
    unsigned char len;
    unsigned char tnosdd;
    unsigned char cmdscd;
    unsigned char strhpd; /* sqn tkn rpl */
    unsigned char dutypln;
    unsigned char sinkid[2];
};

struct net_tno6_head
{
    unsigned char len;
    unsigned char tnocmd;
    unsigned char snohpd;
    unsigned char left;
    unsigned char sddfhq;
};

struct net_tno5_head
{
    unsigned char len;
    unsigned char tnocmd;
    unsigned char sddrsv;
    unsigned char left;
};

struct net_tno5_head_IV
{
    unsigned char len;
    unsigned char tnocmd;
    unsigned char rsvsno;
    unsigned char sddhpd;
    unsigned char left;
    unsigned char fhqndt;
    unsigned char rsvpha;
};

struct net_ivinfo
{
    unsigned char sendctrl;
    unsigned char rsv1;
    unsigned char rsv2;
    unsigned char rsv3;
    unsigned char hllctrl;
    unsigned char lllctrl;
    unsigned char macctrl;
    unsigned char sigq;
};

struct prtcl
{
    unsigned char type; /* type of protocol */
    /* check function of protocol */
    int (*check)(unsigned char *frame, int len, int *begin, int *end);
    /* protocol process */
    int (*proc)(unsigned char *frame, int len);
};

struct nlproc
{
    unsigned char type;
    int (*proc)(unsigned char *frame, int len);
};

#define TNOMASK 0xE0
#define SDDMASK 0x1F
#define CMDMASK 0xE0
#define SCDMASK 0x1F
#define ASWMASK 0x20
#define BITSQN 0x80
#define BITTKN 0x40
#define BITRPL 0x20
#define HPDMASK 0x1F
#define BITMNT 0x80
#define BITACK 0x40
#define BITASW 0x20
#define PLNMASK 0x1F
#define BITFORCE 0x80
#define PHASEMASK 0xC0
//#define STRONGMASK 0x3F
#define STRONGMASK 0x0F
#define DEV43MASK  0x20
#define NETTYPEMASK 0x10
#define TNO5_CMDMASK 0x04
#define TPCM0MASK 0x08
#define TN6HPDMASK 0x0F

#define READ_97 0x01
#define READ_07 0x11

#define TP_APP_EX 0xFF
#define TP_PRO_698 0x03
#define TP_PRO_188 0x00
#define TP_PRO_TRAN 0x00
struct itemlen
{
    int item;
    unsigned char len;
};

static const struct itemlen _ITEMTB07[] =
{
    { 0x01010005, 0x14 }, { 0x01019000, 0x08 }, { 0x040F0004, 0x08 }, { 0x010F0004, 0x08 }, { 0xFF050004, 0x14 },
    { 0x01010004, 0x0A }, { 0x00FF0100, 0X18 }, { 0x00FF0200, 0x18 }, { 0x01FF0100, 0x18 }, { 0x00003003, 0x07 },
    { 0x01003003, 0x0A }, { 0x000D3003, 0x07 }, { 0x010D3003, 0x40 }, { 0x00043003, 0x07 }, { 0x01043003, 0x14 },
    { 0x00053003, 0x07 }, { 0x01053003, 0x0A }, { 0x01013203, 0x06 }, { 0x00019000, 0x08 }, { 0x06013203, 0x08 },
    { 0x00000100, 0x08 }, { 0x00001103, 0x07 }, { 0x00FF0300, 0x18 }, { 0x00FF0400, 0x18 }, { 0x00FF0500, 0x18 },
    { 0x00FF0600, 0x18 }, { 0x00FF0700, 0x18 }, { 0x00FF0800, 0x18 }, { 0x01FF0300, 0x18 }, { 0x01FF0200, 0x18 },
    { 0x01FF0400, 0x18 }, { 0x01FF0500, 0x18 }, { 0x01FF0600, 0x18 }, { 0x01FF0700, 0x18 }, { 0x01FF0800, 0x18 },
    { 0x00FF0101, 0x2C }, { 0x00FF0301, 0x2C }, { 0x00FF0201, 0x2C }, { 0x00FF0401, 0x2C }, { 0x01FF0101, 0x2C },
    { 0x01FF0301, 0x18 }, { 0x01FF0201, 0x18 }, { 0x01FF0401, 0x18 }, { 0x03050004, 0x06 }, { 0x00010113, 0x06 },
    { 0x00010213, 0x06 }, { 0x00010313, 0x06 }, { 0x00020113, 0x07 }, { 0x00020213, 0x07 }, { 0x00020313, 0x07 },
    { 0x01010113, 0x08 }, { 0x01010213, 0x08 }, { 0x01010313, 0x08 }, { 0x01250113, 0x08 }, { 0x01250213, 0x08 },
    { 0x0A008002, 0x08 }, { 0x01010605, 0x08 }, { 0x01020605, 0x08 }, { 0x01040605, 0x08 }, { 0x01050605, 0x08 },
    { 0x01060605, 0x08 }, { 0x01070605, 0x08 }, { 0x01080605, 0x08 }, { 0x01030605, 0x08 }, { 0x01090605, 0x0C },
    { 0x010A0605, 0x0C }, { 0x01023303, 0x06 }, { 0x00029000, 0x09 }, { 0x01063303, 0x09 }, { 0x01063203, 0x09 },
    { 0x00013003, 0x07 }, { 0x01013003, 0x0A }, { 0x00023003, 0x07 }, { 0x01023003, 0x0A }, { 0x00033003, 0x09 },
    { 0x01033003, 0x0A }, { 0x00000000, 0x0A }, { 0x01063003, 0x70 },
};

static const struct itemlen _ITEMTB97[] =
{
    { 0x1090, 0x06 }, { 0x109A, 0x06 }, { 0x1094, 0x06 }, { 0x1098, 0x06 },
    { 0x1F90, 0x16 }, { 0x1F9A, 0x16 }, { 0x1F94, 0x16 }, { 0x1F98, 0x16 },
    { 0x20C0, 0x03 }, { 0x10C0, 0x06 }, { 0x11C0, 0x05 }, { 0x17C1, 0x04 },
    { 0x3AC0, 0x02 }, { 0x3BC0, 0x02 }, { 0x3CC0, 0x02 }, { 0x3DC0, 0x02 },
    { 0x2F90, 0x16 }, { 0x1F91, 0x16 }, { 0x2F91, 0x16 }, { 0x1F95, 0x16 },
    { 0x2F95, 0x16 }, { 0x1F98, 0x16 }, { 0x2F98, 0x16 }, { 0x1F99, 0x16 },
    { 0x2F99, 0X16 }, { 0x2F9A, 0x16 }, { 0x10B2, 0x06 }, { 0x12B2, 0x04 },
    { 0x1190, 0x06 }, { 0x1290, 0x06 }, { 0x1390, 0x06 }, { 0x1490, 0x06 },
    { 0x119A, 0x06 }, { 0x129A, 0x06 }, { 0x139A, 0x06 }, { 0x149A, 0x06 },
    { 0x1194, 0x06 }, { 0x1294, 0x06 }, { 0x1394, 0x06 }, { 0x1494, 0x06 },
    { 0x1198, 0x06 }, { 0x1298, 0x06 }, { 0x1398, 0x06 }, { 0x1498, 0x06 },
    { 0x2090, 0x06 }, { 0x1091, 0x06 }, { 0x2091, 0x06 }, { 0x2094, 0x06 },
    { 0x2095, 0x06 }, { 0x2098, 0x06 }, { 0x1099, 0x06 }, { 0x2099, 0x06 },
    { 0x19C1, 0x06 }, { 0x1AC1, 0x06 },
};

enum nds_type
{
    ALLMETER  = 0x00,
    ALLSNO    = 0x01,
    SNOMETER1 = 0x02,
    METERSNO1 = 0x03,
    METER1SNO = 0x04
};

void DeCompressMeterID(unsigned char meter_num, unsigned char *data, unsigned char *nds, unsigned int *decompresslen);
void CompressMeterID(unsigned char *Meters, int meter_num, unsigned int *ndslength);
static enum nds_type nds_gettype(struct net_msg_head *head);
static int nds_compress(struct ndscont *ndslist, unsigned char *nds, int *ndslen);
static int nds_decompress(enum nds_type type, int num, unsigned char *frame, int framelen,
                          struct ndscont *ndslist, int *ndslen);
static int nds_sort(struct ndscont *unorder_nds);
static void para_compress(unsigned char *meters, int meter_num, unsigned int *ndslength);
static void para_decompress(unsigned char meter_num, unsigned char *data, unsigned char *nds, unsigned int *decompresslen);
static int nl_paratno5(unsigned char *frame, int len, struct para_report *report, struct net_ivinfo *info);
static int nl_paratno6(unsigned char *frame, int len, struct para_report *report, struct net_ivinfo *info);
static int nl_help(unsigned char *frame, int len, struct net_ivinfo *info);

static int nl_check(unsigned char *frame, int len, int *begin, int *end);
static int gb645_check(unsigned char *frame, int len, int *begin, int *end);
static int nl_proc(unsigned char *frame, int len);
static int gb645_proc(unsigned char *frame, int len);

static int nl_normal(unsigned char *frame, int len);
static int nl_error(unsigned char *frame, int len);
// static int nl_paralle(unsigned char *frame, int len);
// static int nl_parallel(unsigned char *frame, int len);
static int nl_confirm(unsigned char *frame, int len);
static int nl_skid(unsigned char *frame, int len);
static int nl_handshake(unsigned char *frame, int len);

static int nl_rand(unsigned char *frame, int len);
static int nl_ivup(unsigned char *frame, int len);
static int report_push(struct para_report *report);

static unsigned char chksum(const unsigned char *data, int len);
static unsigned char chkxor(const unsigned char *data, int len);
unsigned char get_cur_flood_sno(void);

/* V������ */
static int nl_frm_encry(unsigned char *frm, int len);

#ifdef _LINUXPC
static int fd_38 = 3;
#else
static int fd_38 = CHN_38_1;
#endif
#define PRTCL_NL  0x01 /* rt protocol */
#define PRTCL_645 0x02 /* GB376.2 protocol */

struct nlproc nlprocs[] = { { NLT_NORMAL, nl_normal },
    { NLT_ERROR, nl_error },
//    { NLT_PARL, nl_parallel },
//    { NLT_QPARL, nl_paralle },
    { NLT_HANDSHAKE, nl_handshake },
    { NLT_CONFIRM, nl_confirm },
    { NLT_SKID, nl_skid },
    { NLT_RAND, nl_rand },
    { NLT_IVUP, nl_ivup } };

struct prtcl plcapp[] = { { PRTCL_NL, nl_check, nl_proc },
    { PRTCL_645, gb645_check, gb645_proc } };

unsigned char info_v[2] = {0x00}; /* ֡��Ϣ�� */
extern struct nl_api_info nl_api[14];
    
#ifdef UPDATE_STA
static int nl_upd_check(unsigned char *frm, int len, int *end)
{
  int datalen = 0;
  for (int i = 0; i < len; ++i)
   {
     if ((datalen = is_valid_upd(frm + i, len - i)) > 0)
       {
         *end = i + datalen;
         return datalen;
       }
   }
  return 0;
}
#endif  
int plc_decode(unsigned char *frame, int len, unsigned char phase)
{
    int begin = 0, end = 0, framelen = 0;
    struct nl_frm_info *p = (struct nl_frm_info *)frame;
  
    //�ȵ��������������,����0˵����V������Ч���ݣ���������ִ��
    if ((framelen = nl_frm_check(frame, len, &end)) > 0)
      {
        printf_s("\nrev plc frame:    ");
        for(int i = 0; i< len; i++)
          {
            printf_s("%02x ",frame[i]);
          }
        printf_s("\n");
        len = framelen;
  
        /* V�����ĵĴ���������֧��V�����������ﴦ�� */
        memcpy(info_v, p->info, 2); /* ��ȡ��Ϣ�� */
        len = len - 8;
      #ifdef UPDATE_STA 
        int frmlen = 0, end1;
        if ((frmlen = nl_upd_check(frame, len, &end1)) > 0)
          {
            int chnl;
            if (CHN_38_1 == phase)
              chnl = UPD_A;
            else if (CHN_38_2 == phase)
              chnl = UPD_B;
            else if (CHN_38_3 == phase)
              chnl = UPD_C;
            aupd_indication(frame + (end1 - frmlen), frmlen, chnl);
            return end1;
          }
      #endif    
        
        /* Ŀǰ������д������V��������Ҳ������������III���������� */
        for (int i = 0; i < sizeof(nl_api) / sizeof(nl_api[0]); ++i)
          {
            if (nl_api[i].ctrl == p->ctrl)
              {
                nl_api[i].fun(p->data, len, phase);  /* phase����ֱ��ʹ�ã��ø�CHN_38_1��Ӧ���� */
                return framelen;
              }
            if (nl_api[i].ctrl == CTL_43_CMD)
              break;
          }
        
        for (int i = 0; len > 0 && i < sizeof(plcapp) / sizeof(plcapp[0]); ++i)
          {
            if (plcapp[i].check(p->data, len, &begin, &end) == 0)
              {
                assert(end > begin);
                
                printf_s("\n[%d] iv****rev:    ", phase); 
                for(int i = 0; i< (end - begin); i++)
                  {
                    printf_s("%02x ",p->data[begin + i]);
                  }
                printf_s("\n");
                
                plcapp[i].proc(&p->data[begin], end - begin);
                return end;
              }
          }
        return framelen;
      }
#if 0

#endif
    return 0;
}

int plc_comm_645(int fdsno, unsigned char *send, size_t slen, unsigned char *recv, size_t *rlen)
{
        //size_t t_wait = 100;
        size_t t_wait = 1000;       //����ת��ԭ�ȵ�100ms�ȴ�ʱ��̫�̣��ݸ�Ϊ1s
        unsigned char frame[255], index = 0;
        int fd, framelen = sizeof(frame), begin = 0, end = 0;

    if (fdsno == 0)
        fd = CHN_38_1;
    else
        if (fdsno == 1)
            fd = CHN_38_2;
        else
            if (fdsno == 2)
                fd = CHN_38_3;
            else
                return -1;

    sys_uart_read(fd, frame, sizeof(frame));

    nl_rtwrite(fd, send, slen, 0);

    while (t_wait-- > 0)
    {
        mdelay(1);
        framelen = uart_read(fd, frame + index, sizeof(frame) - index);
        index += framelen;
    }

    if (index == 0) /*no reply*/
    {
        *rlen = 0;
        return -2;
    }

    if (gb645_check(frame, index, &begin, &end) != 0)
        return -1;
    if (end <= begin)
        return -1;

    *rlen = end - begin;
    memcpy(recv, frame + begin, *rlen);
    return 0;
}

int get_plc_data(int fd, unsigned char type, unsigned char *msg, unsigned char *recv, size_t len)
{
    size_t t_wait = 50;
    unsigned char frame[255], *pos, index = 0;
    int framelen = sizeof(frame);

    sys_uart_read(fd, frame, sizeof(frame));
    nl_frm38(type, msg + 1, msg[0], frame, &framelen, PLC_DC);

    nl_rtwrite(fd, frame, framelen, 0);

    while (t_wait-- > 0)
    {
        mdelay(1);
        framelen = uart_read(fd, frame + index, sizeof(frame) - index);
        index += framelen;
    }

    if (index > 0)
    {
        pos = memchr(frame, 0x9f, index);
        if (pos != NULL)
        {
            framelen = index - (pos - frame);
            if (nl_frm38_decrypt(pos, framelen) == 0)
            {
                memcpy(recv, pos, framelen);
                return framelen;
            }
        }
    }

    return 0;
}

int nl_rtwrite(int fd, unsigned char *buf, size_t wbytes, size_t t_wait)
{
    int time = t_wait, ret, l = 0;
    static unsigned int delay = 0, delay2;
    extern unsigned int currtick();
    unsigned char tmp[255], info[2] = {0x0, 0x0};
  
    if (fd == CHN_38_1)
        set_rts_value(fd, 1);

    if (t_wait == 0)
    {
        delay2 = currtick();
        while ((currtick() - delay < 500) && (fd != CHN_DM))
        {
            if (currtick() - delay2 > 500)
                break;
        }

        if (fd == CHN_38_1)
        {
            sys_uart_read(CHN_38_1, tmp, sizeof(tmp));
            sys_uart_read(CHN_38_2, tmp, sizeof(tmp));
            sys_uart_read(CHN_38_3, tmp, sizeof(tmp));
        }
        //���ܼӴ�ӡ����Ȼ����������
//         printf_s("\n***************nl_rtwrite_1****************************\n");
//         for(int i = 0; i< wbytes; i++)
//           {
//             printf_s("%02x ",buf[i]);
//           }
        
        size_t wbytes1 = 0;
        wbytes1 = wbytes;
        memcpy(tmp, buf, wbytes1);
        
        if (fd != CHN_DM)  //����·��  ��38���ڲ��ܼ���
          {
            l = nl_fill_frm(CTL_43_CMD, info, buf, wbytes);
            wbytes = l;
          }
        
        ret = uart_write(fd, buf, wbytes);
        
        if (fd == CHN_38_1)
        {
            //memcpy(tmp, buf, wbytes);
            nl_frm38_decrypt(tmp, wbytes1);
            if (tmp[2] != NLT_RAND && tmp[2] != NLT_SKID && tmp[2] != 0x35) //sendtest = 0x35
            {
                tmp[3] = 0x0C; /* tx disable */
                tmp[9] |= 0x20; /* tx disable */
            }
            if (tmp[0] == 0x9F)
            {
                nl_frm38_encrypt(tmp, wbytes1);
                l = nl_fill_frm(CTL_43_CMD, info, tmp, wbytes1);
                wbytes1 = l;
                uart_write(CHN_38_2, tmp, wbytes1);
                uart_write(CHN_38_3, tmp, wbytes1);
            }
        }
        delay = currtick();
        return (ret == wbytes) ? 0 : -1;
    }

    if (fd != CHN_DM)  //����·��  ��38���ڲ��ܼ���
      {
        l = nl_fill_frm(CTL_43_CMD, info, buf, wbytes);
        wbytes = l;
      }
    
    set_rts_value(fd, 1);
    while (get_cts_value(fd) == 0 && time-- > 0) /* CTS=1 and RTS=1, then next step */
        mdelay(1);
    if (time <= 0)
        return -1;
    time = t_wait - 50;
    set_rts_value(fd, 0); /* request */
    mdelay(50);
    while (get_cts_value(fd) == 1 && time-- > 0)
        mdelay(1);
    if (get_cts_value(fd) == 1)
        return -1;
    //���ܼӴ�ӡ����Ȼ����������
//     printf_s("\n***************nl_rtwrite_2****************************\n");
//     for(int i = 0; i< wbytes; i++)
//       {
//         printf_s("%02x ",buf[i]);
//       }
    ret = uart_write(fd, buf, wbytes);
    
    set_rts_value(fd, 1);

    delay = currtick();
    return (ret == wbytes) ? 0 : -1;
}

int nl_getrandom(unsigned char rate, unsigned char *random)
{
    unsigned char  ret;
    unsigned char sendmsg[4] =  { 0x01, rate }, rcvmsg[20];

    ret = get_plc_data(fd_38, NLT_RAND, sendmsg, rcvmsg, sizeof(rcvmsg));
    if (ret == 6 && rcvmsg[2] == NLT_RAND)
    {
        *random = rcvmsg[3];
        return 0;
    }

    return (-1);
}

int nl_getlinfo(unsigned char *para, unsigned char len, unsigned char *recv, unsigned char *rlen)
{
    unsigned char  ret;
    unsigned char sendmsg[255], rcvmsg[255];
    int fd;

    if (para[0] == 0)
        fd = CHN_38_1;
    else
        if (para[0] == 1)
            fd = CHN_38_2;
        else
            if (para[0] == 2)
                fd = CHN_38_3;
            else
                return -1;

    sendmsg[0] = len - 1;
    memcpy(sendmsg + 1, para + 1, len - 1);

    ret = get_plc_data(fd, NLT_LINFO, sendmsg, rcvmsg, sizeof(rcvmsg));
    if (ret > 0 && rcvmsg[2] == NLT_LINFO && (rcvmsg[3] & 0x7F) == para[1])
    {
        *rlen = rcvmsg[1] - 2;
        memcpy(recv, rcvmsg + 4, *rlen);
        return 0;
    }

    return (-1);
}

static int item_to_int(unsigned char *data_id, unsigned char len)
{
    int i, n = 0;
    unsigned char tmp;
    for (i = 0; i < len; i++)
    {
        n <<= 0x08;
        tmp = data_id[i] - 0x33;
        n += tmp;
    }
    return n;
}

unsigned char nl_itemlen(unsigned char *itemstr, unsigned char len)
{
    assert(len == 2 || len == 4);

    int item = item_to_int(itemstr, len);
    if (len == 2)
    {
        for (int i = 0; i < sizeof(_ITEMTB97) / sizeof(_ITEMTB97[0]); ++i)
        {
            if (item ==  _ITEMTB97[i].item)
                return  _ITEMTB97[i].len;
        }
    }
    else
    {
        for (int i = 0; i < sizeof(_ITEMTB07) / sizeof(_ITEMTB07[0]); ++i)
        {
            if (item ==  _ITEMTB07[i].item)
                return _ITEMTB07[i].len;
        }
    }
    return 0;
}

int nl_phasecmd(struct appdata *app)
{
    unsigned char cmd[] = { 0x1F, 0xAE + 0x33 };
    extern unsigned char plc_new;

    if (app->datalen != 3)
        return -1;
    if (memcmp(cmd, app->data, sizeof(cmd)) != 0)
        return -1;
    if (plc_new)
        app->data[2] = 0x40 + 0x33;
    else
        app->data[2] = 0xC0 + 0x33;

    return 0;
}

int nl_parent(struct ndscont *nds, unsigned char flag, unsigned char *msg, size_t len)
{
    int index;
    unsigned char tmp[255];

    if (nds_compress(nds, tmp, &index) != 0)
        return -1;

    if (index + 2 + sizeof(struct net_msg_head) > len) /* 2 = after NDS  data len */
        return -2;

    struct net_msg_head *head = (struct net_msg_head *)msg;

    head->tnosdd = 0x20; /* tno = 1 */
    head->cmdscd = 0x20; /* cmd = 1 */
    head->strhpd = 0x81; /* sqn = 1, rpl = 0 */
    if (flag & BITTKN1)
        head->strhpd |= BITTKN;

    head->dutypln = (nds->num - 1) | BITASW;
    if (flag & BITMNT1)
        head->dutypln |= BITMNT;
    memcpy(head->sinkid, _rtparas.sinkid, sizeof(head->sinkid));
    memcpy(msg + sizeof(struct net_msg_head), tmp, index);

    index += sizeof(struct net_msg_head);
    msg[index++] = 0x07; /* data field */
    msg[index] = _rtparas.wrkno; /* TP */
    head->len = index; /* 2 bytes crc and sum */

    return 0;
}

int nl_parentprocess(unsigned char *msg, size_t len, struct rtinfo *strglvl)
{
    struct mtinfo *mt, *mtprt;
    struct rpinfo rp;
    struct ndscont ndslist;
    int pos = 0, num;

    if ((msg[offset(struct net_msg_head, cmdscd)] & CMDMASK) != 0x20)
        return -1;
    if (memcmp(msg + offset(struct net_msg_head, sinkid), _rtparas.sinkid, sizeof(_rtparas.sinkid)) != 0)
        return -2;
    if (nds_decompress(ALLSNO, 3, msg + sizeof(struct net_msg_head), len, &ndslist, &pos) != 0)
        return -3;
    if (ndslist.nds[0].len != 0x02)
        return -4;

    if ((mtprt = db_find_sno(ndslist.nds[0].id)) == NULL)
        return -5;
    memset(&rp, 0x00, sizeof(struct rpinfo));
    memcpy(rp.rpid, mtprt->node.id, IDLEN);
    rp.addr = 0xFFFF;
    rp.node.idptr = mtprt->addr;  //���û����

    pos += sizeof(struct net_msg_head);
    if (pos + 2  > len)
        return -6;

    memset(strglvl, 0x00, sizeof(struct rtinfo));
    strglvl->phase = (msg[pos] & PHASEMASK) >> 6;

    if (msg[pos] & NETTYPEMASK)
    {
        strglvl->dev43 |= (1 << 7);
    }

    strglvl->strong = msg[pos++] & STRONGMASK;

    num = msg[pos++];
    for (int i = 0; i < num && pos < len; ++i, pos += 2)
    {
        if ((mt = db_find_sno(&msg[pos])) == NULL)
            continue;
        db_appendrp(mt->node.id, &rp);
    }

    return 0;
}

int nl_broadtask2(struct broad_para *para, unsigned char *msg, size_t len)
{
    int index;
    unsigned char tmp[255];

    if (nds_compress(para->nds, tmp, &index) != 0)
        return -1;

    if (index + 8 + sizeof(struct net_msg_head) > len) /* 8 = after NDS  data len */
        return -2;

    struct net_msg_head *head = (struct net_msg_head *)msg;

    head->tnosdd = 0x40; /* tno = 2 */
    head->cmdscd = 0x00; /* cmd = 0 */
    head->strhpd = 0x81; /* sqn = 1, rpl = 0 */
    if (para->flag & BITTKN1)
        head->strhpd |= BITTKN;
    head->dutypln = (para->nds->num - 1) | BITASW;
    if (para->flag & BITMNT1)
        head->dutypln |= BITMNT;
    memcpy(head->sinkid, _rtparas.sinkid, sizeof(head->sinkid));

    if (para->flag & BITORDER)
        head->sinkid[1] |= 0x80;

    memcpy(msg + sizeof(struct net_msg_head), tmp, index);
    index += sizeof(struct net_msg_head);
    msg[index++] = para->vnum | BITFORCE; /* visit number */

    msg[index++] = 0xFF; /* visit list */
    msg[index++] = para->type; /* action */
    if (para->type & 0x04) /* BIT2 */
    {
        memcpy(&msg[index], para->range, sizeof(para->range));
        index += 4;
    }
    head->len = index - 1;

    return 0;
}

int nl_broadprocess(unsigned char *msg, size_t len, unsigned char *touch_num, struct mtlist *list)
{
    unsigned char  list_num, sink[2];
    struct ndscont nds;
    int pos = 0;

    if ((msg[offset(struct net_msg_head, tnosdd)] & TNOMASK) != 0x40)
        return -1;
    memcpy(sink, msg + offset(struct net_msg_head, sinkid), sizeof(sink));
    sink[1] &= ~0x80;
    if (memcmp(sink, _rtparas.sinkid, sizeof(_rtparas.sinkid)) != 0)
        return -2;
    if (nds_decompress(ALLSNO, 3, msg + sizeof(struct net_msg_head), len, &nds, &pos) != 0)
        return -3;

    pos += sizeof(struct net_msg_head);
    if (pos + 2  > len)
        return -4;

    pos++; /* strong level */
    *touch_num = msg[pos++];
    if (*touch_num == 0)
        return 0;

    if (pos + 1 > len)
        return -5;
    list_num = msg[pos++];
    if (list_num > 0 && len - pos > 0)
    {
        enum nds_type type = (msg[offset(struct net_msg_head, sinkid) + 1] & 0x80) ? ALLSNO : ALLMETER;
        if (nds_decompress(type, list_num, &msg[pos], len - pos, &nds, &pos) != 0)
            return -6;
    }
    for (int i = 0; i < nds.num; ++i)
    {
        list[i].state = 0x80 | nds.nds[i].len;
        memcpy(list[i].id, nds.nds[i].id, nds.nds[i].len);
    }

    return 0;
}
extern int plc_38_43;
int nl_frm38(unsigned char type, unsigned char *data, int datalen, unsigned char *frame, int *framelen, unsigned char upd_flag)
{
    unsigned char data_sum = 0, data_xor = 0x00, data_seed = 0x00, index = 0;
    extern unsigned char plc_new;
    unsigned char dflag = 0;//dpsk��־
    unsigned char liskfsk = 0;
    int ret;
    frame[index++] = 0x9F;
    frame[index++] = datalen + 1;
    frame[index++] = type;

    if (plc_new && type != NLT_RAND && type != NLT_SKID && type != NLT_IVDOWN && type != 0x35) // sendtest = 0x35
    {
        frame[1] += 8; /* len + info */
        frame[2] = 0xA0;           /* type */
        frame[index++] = 0x04;        /* tx enable */
        frame[index++] = 0x00;        /* high power */
        frame[index++] = 0x00;        /* FSK and VIII */
        frame[index++] = 0x00;        /* reserve */

        if (_nl_type & FRMTVMASK) //ǿ��ʹ�������ɹ�ģʽ
        {
            if ((_nl_type & FRMTMMASK) ==FRMTFSK)
            {
                liskfsk = 1;
            }

            _nl_type &= ~FRMTVMASK;
            _nl_type &= ~FRMTMMASK;
        }

        ret = is_all_nds_43();
        if (ret >= 0)
        {
            dflag = 1;
        }
        else if (ret == -2 && (get_random_data() & 0x01) && liskfsk == 0) //Ŀ�Ľڵ�����δ֪
        {
            dflag = 1;
        }
        else
        {
            dflag = 0;
        }

        if ((_nl_type & FRMLISTVMASK) == FRMLISTVAL)
        {
            if ((_nl_type & FRMLISTMASK) == FRMLISTN43)
            {
                dflag = 0;
            }
            else if ((_nl_type & FRMLISTMASK) == FRMLIST43)
            {
                dflag = 1;
            }
            else
            {
                if ((get_random_data() & 0x01))
                {
                    dflag = 1;
                }
                else
                {
                    dflag = 0;
                }
            }
            _nl_type &= ~FRMLISTVMASK; //clear valid flag
            _nl_type &= ~FRMLISTMASK;
        }
        if ((_rtparas.state & STARMASK) == STAREG || (_rtparas.state & STABMASK) == STABROAD)
        {
            dflag = 0;
        }
        if ((_nl_type & FRMFFMASK) == FRMFFAIL)//�ϴηֲ�ʽʧ�ܣ��˴�ʹ��FSK
        {
            dflag = 0;
            _nl_type &= ~FRMFFMASK;
        }

        printf_s("dflag:%d ,plc_38_43:%d, _share.flswitch & 0x40:%d, _rtparas.dpsk & DPSKFMASK:%d\n", dflag, plc_38_43, _share.flswitch & 0x40, _rtparas.dpsk & DPSKFMASK); 
        if (((_share.flswitch & 0x20)
             || ((_rtparas.dpsk & DPSKFMASK) == DPSKFORCE && ((_rtparas.state & STARMASK) != STAREG) && ((_rtparas.state & STABMASK) != STABROAD))
             || dflag == 1) && plc_38_43 && ((_share.flswitch & 0x40) == 0))
        {
            //dpsk
          printf_s("dpsk dpsk!!!!!\n");
            _last_sndtype = 1;
            if (_share.flswitch & 0x02)//zcp mode
            {
                frame[index++] = 0x34;//0x37;        /* tx enable */
                frame[index++] = 0x60;        /* high power */
                frame[index++] = 0x88;        /* FSK and VIII */
            }
            else                      //td mode
            {
                frame[index++] = 0x34;//0x37;        /* tx enable */
                frame[index++] = 0x60;        /* high power */
                frame[index++] = 0x48;//0x88;        /* FSK and VIII */
            }
        }
        else
        {
            _last_sndtype = 0;
            frame[index++] = 0x30;        /* tx enable */
            frame[index++] = 0x30;        /* high power */
            frame[index++] = 0x03;        /* FSK and VIII */
        }

        if (PLC_UPDATE == upd_flag)
	      {
		      frame[index++] = 0x34;//0x37;        /* tx enable */
          frame[index++] = 0x60;        /* high power */
          frame[index++] = 0x48;//0x88;        /* FSK and VIII */
	      }

        if (type == NLT_ZERO)
            frame[index - 1] |= 0x04;
        frame[index++] = 0x10;        /* reserve */
    }

    for (int i = 2; i < index; ++i)
    {
        data_sum += frame[i];
        data_xor ^= frame[i];
    }
    for (int i = 0; i < datalen; ++i) /* data */
    {
        data_sum += data[i];
        data_xor ^= data[i];
    }
    frame[datalen + index] = data_sum; /* crc */
    frame[datalen + index + 1] = data_xor;

    frame[1] ^= 0x35; /* encrypt */
    frame[1] += 0x0A;

    data_seed = data_sum ^ data_xor;

    data_seed ^= frame[2];
    frame[2] = data_seed;

    for (int i = 3; i < index; ++i)
    {
        data_seed ^= frame[i];
        frame[i] = data_seed;
    }

    for (int i = 0; i < datalen; ++i)
    {
        data_seed ^= data[i];
        frame[index + i] = data_seed;
    }

    *framelen = datalen + index + 2;

    return 0;
}

int nl_frm38_tno5(unsigned char *data, int datalen, unsigned char *frame, int *framelen, struct info_frame_iv_up *pinfo)
{
    unsigned char data_sum = 0, data_xor = 0x00, data_seed = 0x00, index = 0;
    struct info_frame_iv_down *dninfo = (struct info_frame_iv_down *)(frame + 3);
    extern unsigned char plc_new;

    frame[index++] = 0x9F;
    frame[index++] = datalen + 1;
    frame[index++] = NLT_PARL;

    frame[1] += 8; /* len + info */
    frame[2] = 0xA0;           /* type */

    memcpy(frame + 3, pinfo, 8);
    dninfo->send_on = 1;
    dninfo->send_dir = 0;
    dninfo->phase = 0x01;
    dninfo->d_phase = 0x01;
    dninfo->zero_point = 0;
    dninfo->compress = 0;
    dninfo->false_send = 0x00;
    index += 8;

    for (int i = 2; i < index; ++i)
    {
        data_sum += frame[i];
        data_xor ^= frame[i];
    }
    for (int i = 0; i < datalen; ++i) /* data */
    {
        data_sum += data[i];
        data_xor ^= data[i];
    }
    frame[datalen + index] = data_sum; /* crc */
    frame[datalen + index + 1] = data_xor;

    frame[1] ^= 0x35; /* encrypt */
    frame[1] += 0x0A;

    data_seed = data_sum ^ data_xor;

    data_seed ^= frame[2];
    frame[2] = data_seed;

    for (int i = 3; i < index; ++i)
    {
        data_seed ^= frame[i];
        frame[i] = data_seed;
    }

    for (int i = 0; i < datalen; ++i)
    {
        data_seed ^= data[i];
        frame[index + i] = data_seed;
    }

    *framelen = datalen + index + 2;

    return 0;
}

int nl_frm38_encrypt(unsigned char *frame, int framelen)
{
    if (frame[0] != 0x9F)
        return -1;

    unsigned char seed = 0x00, data_sum = 0x00, data_xor = 0x00;

    data_sum = frame[2];
    data_xor = frame[2];
    for (int i = 3; i < framelen - 2; ++i)
    {
        data_sum += frame[i];
        data_xor ^= frame[i];
    }
    frame[framelen - 2] = data_sum;
    frame[framelen - 1] = data_xor;

    frame[1] ^= 0x35; /* encryptr */
    frame[1] += 0x0A;

    seed = data_sum ^ data_xor;


    for (int i = 0; i < framelen - 4; ++i)
    {
        seed ^= frame[2 + i];
        frame[2 + i] = seed;
    }

    return 0;
}

int nl_frm38_decrypt(unsigned char *frame, int framelen)
{
    if (frame[0] != 0x9F)
        return -1;

    unsigned char seed = 0x00, data_sum = 0x00, data_xor = 0x00, tmpseed = 0x00;

    frame[1] = (frame[1] - 0x0A) ^ 0x35;

    if (frame[1] + 4 != framelen)
        return -1;

    data_sum = frame[framelen - 2];
    data_xor = frame[framelen - 1];

    seed = data_sum ^ data_xor; //seed
    for (int i = 2; i < framelen - 2; ++i)
    {
        tmpseed = frame[i];
        frame[i] = seed ^ frame[i];
        seed = tmpseed;
    }

    data_sum = 0x00;
    data_xor = 0x00;
    for (int i = 2; i < framelen - 2; ++i)
    {
        data_sum += frame[i];
        data_xor ^= frame[i];
    }

    if (data_sum != frame[framelen - 2] || data_xor != frame[framelen - 1])
        return -1;

    return 0;
}

int nl_frm38_decode(unsigned char *frame, int *framelen)
{
    unsigned char tmp[255], cs = 0;
    int tmplen = 0;

    assert(*framelen <= 255);

    memcpy(tmp, frame, *framelen);
    for (int i = 0; i < *framelen; ++i)
    {
        if (tmp[i] == 0x9F)
        {
            tmplen = (tmp[i + 1] - 0x0A) ^ 0x35;
            if (*framelen < tmplen + 4)
                continue;
            if (nl_frm38_decrypt(tmp + i, tmplen + 4) ==  0)
            {
                memcpy(frame, tmp + i, tmplen + 4);
                *framelen = tmplen + 4;
                return i + tmplen + 4;
            }
        }
    }

    memcpy(tmp, frame, *framelen);
    for (int i = 0; i < *framelen; ++i)
    {
        if (tmp[i] == 0x68)
        {
            if (tmp[i + 7] != 0x68)
                continue;
            tmplen = tmp[i + 9];
            if (*framelen < tmplen + 12)
                continue;
            if (tmp[i + tmplen + 11] != 0x16)
                continue;
            for (int j = i; j < tmplen + 10; j++)
                cs += tmp[j];
            if (cs != tmp[i + tmplen + 10])
                continue;
            for (int j = 0; j < tmplen; j++)
                tmp[i + 10 + j] -= 0x33;
            memcpy(frame, tmp + i, tmplen + 12);
            *framelen = tmplen + 12;
            _commbuf.plc.mode |= 0x80;
            return i + tmplen + 12;
        }
    }
    return 0;
}

int nl_frm38_2nl(unsigned char *frame, int framelen)
{
    assert(framelen <= 255);
    unsigned char tmp[255];
    int tmplen = 0;

    memcpy(tmp, frame, framelen); /* copy to tmp */
    tmplen = frame[1];

    memcpy(frame, tmp + 3, tmplen - 1);

    return 0;
}

unsigned int send_tick = 0;
unsigned char WorkNo = 1;
int nl_monittask1(struct appdata *appd, unsigned char mnttkn, unsigned char *sno, unsigned char *frame, int *framelen)
{
    int tmplen = 0, crtlen = 0, len = *framelen;
    unsigned char tmpnds[32 * IDLEN];
    unsigned char mnt = 0, tkn = 0, nsno = 0, asw = 0;
    unsigned char pro;

    mnt = mnttkn & PMNTMASK;
    tkn = mnttkn & PTKNMASK;
    nsno = mnttkn & PNSMASK;
    asw  = mnttkn & PASWMASK;
    if (nds_compress(&_ndscont, tmpnds, &tmplen) != 0) /* nds */
        return -1;
    if (len < sizeof(struct net_msg_head) + tmplen + appd->datalen + 1)
        return -1;

    struct net_msg_head *head = (struct net_msg_head *)frame;
    head->tnosdd = 0x20; /* tno = 1 */
    head->cmdscd = 0x00; /* cmd = 0 */
    head->strhpd = BITSQN;  /* sqn = 1 rpl = 0 */
    head->strhpd += 1;  /* hpd  = 1*/
    if (tkn)
        head->strhpd |= BITTKN;

    head->dutypln = _ndscont.num - 1;
    if (asw == 0)
        head->dutypln |= BITASW;
    if (mnt)
        head->dutypln |= BITMNT;

    memcpy(head->sinkid, _rtparas.sinkid, sizeof(_rtparas.sinkid));
    if (nsno)
        head->sinkid[1] |= 0x80;
    crtlen += sizeof(struct net_msg_head);

    for (int i = 0; i < _ndscont.num - 1; ++i)
    {
        if (_ndscont.nds[i].len != SNOLEN)
            return -1;
    }
    if (_ndscont.nds[_ndscont.num - 1].len == IDLEN)
        head->cmdscd = 0xC0; /* cmd = 6 */

    if (head->cmdscd == 0xC0)
    {
        struct stage0 *s0p = (struct stage0 *)_task.info;
        if ((_rtparas.stage == S0 && (s0p->info & S0TMASK) == S0TTANS))
//        || ((_rtparas.state & STAMMASK) == STAMONIT))
        {
            head->cmdscd = 0x00;
            head->strhpd &= ~BITSQN;
        }
        if (((_rtparas.state & STAMMASK) == STAMONIT) && _ndscont.num == 2)
        {   //��������ֱ������cmd=0���Ų���
            head->cmdscd = 0x00;
            head->strhpd &= ~BITSQN;
        }
    }

    memcpy(frame + crtlen, tmpnds, tmplen);
    crtlen += tmplen;

    if (head->cmdscd == 0xC0)  /* sno */
    {
        memcpy(frame + crtlen, sno, SNOLEN);
        crtlen += SNOLEN;
    }


    pro = appd->protype & PTMASK;

    if (pro == 0x01 || pro == 0x02)
    {
        frame[crtlen++] = appd->datalen + 1;  /* tp */
        frame[crtlen] = 0x00; //����
    }
    else if (pro == TP_PRO_698 || pro == TP_PRO_TRAN)
        {

            frame[crtlen++] = TP_APP_EX;
            frame[crtlen] = 0x00; //����
            frame[crtlen] |= (pro << 4);
#if 0
            if ((appd->protype & PTMASK) == 0x03)//698
            {
                frame[crtlen] |= (TP_PRO_698 << 4);
            }else if((appd->protype & PTMASK) == 0x00)
                        {
                                frame[crtlen] |= (TP_PRO_188 << 4);
                        }
            else
            {
                frame[crtlen] |= (TP_PRO_TRAN << 4);
            }
#endif
        }


    //frame[crtlen++] = _rtparas.wrkno;
    frame[crtlen++] |= WorkNo++;
    if (WorkNo > MAXWRKSNO)
        WorkNo = 1;


    if ((0x01 == pro || 0x02 ==  pro)
        &&(appd->wretlen == 0 || appd->wretlen > 180))
    {
        if (appd->datalen >= 3 && appd->data[0] == READ_97)
            frame[crtlen] = nl_itemlen(appd->data + 1, 2);
        else
            if (appd->datalen >= 5 && appd->data[0] == READ_07)
                frame[crtlen] = nl_itemlen(appd->data + 1, 4);
            else
                frame[crtlen] = appd->wretlen;

        if (frame[crtlen] == 0 && appd->wretlen != 0)
            frame[crtlen] = appd->wretlen;
        if (frame[crtlen] == 0 || frame[crtlen] > 180)
            frame[crtlen] = 180;
        ++crtlen;
    }
    else
        frame[crtlen++] = appd->wretlen;

    if (TP_PRO_TRAN ==  pro || TP_PRO_698 == pro)
    {
        frame[crtlen++] = appd->datalen;
        memcpy(frame + crtlen, appd->data, appd->datalen);
    }
    else
    {
        memcpy(frame + crtlen, appd->data, appd->datalen);
    }
    crtlen +=  appd->datalen;
    if (crtlen - 1 > 0x3f)
        head->len = 0x7F;
    else
        head->len = (crtlen - 1) | 0x40;
    *framelen = crtlen;

    send_tick = get_sys_tick();

    return 0;
}

int nl_monitprocess(unsigned char *frame, int framelen, struct appdata *appd, struct rtinfo *strglvl)
{
    int tmplen = 0, len = 0, num = 3;
    struct ndscont tmpnds;
    unsigned char errbuf1[] = { 0xC0, 0x34 }, errbuf2[] = { 0xC0, 0x35 }, errbuf3[] = { 0xC0, 0x36 };
    unsigned char frm_workno;
    unsigned char dev43_41 = 0;//����Ϊ41����43��30Ϊ0
    struct monitinfo *ml = &_task.ml;

    if (framelen < sizeof(struct net_msg_head))
        return -1;
    struct net_msg_head *head = (struct net_msg_head *)frame;
    len += sizeof(struct net_msg_head);
    if ((head->tnosdd & TNOMASK) != 0x20) /* tno=1 */
        return -1;
    if ((head->cmdscd & CMDMASK) != 0x00 && (head->cmdscd & CMDMASK) != 0xC0) /* cmd=0 cmd=6 */
        return -1;
    if ((head->dutypln & ASWMASK) == 0x20) /*asw = 1*/
        return -8;
    if (nds_decompress(nds_gettype(head), num, frame + len, framelen - len, &tmpnds, &tmplen) != 0) /* nds */
        return -1;
    len += tmplen;

    /* check id */
    unsigned char id[6];
    memset(id, 0x00, sizeof(id));
    if (memcmp(tmpnds.nds[0].id, id, sizeof(id)) == 0)
        return -2;

    if (tmpnds.nds[0].len == IDLEN)
        memcpy(id, tmpnds.nds[0].id, IDLEN);
    else
        if (tmpnds.nds[0].len == SNOLEN)
        {
            struct mtinfo *mtp = db_find_sno(tmpnds.nds[0].id);
            if (mtp == NULL)
                return -3;
            memcpy(id, mtp->node.id, IDLEN);
        }
        else
            return -1;
    if (_task.ml.opt.mt && memcmp(_task.ml.opt.mt->node.id, id, IDLEN) != 0)
        return -4;
    if (_task.ml.opt.mt == NULL && (_rtparas.state & STAMMASK) == STAMONIT &&
        memcmp(_task.minfo.id, id, IDLEN) != 0)
        return -4;

    memset(strglvl, 0x00, sizeof(struct rtinfo));
    strglvl->phase = (frame[len] & PHASEMASK) >> 6;
    if ((frame[len] & DEV43MASK))
    {
        strglvl->dev43 = 1;
    }
    if (frame[len] & NETTYPEMASK) 
    {
       
        strglvl->dev43 |= (1 << 7);
    }

    strglvl->strong = frame[len++] & STRONGMASK;
    if ((head->cmdscd & CMDMASK) == 0xC0 && (head->sinkid[1] & 0x80) == 0x00)
        strglvl->setsno = 1;

    if (frame[len] != 0xFF)
    {
        if (framelen < frame[len] + len + 1) /* +tp[0] tp[1]*/
            return -1;
    }

    if ((get_sys_tick() - send_tick) < 500)
        return -1; //ͬ�·�������Ų�ͬ
    extern unsigned char WorkNo;
    if (frame[len] == 0xFF) //698��־
    {

        if ((frame[len + 1] & 0x0F) != ((WorkNo == 1) ? 0x0F : (WorkNo - 1)))
            return -1;
        dev43_41 = ((frame[len + 1] & 0x80) >> 7);//D7����ʾ�ز�оƬ���ͣ�43���ͣ���1
        appd->datalen = frame[len + 3];
        /* �����ص�Э������ + �㳭�·���Э������*/
        appd->protype = (appd->protype & 0x0F) | (frame[len+2] & 0xF0);

        memcpy(appd->data, frame + len + 4, appd->datalen);
    }
    else
    {
        if ((frame[len + 1] & 0x0F) != ((WorkNo == 1) ? 0x0F : (WorkNo - 1)))
            return -1;
        dev43_41 = ((frame[len + 1] & 0x80) >> 7); //D7����ʾ�ز�оƬ���ͣ�43���ͣ���

        appd->datalen = frame[len++];
        /* �����ص�Э������ + �㳭�·���Э������*/
        appd->protype = (appd->protype & 0x0F) | (frame[len] & 0xF0);
        memcpy(appd->data, frame + len + 1, appd->datalen);
    }

    if(ml->opt.mt!=NULL)
    {
       ml->opt.mt->node.phase &= ~NPDTMASK; /* update dev type info */
       if (dev43_41 > 0 && strglvl->dev43 == 1)
       {
            ml->opt.mt->node.phase |= NPDT43;  //��ǰ����û����db_write�ĵ���
       }
       else
       {
            ml->opt.mt->node.phase |= NPDTN43;
       }
    }



#if 0
    if(_task.ml.opt.mt)
    {
        _task.ml.opt.mt->node.envi &= ~NPRTMASK;
        if ((frame[len + 1] & 0x0F) != _rtparas.wrkno)
        {
            _task.ml.opt.mt->node.envi |= NPIRATE; /* pirate chip !!! */
            _task.ml.opt.mt->node.succhops |= NSUCC;
            ++_task.cnt;
            return -1;  /* wrkno error */
        }
    }
#endif
 //   appd->datalen = frame[len++];
    /* �����ص�Э������ + �㳭�·���Э������*/
 //   appd->protype = (appd->protype & 0x0F) | (frame[len] & 0xF0);
 //   memcpy(appd->data, frame + len + 1, appd->datalen);
    /*�Զ����������Ϊʧ��*/
    if ((memcmp(appd->data, errbuf1, sizeof(errbuf1)) == 0) ||
        (memcmp(appd->data, errbuf2, sizeof(errbuf2)) == 0) ||
        (memcmp(appd->data, errbuf3, sizeof(errbuf3)) == 0))
        return -7;
    return 0;
}

int nl_floodprocess(unsigned char *frame, int framelen, struct appdata *appd, unsigned char *depth)
{
    unsigned char nds[18], id[6], ivup_aid[6];
    unsigned int  t, ndslen;  //nds�ڱ����еĳ���
    unsigned char depth1, depth2;
        unsigned char pro,devtye;
    //�ж�������Ƿ�ͬ�·���һ��
    if (get_cur_flood_sno() != (frame[2] >> 4))
        return -1;

    //NDS��ѹ��
    DeCompressMeterID(2, &frame[4], nds, &ndslen);

    //�жϼ�����ID�Ƿ���ȷ
    rt_jzqid(&id[0]);
    if (memcmp(&nds[0], &id[0], 6))
        return -1;

    memset(ivup_aid, 0x00, IDLEN);
		memcpy(ivup_aid, &nds[IDLEN], IDLEN);
    
  if (memcmp(&nds[IDLEN], _task.minfo.id, IDLEN))
  {
      return -1;
  }


    //���㱨�ĵ�ʵ���м����
    depth1 = frame[2] & 0x0F;
    depth2 = (frame[3] & 0xF0) >> 4; //����ʵ���м����
    *depth = max(depth1, depth2);

    if (frame[4 + ndslen] & 0x08)
        t = 4 + ndslen + 1;
    else
        t = 4 + ndslen;
        
    #ifdef UPDATE_STA
    /* frame[t]���Ǵ�������ֽ� */
    if ((frame[t] & 0x60) == 0x60)  /* ��������Ĵ��ı��Ĵ���,Э�����Ͱ���0b100 */
      {
			   static unsigned char last_frm[IDLEN + 2 + 1]; /* aid + seq + crc16 */
		     int upd_len = 0;
             if ((upd_len = is_valid_upd(&frame[t + 2], frame[t + 1])) > 0)
			   {
				   if (0 == memcmp(last_frm, ivup_aid, IDLEN) &&
				     last_frm[IDLEN] == ((frame[2] >> 4) & 0x07) &&
				     last_frm[IDLEN + 1] == frame[t + 2 + upd_len - 2] &&
				     last_frm[IDLEN + 2] == frame[t + 2 + upd_len - 1])
				     return 0;

				   unsigned char aid_t[IDLEN];
				   memcpy(aid_t, ivup_aid, sizeof(aid_t));
				   id_bintobcd(aid_t);
                   reverse(aid_t, 6);
           /* �Ȳ��棬�����ط��У������ٸ� */
           //depth��취��һ��
// 				   if (db_find(AID, aid_t, &pos) == 0 && 0 == rnode[pos].depth)/* AID���������ݿ��� */
// 				       {
// 						  dc_succ_flag[pos] = 2;  //3.5���㳭�ɹ�
// 						  if (*depth < 7)
// 							  rnode[pos].depth = *depth + 1;
// 						  else
// 							  rnode[pos].depth = 7;

// 					   }
				   memcpy(last_frm, ivup_aid, IDLEN);
				   last_frm[IDLEN] = ((frame[2] >> 4) & 0x07);
				   last_frm[IDLEN + 1] = frame[t + 2 + upd_len - 2];
				   last_frm[IDLEN + 2] = frame[t + 2 + upd_len - 1];
				   aupd_indication(&frame[t + 2], frame[t + 1], UPD_APP);
               }

            return (0);
      }
    #endif
    
    pro =(frame[t]&0x30)>>4; //apv
    devtye = (frame[t] & 0x04) >> 2; //dev43 ==1
    if (frame[t++] & 0x02)                   //�����¼�
    appd->protype |= 0x10;
    appd->protype &= 0xF0;
    appd->protype |= pro;
    if(pro == 1||pro == 2)
    {

        appd->data[0] = frame[t];
            memcpy(&appd->data[1], &frame[t + 2], frame[t + 1]);
            appd->datalen = frame[t + 1] + 1;  //645�ĳ���+ctrl

    }else
    {
            appd->datalen = frame[t];
            memcpy(appd->data, &frame[t + 1], appd->datalen);
    }
                                                        //buf[t], c+len+data
    if (_task.ml.opt.mt)
    {
        _task.ml.opt.mt->node.phase &= ~NPDTMASK;
        if (devtye == 0)
        {
            _task.ml.opt.mt->node.phase |= NPDTN43;  //��ǰ����û����db_write�ĵ���
        }
        if (_last_sndtype == 1)
        {
            _task.ml.opt.mt->node.phase |= NPDT43;
        }
    }


    return (0);
}

int nl_IVfloodprocess(unsigned char *frame, int framelen, struct appdata *appd, unsigned char *depth)
{
    unsigned char nds[18], id[6];
    unsigned int  t, ndslen;  //nds�ڱ����еĳ���
    unsigned char depth1, depth2;

    //�ж�������Ƿ�ͬ�·���һ��
    if (get_cur_flood_sno() != (frame[2] >> 4))
        return -1;

    //NDS��ѹ��
    DeCompressMeterID(2, &frame[6], nds, &ndslen);

    //�жϼ�����ID�Ƿ���ȷ
    rt_jzqid(&id[0]);
    if (memcmp(&nds[0], &id[0], 6))
        return -1;

    //���㱨�ĵ�ʵ���м����
    depth1 = frame[2] & 0x0F;
    depth2 = (frame[3] & 0xF0) >> 4; //����ʵ���м����
    *depth = max(depth1, depth2);

    t = 6 + ndslen + 1;
    appd->data[0] = frame[t];
    memcpy(&appd->data[1], &frame[t + 2], frame[t + 1]);
    appd->datalen = frame[t + 1] + 1;  //645�ĳ���+ctrl
                                       //buf[t], c+len+data

    return (0);
}

static int list_task2(size_t round, struct mtlist *mlist, unsigned char *listnum, unsigned char *frame,
                      int *framelen, int allsno)
{
    int tmplen = 0, crtlen = 0, len = *framelen;
    struct ndscont visitlist;
    unsigned char tmpnds[32 * 6];
    unsigned char listtype;

    if (len < sizeof(struct net_msg_head))
        return -1;
    struct net_msg_head *head = (struct net_msg_head *)frame;
    head->tnosdd = 0x40; /* tno=2 */
    head->cmdscd = 0x00; /* cmd=0 */
    head->strhpd = 0x01; /* hpd = 1 */
    head->strhpd |= BITSQN; /* sqn=1 */
    head->strhpd |= BITTKN; /* tkn=1 */
    head->dutypln = (_ndscont.num - 1) | BITMNT | BITASW;
    memcpy(head->sinkid, _rtparas.sinkid, sizeof(_rtparas.sinkid));
    if (round == 1)
        head->sinkid[0] |= 0x80; /* task2 flag */
    crtlen += sizeof(struct net_msg_head);

    if (nds_compress(&_ndscont, tmpnds, &tmplen) != 0) /* nds */
        return -1;
    if (len < crtlen + tmplen)
        return -1;
    memcpy(frame + crtlen, tmpnds, tmplen);
    crtlen += tmplen;

    visitlist.num = *listnum;
    for (int i = 0; i < *listnum; ++i) /* copy to tmp */
    {
        if (allsno == 1)
        {
            visitlist.nds[i].len = SNOLEN;
            memcpy(visitlist.nds[i].id, mlist[i].sno, SNOLEN);
        }
        else
        {
            visitlist.nds[i].len = IDLEN;
            memcpy(visitlist.nds[i].id, mlist[i].id, IDLEN);
        }

    }
    if (allsno == 1)
        head->sinkid[1] |= 0x80; /* sno */

    nds_sort(&visitlist);
    if (nds_compress(&visitlist, tmpnds, &tmplen) != 0)  /* visitlist */
        return -1;


    if (len < crtlen + tmplen + 1)
        return -1;
    if (round == 1)
        frame[crtlen++] = visitlist.num;  /* visitnum */
    else
        frame[crtlen++] = (visitlist.num | 0x80);  /* visitnum */
    memcpy(frame + crtlen, tmpnds, tmplen);

    *listnum = visitlist.num;   /* save to mtlist */
    for (int i = 0; i < visitlist.num; ++i)
    {
        mlist[i].state = visitlist.nds[i].len;
        memcpy(mlist[i].id, visitlist.nds[i].id, mlist[i].state);
    }

    crtlen += tmplen;

    head->len = crtlen - 1;
    *framelen = crtlen;

    return 0;
}

int nl_listtask2(size_t round, struct mtlist *mlist, unsigned char *listnum, unsigned char *frame,
                 int *framelen, unsigned char type)
{

    int pos = -1, maxnum = list_maxnode(_rtparas.stage), allsno = 0;

    struct mtlist tmplist[32];

    for (int i = 0; i < *listnum; ++i)
    {
        if ((mlist[i].sno[0] & NNEWMASK) && pos == -1)
            pos = i;
        tmplist[i] = mlist[i];
    }

    pos = 0;              /*����Ϊ����ȫ�ñ�������*/
    if (pos == -1)
        allsno = 1;

    if (type == TASK2_REAL)
        return list_task2(round, mlist, listnum, frame, framelen, allsno);

    if ((pos != 0) && (pos == *listnum - 1))
    {
        if ((*listnum > (maxnum / 4) * 3) && (*listnum > 1))
        {
            *framelen = 0x80;
            return 0;
        }
    }

    return list_task2(round, tmplist, listnum, frame, framelen, allsno);

}

int nl_listprocess(unsigned char listnum, unsigned char *frame, int framelen, struct mtlist *mlist)
{
    int tmplen = 0, len = 0, num = 3;
    struct ndscont tmpnds;

    if (framelen < sizeof(struct net_msg_head))
        return -1;
    struct net_msg_head *head = (struct net_msg_head *)frame;
    if ((head->tnosdd & TNOMASK) != 0x40) /* tno=2 */
        return -1;
    if ((head->strhpd & BITRPL) == 0) /* rpl=1 */
        return -1;
    len += sizeof(struct net_msg_head);

    if (nds_decompress(nds_gettype(head), num, frame + len, framelen - len, &tmpnds, &tmplen) != 0) /* nds */
        return -1;
    len += tmplen;

    len++; /* strong level */
    num = frame[len++]; /* touch number */
    if (num == 0)
        return 0;
    if (num > listnum)
        return -1;

    int nbyte = 0, tmpbyte = listnum / 8;
    nbyte = listnum % 8 == 0 ? tmpbyte : tmpbyte + 1;
    for (int i = 0; i < nbyte; ++i)
    {
        for (int j = 0; j < 8; ++j)
        {
            if ((frame[len + i] << j) & 0x80)
            {
                mlist[8 * i + j].state |= 0x80;
                if (--num == 0)
                    return 0;
            }
        }
    }

    return 0;
}

int nl_regtask(unsigned char sno, unsigned char time, unsigned char *tp, int tplen, unsigned char *msg,
               int *len)
{
    unsigned int tmplen = 0, ndslen;

    struct net_tno6_head *head = (struct net_tno6_head *)msg;

    head->tnocmd = 0xC2;
    head->snohpd = (sno << 4) + 1;
    head->left = time;
    head->sddfhq = 0;
    tmplen += sizeof(struct net_tno6_head);
    for (int i = 0; i < 3; ++i)
        rt_jzqid(msg + tmplen + i * IDLEN);
    para_compress(msg + tmplen, 3, &ndslen);
    tmplen += ndslen;

    if (tplen > 0)
    {
        memcpy(msg + tmplen, tp, tplen);
        tmplen += tplen;
    }

    msg[tmplen] = chksum(msg + 1, tmplen - 1);
    msg[tmplen + 1] = chkxor(msg + 1, tmplen - 1);

    head->len = 0x40 + tmplen + 1;
    *len = tmplen + 2;

    return 0;
}

int nl_paraprocess(unsigned char *frame, int len, struct para_report *report)
{

    if ((frame[1] & TNOMASK) == TNO5)
        return nl_paratno5(frame, len, report, NULL);
    if ((frame[1] & TNOMASK) == TNO6)
        return nl_paratno6(frame, len, report, NULL);
    return -1;
}

int nl_dbgtask(unsigned char ccw, unsigned char *data, int datalen, unsigned char *frame, int *len)
{
    unsigned int index = 1, ndslen;

    frame[index++] = 0xa4;
    frame[index++] = 0x00;
    frame[index++] = 0x00;

    rt_jzqid(frame + index);
    rt_jzqid(frame + index + 6);
    memset(frame + index + 12, 0x64, 12);
    para_compress(frame + index, 4, &ndslen);
    index += ndslen;
    frame[index++] = 0x6F;
    frame[index++] = datalen + 1 + 1 + 6;
    frame[index++] = 0x02;
    memcpy(frame + index, _rtparas.jzqid, 6);
    for (int i = 0; i < 6; ++i)
        frame[index + i] = bintobcd(frame[index + i]);
    index += 6;
    frame[index++] = ccw;
    memcpy(frame + index, data, datalen);
    index += datalen;

    frame[index] = chksum(frame + 1, index - 1);
    frame[index + 1] = chkxor(frame + 1, index - 1);

    frame[0] = 0x40 + index + 1;
    *len = index + 2;

    return 0;
}

static unsigned char flood_sno = 0;
unsigned char get_next_flood_sno(void)
{
    if (++flood_sno > 15)
    {
        flood_sno = 1;
    }
    return (flood_sno & 0x0f);
}

unsigned char get_cur_flood_sno(void)
{
    return (flood_sno & 0x0f);
}

int nl_floodtask(unsigned char buf[], unsigned char id[], int depth, struct appdata *appd)
{
    unsigned int ndslength, len = 4;  //��¼����㱨�ĵĳ���,��ʼֵ7Ϊ����NDSǰ�ĳ���
    unsigned char t, addr[12];

    // ******  ��֯ NL.data  ***** //
    if (depth > 7)
        depth = 7;

    buf[1] = 0xE1;                               //Tno
    buf[2] = get_next_flood_sno() << 4;
    buf[3] = depth;                             // MaxHPD
    rt_jzqid(&addr[0]);
    memcpy(&addr[6], &id[0], 6);               //DestID
    CompressMeterID(&addr[0], 2, &ndslength);   //ѹ��NDS
    memcpy(&buf[len], addr, ndslength);
    len += ndslength;
    //�����ж�
        if (0x02 == (appd->protype & PTMASK))
        {
            if (appd->data[0] & 0x10)
                    t = 0x20;
            else
                    t = 0x10;
        }
        else
        {
            t = 0x00; //188Э��
        }

        buf[len++] = t + 1; //TPH
        if (0x02 == (appd->protype & PTMASK))
        {
            buf[len++] = appd->data[0]; //ctrl
            buf[len++] = appd->datalen - 1; //len

            memcpy(&buf[len], &appd->data[1], appd->datalen - 1);  //data
            len += appd->datalen - 1;
        }
        else
        {
            buf[len++] = appd->datalen;
            memcpy(&buf[len], appd->data, appd->datalen);
            len += appd->datalen;
        }

    //Tno7.CSum CXor
    buf[len] = chksum(&buf[1], len - 1);
    buf[len + 1] = chkxor(&buf[1], len - 1);

    len += 2;
    //Tno7.b0.Len
    buf[0] = 0x40 + (len - 1 < 61 ? len - 1 : 61);

    return len; //�������ĵĳ���
}
#ifdef UPDATE_STA
int nl_floodtask_update(unsigned char buf[], unsigned char *aid, unsigned char *frm, int depth, unsigned char update_len)//unsigned char len,
{
  //�ο���nl_floodtask
  unsigned int ndslength, len = 4;  //��¼����㱨�ĵĳ���,��ʼֵ7Ϊ����NDSǰ�ĳ���
  unsigned char t, addr[12];
  int pos = 0;
  unsigned char update_state = PLC_UPDATE;  /* �����Ĭ�������ĺ��� */
  
  // ******  ��֯ NL.data  ***** //
  if (depth > 7)
      depth = 7;

  buf[1] = 0xE1;                               //Tno
  buf[2] = get_next_flood_sno() << 4;                          //֡���ʹ��5����
  buf[3] = depth;                             // MaxHPD
  rt_jzqid(&addr[0]);
  memcpy(&addr[6], &aid[0], 6);               //DestID
  CompressMeterID(&addr[0], 2, &ndslength);   //ѹ��NDS
  memcpy(&buf[len], addr, ndslength);
  len += ndslength;
  //�����ж�

  #if 0
      //Э�����Ϳ�����ô��ȡһ��
      if (0x02 == (appd->protype & PTMASK))
      {
          if (appd->data[0] & 0x10)
                  t = 0x20;
          else
                  t = 0x10;
      }
      else
      {
          t = 0x00; //188Э��
      }
  //#else
      if (db_find(AID, aid, &pos) == 0)/* AID���������ݿ��� */
        {
          if (rnode[pos].node.protocol == 0x1)
            t = 0x10;  /* 0x10��97 */
          else
            t = 0x20;  /* 0x20��07? */
        }
      else
        t = 0x20;  /* 0x20��07? */
  #endif
      
      t = 0x20;  /* 0x20��07? *//* ����û��Э�����ͣ�����Ϊ07�� */
      
      buf[len++] = t + 1; //TPH


      if (update_state == PLC_UPDATE)  /* ����4��������ʽ�鱨�� */
        {
		  unsigned char dst_addr[IDLEN] = {0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F};
		  if (0 ==memcmp(dst_addr, aid, sizeof(dst_addr)))
		    buf[1] = 0xE0;
          /* ��������Ĵ��ı��Ĵ���,Э�����Ͱ���0b100 */
          buf[len-1] = 0x60;   /* ����TPH */
          buf[len++] = 0x00; /* TP.CMD */
          buf[len++] = update_len;
          memcpy(&buf[len], frm, update_len);
          len += update_len;
        }
      else
        {
          //if (0x02 == (appd->protype & PTMASK))
            {
                buf[len++] = frm[8]; //appd->data[0]; //ctrl
                buf[len++] = (frm[8+1] + 1) - 1;//appd->datalen - 1; //len

                memcpy(&buf[len], &frm[8+2], (frm[8+1] + 1) - 1);  //data
                len += (frm[8+1] + 1) - 1;//appd->datalen - 1;
            }
            /*T188Э����ʱû��else
            {
                buf[len++] = appd->datalen;
                memcpy(&buf[len], appd->data, appd->datalen);
                len += appd->datalen;
            }*/
        }

  //Tno7.CSum CXor
  buf[len] = chksum(&buf[1], len - 1);
  buf[len + 1] = chkxor(&buf[1], len - 1);

  len += 2;
  //Tno7.b0.Len
  buf[0] = 0x40 + (len - 1 < 61 ? len - 1 : 61);

  return len; //�������ĵĳ���
}
#endif
int nl_IVfloodtask(unsigned char buf[], unsigned char id[], int depth, struct appdata *appd)
{
    unsigned int ndslength, len = 0;  //��¼����㱨�ĵĳ���,��ʼֵ7Ϊ����NDSǰ�ĳ���
    unsigned char t, addr[12];

    // ******  ��֯ NL.data  ***** //
    if (depth > 7)
        depth = 7;
    len++;                                          // length
    buf[len++] = 0xE9;                              // Tno
    buf[len++] = get_next_flood_sno() << 4;
    buf[len++] = depth;                             // MaxHPD
    buf[len++] = NT_JZQ << 4 + NT_UNKNOWN;
    buf[len++] = 0;                                 // phase

    rt_jzqid(&addr[0]);
    memcpy(&addr[6], &id[0], 6);               //DestID
    CompressMeterID(&addr[0], 2, &ndslength);   //ѹ��NDS
    memcpy(&buf[len], addr, ndslength);
    len += ndslength;
    //�����ж�
    if (appd->data[0] & 0x10)
        t = 0x20;
    else
        t = 0x10;

    buf[len++] = t + 1; //TPH
    buf[len++] = appd->data[0]; //ctrl
    buf[len++] = appd->datalen - 1; //len

    memcpy(&buf[len], &appd->data[1], appd->datalen - 1);  //data
    len += appd->datalen - 1;

    //Tno7.CSum CXor
    buf[len] = chksum(&buf[1], len - 1);
    buf[len + 1] = chkxor(&buf[1], len - 1);

    len += 2;
    //Tno7.b0.Len
    buf[0] = 0x40 + (len - 1 < 61 ? len - 1 : 61);

    return len; //�������ĵĳ���
}

static unsigned char para_sno = 0;
unsigned char get_next_para_sno(void)
{
    if (++para_sno > 15)
        para_sno = 0;
    return (para_sno & 0x0f);
}

int nl_paratask(unsigned char buf[], unsigned int time, unsigned char data[], int data_len, unsigned char type)
{
    unsigned int len, ndslength;
    STRU_TPL_CMD1 *ptr_tpl;
    unsigned char sno;

    sno = get_next_para_sno();
    if (0x00 == sno)
        return (-1);

    len = 1; //ָ��Tno
    buf[len] = 0xC0;
    buf[++len] = (sno << 4) + 1;
    buf[++len] = time / 4;
    buf[++len] = 0;
    len++;

    rt_jzqid(&buf[len]);
    rt_jzqid(&buf[len + 6]);
    rt_jzqid(&buf[len + 12]);
    CompressMeterID(&buf[len], 3, &ndslength);
    len += ndslength;

    ptr_tpl = (STRU_TPL_CMD1 *)&buf[len];
    ptr_tpl->tpv = 0x00;
    ptr_tpl->apv = type;
    if (type >= 0x03)
    {
        ptr_tpl->apv = 0x01;
    }
    ptr_tpl->cmd0 = 0x01;
    ptr_tpl->cmf = 0x00;
    ptr_tpl->noc = 0x01;

    ptr_tpl->cmd1 = 0x04;
    ptr_tpl->flag = 0x09;

    len += 2;
    buf[len++] = data[0];
    buf[len++] = data_len - 1;
    memcpy(&buf[len], &data[1], data_len - 1);
    len += data_len - 1;
    //Tno6.CSum CXor
    buf[len] = chksum(&buf[1], len - 1);
    buf[len + 1] = chkxor(&buf[1], len - 1);
    len += 2;
    //Tno6.b0.Len
    buf[0] = 0x40 + (len - 1 < 61 ? len - 1 : 61);

    return (len); //�������ĵĳ���
}


int nl_paratask_read(unsigned char buf[], unsigned int time, unsigned char data[], int data_len, unsigned char type)
{
    unsigned int len, ndslength;
    STRU_TPL_CMD0 *ptr_tpl;
    unsigned char sno;

    sno = getNewTno6Sno(time, GuangBoChaoBiao);//get_next_para_sno();
    if (0x00 == sno)
        return (-1);

    len = 1; //ָ��Tno
    buf[len] = 0xC0;
    buf[len] |= 0x02;  //��Ҫ��Ӧ
    buf[++len] = (sno << 4) + 1;
    buf[++len] = time / 4;
    buf[++len] = 0;
    len++;

    rt_jzqid(&buf[len]);
    rt_jzqid(&buf[len + 6]);
    rt_jzqid(&buf[len + 12]);
    CompressMeterID(&buf[len], 3, &ndslength);
    len += ndslength;

    ptr_tpl = (STRU_TPL_CMD0 *)&buf[len];
    ptr_tpl->tpv = 0x00;
    ptr_tpl->apv = 0x02;
    ptr_tpl->cmd0 = 0x00;
    ptr_tpl->cmf = 0x00;
    ptr_tpl->noc = 0x01;

    len += 1;
    buf[len++] = data[0];
    buf[len++] = data_len - 1;
    memcpy(&buf[len], &data[1], data_len - 1);
    len += data_len - 1;

    //Tno6.CSum CXor
    buf[len] = chksum(&buf[1], len - 1);
    buf[len + 1] = chkxor(&buf[1], len - 1);

    len += 2;
    //Tno6.b0.Len
    buf[0] = 0x40 + (len - 1 < 61 ? len - 1 : 61);

    return (len); //�������ĵĳ���
}

static int nds_swap(int index, unsigned char *id1, unsigned char *id2)
{
    if (index <= 0)
        return 0;

    for (int m = index - 1; m >= 0; m--)
    {
        if (id1[m] < id2[m])
            return -1;
        else
            if (id1[m] > id2[m])
                return 0;
    }
    return 0;
}

static int nds_sort(struct ndscont *unorder_nds)
{
    for (int i = 0; i < unorder_nds->num; ++i)
        memset(unorder_nds->nds[i].id + unorder_nds->nds[i].len, 0x00, IDLEN - unorder_nds->nds[i].len);

    for (int i = 0; i < IDLEN; ++i)
    {
        for (int j = 0; j < unorder_nds->num; ++j)
        {
            for (int k = j + 1; k < unorder_nds->num; ++k)
            {
                if (unorder_nds->nds[j].id[i] > unorder_nds->nds[k].id[i]) /* need not to swap */
                    continue;
                if (unorder_nds->nds[j].id[i] == unorder_nds->nds[k].id[i])
                {
                    if (nds_swap(i, unorder_nds->nds[j].id, unorder_nds->nds[k].id) == 0) /* need not to swap */
                        continue;
                }

                unsigned char tmplen = unorder_nds->nds[j].len;;
                unsigned char tmpid[IDLEN];
                memcpy(tmpid, unorder_nds->nds[j].id, IDLEN);

                unorder_nds->nds[j].len = unorder_nds->nds[k].len;
                memcpy(unorder_nds->nds[j].id, unorder_nds->nds[k].id, IDLEN);

                unorder_nds->nds[k].len = tmplen;
                memcpy(unorder_nds->nds[k].id, tmpid, IDLEN);
            }
        }
    }

    return 0;
}

static int unzero_high(unsigned char *data, int datalen)
{
    int x = datalen - 1;
    for (; x >= 0; --x)
    {
        if (data[x])
            return x;
    }
    return -1;
}

static int nds_compress(struct ndscont *ndslist, unsigned char *nds, int *ndslen)
{
    unsigned char id_a[IDLEN];
    memset(id_a, 0x00, IDLEN);

    *ndslen = 0;
    for (int i = 0; i < ndslist->num; ++i)
    {
        unsigned char id_b[IDLEN], id_c[IDLEN];
        memset(id_b, 0x00, IDLEN);
        memset(id_c, 0x00, IDLEN);

        memcpy(id_b, ndslist->nds[i].id, ndslist->nds[i].len);  /* initialize */

        for (int j = 0; j < ndslist->nds[i].len; ++j)  /* encry */
            id_c[j] = (id_b[j] - id_a[j]) & 0x7F;

        int lenc = 0;
        if ((lenc = unzero_high(id_c, IDLEN)) == -1)
            lenc = 0;
        id_c[lenc] |= 0x80;

        for (int j = 0; j < lenc + 1; ++j) /* copy to nds */
            nds[(*ndslen)++] = id_c[j];

        memcpy(id_a, id_b, ndslist->nds[i].len); /* reset id_a */
    }

    return 0;
}

static enum nds_type nds_gettype(struct net_msg_head *head)
{
    enum nds_type type = ALLMETER;
    unsigned char cmd = head->cmdscd >> 5;
    unsigned char sqn = head->strhpd >> 7;
    unsigned char pln = head->dutypln & PLNMASK;
    unsigned char rpl = (head->strhpd >> 5) & 0x01;

    if (cmd != 6 && sqn == 1) /* cmd<>6 sqn1 */
        type = ALLSNO;
    if (cmd == 6 && sqn == 1) /* cmd6 sqn1 */
    {
        type = SNOMETER1;
        if (rpl) /* rpl0 */
        {
            if (pln == 1)
                type = METERSNO1;
            else
                type = METER1SNO;
        }
    }

    return type;
}

static int nds_decompress(enum nds_type sqn, int num, unsigned char *frame, int framelen,
                          struct ndscont *ndslist, int *ndslen)
{
    if (num <= 0)
        return -1;
    unsigned char id_a[IDLEN], id_b[IDLEN];
    memset(id_a, 0x00, IDLEN);
    memset(id_b, 0x00, IDLEN);

    int index = 0, len = IDLEN;
    if (sqn == ALLSNO || sqn == SNOMETER1)
        len = SNOLEN;

    for (int i = 0; i < num; ++i)
    {
        if (i == num - 1 && sqn == SNOMETER1)
            len = IDLEN;
        if (i == num - 1 && sqn == METERSNO1)
            len = SNOLEN;
        if (i > 0 && sqn == METER1SNO)
            len = SNOLEN;

        for (int j = 0; j < len; ++j)
        {
            id_a[j] = id_b[j] + frame[index];
            id_a[j] &=  0x7F;

            if (frame[index++] >= 0x80)
                break;
            if (index >= framelen)
                return -1;
        }
        memset(ndslist->nds[i].id, 0x00, IDLEN);
        memcpy(ndslist->nds[i].id, id_a, len); /* copy to ndscontent */
        ndslist->nds[i].len = len;
        if (id_a[0] == 0x7D || id_a[0] == 0x7E || id_a[0] == 0x7F)
        {
            memset(ndslist->nds[i].id + 1, 0x00, IDLEN - 1);
            ndslist->nds[i].len = 1;
        }
        int index = unzero_high(id_a, IDLEN);  /* reset id_b */
        memcpy(id_b, id_a, index + 1);
    }

    *ndslen = index;
    ndslist->num = num;
    return 0;
}

static void para_decompress(unsigned char meter_num, unsigned char *data, unsigned char *nds, unsigned int *decompresslen)
{
    int index = 0, count = 0;
    int ndsindex = 0, i, x;

    for (i = 0;; ++i)
    {
        if (ndsindex >= meter_num * IDLEN)
        {
            break;
        }
        // ��ѹ
        if ((data[i] >> 6) == 0x03) // ����λΪ11
        {
            count = (data[i] & 0x07) + 2;
            index = (data[i] >> 3) & 0x07;

            if (index > 3)
            {
                index = 6 * (index - 3);
            }
            else
                if (index == 0)
                {
                    for (x = 0; x < count; ++x)
                    {
                        nds[ndsindex++] = (char)0x00;
                    }

                    continue;
                }

            index = ndsindex - index;
            for (x = 0; x < count; ++x)
            {
                nds[ndsindex++] = nds[index + x];
            }
        }
        else
        {
            nds[ndsindex++] = data[i];
        }
    }

    *decompresslen = i;
}

static void para_compress(unsigned char *meters, int meter_num, unsigned int *ndslength)
{
    //unsigned char   *tmpnds = (unsigned char *) malloc(meter_num*ID_LENGTH);
    unsigned char  tmpnds[0x80];
    int ndsindex = 0;
    int i, tmpindex, samenum, nowindex, t;  // ��ʱ����
    int maxsamenum, index;                  // �������ƥ��index��samenum

    //
    //tmpnds  ���ѹ����ڵ����� Vn��ʼ
    i = meter_num * IDLEN - 1;  // �Ӵ�β��ʼѹ��
    while (i >= 0)
    {
        tmpindex = i;
        samenum = 0;
        nowindex = i;
        maxsamenum = 0;
        index = 0;

        while (meters[tmpindex] == 0 && tmpindex >= 0 && samenum < 9) //s >0
        {
            samenum++;
            tmpindex--;
        }
        maxsamenum = samenum;
        for (t = 1; t < 8; ++t)  // 7�����
        {
            samenum = 0; nowindex = i;

            if (t < 4)
                tmpindex = i - t;
            else
                tmpindex = i - 6 * (t - 3);

            while (meters[nowindex] == meters[tmpindex] && tmpindex >= 0 && samenum < 9)
            {
                samenum++;
                nowindex--;
                tmpindex--;
            }

            if (maxsamenum < samenum)
            {
                maxsamenum = samenum;
                index = t;
            }
        }

        if (maxsamenum <= 1)
        {
            tmpnds[ndsindex++] = meters[i];
            i--;
        }
        else
        {
            unsigned char tempvalue = 0x03;
            tempvalue <<= 3;
            tempvalue += index;
            tempvalue <<= 3;
            tempvalue += maxsamenum - 2;

            tmpnds[ndsindex++] = tempvalue; //11(index)(maxsamenum - 2)BIN;
            i -= maxsamenum;
        }
    }

    for (i = ndsindex - 1; i >= 0; i--)
    {
        meters[ndsindex - 1 - i] = tmpnds[i];
    }

    *ndslength = ndsindex;
    //free(tmpnds);
}

static int nl_normal(unsigned char *frame, int len)
{
    unsigned char tmp[255];
    int tmplen = 0;

    memcpy(tmp, frame, len); /* copy to tmp */
    tmplen = frame[1];

    memcpy(_commbuf.plc.buf, tmp + 3, tmplen - 1);
    _commbuf.plc.len = tmplen - 1;

    _commbuf.plc.mode = PLCNORMAL; /* normal */
    return 0;
}

static int nl_error(unsigned char *frame, int len)
{
    _commbuf.plc.mode = PLCERR; /* error*/
    return 0;
}

static int chk_verify(unsigned char *frame, int len)
{
    unsigned char sum = chksum(frame + 1, len - 3), xor = chkxor(frame + 1, len - 3);
    if ((sum == frame[len - 2]) && (xor == frame[len - 1]))
    return 0;
    return -1;
}

static int nl_sendcfm(unsigned char *curid, unsigned char *destid, struct net_ivinfo *info)
{
    unsigned char tmp[255], tmplen = 0, frame[255];
    unsigned int ndslen;
    int len = sizeof(struct net_ivinfo);
    struct net_ivinfo *infodw = (struct net_ivinfo *)tmp;

    memcpy(tmp, info, sizeof(struct net_ivinfo));
    infodw->sendctrl = 0x04;
    infodw->rsv1 = 0x00;
    infodw->rsv2 = 0x00;
    infodw->rsv3 = 0x00;
    tmplen += sizeof(struct net_ivinfo) + 1;
    tmp[tmplen++] = 0x04;
    memcpy(&tmp[tmplen], curid, IDLEN);
    memcpy(&tmp[tmplen + 6], destid, IDLEN);
    para_compress(tmp + tmplen, 2, &ndslen);
    tmplen += ndslen;
    if (tmplen + 3 > sizeof(tmp))
        return -1;
    tmp[tmplen++] = (info->sigq & 0x0F) << 4;
    tmp[sizeof(struct net_ivinfo)] = 0x40 + tmplen - len - 1;

    nl_frm38(NLT_IVDOWN, tmp, tmplen, frame, &len, PLC_DC);
    nl_rtwrite(fd_38, frame, len, 0);
    return 0;
}

static int nl_helpres(unsigned char *curid, unsigned char *destid, struct net_ivinfo *info)
{
    unsigned char tmp[255], tmplen = 0, frame[255];
    unsigned int ndslen;
    int len = sizeof(struct net_ivinfo);
    struct net_ivinfo *infodw = (struct net_ivinfo *)tmp;

    memcpy(tmp, info, sizeof(struct net_ivinfo));
    infodw->sendctrl = 0x04;
    infodw->rsv1 = 0x00;
    infodw->rsv2 = 0x00;
    infodw->rsv3 = 0x00;
    tmplen += sizeof(struct net_ivinfo) + 1;
    tmp[tmplen++] = 0x02;
    memcpy(&tmp[tmplen], curid, IDLEN);
    memcpy(&tmp[tmplen + 6], destid, IDLEN);
    memcpy(&tmp[tmplen + 12], curid, IDLEN);
    para_compress(tmp + tmplen, 3, &ndslen);
    tmplen += ndslen;
    if (tmplen + 3 > sizeof(tmp))
        return -1;
    tmp[tmplen++] = (info->sigq & 0x0F) << 4;
    tmp[sizeof(struct net_ivinfo)] = 0x40 + tmplen - len - 1;

    nl_frm38(NLT_IVDOWN, tmp, tmplen, frame, &len, PLC_DC);
    nl_rtwrite(fd_38, frame, len, 0);
    return 0;
}

static int nl_dbgproc(unsigned char *frame, int len)
{
    unsigned char index = 1, id[6];

    if ((frame[0] & 0x01) == 0) /* router to 38*/
        return 0;
    if (frame[0] & 0x08)
        index += 6;
    if (frame[0] & 0x02)
    {
        memcpy(id, _rtparas.jzqid, 6);
        for (int i = 0; i < 6; ++i)
            id[i] = bintobcd(id[i]);
        if (memcmp(id, frame + index, 6) != 0)
            return 0;

        index += 6;
    }
    if (len < index + 3)
        return 0;
    if (frame[index] != 0x01 && frame[index] != 0x07)
        return 0;

    return rt_debug(frame + index + 1, len - index - 1, frame[index]);

}

struct
{
    unsigned char id[6];
    unsigned char jzqid[6];
    unsigned char sno;
    struct info_frame_iv_up info_tno5;

}_tno5_info_III;

static int organize_tno5_iv(unsigned char id[], unsigned char jzqid[], unsigned char sno, struct info_frame_iv_up *pinfo)
{
    unsigned char buf[0x40], nlframe[0xFF];
    int len = 0, nllen = 0;   //t,
    unsigned int ndslength = 0;

    buf[len++] = 0; //  1
    buf[len++] = 0xb5;


    buf[len++] = 0x80 + sno;  //5

    buf[len++] = 0x00;    //tgn  6
    buf[len++] = 3;
    buf[len++] = 0xF0 + 0x07;
    buf[len++] = 0x05;

    //nds  --------------   path??
    //get_jzq_address(&buf[len]);
    char board[6] = { 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f };
    char sinkid[6] = { 0x00, 0x00, 0x64, 0x00, 0x00, 0x00 };
    memcpy(sinkid, _rtparas.sinkid, 2);
    if (memcmp(jzqid, board, IDLEN) == 0)
        memcpy(jzqid, sinkid, IDLEN);

    memcpy(buf + len, jzqid, 6);
    memcpy(&buf[len + 6], &id[0], 6);

    memcpy(buf + len + 12, jzqid, 6);
    memset(&buf[len + 18], 0x7F, 6);

    memcpy(buf + len + 24, jzqid, 6);

    //t = compute_down_frame_len(depth, &buf[len]);
    CompressMeterID(&buf[len], 5, &ndslength);
    len += ndslength;

    unsigned char t_buf[] = { 0x0c, 0x02, 0x80, 0x01 };
    memcpy(&buf[len], &t_buf[0], sizeof(t_buf));
    len += sizeof(t_buf);

    buf[len] = chksum(&buf[1], len - 1);
    buf[len + 1] = chkxor(&buf[1], len - 1);
    len += 2;

    buf[0] = (len - 1) | 0x40;
    extern int fd;
    nl_frm38_tno5(buf, len, nlframe, &nllen, pinfo);
    nl_rtwrite(CHN_38_1, nlframe, nllen, 0);
    return (len);
}

static void send_tno5_frame(void)
{
    organize_tno5_iv(&_tno5_info_III.id[0], _tno5_info_III.jzqid, _tno5_info_III.sno, &_tno5_info_III.info_tno5);
}

static int nl_paratno5_IV(unsigned char *frame, int len, struct para_report *report, struct net_ivinfo *info)
{
    unsigned char nds[5 * IDLEN];
    struct net_tno5_head_IV *head = (struct net_tno5_head_IV *)frame;
    unsigned int tmplen, tplen;
    unsigned char new_event_data[] = { 0x15 + 0x33, 0x00 + 0x33, 0x04 + 0x33 };

    para_decompress(5, frame + sizeof(struct net_tno5_head_IV), nds, &tmplen);
#if 0
    if (db_find(nds) == NULL && memcmp(nds, id, 6) != 0)
    return -1;
#endif

    tmplen += sizeof(struct net_tno5_head_IV);
    if ((head->tnocmd & TNO5_CMDMASK)) /* TNO5_CMDMASK = 0x02 */
    {
        if (frame[tmplen] != 0x6F)
            tmplen += frame[tmplen + 1] + 2;
        else
        {
            nl_dbgproc(frame + tmplen + 2, frame[tmplen + 1]);
            return -1;
        }
    }

    unsigned char sinkid[6];
    char board[6] = { 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f };

    rt_jzqid(sinkid);

    //V0:Դ��ַ V1:Ŀ�ĵ�ַ V2:������ V3:������ V4:���ڵ��ַ
    //V4Ϊ�������ڵ��ַ,����V1��V3��V4��Ϊ�㲥��ַ���Ż��ϱ��¼�
    if (memcmp(_rtparas.jzqid, &nds[4 * IDLEN], IDLEN) != 0 &&
        memcmp(sinkid, &nds[4 * IDLEN], IDLEN) != 0 &&
        (memcmp(board, nds + IDLEN, IDLEN) != 0 ||
         memcmp(board, nds + IDLEN * 3, IDLEN) != 0 ||
         memcmp(board, nds + IDLEN * 4, IDLEN) != 0))
        return -1;

    if (info != NULL && memcmp(&nds[3 * IDLEN], &nds[4 * IDLEN], IDLEN) == 0 &&
        (head->tnocmd & 0x18) != 0x10)          //NPV=2 ����ȷ��
        nl_sendcfm(&nds[3 * IDLEN], &nds[2 * IDLEN], info);

    if ((head->tnocmd & 0x18) == 0x10 &&        //NPV=2
        (head->tnocmd & 0x02))                  //ASW=1
    {
        memcpy(&_tno5_info_III.info_tno5, info, 8);
        _tno5_info_III.sno = frame[2] & 0x7F;
        memcpy(&_tno5_info_III.id[0], &nds[0], 6);
        memcpy(_tno5_info_III.jzqid, nds + 24, 6);
        alloc_a_timer(TIMER_SENDTNO5TIMER, 50, 50, send_tno5_frame);

        if (len <= tmplen + 2)
            return -1;
        tplen = len - tmplen - 2;               /* len + xor + sum */
        if (tplen < 2 || tplen != frame[tmplen + 1] + 2)
            return -1;

        if (_share.version == NEW_GBPRO)
        {
            report->type = TNO5_NEW;
        }
        else
        {
            //���¼�������Э��
            if (frame[tmplen + 2] == 0x91 &&
                memcmp(frame + tmplen + 4, new_event_data, 3) == 0)
            {
                return -1;
            }

            report->type = TNO5;
        }
        memcpy(report->id, nds, IDLEN);
        report->tp[0] = frame[tmplen + 2];
        report->tplen = frame[tmplen + 1];  /* ���ܼ�1 */
        
        if (report->tplen == 0)
          return 0;

        memcpy(&report->tp[1], frame + tmplen + 3, report->tplen - 1);

        for (int i = 1; i < report->tplen; ++i)
            report->tp[i] -= 0x33;

        return 0;
    }

    if (len <= tmplen + 3)
        return -1;
    tplen = len - tmplen - 2;               /* len + xor + sum */
    if (tplen < 3 || tplen != frame[tmplen + 2] + 3)
        return -1;
    if ((frame[tmplen] & TPCM0MASK) != 0x00)
        return -1;

    if (_share.version == NEW_GBPRO)
    {
        report->type = TNO5_NEW;
    }
    else
    {
        //���¼�������Э��
        if (frame[tmplen + 1] == 0x91 &&
            memcmp(frame + tmplen + 4, new_event_data, 3) == 0)
        {
            return -1;
        }

        report->type = TNO5;
    }

    memcpy(report->id, nds, IDLEN);
    report->tp[0] = frame[++tmplen];
    report->tplen = frame[++tmplen] + 1;

    memcpy(&report->tp[1], frame + tmplen + 1, report->tplen - 1);

    for (int i = 1; i < report->tplen; ++i)
        report->tp[i] -= 0x33;

    return 0;
}

static int nl_paratno5(unsigned char *frame, int len, struct para_report *report, struct net_ivinfo *info)
{
    unsigned char nds[4 * IDLEN], jzqid[6];
    struct net_tno5_head *head = (struct net_tno5_head *)frame;
    unsigned int tmplen, tplen;
    unsigned char new_event_data[] = { 0x15 + 0x33, 0x00 + 0x33, 0x04 + 0x33 };

    if (chk_verify(frame, len) != 0)
        return -1;

    if ((head->tnocmd & 0x18) != 0x00)
    {
        //NPV��Ϊ0  ֱ�ӽ���NPV=1��2�Ĵ���������
        return nl_paratno5_IV(frame, len, report, info);   /*new frame*/
    }

    para_decompress(4, frame + sizeof(struct net_tno5_head), nds, &tmplen);
#if 0
    if (db_find(nds) == NULL && memcmp(nds, id, 6) != 0)
    return -1;
#endif

    tmplen += sizeof(struct net_tno5_head);
    if ((head->tnocmd & TNO5_CMDMASK)) /* TNO5_CMDMASK = 0x02 */
    {
        if (frame[tmplen] != 0x6F)
            tmplen += frame[tmplen + 1] + 2;
        else
        {
            nl_dbgproc(frame + tmplen + 2, frame[tmplen + 1]);
            return -1;
        }
    }
    rt_jzqid(jzqid);
    if (memcmp(jzqid, &nds[3 * IDLEN], IDLEN) != 0)
        return -1;

    if (info != NULL && memcmp(&nds[2 * IDLEN], &nds[3 * IDLEN], IDLEN) == 0)
        nl_sendcfm(&nds[2 * IDLEN], &nds[1 * IDLEN], info);

    if (len <= tmplen + 3)
        return -1;
    tplen = len - tmplen - 2;               /* len + xor + sum */
    if (tplen < 3 || tplen != frame[tmplen + 2] + 3)
        return -1;
    if ((frame[tmplen] & TPCM0MASK) != 0x00)
        return -1;

    if (_share.version == NEW_GBPRO)
    {
        report->type = TNO5_NEW;
    }
    else
    {
        //���¼�������Э��
        if (frame[tmplen + 1] == 0x91 &&
            memcmp(frame + tmplen + 4, new_event_data, 3) == 0)
        {
            return -1;
        }

        report->type = TNO5;
    }

    memcpy(report->id, nds, IDLEN);
    report->tp[0] = frame[++tmplen];
    report->tplen = frame[++tmplen] + 1;

    memcpy(&report->tp[1], frame + tmplen + 1, report->tplen - 1);

    for (int i = 1; i < report->tplen; ++i)
        report->tp[i] -= 0x33;

    return 0;
}

static int nl_paratno6(unsigned char *frame, int len, struct para_report *report, struct net_ivinfo *info)
{
    unsigned char nds[5 * IDLEN], id[IDLEN], t;
    struct net_tno6_head *head = (struct net_tno6_head *)frame;
    unsigned int tmplen, num = (head->snohpd & TN6HPDMASK) + 2;

    if (chk_verify(frame, len) != 0)
        return -1;
    if ((head->snohpd & TN6HPDMASK) == 0)    /* TN6HPDMASK = 0x0F*/
        return -1;
    num = (num > 5) ? 5 : num;
    para_decompress(num, frame + sizeof(struct net_tno6_head), nds, &tmplen);
    rt_jzqid(id);
    if (memcmp(id, &nds[(num - 1) * IDLEN], IDLEN) != 0)
        return -1;

    t = sizeof(struct net_tno6_head) + tmplen;

#if 1 //ע��Ҫ�õ�
    if (GuangBoChaoBiao == getTno6TaskType(head->snohpd >> 4))
    {
        report->type = _TNO6;
        t += 2;
        t += (1 + frame[t]);
        if ((_rtparas.state & STARMASK) != STAREG)
        {
            if ((t + 3) >= len)
            {
                if (info != NULL && memcmp(&nds[(num - 2) * IDLEN], id, IDLEN) == 0
                    && memcmp(id, &nds[(num - 3) * IDLEN], IDLEN) != 0)
                    nl_sendcfm(id, &nds[(num - 3) * IDLEN], info);
                return (-1);
            }
        }
        if ((frame[1 + t] < 100) && frame[1 + t])
        {
            report->tp[0] = frame[t];
            memcpy(&report->tp[1], &frame[t + 2], frame[1 + t]);
            report->tplen = frame[1 + t] + 1;
            for (int i = 1; i < report->tplen; ++i)
                report->tp[i] -= 0x33;
        }
        else
            report->tplen = 0;
    }
    else
#endif
        report->type = TNO6;

    if (info != NULL && memcmp(&nds[(num - 2) * IDLEN], id, IDLEN) == 0
        && memcmp(id, &nds[(num - 3) * IDLEN], IDLEN) != 0)
        nl_sendcfm(id, &nds[(num - 3) * IDLEN], info);
    memcpy(report->id, nds, IDLEN);

    return 0;
}

static int nl_help(unsigned char *frame, int len, struct net_ivinfo *info)
{
    unsigned char nds[2 * IDLEN], id[IDLEN];
    unsigned int tmplen;

    para_decompress(2, frame + 2, nds, &tmplen);

    rt_jzqid(id);
    if (memcmp(id, &nds[IDLEN], IDLEN) != 0)
    {
        if (memcmp(_rtparas.jzqid, &nds[IDLEN], IDLEN) != 0)
            return -1;
        memcpy(id, _rtparas.jzqid, IDLEN);
    }

    return nl_helpres(id, nds, info);
}
#if 0
static int nl_paralle(unsigned char *frame, int len)
{
    unsigned char num = frame[3], tmplen = 1, tmpbuf[255];
    struct para_report report;

    _commbuf.plc.mode = PLCACTIVE; /* active */

    for (int i = 0; i < num && tmplen < len; i++)
        tmplen += frame[3 + tmplen] + 1;

    if (frame[1] != tmplen + 1)
        return -1;

    for (int i = 0, index = 4; i < num; ++i)
    {
        tmplen = frame[index] + 1;
        memcpy(tmpbuf, &frame[index], tmplen);
        index += tmplen;
        if (nl_paraprocess(tmpbuf, tmplen, &report) != 0)
            continue;
        if ((report.type == TNO6 && (_rtparas.state & STARMASK) == STAREG)
            || (report.type == TNO5) || (report.type == _TNO6))
            report_push(&report);
    }

    set_rts_value(CHN_38_1, 1);

    return 0;
}

static int nl_parallel(unsigned char *frame, int len)
{
    unsigned char tmp[255];
    int tmplen = 0;

    memcpy(tmp, frame, len); /* copy to tmp */
    tmplen = frame[1];

    memcpy(_commbuf.plc.buf, tmp + 3, tmplen - 1);
    _commbuf.plc.len = tmplen - 1;

    _commbuf.plc.mode = PLCNORMAL; /* normal */
    return (0);
}
#endif
static int nl_confirm(unsigned char *frame, int len)
{
    _commbuf.plc.mode = PLCCFM; /* confirm */
    return 0;
}

static int nl_handshake(unsigned char *frame, int len)
{
    if (0x43 == frame[8])
    {
        plc_38_43 = 1;
    }

    _commbuf.plc.mode = PLCRPT; /* normal */
    return (0);
}

static int nl_skid(unsigned char *frame, int len)
{
    unsigned char id[IDLEN], nlframe[20];
    int nllen;

    rt_jzqid(id);

    nl_frm38(NLT_SKID, id, IDLEN, nlframe, &nllen, PLC_DC);
    nl_rtwrite(CHN_38_1, nlframe, nllen, 0);

    _commbuf.plc.mode = PLCSKID; /* active */
    return 0;
}

static int nl_rand(unsigned char *frame, int len)
{
    _commbuf.plc.buf[0] = frame[3];
    _commbuf.plc.len = 1;

    _commbuf.plc.mode = PLCRPT; /* normal */
    return 0;
}

static int nl_ivup(unsigned char *frame, int len)
{
    unsigned char tmplen = 3 + sizeof(struct net_ivinfo), tmpbuf[255];
    int ret = -1;
    struct para_report report;
    struct net_ivinfo info;

    _commbuf.plc.mode = PLCACTIVE; /* active */

    memcpy(&info, (struct net_ivinfo *)&frame[3], sizeof(struct net_ivinfo));
    /*protect, dont compress, dont recognize VIII or VIV*/
    info.lllctrl &= ~0x02;
    memcpy(tmpbuf, &frame[tmplen], frame[1] - 1 - sizeof(struct net_ivinfo));
    tmplen = frame[1] - 1 - sizeof(struct net_ivinfo);

    if ((tmpbuf[1] & TNOMASK) == TNO0)
        return nl_help(tmpbuf, tmplen, &info);

    if ((tmpbuf[1] & TNOMASK) == TNO7)
    {
        if ((tmpbuf[1] & 0x02) == 0) /*rpl == 0,down*/
        {
            _commbuf.plc.mode = PLCEMP;
            return -1;
        }

        memcpy(_commbuf.plc.buf, tmpbuf, tmplen);
        _commbuf.plc.len = tmplen;
        _commbuf.plc.mode = PLCNORMAL;
        return 0;
    }

    if ((tmpbuf[1] & TNOMASK) == TNO5)
        ret = nl_paratno5(tmpbuf, tmplen, &report, &info);
    if ((tmpbuf[1] & TNOMASK) == TNO6)
        ret = nl_paratno6(tmpbuf, tmplen, &report, &info);

    if (ret == 0)
        report_push(&report);

    return ret;
}

static int nl_check(unsigned char *frame, int len, int *begin, int *end)
{
    unsigned char tmp[255], buf[255];
    unsigned char tmplen = 0;

    memcpy(tmp, frame, len);
    for (int i = 0; i < len; ++i)
    {
        if (tmp[i] == 0x9F)
        {
            tmplen = (tmp[i + 1] - 0x0A) ^ 0x35;
            if (len < tmplen + 4)
                continue;
            if (i + tmplen + 4 > len)
                continue;
            memcpy(buf, tmp + i, tmplen + 4);
            if (nl_frm38_decrypt(buf, tmplen + 4) ==  0)
            {
                memcpy(frame + i, buf, tmplen + 4);
                *begin = i;
                *end = i + tmplen + 4;
                return 0;
            }
        }
    }
    return -1;
}

static int gb645_check(unsigned char *frame, int len, int *begin, int *end)
{
    unsigned char tmp[255], cs = 0;
    int tmplen = 0;

    memcpy(tmp, frame, len);
    for (int i = 0; i < len; ++i)
    {
        if (tmp[i] == 0x68)
        {
            if (tmp[i + 7] != 0x68)
                continue;
            tmplen = tmp[i + 9];
            if (len < tmplen + 12)
                continue;
            if (i + tmplen + 11 > len)
                continue;
            if (tmp[i + tmplen + 11] != 0x16)
                continue;
            for (int j = i; j < tmplen + 10; j++)
                cs += tmp[j];
            if (cs != tmp[i + tmplen + 10])
                continue;
            *begin = i;
            *end = i + tmplen + 12;
            return 0;
        }
    }
    return -1;
}

static int nl_proc(unsigned char *frame, int len)
{
    for (int i = 0; i < sizeof(nlprocs) / sizeof(nlprocs[0]); ++i)
    {
        if (frame[2] == nlprocs[i].type)
            return nlprocs[i].proc(frame, len);
    }

    _commbuf.plc.mode = PLCERR; /* error */
    return 0;

}

static int report645(unsigned char *frame, int len)
{
    struct para_report report;

    _commbuf.plc.mode = PLCACTIVE;

    memcpy(report.id, &frame[1], IDLEN);
    for (int i = 0; i < IDLEN; ++i)
        report.id[i] = bcdtobin(report.id[i]);
    if (db_find(report.id) != NULL)
    {
        report.type = TNO5;
        report.tp[0] = frame[8];
        report.tplen = frame[9] + 1;
        memcpy(&report.tp[1], frame + 10, frame[9]);
        report_push(&report);
    }

    return 0;
}

static int gb645_proc(unsigned char *frame, int len)
{
    unsigned char tmp[255];
    int tmplen = frame[9];

    memcpy(tmp, frame, len);
    for (int i = 0; i < tmplen; i++)
        tmp[10 + i] -= 0x33;

    if (frame[8] == 0x9F)
        return report645(tmp, len);

    memcpy(_commbuf.plc.buf, tmp, len);
    _commbuf.plc.len  = len;
    _commbuf.plc.mode = 0;

    return 0;
}

static unsigned char chksum(const unsigned char *data, int len)
{
    unsigned char cs = 0;

    while (len-- > 0)
        cs += *data++;
    return (cs);
}

static unsigned char chkxor(const unsigned char *data, int len)
{
    unsigned char cs = 0;

    while (len-- > 0)
        cs ^= *data++;
    return (cs);
}

static int report_push(struct para_report *report)
{
    unsigned char tmplen = 0;

    if (report->type == TNO6)
        tmplen = offset(struct para_report, tplen);
    else
        if (report->type == TNO5 || report->type == TNO5_NEW)
            tmplen = offset(struct para_report, tp) + report->tplen;
        else
            if (report->type == _TNO6)
                tmplen = offset(struct para_report, tp) + report->tplen;
            else
                return -1;

    if (tmplen + _rtreport.len >= sizeof(_rtreport.buf))
        return -1;

    memcpy(&_rtreport.buf[_rtreport.len], report, tmplen);
    _rtreport.len += tmplen;
    _rtreport.buf[_rtreport.len++] = tmplen;
    return 0;
}

/**************************��ʾ��Ԫ***********************/
int dispnl_monittask1(struct appdata *appd, unsigned char cmd, unsigned char mnttkn,
                      unsigned char *sno, unsigned char *frame, int *framelen)
{
    int tmplen = 0, crtlen = 0, len = *framelen;
    unsigned char tmpnds[32 * IDLEN];
    unsigned char mnt = 0, tkn = 0, nsno = 0, asw = 0;

    mnt = mnttkn & PMNTMASK;
    tkn = mnttkn & PTKNMASK;
    nsno = mnttkn & PNSMASK;
    asw  = mnttkn & PASWMASK;
    if (nds_compress(&_ndscont, tmpnds, &tmplen) != 0) /* nds */
        return -1;
    if (len < sizeof(struct net_msg_head) + tmplen + appd->datalen + 1)
        return -1;

    struct net_msg_head *head = (struct net_msg_head *)frame;
    head->tnosdd = 0x20; /* tno = 1 */
    head->cmdscd = cmd << 5; /* cmd = 0 */
    head->strhpd = BITSQN;  /* sqn = 1 rpl = 0 */
    if (cmd == 0)
        head->strhpd &= ~BITSQN;
    head->strhpd += 1;  /* hpd  = 1*/
    if (tkn)
        head->strhpd |= BITTKN;

    head->dutypln = _ndscont.num - 1;
    if (asw == 0)
        head->dutypln |= BITASW;
    if (mnt)
        head->dutypln |= BITMNT;

    memcpy(head->sinkid, _rtparas.sinkid, sizeof(_rtparas.sinkid));
    if (nsno)
        head->sinkid[1] |= 0x80;
    crtlen += sizeof(struct net_msg_head);

    memcpy(frame + crtlen, tmpnds, tmplen);
    crtlen += tmplen;

    if (head->cmdscd == 0xC0)  /* sno */
    {
        memcpy(frame + crtlen, sno, SNOLEN);
        crtlen += SNOLEN;
    }

    frame[crtlen++] = appd->datalen + 1 + 6;  /* tp */
    frame[crtlen++] = _rtparas.wrkno | 0x40;

    if (appd->wretlen == 0)
    {
        if (appd->datalen >= 3 && appd->data[0] == READ_97)
            frame[crtlen++] = nl_itemlen(appd->data + 1, 2);
        else
            if (appd->datalen >= 5 && appd->data[0] == READ_07)
                frame[crtlen++] = nl_itemlen(appd->data + 1, 4);
            else
                frame[crtlen++] = 0;
    }
    else
        frame[crtlen++] = appd->wretlen;

    memcpy(frame + crtlen, appd->data, appd->datalen);
    crtlen +=  appd->datalen;

    memcpy(frame + crtlen, _task.minfo.id, IDLEN);
    crtlen += IDLEN;

    if (crtlen - 1 > 0x3f)
        head->len = 0x7F;
    else
        head->len = (crtlen - 1) | 0x40;
    *framelen = crtlen;

    send_tick = get_sys_tick();

    return 0;
}

int dispnl_monitprocess(unsigned char *frame, int framelen, struct appdata *appd, struct rtinfo *strglvl)
{
    int tmplen = 0, len = 0, num = 3;
    struct ndscont tmpnds;

    if (framelen < sizeof(struct net_msg_head))
        return -1;
    struct net_msg_head *head = (struct net_msg_head *)frame;
    len += sizeof(struct net_msg_head);
    if ((head->tnosdd & TNOMASK) != 0x20) /* tno=1 */
        return -1;
    if ((head->strhpd & BITRPL) != BITRPL)
        return -1;
    if ((head->cmdscd & CMDMASK) != 0x00 && (head->cmdscd & CMDMASK) != 0xC0) /* cmd=0 cmd=6 */
        return -1;
    if ((head->dutypln & ASWMASK) == 0x20) /*asw = 1*/
        return -8;
    if (nds_decompress(nds_gettype(head), num, frame + len, framelen - len, &tmpnds, &tmplen) != 0) /* nds */
        return -1;
    len += tmplen;

    if (memcmp(tmpnds.nds[0].id, dispidno, IDLEN) != 0)
        return -2;

    memset(strglvl, 0x00, sizeof(struct rtinfo));
    strglvl->phase = (frame[len] & PHASEMASK) >> 6;
    strglvl->strong = frame[len++] & STRONGMASK;
    if ((head->cmdscd & CMDMASK) == 0xC0 && (head->sinkid[1] & 0x80) == 0x00)
        strglvl->setsno = 1;

    if (framelen < frame[len] + len + 1) /* +tp[0] tp[1]*/
        return -1;

    if ((get_sys_tick() - send_tick) < 500)
        return -1; //ͬ�·�������Ų�ͬ

    if (_task.ml.opt.mt)
    {
        _task.ml.opt.mt->node.envi &= ~NPRTMASK;
        if ((frame[len + 1] & 0x0F) != _rtparas.wrkno)
        {
            _task.ml.opt.mt->node.envi |= NPIRATE; /* pirate chip !!! */  //��ǰ����û����db_write�ĵ���
            _task.ml.opt.mt->node.succhops |= NSUCC;  //��ǰ����û����db_write�ĵ���
            ++_task.cnt;
            return -1;  /* wrkno error */
        }
    }

    if (frame[len] < 6)
        return -1;

    unsigned char id[6];
    appd->datalen = frame[len++] - 6;
    memcpy(id, frame + len + 1 + appd->datalen, IDLEN);
    if (memcmp(_task.minfo.id, id, IDLEN) != 0)
        return -2;

    /* �����ص�Э������ + �㳭�·���Э������*/
    appd->protype = (appd->protype & 0x0F) | (frame[len] & 0xF0);
    memcpy(appd->data, frame + len + 1, appd->datalen);

    return 0;
}

/**************************7���м�***********************/
int s9nl_monittask1(struct appdata *appd, unsigned char mnttkn, unsigned char *sno, unsigned char *frame, int *framelen)
{
    int tmplen = 0, crtlen = 0, len = *framelen;
    unsigned char tmpnds[32 * IDLEN];
    unsigned char mnt = 0, tkn = 0, nsno = 0, asw = 0;

    mnt = mnttkn & PMNTMASK;
    tkn = mnttkn & PTKNMASK;
    nsno = mnttkn & PNSMASK;
    asw  = mnttkn & PASWMASK;
    if (nds_compress(&_ndscont, tmpnds, &tmplen) != 0) /* nds */
        return -1;
    if (len < sizeof(struct net_msg_head) + tmplen + appd->datalen + 1)
        return -1;

    struct net_msg_head *head = (struct net_msg_head *)frame;
    head->tnosdd = 0x20; /* tno = 1 */
    head->cmdscd = 0x00; /* cmd = 0 */
    head->strhpd = BITSQN;  /* sqn = 1 rpl = 0 */
    head->strhpd += 1;  /* hpd  = 1*/
    if (tkn)
        head->strhpd |= BITTKN;

    head->dutypln = _ndscont.num - 1;
    if (asw == 0)
        head->dutypln |= BITASW;
    if (mnt)
        head->dutypln |= BITMNT;

    memcpy(head->sinkid, _rtparas.sinkid, sizeof(_rtparas.sinkid));
    if (nsno)
        head->sinkid[1] |= 0x80;
    crtlen += sizeof(struct net_msg_head);

    head->cmdscd = 0x00;
    head->strhpd &= ~BITSQN;

    memcpy(frame + crtlen, tmpnds, tmplen);
    crtlen += tmplen;

    frame[crtlen++] = appd->datalen + 1;  /* tp */
    //frame[crtlen++] = _rtparas.wrkno;
    frame[crtlen++] = WorkNo++;
    if (WorkNo > MAXWRKSNO)
        WorkNo = 1;

    if (appd->wretlen == 0)
    {
        if (appd->datalen >= 3 && appd->data[0] == READ_97)
            frame[crtlen++] = nl_itemlen(appd->data + 1, 2);
        else
            if (appd->datalen >= 5 && appd->data[0] == READ_07)
                frame[crtlen++] = nl_itemlen(appd->data + 1, 4);
            else
                frame[crtlen++] = 0;
    }
    else
        frame[crtlen++] = appd->wretlen;

    memcpy(frame + crtlen, appd->data, appd->datalen);
    crtlen +=  appd->datalen;

    if (crtlen - 1 > 0x3f)
        head->len = 0x7F;
    else
        head->len = (crtlen - 1) | 0x40;
    *framelen = crtlen;

    send_tick = get_sys_tick();

    return 0;
}

/* V���鱨�ĺ��� */
int nl_fill_frm(unsigned char ctrl, unsigned char *info, unsigned char *buf, int len)
{
  unsigned char sbuf[0x100];
  memset(sbuf, 0x00, sizeof(sbuf));
  
  /* ����4����ӡ��Ϣ */
  if (ctrl == CTL_43_CMD)
    {
      int debug_begin = 0, debug_end = 0, debug_len = 0;
      debug_len = len;
      memcpy(sbuf, buf, debug_len);
      
      if (nl_check(sbuf, debug_len, &debug_begin, &debug_end) == 0)
        {
          printf_s("\niv****send:    ");
          
          for(int i = 0; i< (debug_end - debug_begin); i++)
            {
              printf_s("%02x ",sbuf[debug_begin + i]);
            }
          printf_s("\n");
        }
      
      memset(sbuf, 0x00, sizeof(sbuf));
    }
  
  struct nl_frm_info *pframe = (struct nl_frm_info *)&sbuf[0];

  memmove(&pframe->data[0], &buf[0], len);
  pframe->len = len + 3;     /*ctr+info+data*/
  pframe->start_flag = NL_FRM_HEADER;
  pframe->ctrl = ctrl;

  if(NULL == info)
    {
      pframe->info[0] = 0;
      pframe->info[1] = 0;
    }
  else
    {
      pframe->info[0] = info[0];
      pframe->info[1] = info[1];
    }
#if 0
  pframe->data[len] = chksum((unsigned char *)&pframe->ctrl, pframe->len);
  pframe->data[len + 1] = chkxor((unsigned char *)&pframe->ctrl, pframe->len);
#else
  unsigned short crc;
  crc = crc16_soft1(&pframe->ctrl, pframe->len);
  pframe->data[len] = (crc >> 8) & 0xFF;  /* �㷨�����Ѿ������� */
  pframe->data[len + 1] = crc & 0xFF;
#endif

  printf_s("\nv****send:    ");
  for(int i = 0; i< len + 8; i++)
    printf_s("%02x ",sbuf[i]);
  printf_s("\n");

#ifndef CZZ_DEBUG
  nl_frm_encry((unsigned char *)&pframe->start_flag, pframe->len + 5);
#endif
  memcpy(buf, sbuf, len+8);

  return(len + 8);
}

static int nl_frm_encry(unsigned char *frm, int len)
{
	struct nl_frm_info *pframe = (struct nl_frm_info *)&frm[0];
	unsigned char seed, tmp_len, *ptr;

	if(NL_FRM_HEADER != pframe->start_flag) 
    return -1;
	if(0x00 == pframe->len)
    return -1;
	if(len != (pframe->len + 5)) 
    return -1;

	tmp_len = pframe->len;
	ptr = (unsigned char *)&pframe->ctrl + pframe->len; /*ptrָ��SUM*/
	seed = *ptr++;
	seed ^= *ptr;

	ptr = (unsigned char *)&pframe->ctrl;					/*ptrָ��Type*/
	do
	{
		seed ^= *ptr;
		*ptr++ = seed;
	}while(--tmp_len);

	pframe->len = (pframe->len ^ 0x2129) + 0x0A5A;
	return 0;
}

static int nl_frm_decry(unsigned char *frm, int len)
{       
  unsigned char csum = 0x00, cxor = 0x00;

  if (frm[0] != 0x9F)
    return -1;

  for (int i = len - 3; i > 3; i--)     /* decry */
    frm[i] ^= frm[i - 1];

  #ifndef CZZ_DEBUG
  frm[3] ^= frm[len - 2] ^ frm[len - 1];
  #endif
#if 0  /* ����У�� */
  for (int i = 3; i < len - 2; ++i)                               /* check csum and cxor */
    {
      csum += frm[i];
      cxor ^= frm[i];   
    }
  if (csum != frm[len - 2] || cxor != frm[len - 1])
    return -1;
#else
  
  unsigned short crc;
  crc = crc16_soft1(&frm[3], len - 5);  /* �㷨�����Ѿ������� */
  if (crc != frm[len - 2] * 256 + frm[len - 1])  /* ���ﲻ��Ҫ���� */
    return -1;
#endif
  return 0;             
}

static int nl_frm_check(unsigned char *frm, int len, int *end)
{
  unsigned char tmp[255];
  unsigned short datalen;
  int result = -1;
  
  /* ���ܻή��Ч�� */
  #if 0  //��ʱ����,���������
  for (int i = 0; i < len; ++i)  /* ������״̬���⴦�� */
    {
      if (frm[i] != 0xFE)
        continue;

      if(is_data_all_same(&frm[i], 4, 0xFE) && (get_645_frame(frm, len - i) >= 0)
      && ((len-4-i) >= 23) && (frm[8+i+4] == 0x9F) && (frm[9+i+4] == 0x0B) && (frm[19+i+4] == 0x33))  /* �жϷ���Ҫ���ٴ汨�� */
        {
          memcpy(zero_detect_buf, &frm[i + 4], len - i);
          break;
        }
    }
  #endif
  for (int i = 0; i < len; ++i)
    {
      if (frm[i] != 0x9F)
        continue;
      datalen = (frm[i + 2] << 8) | frm[i + 1];
      
#ifndef CZZ_DEBUG
      datalen = (datalen - 0x0A5A) ^ 0x2129;
#endif
      if (datalen < 1 || datalen > 255)
        continue;
      if (i + datalen + 5 > len)
        {
          result = 0;
          continue;
        }
      memcpy(tmp, frm + i, datalen + 5);
      
#ifndef CZZ_DEBUG
      if (nl_frm_decry(tmp, datalen + 5) == 0)
#endif
        {
          memcpy(frm, tmp, datalen + 5);
          *end = i + datalen + 5;
          return datalen + 5;
        }
    }

  return result;
}

/************************************************************************************************
*	����˵��:   ��ѹ��������Ϣ(3.5������)
*
*	����˵��:   meter_num(in)      -  ��Ҫ��ѹ�����ŵĸ���
*                   data(in)     -  ����(���ֽ�ΪNDS��ʼ)
*                   nds(out)     -   �����Num����������(6*meter_num���ֽ�)
*                   decompresslen(out)     -   ��ѹ���ı�����ԭ�����еĳ���
*	����ֵ:	    ��
************************************************************************************************/
void DeCompressMeterID(unsigned char meter_num, unsigned char *data, unsigned char *nds, unsigned int *decompresslen)
{
	int index = 0, count = 0;
	int ndsindex = 0, i, x;

	for ( i = 0;; ++i)
	{
		if (ndsindex >= meter_num * ID_LENGTH)
		{
			break;
		}
		// ��ѹ
		if ((data[i] >> 6) == 0x03) // ����λΪ11
		{
			count = (data[i] & 0x07) + 2;
			index = (data[i] >> 3) & 0x07;

			if (index > 3)
			{
				index = 6 * (index - 3);
			}
			else if (index == 0) 
			{
				for (x = 0; x < count; ++x)
				{
					nds[ndsindex++]= (char)0x00;
				}

				continue;
			}

			index = ndsindex - index;
			for (x = 0; x < count; ++x)
			{
				nds[ndsindex++]= nds[index + x];
			}
		}
		else
		{
			nds[ndsindex++]= data[i];
		}
	}

	*decompresslen = i;
}

/************************************************************************************************
*	����˵��: ����ѹ��(3.5������)
*
*	����˵��:	
*                 Meters (in/out)   -	����(˳��v0, v1,v2,v3,), 
*                                   ����ѹ������������д����Meters�У���0λ�ÿ�ʼ���ǣ�
*                 meter_num (in)    -	Meters�д�ű��ŵĸ���
*                 ndslength (out)   -	ѹ����ı��ŵĳ���*
*	����ֵ:	  ��
*	  ��ע:   Meters�ĳ�����= meter_num * ID_LENGTH
************************************************************************************************/

void CompressMeterID(unsigned char *Meters, int meter_num, unsigned int *ndslength)
{	
	//unsigned char   *tmpnds = (unsigned char *) malloc(meter_num*ID_LENGTH);
     unsigned char  tmpnds[0x80];
	int ndsindex = 0;
        int i, tmpindex, samenum , nowindex,t ;  // ��ʱ����
 	int maxsamenum, index ;                  // �������ƥ��index��samenum
        
	// 
	//tmpnds  ���ѹ����ڵ����� Vn��ʼ
	i = meter_num*ID_LENGTH - 1;  // �Ӵ�β��ʼѹ��
	while (i >= 0)
	{
		tmpindex = i;
		samenum = 0;
		nowindex = i;  
		maxsamenum = 0;
		index = 0;
        	
        while (Meters[tmpindex] == 0 && tmpindex >= 0 && samenum < 9) //s >0
		{
			samenum ++;
			tmpindex --;
		}
		maxsamenum = samenum;	
		for (t = 1; t < 8; ++t)  // 7�����
		{
			samenum = 0; nowindex = i;

			if (t < 4)
				tmpindex = i - t;
			else
				tmpindex = i - 6 * (t - 3);
				
			while (Meters[nowindex] == Meters[tmpindex] && tmpindex >= 0 && samenum < 9)
			{
				samenum ++;
				nowindex --;
				tmpindex --;
			}

			if (maxsamenum < samenum)
			{
				maxsamenum = samenum;
				index = t;
			}
		}
			
		if (maxsamenum <= 1)
		{
			tmpnds[ndsindex++]= Meters[i];
			i --;
		}
		else
		{
			unsigned char tempvalue = 0x03;
			tempvalue <<= 3;
			tempvalue += index;
			tempvalue <<= 3;
			tempvalue += maxsamenum - 2;

			tmpnds[ndsindex++]= tempvalue; //11(index)(maxsamenum - 2)BIN;
			i -= maxsamenum;
		}
	}

	for (i = ndsindex - 1; i >= 0; i--)
	{
		Meters[ndsindex - 1 - i]= tmpnds[i];
	}

	*ndslength = ndsindex;
	//free(tmpnds);
}
