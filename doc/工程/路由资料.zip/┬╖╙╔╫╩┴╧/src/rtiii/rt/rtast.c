/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rtast.c
 *
 * Description: Router assist funcation interface and inner route strategy
 *
 * Version: v1.0
 * Time:    2010-1-13
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/dev/eeprom.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rt.h"
#include "../include/rt/rterrs.h"
#include "../include/app/app.h"
#include "../include/rt/rtast.h"
#include "dev_ctrl.h"
#include "../include/app/nwtask.h"
#include "router.h"
#include "../include/db/hash.h"
#include "boot.h"
#include "tlib.h"


#define  SINK38SET 0x01
//#define  FAILCNT 0x09
#define  FAILCNT 0x03

static  unsigned char sink38mode = 0;
unsigned char _testdata[] = {0x01, 0x53, 0xf3};
unsigned char _testgb[] = {0x11, 0x33, 0x33, 0x34, 0x33};
unsigned char channel38 = 0;
unsigned char plc_new = 0, plc_t_end = 0;


unsigned int tno6TaskLft[TNO6_MAX_TASK_NUMBER]={0};  //���г����ĸ�����ŵ�ʣ��ʱ��(15������)
enum ParallelTaskType tno6TaskType[TNO6_MAX_TASK_NUMBER]; //���������Ӧ��698.42����Э������
unsigned char lastTno6Sno = 0;   //�ϴ�������������



extern int fd;
extern unsigned char local_viv_swi;
//static int floodreq1();
//static int floodreq2(struct mtlist *mtl);
//static int floodplc1();
//static int floodplc2(struct mtlist *mtl);
//static int floodret1();
//static int floodret2(struct mtlist *mtl);
static unsigned int fload_waittime(int maxHpd, int frameDownLen, int frameUpLen);
static int rt_floodmntplc();

static int monitreq1();
static int monitreq2(struct mtlist *mtl);
static int monitplc1();
static int monitplc2(struct mtlist *mtl);
static int monitret1();
static int monitret2(struct mtlist *mtl);
static int monitdlytm1();
static int monitdlytm2(struct mtlist *mtl);
static int monitnds();
static int monit_update(struct rtinfo *strglvl, unsigned char upsucc);
static int clr_strglvl_dev(struct rtinfo *strglvl);
static int confmt(struct mtlist *mtl);

static int s9req2(struct mtlist *mtl);
static int s9plc1();
static int s9plc2(struct mtlist *mtl);

static int rt_appmnt_init(unsigned char *mtid);
static int rt_mntplc();
static int rt_mntplc_v();
static int rt_disp_mntplc();
static int rt_mntprocess();
static void rt_mntclear();

//static int rt_floodmntplc();
static void reg_timer();
static int report_valid(struct para_report *report);
static int apptask(struct para_report *report);
static void report_start();
static int report_pop(struct para_report *report);

static int flood_updata(struct mtinfo *mt, unsigned char depth, unsigned char suc);
static void mnt_init_to_flood(unsigned char depth);
extern int appgb_nw_dc_v(unsigned char proto, unsigned char add[], unsigned char *buf, unsigned char len, unsigned char exlen);
int appgb_build_645cmd(const unsigned char *meter, unsigned char ctrl, unsigned char *data, int dlen, unsigned char *buff);
enum
  {
    PRTCL_RT = 0x01,
    PRTCL_GB = 0x02,
  };

enum
  {
    RTSPWD    = 0x00,
    RTSWMODE  = 0x01,
    RTSSUCC   = 0x02,
  };

struct bkdata
{
  unsigned char mtid[6];
  unsigned char mtsno[2];
  unsigned char pro;
};

struct mntproces
{
  int (*task)();
  int (*process)(struct mtlist *mtl);
};

struct mntproces monitproc[4] = {{monitreq1, monitreq2}, {monitplc1, monitplc2}, {monitret1, monitret2}, {monitdlytm1, monitdlytm2}};
//struct mntproces floodproc[3] = {{floodreq1, floodreq2}, {floodplc1, floodplc2}, {floodret1, floodret2}};
struct mntproces s9proc[4]    = {{monitreq1, s9req2}, {s9plc1, s9plc2}, {monitret1, monitret2}, {monitdlytm1, monitdlytm2}};

struct rtreport _rtreport;
struct para_report _report645;

typedef struct
{
    unsigned char item[4];
    unsigned char len;
    unsigned char type;/*������ 0����1����*/
}FREEZE_ITEM_T;
FREEZE_ITEM_T freeze_item[] =
{
    { { 0x34, 0x34, 0x39, 0x38 }, 4, 0},   //05060101
    { { 0x34, 0x35, 0x39, 0x38 }, 4 ,1},   //05060201
    { { 0x34, 0x33, 0x34, 0x33 }, 4 ,0},   //00010001
    { { 0x52, 0xC3, }, 2 ,0},              //901F
    { { 0x43, 0xC3, }, 2 ,0},              //9010
    { { 0x52, 0xC7, }, 2 ,0},              //941F
};
#define FRITEM_LEN  20               //���ƽ�����������
#define FRITEM_SLEN 4               //ÿ��������������ռ���ֽ���

#define CPRETC 50000  /*Comparison of electricity�����ε����ԱȲ�ֵ500��*/
#define ETCDIFF 500   /*Consumption difference���ն�����ƽ�Ⱥ��ܵ����Ĳ�ֵ5��*/

unsigned int absolute_value(unsigned int val1, unsigned int val2)
{
    if (val1 >= val2)
    {
        return (val1 - val2);
    }
    else
    {
        return (val2 - val1);
    }
}
int is_data_freeze_item(unsigned char buf[], unsigned char len, unsigned char *type)
{
    int i;
    if (buf == NULL || len == 0)
    {
        return -1;
    }
    for (i = 0; i < (sizeof(freeze_item) / sizeof(FREEZE_ITEM_T)); i++)
    {
        if (0 == memcmp(freeze_item[i].item, buf, freeze_item[i].len))
        {
            *type = freeze_item[i].type;
            return freeze_item[i].len;
        }
    }
    return -1;
}
//�����жϻ����������� �Ƿ���ڼ��ƽ��֮��
int is_energy_right(unsigned char buf[], unsigned char len, unsigned int *all)
{
    unsigned char item[32];
    unsigned int sub[5]; //�ܼ��ƽ��
    unsigned int spfv;  //Sharp peak flat valley֮��
    unsigned int dif;
    unsigned char buf1[] = {0x52, 0xC3}, buf2[] = {0x52, 0xC7};
    memset(sub,0x00,sizeof(sub));
    if (buf == NULL || len == 0|| len % FRITEM_SLEN != 0 || len > FRITEM_LEN) 
    {
        return -1;
    }
    if ( len == FRITEM_LEN)
      {
        memcpy(item, buf, len);
        for (int i = 0; i < len; i++)
          {
             item[i] = (item[i] - 0x33);
          }
        bcd_to_bin(item, len);
        for (int i = 0; i < (len / FRITEM_SLEN); i++)
          {
            order_reverse(&item[i * FRITEM_SLEN], FRITEM_SLEN);
            sub[i] = ((item[i * FRITEM_SLEN + 0] * 1000000)
                      + (item[i * FRITEM_SLEN + 1] * 10000)
                      + (item[i * FRITEM_SLEN + 2] * 100)
                      + (item[i * FRITEM_SLEN + 3]));
          }
        spfv = sub[1] + sub[2] + sub[3] + sub[4];
        dif = absolute_value(sub[0], spfv);
        if (memcmp(_task.appd.data+1, buf1, 2)!=0 && memcmp(_task.appd.data+1, buf2, 2)!=0)
          {
             if (dif > ETCDIFF )
               {
                 return -1;
               }
             else
               {
                 *all = sub[0];
                 return 0; //�ܵ���
               }
          }
        else
          { 
             *all = sub[0];
             return 0; //�ܵ��� 
          }
      }
    else //�ǰ������ƽ���ܵ���Ϊ��һ�������ܣ�ֱ�ӷ���
     {
        memcpy(item, buf, len);
        for (int i = 0; i < len; i++)
        {
            item[i] = (item[i] - 0x33);
        }
        bcd_to_bin(item, len);
        order_reverse(&item[0], FRITEM_SLEN);
        sub[0] = ((item[0] * 1000000)
                  + (item[1] * 10000)
                  + (item[2] * 100)
                  + (item[3]));
        *all = sub[0];
        return 0; //�ܵ���
    }

}
// -1,ֱ���ϱ�ʧ�ܣ�-2���µ㳭��0������ȷ�������ϱ�
int chk_task_appdata(void)
{
    int itemlen=0;
    unsigned int sum;
    unsigned char type;
    unsigned char temp_data[5];
    memset(temp_data,0x00,sizeof(temp_data));
//    for (int i = 1; i < _task.appd.itemlen; ++i)
//      _task.appd.item[i] += 0x33;
    if ((_task.appd.item[0] == 0x01 || _task.appd.item[0] == 0x02)&&_task.appd.item[0]!=0)
      {
         memcpy(temp_data, _task.appd.item + 1, _task.appd.itemlen-1 );
         if(0 == memcmp(temp_data,_task.appd.data+1, 2))
           {
              itemlen = is_data_freeze_item(&_task.appd.data[1], _task.appd.datalen-1,&type);
           }
         else
           return -1;
      }
    else if((_task.appd.item[0] == 0x11 || _task.appd.item[0] == 0x12)&&_task.appd.item[0]!=0)
      {
         memcpy(temp_data, _task.appd.item + 1, _task.appd.itemlen-1 );
         if(0 == memcmp(temp_data, _task.appd.data+1, 4 ))
           {
              itemlen = is_data_freeze_item(&_task.appd.data[1], _task.appd.datalen-1,&type);
           }
         else
           return -1;
      }  
    if (itemlen > 0)
    {
        if (is_energy_right(_task.appd.data + itemlen+1, _task.appd.datalen - itemlen-1, &sum) < 0)
        {
          //  _rtparas.state &= ~STAMMASK;
          //  app_gbcomm(_task.minfo.id, _task.appd.protype, NULL, 0);
          //  rt_mntclear();
            return -1; //�ԱȲ���ȷ��ֱ���ϱ�ʧ��
        }
        if (_task.ml.opt.mt != NULL && type ==0 )
        {
            if (_task.ml.opt.mt->freeze_val != 0 &&
                (_task.ml.opt.mt->freeze_val > sum || absolute_value(_task.ml.opt.mt->freeze_val, sum) > CPRETC  ))
            {
                 _task.ml.opt.mt->freeze_val = sum;
                return -1;
#if 0

                if (_task.remnt & RMNTCNTMASK == 0) //��һ��
                {
                    _task.flag = TSNO;
                    _task.remnt |= RMNTFLOOD;
                    return -2;
                }
                else
                {
                    return -1; //�������γ����Աȹ���ֱ���ϱ�ʧ��
                }
#endif

            }
            _task.ml.opt.mt->freeze_val = sum;
        }
    }

    return 0;
}


unsigned int currtick()
{
#ifndef _LINUXPC
  return get_sys_tick();
#endif
}

unsigned char get_apptype()
{
    return PRTCL_GB;
    set_apptype(PRTCL_GB);
    //return _rtparas.apptype;
}

extern unsigned int flag_set_apptype_eeprom;
int set_apptype(unsigned char apptype)
{
  if(apptype == _rtparas.apptype)
    return 0;
  if ((apptype == PRTCL_RT) && _rtparas.runmd != 0x03 && _rtparas.runmd != 0xFC)
    return -1;
  _rtparas.apptype = apptype;
  eeprom_write(DBPBEGIN + offset(struct rtpara, apptype), (unsigned char *)&_rtparas.apptype,
               sizeof(_rtparas.apptype));
  
  flag_set_apptype_eeprom++;
  return 0;
}

void req_pwdwmode()
{
  if ((_task.flag & TSMASK) == TSRUN)
    return ;

  unsigned char apprt_get_pwdwmode();

  int ret = -1;
  unsigned pwdwmode = apprt_get_pwdwmode();

  switch(pwdwmode)
    {
    case RTSPWD:
      ret = app_request(RQPWD, 0x00, NULL);
      break;
    case RTSWMODE:
      ret = app_request(RQWMODE, 0x00, NULL);
      break;
    default:
      break;
    }

  memset(&_task, 0x00, sizeof(_task));
  if (ret == 0)
    {
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = 2000;
    }
  return;
}

unsigned char touchnum()
{
  unsigned char touchnum = 0;

  for (int i = 0; i < _task.ml.num; ++i)   /* append rp */
    {
      if ((_task.ml.list[i].state & LTMASK) == LTOUCH)
    ++touchnum;
    }
  return touchnum;
}

void saveposition(struct mtinfo *mt)
{
  assert(mt);

  memcpy(_rtparas.curid, mt->node.id, IDLEN);
}

void nextstage()
{
  if (_rtparas.stage != S5) /* for restore breakpoint */
    memset(&_task, 0x00, sizeof (struct task));/* clear task */
  if (_rtparas.stage == S5)
    {
      _task.flag = TSNO;
      memset(&_rtreport, 0x00, sizeof(struct rtreport));
    }
  _rtparas.round = 0x01;

  ++_rtparas.stage;
#if 0
  switch(_rtparas.stage)
  {
    case S4:
      _rtparas.stage = S6;
      break;
    case S8 :
      _rtparas.stage = S5;
      break;
    case S5:
      _rtparas.stage += 4;
      break;
    default:
      ++_rtparas.stage;
      break;
  } /* stage step */
#endif
}

void rtnext()
{
  _task.flag = TSNO;  /* clear task */
  db_trav_reset(CHAN_RT1);
  if (_rtparas.round > _rtparas.maxround || _rtparas.round > MAXHOPS)
    nextstage();
  else
    ++_rtparas.round;
}

int ploughpath(struct rpinfo *rp)
{
  assert(rp);

  int ret = -1;
  struct mtinfo *mt;
  struct rpinfo *tmprp = rp;

  for (size_t i = 0; i < MAXHOPS; ++i)
    {
      if ((mt = db_find(rp->rpid)) == NULL)
    break; /* meter not exist */

      if (mt->node.sno[0] & NNEWMASK)
    break; /* new */


      memcpy(_ndscont.nds[_ndscont.num].id, mt->node.sno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      if ((mt->node.succhops & NHMASK) == 0x00)
    {
      ret = 0;
      break;
    }

      if ((rp = db_getfrp(mt)) == NULL) /* get parent of mt */
    break; /* error */

    }

  if(ret == -1)              /*·����������ֱ�ӽ�ʧ�ܴ�����Ϊ����Ż�ʱɾ��*/
    tmprp->node.failtms = 0x40;

  return ret;
}

void ndsrevers(struct ndscont *list)
{
  unsigned char id[6], len;

  if (list->num <= 1)
    return;
  for (int i = 0, j = list->num - 1; i < j; ++i, --j)
    {
      len = list->nds[i].len;
      memcpy(id, list->nds[i].id, len);
      memcpy(list->nds[i].id, list->nds[j].id, list->nds[j].len);
      list->nds[i].len = list->nds[j].len;
      memcpy(list->nds[j].id, id, len);
      list->nds[j].len = len;
    }
}

int list_maxnode(enum stageinfo spara)
{
  unsigned char maxnode = 32;

  if (spara == S2)
    {
      struct stage2 *s2p = (struct stage2 *) _task.info;

      if (s2p->info & S2FMASK) /* first run */
    maxnode >>= 3 - (((s2p->info & S2CMASK) - 1) / 3) - 1;
      else if (_rtparas.mtnum - _rtparas.succnum < MINRANDOM)
    maxnode = _rtparas.mtnum - _rtparas.succnum;
      else
        maxnode >>= 3 - (s2p->info & S2CMASK);

      /* all are set sno, maxnode = 32 */
      /* high scan level( >8 ), maxnode = 32 */
    }
  else
    {
      if (_rtparas.round == 1) /* round */
        {
          if (_rtparas.slevel == 1)
            maxnode >>= 0;
          else if (_rtparas.slevel == 2)
            maxnode >>= 1;
          else
            maxnode >>= 2;
        }
      else if (_rtparas.round <= 3)
        {
          if (_rtparas.slevel == 1)
            maxnode >>= 1;
          else if (_rtparas.slevel == 2)
            maxnode >>= 2;
          else
            maxnode >>= 2;
        }
      else if (_rtparas.round < 11)
    maxnode >>= 2;
      else
    maxnode >>= 3;
    }

  if(maxnode<3)
  {
    maxnode =3;
  }
  return maxnode;
}

void touchmt(struct mtinfo *famt)
{
  struct mtinfo *mt = NULL;
  struct rpinfo rp;

  assert(famt);

  memset(&rp, 0x00, sizeof(struct rpinfo));
  memcpy(rp.rpid, famt->node.id, IDLEN);
  rp.addr = 0xFFFF;
  rp.node.idptr = famt->addr;  //���û����

  for (int i = 0; i < sizeof(_task.ml.list) / sizeof(_task.ml.list[0]); ++i)
    {
      if ((_task.ml.list[i].state & LTMASK) == 0) /* not touch */
    continue;
      if ((_task.ml.list[i].state & LLMASK) == SNOLEN)
    mt = db_find_sno(_task.ml.list[i].id);
      else
    mt = db_find(_task.ml.list[i].id);
      if (mt == NULL)
    continue;
      db_appendrp(mt->node.id, &rp);
      mt->node.succhops &= ~NRMASK;  //��ǰ����û����db_write�ĵ���
      mt->node.succhops |= NREACH; /* bit6: study flag, 1 - reachable */

      //�����ɹ�������صı�־λ��λ��Ч��ͬʱ��ģʽ���棬�����㳭��ʱ��ʹ��
      _task.ml.list[i].state2 &= ~LASTDMASK; //�����һ�ε�dpsk or fskģʽ����λ���
      _task.ml.list[i].state2 |= LASTMVALID; /*��bit 4��Ч*/
      if (_last_sndtype)
      {
          _task.ml.list[i].state2 |= LASTDPSK; //��DPSK��λ
      }

  }
}

void mlist_clear()
{
  _task.ml.num = 0;
  memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
}

void mlist_add(unsigned char *id, unsigned char idlen)
{
  unsigned char *nump = &_task.ml.num;

  memcpy(_task.ml.list[*nump].id, id, idlen);
  _task.ml.list[*nump].state = idlen;
  ++(*nump);
}

int task2nds(struct mtinfo *mt)
{
  struct rpinfo *rp = db_getfrp(mt);

  memset((unsigned char *)&_ndscont, 0x00, sizeof(_ndscont));

  if(memcmp(mt->node.sno, sinksno, SNOLEN) == 0) /* round = 1 process */
    {
      memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      memcpy(_ndscont.nds[_ndscont.num].id, broadsno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      return 0;
    }

  if ((mt->node.sno[0] & NNEWMASK) || rp == NULL)
    return -1;

  memcpy(_ndscont.nds[_ndscont.num].id, mt->node.sno, SNOLEN);
  _ndscont.nds[_ndscont.num++].len = SNOLEN;

  if (ploughpath(rp) != 0)
    {
      _ndscont.num = 0;
      return -1;
    }
  ndsrevers(&_ndscont);
  return 0;
}

int gainrand() /* get random number */
{
  static unsigned int count = 0;
  unsigned int u, un1, un2, un3, un4;

#ifndef _LINUXPC
  srand(++count);
#else
  srand(time(NULL));
#endif
  u = rand();
  un1 = u & 0xFF;
  un2 = (u >> 8) & 0xFF;
  un3 = (u >> 16) & 0xFF;
  un4 = (u >> 24) & 0xFF;

  return (un1 ^ un2 ^ un3 ^ un4) & 0x7F;
}

int rt_mntbrd()
{
  memset(&_task.minfo, 0, sizeof(struct mntinfo));
  _task.flag = TSNO;
  _task.cnt = 0;

  memset(&_ndscont, 0x00, sizeof (struct ndscont));

  memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
  _ndscont.nds[_ndscont.num++].len = SNOLEN;
  memcpy(_ndscont.nds[_ndscont.num].id, broadsno, SNOLEN);
  _ndscont.nds[_ndscont.num++].len = SNOLEN;

  unsigned char mnttkn = PARAMNT|PARAASW, nlframe[255];
  int nllen = 255;
  int ret = nl_monittask1(&_task.appd, mnttkn, NULL, nlframe, &nllen); /*  tkn=0, asw=0 */
  assert(ret == 0);

  unsigned char rtframe[255];
  int rtlen = 255;
  nl_frm38(NLT_NORMAL, nlframe, nllen, rtframe, &rtlen, PLC_DC);
  nl_rtwrite(fd, rtframe, rtlen, 0);

  app_res(NULL, 0); /* need to send confirm frame to dm */
  return 0;
}

int rt_chkmntid(unsigned char *mtid)
{
  assert(mtid);

  db_trav_reset(CHAN_TMP1);

  struct mtinfo *mtp;
  unsigned char err;
  while (mtp = db_trav_mtnext(CHAN_TMP1))
    {
      if (memcmp(mtp->node.id, mtid, IDLEN) == 0) /* find the meter */
    return 0;
    }

  if (_rtparas.apptype == PRTCL_GB) /* id dont be requered in database */
    return 0;

  if (_rtparas.apptype == PRTCL_RT)
    err = RTFERR_IDNOT;
  app_err(&err, sizeof(err));

  return -1;
}

int rt_appmnt_dlytm()
{
  int appgb_reqdlytm(unsigned char *mtid);

  if ((_task.flag & TSMASK) == TSRUN)
    {
      return 0;
    }
  if ((_task.flag & TSMASK) == TSNO) /* monit task */
    {
      _task.cnt = 0;
      if(appgb_reqdlytm(_task.minfo.id) < 0)
        return -1;

      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = 2000;

      return 0;
    }
  else if ((_task.flag & TSMASK) == TSFAIL)
  {
    _task.minfo.state &= ~STDLYTMMASK;
    _task.flag = TSNO;
    return -1;
  }
  else if ((_task.flag & TSMASK) == TSSUCC)
  {
    if ((_task.appd.protype & APFMASK) == APFAIL) // ����ȡ��
      return -1;

    _task.minfo.state &= ~STDLYTMMASK;
    _task.flag = TSNO;

    return 0;
  }
  return -1;
}

extern unsigned int flag_rt_appmnt_fail;
int rt_appmnt()
{
  int appgb_deny(unsigned char errcode);
 // void para_bkup();

  unsigned char err;
  static unsigned char wait = 0;
  int t = 0;
  struct mtinfo *mtp;

  if ((_rtparas.dcviv == TYPE53) || _rtparas.dcviv == TYPE43_53 || _rtparas.dcviv == TYPE53_43) 
    {
      rt_mntplc_v();
      return 0;
    }
  if ((_task.minfo.state & STDLYTMMASK) == STDLYTM)
  {
     if(rt_appmnt_dlytm() < 0)
     {
       _task.minfo.state &= ~STDLYTMMASK;
       rt_mntclear();
     }
     return 0;
  }

  if ((_task.minfo.state & STIMASK) == STINIT) /* init */
    {
      if (rt_appmnt_init(_task.minfo.id) != 0)
        {
          wait = 1;
          return 0;
        }
    }

  if ((_task.flag & TSMASK) == TSRUN)
    {
      rt_report(REPOIDLE, 0x00);
      return 0;
    }

  if (wait == 1)
    {
      unsigned char info = INFCHPATH;
      app_info(&info, sizeof(info));
      wait = 0;
    }

  rt_report(REPORESUME, 1);
 // para_bkup();
  if ((_task.flag & TSMASK) == TSNO) /* monit task */
    {
      if ((mtp = db_find(_task.minfo.id)) == NULL && _rtparas.apptype == PRTCL_RT)
      {
        seterrno(RTFERR_IDNOT);
        _rtparas.state &= ~STAMMASK;
        printf_s("\n****STAMONIT----CLEAR----rt_appmnt****\n");
        return -1;
      }
      
      printf_s("\nrt_appmnt current aid is:  ");
      for(int i = 0; i< IDLEN; i++)
        {
          unsigned char aid_tmp[IDLEN];
          memcpy(aid_tmp, _task.minfo.id, IDLEN);
          id_bintobcd(aid_tmp);
          reverse(aid_tmp, 6);
          
          printf_s("%02x ",aid_tmp[i]);
        }
      printf_s("\n");
      
      if((_task.minfo.state & STDISPMASK) == STDISPCOMM)
        t = rt_disp_mntplc();
      else if (_task.flood & MFMASK)
        t = rt_floodmntplc();
      else if (_share.conswitch & 0x01)
      {
        t = rt_mntplc();
      }
      else
      {
        t = rt_floodmntplc();
      }

      if (t != 0)
        {
          if (_rtparas.apptype == PRTCL_RT)
          {
            err = ERRIDFAIL;
            app_err(&err, sizeof(err));
          }
          else if (_rtparas.apptype == PRTCL_GB)
          {
            extern unsigned char callmeter;//�ӽڵ㱨���ظ�����
            if (callmeter == 1)
            {
              appgb_deny(GBERR_TIMEOUT);
              callmeter = 0;
            }
            else
            {
              app_gbcomm(_task.minfo.id, _task.appd.protype&0x0F, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 2);  //����ʧ��
              flag_rt_appmnt_fail++;
            }
            
          }
          rt_mntclear();
        }
      return 0;
    }
  else
    return rt_mntprocess(); /* process */
}

int rt_appmnt_38()
{
  unsigned char err;

  if ((_task.flag & TSMASK) == TSRUN)
    {
      rt_report(REPOIDLE, 0x00);
      return 0;
    }
  if ((_task.flag & TSMASK) == TSFAIL) /* monit task */
    {
      if (_rtparas.apptype == PRTCL_RT)
        {
          err = ERRIDFAIL;
          app_err(&err, sizeof(err));
        }
    }
  else if ((_task.flag & TSMASK) == TSSUCC)
    app_res(_commbuf.plc.buf, _commbuf.plc.len); /* return data to dm */

  rt_mntclear();
  return 0;
}

int rt_debug(unsigned char *frame, int len, unsigned char ccw)
{
  if ((_rtparas.state & STASTMASK) == STARUN || (_rtparas.state & STARMASK) == STAREG)
    return 0;

 // channel38 = 1;
 // app_debug(frame, len, ccw);
  return 0;
}

static void inc_failtms()
{
  struct monitinfo *ml = &_task.ml;
  struct mtinfo *rpmt;
  struct rpinfo *rp;

  if ((_rtparas.stage != S0 && _rtparas.stage != S1)
      || ((_rtparas.state & STABMASK) == STABROAD))
    return;

  if (ml->opt.state & OPTNEXIST)
    return ;
  rpmt = db_find_sno(_ndscont.nds[_ndscont.num - 1].id);
  assert (rpmt != NULL);
  rp = db_findrp(ml->opt.mt->node.id, rpmt->node.id);
  if (rp != NULL)
    rp->node.failtms++;
}
static int sn_monitor;
int monittask()
{
  int (*taskp)();

  if ((_task.flag & TSMASK) == TSRUN)
    return 0;
  printf_s("S0MONIT!\n");
  struct monitinfo *ml = &_task.ml;
  struct mtinfo *mtp;
  for (int i = 0; i < sizeof(ml->list) / sizeof(ml->list[0]); ++i)
    {
      if (((ml->list[i].state & LTMASK) != LTOUCH) || ((ml->list[i].state & LOMASK) == LOPRT))
    continue;

      if ((ml->list[i].state & LSMASK) == LINIT) /* initalize */
    {
      if (confmt(&ml->list[i]) != 0)
        {
          ml->list[i].state |= LOPRT;
          continue;
        }

      ml->list[i].state &= ~LSMASK; /* clear meter state */
      ml->list[i].state |= (ml->opt.state & OPTNEXIST) ? LPLC : LREQ;
      _task.cnt = 0;
      ml->opt.reqcnt = 0;
          ml->opt.dlytm = 0;
          ml->list[i].state2 &= ~0x01;
      _task.flag &= ~(TSMASK | TTMASK);

          inc_failtms();
    }

      size_t pos = (ml->list[i].state & LSMASK) / LREQ - 1;
#if 0
      if((ml->list[i].state2 & 0x01) != 0)
        pos = 0x03;       // dlytm process
#endif
      if ((_task.flag & TSMASK) == TSNO)
    taskp = monitproc[pos].task;
      else
    {
          int ret;
          ret = monitproc[pos].process(&ml->list[i]);
          if (ret == -8) /*plc2 asw = 1, ret = -8*/
          {
            _task.flag &= ~TSMASK;
            _task.flag |= TSRUN;
            return 0;
          }

      if (ret != 0)
        {
          _task.flag &= ~(TSMASK | TTMASK);
          ml->list[i].state |= LOPRT;
          continue;
        }
      /* process may be change list[i].state */
      pos = (ml->list[i].state & LSMASK) / LREQ - 1;
#if 0
      if((ml->list[i].state2 & 0x01) != 0)
            pos = 0x03;       // dlytm process
#endif
      if (ml->list[i].state2 & LASTMVMASK)
          {
              _nl_type &= ~FRMTVMASK;//�����Ч��־λ
              _nl_type &= ~FRMTMMASK;//���ģʽ��־λ
              _nl_type |= FRMTVALID; //����Ч��־λ
              if (ml->list[i].state2 & LASTDMASK)//��һ����DPSKģʽ�����ɹ�
              {
                  _nl_type |= FRMTDPSK;//ǿ��ʹ�������ɹ�ģʽ
              }
          }
      taskp = monitproc[pos].task;
    }

      _task.flag &= ~(TSMASK | TTMASK);
      sn_monitor = i;
      if (taskp() == 0)
        return 0;
      ml->list[i].state |= LOPRT; /* task error */
    }
  return -1;
}

static int checkmt(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;

  memset(&ml->opt, 0x00, sizeof(ml->opt));
  if((mtl->state & LLMASK) == SNOLEN)
    return -1;
  else
    if ((ml->opt.mt = db_find(mtl->id)) == NULL)
      return -1;
   ml->opt.reqcnt = mtl->sno[0];

  return 0;
}

#if 0
int floodtask()
{
   int (*taskp)();

  if ((_task.flag & TSMASK) == TSRUN)
    return 0;

  struct monitinfo *ml = &_task.ml;
  for (int i = 0; i < sizeof(ml->list) / sizeof(ml->list[0]); ++i)
    {
      if (((ml->list[i].state & LTMASK) != LTOUCH) || ((ml->list[i].state & LOMASK) == LOPRT))
    continue;

      if ((ml->list[i].state & LSMASK) == LINIT) /* initalize */
    {
      if (checkmt(&ml->list[i]) != 0)
        {
          ml->list[i].state |= LOPRT;
          continue;
        }

      ml->list[i].state &= ~LSMASK; /* clear meter state */
      ml->list[i].state |= LREQ;
          ml->opt.failcnt = 0; /*failcnt = reqcnt*/
      _task.cnt = 0;
      _task.flag &= ~(TSMASK | TTMASK);
    }

      size_t pos = (ml->list[i].state & LSMASK) / LREQ - 1;
      if ((_task.flag & TSMASK) == TSNO)
    taskp = floodproc[pos].task;
      else
    {
      if (floodproc[pos].process(&ml->list[i]) != 0)
        {
              _task.flag &= ~(TSMASK | TTMASK);
          ml->list[i].state |= LOPRT;
          continue;
        }
      /* process may be change list[i].state */
      pos = (ml->list[i].state & LSMASK) / LREQ - 1;
      taskp = floodproc[pos].task;
    }

      _task.flag &= ~(TSMASK | TTMASK);
      if (taskp() == 0)
        return 0;
      ml->list[i].state |= LOPRT; /* task error */
    }
  return -1;
}
#endif

int rt_jzqid(unsigned char *id)
{
  memset(id, 0x00, IDLEN);
  memcpy(id, _rtparas.sinkid, SNOLEN);
  id[2] = 0x64;

  return 0;
}

int report_up(struct para_report *report)
{
  if ((_task.flag & TSMASK) == TSRUN)
    return 0;

    if ((_rtparas.state & STARMASK) != STAREG &&
        (_rtparas.state & STAPMASK) != STARPT)      //ע��ʱ�䵽��ֹͣ�ϱ�
    {
        _task.flag = TSNO;
        return -1;
    }
  if ((_task.flag & TSMASK) == TSNO)
    {
      _task.cnt = 0;
      if (report_valid(report)!= 0)
        return -1;
      else
      {
        _rtreport.idletm = 0;
        return apptask(&_rtreport.report);
      }
    }

  if (((_task.flag & TTMASK) ==  TTAPD && (_task.flag & TSMASK) == TSSUCC
      && (_task.appd.protype & APCMASK)) || (++_task.cnt >= 9))
    {
      _task.flag = TSNO;
      return 0;
    }
  else
    return apptask(report);
}

void rt_autoreg()
{
  if ((_task.flag & TSMASK) == TSRUN)
    return;

  if (_rtreport.state == REPORT_PLC)
    report_start();

  if (_rtreport.state == REPORT_APP && report_up(&_rtreport.report) < 0)
    set_rts_value(CHN_38_1, 0);

}

int rt_newdb()
{
  struct mtinfo *mt;
  int state = 1;

  if (_rtparas.flood == 1)
    return 0;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {

    if (((mt->node.sno[0] & NNEWMASK) && (mt->node.succhops & NFSUC))
        || (mt->node.sno[0] & NNEWMASK) == 0)
    {
      state = 0;
      break;
    }
  }
  return state;
}

int get_dlytm(unsigned int *dlytm)
{
  unsigned char sno[2], flag = 0, msg[255];
  int len = 255;
  struct monitinfo *ml = &_task.ml;

  if(_rtparas.srelay == 0x01)
  {
    memcpy(sno, ml->opt.mt->node.sno, SNOLEN);
    sno[0] &= ~NNEWMASK;
    if ((_task.cnt & 0x01) == 0)
      flag |= PARAMNT; /* mnt = 1 */
    if (s9nl_monittask1(&_task.appd, flag, sno, msg, &len) != 0)
      return -1;
  }
  else if ((_rtparas.state & STAMMASK) == STAMONIT)
  {
    struct mtinfo *mtp;
    struct rpinfo *rp;
    if ((mtp = db_find(_task.minfo.id)) == NULL && _rtparas.apptype == PRTCL_RT)
    {
      return -1;
    }

    unsigned char sno[SNOLEN], ndsflag = 0; /* ndsflag: organize path successfully or fail */
    if(mtp)
      memcpy(sno, mtp->node.sno, SNOLEN);
    sno[0] &= ~NNEWMASK;

    if (mtp == NULL || (mtp->node.sno[0] & NNEWMASK) || _rtparas.srelay == 0x01) /* new meter || 7���м� */
    {
      if (_task.cnt == 0)
      {
        memset(&_ndscont, 0x00, sizeof (struct ndscont));

        memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
        _ndscont.nds[_ndscont.num++].len = SNOLEN;
        memcpy(_ndscont.nds[_ndscont.num].id, _task.minfo.id, IDLEN);
        _ndscont.nds[_ndscont.num++].len = IDLEN;
      }
      /* if _task.cnt == 1, do not need to organize nds */
    }
    else
    {
      while (rp = db_trav_rpnext(CHAN_TMP, CHAN_TDEF)) /* next rp */
      {
        memset(&_ndscont, 0x00, sizeof (struct ndscont));
        if (ploughpath(rp) == 0)
        {
          ndsrevers(&_ndscont);
          if(_ndscont.num == 1) /*ֱ�����ñ���*/
          {
            memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.id, IDLEN);
            _ndscont.nds[_ndscont.num++].len = IDLEN;
          }
          else
          {
            memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.sno, SNOLEN);
            _ndscont.nds[_ndscont.num++].len = SNOLEN;
          }
          ndsflag = 1;
          break;
        }
        /* next rp */
        if (ndsflag == 0) /* no more rp */
          return -1;
      }
    }
    db_trav_rpreset(CHAN_TMP);
    if (_task.cnt % 2 == 0)
      flag |= PARAMNT;

    if (_task.minfo.state & STBMASK) /* broad */
    {
      memcpy(_ndscont.nds[_ndscont.num].id, broadsno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      flag |= PARAASW;
    }
    if (nl_monittask1(&_task.appd, flag, sno, msg, &len) != 0)
      return -1;
  }
  else
  {
    memcpy(sno, ml->opt.mt->node.sno, SNOLEN);
    sno[0] &= ~NNEWMASK;
    if ((_task.cnt & 0x01) == 0)
      flag |= PARAMNT; /* mnt = 1 */
    if (nl_monittask1(&_task.appd, flag, sno, msg, &len) != 0)
      return -1;
  }

  *dlytm = ((len + 4) * 8 * (_ndscont.num - 1) * 1000) / 330;
  if((*dlytm % 1000) > 500)
    *dlytm = *dlytm / 1000 + 1;
  else
    *dlytm = *dlytm / 1000;
  return 0;
}

static int monitdlytm1()
{
  int ret = 0;
  struct monitinfo *ml = &_task.ml;

  assert((ml->opt.state & OPTNEXIST) == 0); /* in database */

  ret = app_request(RQDLYTM, ml->opt.reqcnt, ml->opt.mt->node.id);

  if (ret == 0)
    {
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = 2000;
    }

  return ret;
}

static int monitdlytm2(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;
  unsigned char type = _task.appd.protype & (APCMASK | APDMASK);

  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (type == 0 || type == (APCMASK | APDMASK))
        return 0;

      if(_task.appd.protype & APFAIL) //����Ϊ0����������
        return -1;
      if (_task.appd.protype & APDMASK)
    {
      if (((_rtparas.state & STABMASK) == STABROAD) && (nl_phasecmd(&_task.appd) == 0))
        ml->opt.state |= OPTPCHK;
    }

      ++ml->opt.reqcnt; /* only used in broad operation */
      _task.cnt = 0;
      mtl->state &= ~LSMASK;
      mtl->state |= LPLC;
    }
  else
  {
      ml->opt.dlytm = 0;
      mtl->state &= ~LSMASK;    //����ʧ�����������볭����
      mtl->state |= LREQ;
//     --gbmessage.gbmcnt; /*�ط����кŲ���*/
  }
  mtl->state2 &= ~0x01;
  return 0; /* if failure, continue request */
}

static int monitnds()
{
  unsigned char broadsno[] = {0x7F, 0x00};
  struct monitinfo *ml = &_task.ml;

  if (ml->opt.state & OPTNEXIST)
    {
      memcpy(_ndscont.nds[_ndscont.num].id, ml->opt.id, IDLEN);
      _ndscont.nds[_ndscont.num].len = IDLEN;
    }
  else if (ml->opt.mt->node.sno[0] & NNEWMASK)
    {
      memcpy(_ndscont.nds[_ndscont.num].id, ml->opt.mt->node.id, IDLEN);
      _ndscont.nds[_ndscont.num].len = IDLEN;
    }
  else if (ml->opt.state & OPTCMD1)
    {
      memcpy(_ndscont.nds[_ndscont.num].id, ml->opt.mt->node.sno, SNOLEN);
      _ndscont.nds[_ndscont.num].len = SNOLEN;
    }
  else
    {
      memcpy(_ndscont.nds[_ndscont.num].id, ml->opt.mt->node.id, IDLEN); /* all use CMD = 6 frame */
      _ndscont.nds[_ndscont.num].len = IDLEN;

      /* memcpy(_ndscont.nds[_ndscont.num].id, ml->opt.mt->node.sno, SNOLEN); */
      /* _ndscont.nds[_ndscont.num].len = SNOLEN; */

    }
  _ndscont.num++;

  if ((_rtparas.state & STABMASK) == STABROAD)
    {
      if (_ndscont.num != 1)
    --_ndscont.num; /* remove destination node */
      else
    _ndscont.nds[_ndscont.num - 1].len = SNOLEN; /* sinkid */

      memcpy(_ndscont.nds[_ndscont.num].id, broadsno, SNOLEN);
      _ndscont.nds[_ndscont.num].len = SNOLEN;

      if((_rtparas.wkstate & DISPBDMASK) == DISPBROAD)
      {
      memcpy(_ndscont.nds[_ndscont.num].id, dispbdidsno, SNOLEN);
      _ndscont.nds[_ndscont.num].len = SNOLEN;
      }
      _ndscont.num++;
    }
  return 0;
}

static int monitreq1()
{
  int ret = 0;
  struct monitinfo *ml = &_task.ml;

  assert((ml->opt.state & OPTNEXIST) == 0); /* in database */

  memset((unsigned char *)&_task.appd, 0x00, sizeof(_task.appd));

  if ((_rtparas.state & STABMASK) != STABROAD && (get_apptype() == PRTCL_GB))
  {
    /*�ɹ�������������*/
    if ((_share.version == NEW_GBPRO) && (ml->opt.mt->node.envi & NCMD1MASK) == NCMD1SUC)
    {
      _task.flag |= (TSSUCC | TTAPD);
      _task.appd.protype |= APCCFM;
     // ml->opt.reqcnt++;
#if 0
      if (_rtparas.stage == S0 && (ml->opt.mt->node.attr & NNEWMASK))
      {
          ml->opt.reqcnt++;//++Ϊ����һ��,���ٶ�㳭һ��
      }
#endif
      return ret;
      //return -1;
    }
  }

  if ((_rtparas.state & STABMASK) == STABROAD) /* broad operation */
    ret = app_request(RQBRDC, ml->opt.reqcnt, NULL);
  else
    ret = app_request(RQMNTC, ml->opt.reqcnt, ml->opt.mt->node.id);

  if ((_rtparas.state & STABMASK) == STABROAD && ret == -2) /* needn't to request in the broadcast mode */
    {
      if(nl_phasecmd(&_task.appd) == 0)
        ml->opt.state |= OPTPCHK;
      ml->list[0].state &= ~LSMASK;
      ml->list[0].state |= LPLC;
      return 0;
    }

#if 0
  if (ret == 3)//���������ҵ��ñ�����������
  {
      ml->list[sn_monitor].state &= ~LSMASK;
      ml->list[sn_monitor].state |= LPLC;
      return 0;
  }
  else if ((_rtparas.state & STABMASK) != STABROAD&& ret == -1) //�㳭�ģ����������Ҳ���������
  {
      _task.flag |= (TSSUCC | TTAPD);
      _task.appd.protype |= APCCFM;
     // ml->opt.reqcnt++;
      return 0;
     // return -1;
  }
#endif

    if (ret == 0)
     {
#if 0
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = DM_OVER_TICK;
#endif
        _task.flag |= TSSUCC | TTAPD;//ֱ����Ϊ�ɹ�������req2
     }

  return ret;
}

static void set_testitem(struct mtinfo *mt)
{
  if (mt->item.len != 0 && mt->item.len <= sizeof (mt->item.data))
  {
     /* _task.appd.protype = mt->item.len == 0x03 ? 0x00 : 0x01; */ /* 97 (645) */
     _task.appd.protype = mt->item.type;
     _task.appd.datalen = mt->item.len;
     _task.appd.wretlen = mt->item.wretlen;
     memcpy(_task.appd.data, mt->item.data, mt->item.len);
     return ;
  }
  if (get_apptype() == (unsigned char)PRTCL_RT)
  {
    _task.appd.protype = 0x00; /* 97 (645) */
    _task.appd.datalen = sizeof(_testdata);
    memcpy(_task.appd.data, _testdata, sizeof(_testdata));
  }
  else
  {
    _task.appd.protype = 0x01; /* 07 (645) */
    _task.appd.datalen = sizeof(_testgb);
    memcpy(_task.appd.data, _testgb, sizeof(_testgb));
  }
}
//�������
void add_task_setmtitem(unsigned char *bcdid, unsigned char wretlen, unsigned char pro, unsigned char *data, unsigned char datalen)
{
    struct mtinfo *mt;
    unsigned char tid[IDLEN];
    memcpy(tid, bcdid, 6);
    id_bcdtobin(tid);
    reverse(tid, IDLEN);

    if ((mt = db_find(tid)) == NULL)
    {
        return;
    }
    if (mt->item.len != 0 && mt->item.len <= datalen)
    {
        return;
    }
    mt->item.len = datalen; /* save recently reading item of the meter */
    mt->item.type = pro;
    mt->item.wretlen = wretlen;
    memcpy(mt->item.data, data, datalen);
    return;
}
static void set_mtitem(struct mtinfo *mt)
{
  if(mt->item.len != 0 && mt->item.wretlen < _task.appd.wretlen)
  {
    return;
  }

  mt->item.len  = _task.appd.datalen; /* save recently reading item of the meter */
  mt->item.type = _task.appd.protype;
  mt->item.wretlen = _task.appd.wretlen;
  memcpy(mt->item.data, _task.appd.data, _task.appd.datalen);
  return;
}

static int monitreq2(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;
  unsigned char type;

  if ((_rtparas.state & STABMASK) != STABROAD)
  {
      get_read_from_task(ml->opt.mt->node.id);
  }
  
  printf_s("\n****monitreq2****\n");
  
  type = _task.appd.protype &(APCMASK | APDMASK);
  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (type == 0 || type == (APCMASK | APDMASK))
        return 0;
      if (_task.appd.protype & APCMASK) /* application confirm */
    {
      if ((_rtparas.state & STABMASK) == STABROAD) /* broad receive confirm,next meter */
        return -1;
      if (ml->opt.reqcnt > 0)
        return -1;
          if((_task.appd.protype & APFMASK) != APFAIL)
              ml->opt.mt->node.envi |= NCMD1SUC;  //��ǰ����û����db_write�ĵ���
      /* first request */
      if (ml->opt.mt->node.sno[0] & NNEWMASK) /* not set order */
        {
              set_testitem(ml->opt.mt);

          ml->opt.state |= OPTDEFAPP; /* cmd = 6 && default item */
        }
      else
          {
            if((ml->opt.mt->node.succhops & NSMASK) == NSUCC) /*�ɹ�����DM�޿ɳ����������л�*/
              return -1;
        ml->opt.state |= OPTCMD1; /* cmd = 1 */
          }
    }

      if (_task.appd.protype & APDMASK)
    {
      if (((_rtparas.state & STABMASK) == STABROAD) && (nl_phasecmd(&_task.appd) == 0))
        ml->opt.state |= OPTPCHK;

          if ((_rtparas.state & STABMASK) != STABROAD && _task.appd.datalen <= sizeof(ml->opt.mt->item.data))
          {
            if(ml->opt.dlytm == 0)
               set_mtitem(ml->opt.mt);
#if 0
            ml->opt.mt->item.len  = _task.appd.datalen; /* save recently reading item of the meter */
            ml->opt.mt->item.type = _task.appd.protype;
            ml->opt.mt->item.wretlen = _task.appd.wretlen;
            memcpy(ml->opt.mt->item.data, _task.appd.data, _task.appd.datalen);
#endif
          }
    }

      ++ml->opt.reqcnt; /* only used in broad operation */
      _task.cnt = 0;
      mtl->state &= ~LSMASK;
      mtl->state |= LPLC;
      if(ml->opt.dlytm != 0)
        mtl->state2 |= 0x01;
      else
        mtl->state2 &= ~0x01;
    }
  else
  {
     --gbmessage.gbmcnt; /*�ط����кŲ���*/
  }
  return 0; /* if failure, continue request */
}

static int monitplc1()
{
  unsigned char flag = 0, msg[255], frame[255], sno[2], type = NLT_NORMAL;
  int len = sizeof(msg), ret = 0, framelen = sizeof(frame);;
  struct monitinfo *ml = &_task.ml;

  monitnds();
  if (ml->opt.state & OPTCMD1)
    {
      flag |= BITTKN1;
      if ((_task.cnt & 0x01) == 0)
    flag |= BITMNT1;
      if (nl_parent(&_ndscont, flag, msg, sizeof(msg)) != 0)
    ret = -1;
      len = msg[0] + 1;
    }
  else
    {
      flag |= PARATKN; /* tkn = 1 */
      if (ml->opt.state & OPTNEXIST)
    flag |= PARANS; /* only read ,no set order */
      else
        memcpy(sno, ml->opt.mt->node.sno, SNOLEN);
      sno[0] &= ~NNEWMASK;
      if ((_task.cnt & 0x01) == 0)
    flag |= PARAMNT; /* mnt = 1 */
      if ((_rtparas.state & STABMASK) == STABROAD) /* asw = 0 */
    flag |= PARAASW;
      if (nl_monittask1(&_task.appd, flag, sno, msg, &len) != 0)
    ret = -1;
    }
  if (ml->opt.state & OPTPCHK)
    type = NLT_ZERO;

  if (ret == 0)
    {
      printf_s("\n****monitplc1****\n");
      
      nl_frm38(type, msg, len, frame, &framelen, PLC_DC);
      nl_rtwrite(fd, frame, framelen, 0);

      unsigned char round = _rtparas.round;
      if(_rtparas.stage == S4)
        round += 1;

      _task.flag |= TSRUN | TTPLC;
      _task.start = currtick();
     // if ((_rtparas.state & STABMASK) == STABROAD)
    //  {
     //     _task.wait = round * MAXBRDTM; /* max wait time */
    //  }
     // else
     // {
          _task.wait = round * MAXHOPTM; /* max wait time */
     // }
      _task.cnt++;
      ml->opt.mt->trycnt++;
    }

  _ndscont.num--; /* next */

  return ret;
}

extern unsigned int flag_monit_update_eeprom;
static int monit_update(struct rtinfo *strglvl, unsigned char upsucc)
{
  struct mtinfo *mtp;
  struct rpinfo rp;
  struct monitinfo *ml = &_task.ml;

  unsigned char phase = ((ml->opt.mt->node.phase & NPAMASK) >> 6);
  int phase_ok = 1;
  if (phase > 3 || phase == 0) //��Ч
  {
      phase_ok = 0;
  }
  if((_task.minfo.state & STDISPMASK) == STDISPCOMM)
    return 0;

  ml->opt.mt->rdtick = TICK_NEWEST; //update tick val
  if (_rtparas.stage == S2 && (ml->opt.mt->node.succhops & NSMASK) == NSUCC)
    return 0;

  if ((ml->opt.mt->node.sno[0] & NNEWMASK) && (_rtparas.state & STAMMASK) == STAMONIT && phase_ok == 0)
  {
      ml->opt.mt->node.phase &= ~NPAMASK;/* update info */
      ml->opt.mt->node.phase |= (strglvl->phase << 6);
      return 0;
  }

  if (_rtparas.stage == S0 && (ml->opt.mt->node.sno[0] & NNEWMASK))
  {
    struct stage0 *s0p = (struct stage0 *) _task.info;
    if ((s0p->info & S0TMASK) == S0TTANS)
    {
        if (phase_ok == 0)
        {
          ml->opt.mt->node.phase &= ~NPAMASK;/* update info */
          ml->opt.mt->node.phase |= (strglvl->phase << 6);
        }

      ml->opt.mt->node.envi &= ~NTSMASK;
      ml->opt.mt->node.envi |= NTANSUC;
      return 0;
    }
  }
  memset(&rp, 0x00, sizeof(struct rpinfo));  /* insert rp */
  rp.addr = 0xFFFF;
  if (_ndscont.nds[_ndscont.num - 1].len == SNOLEN)
    {
      if ((mtp = db_find_sno(_ndscont.nds[_ndscont.num - 1].id)) == NULL)
    return -1;
      memcpy(rp.rpid, mtp->node.id, IDLEN);
    }
  else
    memcpy(rp.rpid, _ndscont.nds[_ndscont.num - 1].id, IDLEN);

  if ((mtp = db_find(rp.rpid)) == NULL) /* find rp meter address */
    return -1;
  else
    rp.node.idptr = mtp->addr;

  rp.node.succtms = 1;
  rp.node.rsv1 &= ~SIGMASK;
  rp.node.rsv1 |= (strglvl->strong & SIGMASK);
  db_insertrp(ml->opt.mt->node.id, &rp);
  ml->opt.mt->node.succhops &= ~NHMASK;  /* success flag */
  ml->opt.mt->node.succhops |= _ndscont.num;
  /* update success flag*/
  if (upsucc)
    {
      ml->opt.mt->node.succhops &= ~NSMASK;
      ml->opt.mt->node.succhops |= NSUCC;
    }

  if (phase_ok == 0)
  {
      ml->opt.mt->node.phase &= ~NPAMASK;/* update info */
      ml->opt.mt->node.phase |= (strglvl->phase << 6);
  }

  /* strong level*/
  if (strglvl->setsno)  /* set sno */
    {
      unsigned char sno[SNOLEN];
      ml->opt.mt->node.sno[0] &= ~NNEWMASK;
      ml->opt.mt->node.succhops &= ~NFSUC;
      db_read(ml->opt.mt->addr + offset(struct mtnode, sno), sno, SNOLEN);
      if (sno[0] & NNEWMASK)
    {
      sno[0] &= ~NNEWMASK;
      db_write(ml->opt.mt->addr + offset(struct mtnode, sno), sno, SNOLEN);
      
      flag_monit_update_eeprom++;
      
    }
    }
  return 0;
}

static int clr_strglvl_dev(struct rtinfo *strglvl)
{
    strglvl->dev43 &= ~(1 << 7);
}

extern unsigned int flag_monitplc2_eeprom;
extern unsigned int flag_monitplc2_succ;
static int monitplc2(struct mtlist *mtl)
{
  int  ret, failcnt;
  struct rtinfo strglvl;
  struct monitinfo *ml = &_task.ml;
  unsigned char dbuf[255];
  int dlen = 0;
  unsigned char meter_id[6];

  if ((_rtparas.state & STABMASK) == STABROAD)
    {
      mtl->state &= ~LSMASK;
      mtl->state |= LREQ; /* continue request */
      return 0;
    }

  if ((_task.flag & TSMASK) == TSFAIL)
    {
      
      printf_s("\n****monitplc2    TSFAIL****\n");
      
      if(_rtparas.dlytm & 0x08)
      {
      if (_task.cnt > 0x00)
    {
          struct stage0 *s0p = (struct stage0 *) _task.info;
      if (((_rtparas.stage == S0 && (s0p->info & S0TMASK) != S0TTANS) || _rtparas.stage == S1) &&
              ((ml->opt.state & OPTCMD1) == 0) && (++ml->opt.failcnt < FAILCNT))
        {
          mtl->state &= ~LSMASK;
          mtl->state |= LREQ; /* continue request until confirm frame received */
          return 0;
        }

      return -1;
    }
      }
      else
      {
      if (_task.cnt > 0x01)
    {
          struct stage0 *s0p = (struct stage0 *) _task.info;
      if (((_rtparas.stage == S0 && (s0p->info & S0TMASK) != S0TTANS) || _rtparas.stage == S1) &&
              ((ml->opt.state & OPTCMD1) == 0) && (++ml->opt.failcnt < FAILCNT))
        {
          mtl->state &= ~LSMASK;
          mtl->state |= LREQ; /* continue request until confirm frame received */
          return 0;
        }

      return -1;
    }
      }


    }
  else /* task success*/
    {
      
      printf_s("\n****monitplc2    SUCC****\n");
      
      failcnt = ml->opt.failcnt;
      ml->opt.failcnt = 0;
      if (ml->opt.state & OPTNEXIST) /* not in database */
    return -1;
      memset((unsigned char *)&strglvl, 0x00, sizeof(strglvl));
      if (ml->opt.state & OPTCMD1)
    ret = nl_parentprocess(_commbuf.plc.buf, (_commbuf.plc.buf[0] & 0x3F) + 1, &strglvl);
      else
    ret = nl_monitprocess(_commbuf.plc.buf, _commbuf.plc.len, &_task.appd, &strglvl);

      ml->opt.mt->rdtick = TICK_NEWEST;
      if(ret == -8) /*ret = -8 then continue wait timeout*/
        return -8;

      if (ret != 0 && ret != -7)
        return (_task.cnt > 0x01)? -1: 0;
      
      if (ml->opt.mt != NULL)
        {
          if (((strglvl.dev43 & 0x80) >> 7) == 1) 
          {
              if ((ml->opt.mt->node.viv & NNDMASK) != NND55 || 
                  ((ml->opt.mt->node.viv & NETMASK) >> 2 == 0x00))
              {
                  ml->opt.mt->node.viv &= ~NNDMASK;
                  ml->opt.mt->node.viv |= NND55;
                  ml->opt.mt->node.viv &= ~(1 << 2);   //43���������55,�ó�0
                                                             //ֱ�ӽ���V��������������ʽ��4���ĳ���
                  ml->opt.mt->dc_55_iv_cnt++; 
                  
                  if (local_viv_swi != 1 && (ml->opt.mt->dc_55_iv_cnt >= 8)) 
                  {
                      dlen = get_data_item(_task.ml.opt.mt, dbuf);

                      if (dlen > 0 && dlen < 255) 
                      {
                          memcpy(meter_id, _task.ml.opt.mt->node.id, 6);
                          id_bintobcd(meter_id);
                          reverse(meter_id, 6);
                          nl_p2p(meter_id, dbuf, dlen, _task.dcseq++, PLC_DC);
                          ml->opt.mt->dc_55_iv_cnt = 0; 
                          _task.flag = TSRUN | TTPLC;
                          _task.start = currtick();
                          _task.wait = 10 * 1000;
                      }
                  }
              }
          }
          else
          {
              ml->opt.mt->node.viv &= ~NNDMASK;
              ml->opt.mt->node.viv |= NND43; 
          }

          clr_strglvl_dev(&strglvl); 

          db_write(ml->opt.mt->addr + offset(struct mtnode, viv), &ml->opt.mt->node.viv, sizeof(ml->opt.mt->node.viv));
          set_dc_fail_cnt(ml->opt.mt->node.id, 1);  //�ɹ������־
          flag_monitplc2_succ++;
          flag_monitplc2_eeprom++;
        }
      
      monit_update(&strglvl, 1);

      if(ret == -7)     /*c0 01 34ˢ��·��*/
      {
        ml->opt.failcnt = failcnt + 1;
        if (ml->opt.failcnt >= FAILCNT)
        return -1;
      }
      if ((ml->opt.state & OPTCMD1) == 0x00)
        {
          ml->opt.mt->node.attr &= ~NMMASK;  //��ǰ����û����db_write�ĵ���
          if (_task.appd.protype & 0xF0)
            ml->opt.mt->node.attr |= NMTIV;  //��ǰ����û����db_write�ĵ���
        }

      if((ml->opt.state & OPTCMD1) || (ml->opt.state & OPTDEFAPP))
        return -1;

      mtl->state &= ~LSMASK;
      mtl->state |= LRET;
      ml->opt.retcnt = 0;
    }

  return 0;
}

extern unsigned int flag_monitret1_succ;
static int monitret1()
{
  unsigned char data[255], event = 0;
  unsigned char bcdid[6];
  unsigned char databuf1[] = { 0x01, 0x01, 0x06, 0x05 };
  unsigned char databuf2[] = { 0x1F, 0x90 };
  unsigned char temp_item[5];
  memset(temp_item,0x00,sizeof(temp_item));     //����һ����ʱ�����洢�������ݱ�ʶ
  unsigned char pro = _task.appd.protype & 0x0F;
  memcpy(data, _task.appd.data, _task.appd.datalen);

  printf_s("\n****monitret1    up unknow****\n");

//    if (pro == 1 || pro == 2)
#if 0
  if ((_task.appd.data[0] & 0x40) ==0x00)
    {
      if ((_task.appd.item[0] == 0x01 || _task.appd.item[0] == 0x02) && (_task.appd.item[0] !=0x00))     //�����97Э�飬�ж��������п������Ƿ�����Լ����ݱ�ʶ�Ƿ����
        {
          memcpy(temp_item, _task.appd.item + 1, _task.appd.itemlen-1 );
          if ((_task.appd.item[0] == _task.appd.data[0])||(0 != memcmp(temp_item,_task.appd.data+1, 2))) 
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              return -1;
            }
        }
      if ((_task.appd.item[0] == 0x11 || _task.appd.item[0] == 0x12) && (_task.appd.item[0] !=0x00))      //�����07Э�飬�ж��������п������Ƿ�����Լ����ݱ�ʶ�Ƿ����
        {
          memcpy(temp_item, _task.appd.item + 1, _task.appd.itemlen-1 );
          if ((_task.appd.item[0] == _task.appd.data[0])||(0 != memcmp(temp_item,_task.appd.data+1, 4))) 
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              return -1;
            }
        }
      if (chk_task_appdata() < 0)
        {
          if (report_task_fail(_task.ml.opt.mt->node.id, TASK_EXE_RT, TASK_STATUS_NO_RES) >= 0)
            {
              _task.flag |= TSRUN | TTAPD;
              _task.start = currtick();
              _task.wait = DM_OVER_TICK;
              return 0;
            }
          else
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              return -1;
            }
         }
    }
 #endif
  for (int i = 1; i < _task.appd.datalen; ++i)
    data[i] -= 0x33;
    if (data[0] == 0x91 &&(0 == memcmp(databuf1,data+1, 4)))
      {
        for (int i = 5; i < _task.appd.datalen; ++i)
          if ((data[i] & 0x0F) > 9 || ((data[i] >> 4) & 0X0F) > 9 )
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
              flag_monitret1_succ++;
               return -1;
            }
      }
    if (data[0] == 0x81 && (0 == memcmp(databuf2,data+1, 2)))
      {
        for (int i = 3; i < _task.appd.datalen; ++i)
          if ((data[i] & 0x0F) > 9 || ((data[i] >> 4) & 0X0F) > 9 )
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
              flag_monitret1_succ++;
               return -1;
            }
      }
  unsigned char ctemp = 0xF1;
//  send_uart_data_blocking(CHN_DM,&ctemp,1);
//  send_uart_data_blocking(CHN_DM, data, _task.appd.datalen);
  _task.appd.protype &= ~APCMASK;
  if(_task.appd.protype & 0x10)
    event = 1;
  if(_task.ml.opt.retcnt == 0)
  {
      _task.appd.dlytm = ((_commbuf.plc.len + 4) * 8 * (_ndscont.num - 1) * 1000) / 330;
      if((_task.appd.dlytm % 1000) > 500)
        _task.appd.dlytm = _task.appd.dlytm / 1000 + 1;
      else
        _task.appd.dlytm = _task.appd.dlytm / 1000;
      if(_task.appd.dlytm == 0)
        _task.appd.dlytm = 1;
  }
  else
      _task.appd.dlytm += DM_OVER_TICK / 1000; //ÿ���ظ��ϱ�ʱ���3s
  if (app_data(_task.ml.opt.mt->node.id, data, _task.appd.datalen, pro,event) == 0)
    {
      printf_s("\n****monitret1    up_succc****    AID");
      set_dc_fail_cnt(_task.ml.opt.mt->node.id, 1);  //�ɹ������־
      flag_monitret1_succ++;
      unsigned char aid_tmp[IDLEN];
      memcpy(aid_tmp, _task.ml.opt.mt->node.id, IDLEN);
      id_bintobcd(aid_tmp);
      reverse(aid_tmp, 6);

      for (int i = 0; i< IDLEN; i++)
        {
          printf_s("%02x ", aid_tmp[i]);
        }
      printf_s("\n");
      
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = DM_OVER_TICK;

      return 0;
    }

  return -1;
}

static int monitret2(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;

  if (((_task.flag & TSMASK) == TSSUCC && (_task.appd.protype & APCMASK))
      || (++ml->opt.retcnt >= FAILCNT))
    {
      
      printf_s("\n****monitret2****  succ\n");
      
      mtl->state &= ~LSMASK;
      mtl->state |= LREQ;

      del_cur_task(TASK_EXE_RT); //�յ�ȷ��֡��,ɾ��������

    }

  if ((_task.flag & TSMASK) != TSSUCC)
  {
    --gbmessage.gbmcnt; /*�ط����кŲ���*/
  }
  return 0; /* continue return data to dm */
}

static int confmt(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;

  memset(&ml->opt, 0x00, sizeof(ml->opt));
  if((mtl->state & LLMASK) == SNOLEN)
    {
      if ((ml->opt.mt = db_find_sno(mtl->id)) == NULL)
    return -1;
    }
  else
    {
      if ((ml->opt.mt = db_find(mtl->id)) == NULL)
    {
      ml->opt.state = OPTNEXIST;
      memcpy(ml->opt.id, mtl->id, IDLEN);
          if (get_apptype() == (unsigned char)PRTCL_RT)
            {
              _task.appd.protype = 0x00; /* 97 (645) */
              _task.appd.datalen = sizeof(_testdata);
              memcpy(_task.appd.data, _testdata, sizeof(_testdata));
            }
          else
            {
              _task.appd.protype = 0x01; /* 07 (645) */
              _task.appd.datalen = sizeof(_testgb);
              memcpy(_task.appd.data, _testgb, sizeof(_testgb));
            }
    }
    }

  return 0;
}

static int rt_appmnt_init(unsigned char *mtid)
{
  if ((_task.flag & TTMASK) == TTPLC && (_task.flag & TSMASK) == TSRUN)
    return -1;
  struct mtinfo *mt;
  int depth;
  _task.flag = TSNO;
  _task.cnt = 0;
  _task.minfo.state &= ~STIMASK;
  _task.minfo.state |= STMNT;
  _task.flood = 0;


  if ((_share.conswitch & 0x01) == 0 && (_share.flswitch & 0x01) == 1)
  {
      if ((mt = db_find(_task.minfo.id)) == NULL)
      {
          depth = DEFLOODHOP;
      }
      else
      {
          if (mt->node.succhops & NFSUC)
          {
              depth = mt->node.envi & NFHMASK;
          }
          else
          {
              depth = DEFLOODHOP;
          }
      }
      mnt_init_to_flood(depth);

  }
  return 0;
}

static void rt_mntclear()
{
  _rtparas.state &= ~STAMMASK;
  
  printf_s("\n****STAMONIT----CLEAR----rt_mntclear****\n");
  
  _task.flag = TSNO;
  memset(_task.ml.list, 0, sizeof(_task.ml.list));
}
static void mnt_init_to_flood(unsigned char  depth)
{
    unsigned int maxdepth;
    maxdepth = MAXFHOP;
    if (maxdepth > MAXFLOODHOP)
    {
        maxdepth = MAXFLOODHOP;
    }
    _task.cnt = 0;
    _task.flood |= MFLOOD; //valid mt,then use flood to read
    _task.flood &= ~MFDMASK;
    _task.flood |= maxdepth;
    _task.fdepth = depth;
}
static int rt_mntplc()
{
  struct mtinfo *mtp;
  struct rpinfo *rp;
  unsigned char fdepth;
  if ((mtp = db_find(_task.minfo.id)) == NULL && _rtparas.apptype == PRTCL_RT)
    {
      seterrno(RTFERR_IDNOT);
      _rtparas.state &= ~STAMMASK;
      
      printf_s("\n****STAMONIT----CLEAR1----rt_mntplc****\n");
      
      return -1;
    }

  unsigned char sno[SNOLEN], ndsflag = 0; /* ndsflag: organize path successfully or fail */
  if (mtp)
  {

    memcpy(sno, mtp->node.sno, SNOLEN);
  }
  sno[0] &= ~NNEWMASK;

  if (mtp == NULL || (mtp->node.sno[0] & NNEWMASK) || _rtparas.srelay == 0x01) /* new meter || 7���м� */
    {
      if(_rtparas.dlytm & 0x04)
      {
        if (_task.cnt > 0) /* no more path, have read two times */
        {
          seterrno(RTFERR_IDFAIL);
          _rtparas.state &= ~STAMMASK;
          
          printf_s("\n****STAMONIT----CLEAR2----rt_mntplc****\n");
          
          return -1;
        }
      }
      else
      {
        if (_task.cnt > 1) /* no more path, have read two times */
        {
            if (mtp == NULL
                || _rtparas.srelay == 0x01
                || ((_share.flswitch & 0x01) == 0))
          {
            seterrno(RTFERR_IDFAIL);
            _rtparas.state &= ~STAMMASK;
            
            printf_s("\n****STAMONIT----CLEAR3----rt_mntplc****\n");
            
            return -1;
          }
          else
          {
              if (mtp->node.succhops & NFSUC)
              {
                  fdepth = mtp->node.envi & NFHMASK;
              }
              else
              {
                  fdepth = DEFLOODHOP;
              }
              mnt_init_to_flood(fdepth);
            return 0;
          }

        }
      }
      if (_task.cnt == 0)
      {
        memset(&_ndscont, 0x00, sizeof (struct ndscont));

        memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
        _ndscont.nds[_ndscont.num++].len = SNOLEN;
        memcpy(_ndscont.nds[_ndscont.num].id, _task.minfo.id, IDLEN);
        _ndscont.nds[_ndscont.num++].len = IDLEN;
      }
      /* if _task.cnt == 1, do not need to organize nds */
    }
  else
    {
      if (_task.cnt % 2 == 1)
          ndsflag = 1; /* do not need to organize nds */
      else
        {
          while (rp = db_trav_rpnext(CHAN_TMP1, CHAN_TDEF)) /* next rp */
            {
              memset(&_ndscont, 0x00, sizeof (struct ndscont));
              if (ploughpath(rp) == 0)
            {
              ndsrevers(&_ndscont);

    //                  if(_ndscont.num == 1) /*ֱ�����ñ���*/
                      {
                        memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.id, IDLEN);
                        _ndscont.nds[_ndscont.num++].len = IDLEN;
                      }
    #if 0
                      else
                      {
                        memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.sno, SNOLEN);
                        _ndscont.nds[_ndscont.num++].len = SNOLEN;
                      }
    #endif
              ndsflag = 1;
              break;
            }
              /* next rp */
            }
          if (ndsflag == 0) /* no more rp */
            {
              if ((_share.flswitch & 0x01) == 1)
              {
                  if (mtp->node.succhops & NFSUC)
                  {
                      fdepth = mtp->node.envi & NFHMASK;
                  }
                  else
                  {
                      fdepth = DEFLOODHOP;
                  }
                  mnt_init_to_flood(fdepth);
                  return 0;
              }
              else
              {
                   seterrno(RTFERR_IDFAIL);
                   _rtparas.state &= ~STAMMASK;
                
                   printf_s("\n****STAMONIT----CLEAR4----rt_mntplc****\n");
                
                   return -1;
              }

            }
        }
    }

  memset(&_task.ml, 0x00, sizeof(struct monitinfo));
  _task.ml.opt.mt = mtp;  /* to use monit_update */
  
  if (mtp)
    mtp->dc_cnt++;

  unsigned char mnttkn = 0, nlframe[255];
  int nllen = 255;
  if (_task.cnt % 2 == 0)
    mnttkn |= PARAMNT;

  if (_task.minfo.state & STBMASK) /* broad */
    {
      memcpy(_ndscont.nds[_ndscont.num].id, broadsno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      mnttkn |= PARAASW;
    }

  int ret = nl_monittask1(&_task.appd, mnttkn, sno, nlframe, &nllen); /*  tkn=0, asw=1 */
  assert(ret == 0);

  unsigned char rtframe[255];
  int rtlen = 255;
  nl_frm38(NLT_NORMAL, nlframe, nllen, rtframe, &rtlen, PLC_DC);
  nl_rtwrite(fd, rtframe, rtlen, 0);

  if (_task.minfo.state & STABMASK) /* broad */
    {
      app_res(NULL, 0); /* need to send confirm frame to dm */
      _rtparas.state &= ~STAMMASK; /* no task, no monit */
      
      printf_s("\n****STAMONIT----CLEAR5----rt_mntplc****\n");
      
      return 0;
    }

  if(_task.cnt > 1) /* info frame: change another path */
    {
      if ((_share.flswitch & 0x01) == 1)
      {
          if (mtp->node.succhops & NFSUC)
          {
              fdepth = mtp->node.envi & NFHMASK;
          }
          else
          {
              fdepth = DEFLOODHOP;
          }
          mnt_init_to_flood(fdepth);
          return 0;
      }
      else
      {
          return -1;
      }
      //unsigned char info = INFCHPATH;
      //app_info(&info, sizeof(info));
    }

  if (mtp)
  mtp->trycnt++;
  ++_task.cnt;
  _task.flag = TSRUN | TTPLC;
  _rtparas.state &= ~STAMMASK;
  _rtparas.state |= STAMONIT;
    
  printf_s("\n****STAMONIT----ADD----rt_mntplc****\n");

  _task.start = currtick();
  if(mtp == NULL || (mtp->node.succhops & NHMASK) == 0x00)
    _task.wait = MAXHOPTM;
  else
    _task.wait = (mtp->node.succhops & NHMASK) * MAXHOPTM; /* max wait time */
  return 0;
}

extern unsigned int flag_rt_mntplc_v_fail;
extern unsigned int flag_rt_mntplc_v_succ;
static int rt_mntplc_v()
{
  unsigned short crc1;
  unsigned short len_trans;
  int elen = 0;
  int pro = 3;
  if ((_task.minfo.state & STIMASK) == STINIT) /* ��ʼ�� */
    {
      if ((_task.flag & TTMASK) == TTPLC && (_task.flag & TSMASK) == TSRUN)
        return -1;
      _task.flag = TSNO;
      _task.cnt = 0;
      _task.minfo.state &= ~STIMASK;
      _task.minfo.state |= STMNT;
    }
  if ((_task.minfo.state & STIMASK) == STMNT)
    {
      if ((_task.flag & TSMASK) == TSRUN) /* ����ִ���� */
        {
          rt_report(REPOIDLE, 0x00);
          return 0;
        }
      if ((_task.flag & TSMASK) == TSSUCC)
        {
          if (_task.dcsucc == 2)
            {

             if ((_task.appd.data[0] == 0x9e) && ((_task.appd.protype & PTMASK) == 0x03)) 
               {
 
                 len_trans = _task.appd.datalen;
                 crc1 = _task.appd.data[len_trans - 1] * 256 + _task.appd.data[len_trans - 2];

                 if ((elen = check_9e(&_task.appd.data[0], _task.appd.datalen, crc1)) == -1)
                 {
                   rt_mntclear();
                   flag_rt_mntplc_v_succ++;
                   _rtparas.state &= ~STAMMASK;


                   _task.dcsucc = 0;
                   return 0; 
                 }
                 else
                 {
                   /* ������� -2��֮��ֱ���ϱ� */
                   pro = 0;

                   _task.appd.datalen -= 2;  //У����˽�len���ȼ�2ֻ��header��payload
                   memmove(_task.appd.data, &_task.appd.data[11 + elen], _task.appd.datalen - 11 - elen);
                   _task.appd.datalen = _task.appd.datalen - 11 - elen;
                 }
               }

              app_gbcomm(_task.minfo.id, pro, _task.appd.data, _task.appd.datalen);
              set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
              rt_mntclear();
              flag_rt_mntplc_v_succ++;
              _rtparas.state &= ~STAMMASK;
              
              printf_s("\n****STAMONIT----CLEAR----rt_mntplc_v****\n");
              
              _task.dcsucc = 0;
              return 0;
            }
          else
            {
              _task.flag &= ~TSMASK;
              _task.flag |= TSRUN;
              return 0;
            }
        }
      if ((_task.flag & TSMASK) == TSFAIL) /* ʧ�� */
        {
          if (_task.dcsucc != 1 || (get_sys_tick() - _task.start) < _task.wait)
            {
              _task.flag &= ~TSMASK;
              _task.flag |= TSRUN;
              return 0;
            }
          if (_task.cnt < 2) /* �ط�һ�� */
            {
              if (_rtparas.dcviv == TYPE53_43)  //�л���43����һ��
              {
                  _rtparas.dcviv = TYPE43;
                  set_dcv_to_dciv();
              }
               _task.flag = TSNO;
               _task.minfo.state &= ~STIMASK;
               _task.minfo.state |= STMNT;
               return 0;
            }
          else
            {
              chn_fail();
              app_gbcomm(_task.minfo.id, _task.appd.protype & 0x0F, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 2);  /* ʧ�� */
              flag_rt_mntplc_v_fail++;
              rt_mntclear();
              _task.dcsucc = 0;
              return 0;
            }
        }
      if ((_task.flag & TSMASK) == TSNO) /* ִ�� */
        {
          static unsigned char dcseq_v = 0;
          printf_s("_task.appd.datalen:%d\n", _task.appd.datalen); 
          _task.dcseq = dcseq_v++;
          nl_p2p(_task.minfo.id, _task.appd.data, _task.appd.datalen, _task.dcseq, PLC_DC);

          ++_task.cnt;
          _task.flag = TSRUN | TTPLC;
          _rtparas.state &= ~STAMMASK;
          _rtparas.state |= STAMONIT;
          
          printf_s("\n****STAMONIT----ADD----rt_mntplc_v****\n");
          
          _task.dcsucc = 1;
          _task.start = currtick();
          if(_task.cnt == 1)
            _task.wait = 10*1000;
          else
            _task.wait = 15*1000; /* max wait time */
          return 0;
        }
    }
 
}

#if 1
static int rt_floodmntplc()
{
  struct mtinfo *mtp;

  if ((mtp = db_find(_task.minfo.id)) == NULL)
   {
  // seterrno(RTFERR_IDNOT);
   // _rtparas.state &= ~STAMMASK;
   //return -1;
  }
  _task.flag &= ~TSFLOODRMASK; //����������ݱ�־λ
//if (_task.cnt > 0) /* no more path, have read two times */
//{
//  seterrno(RTFERR_IDFAIL);
//  _rtparas.state &= ~STAMMASK;
//  return -1;
//}
  if (_task.cnt == 0)
  {
    memset(&_ndscont, 0x00, sizeof (struct ndscont));
    memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
    _ndscont.nds[_ndscont.num++].len = SNOLEN;
    memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.id, IDLEN);
    _ndscont.nds[_ndscont.num++].len = IDLEN;
  }

  memset(&_task.ml, 0x00, sizeof(struct monitinfo));
  _task.ml.opt.mt = mtp;  /* to use monit_update */

  unsigned char nlframe[255], depth;

 // depth = mtp->node.envi & NFHMASK;

  //if(depth > 4)
   // depth = 4;
  //depth = _task.flood & MFDMASK;
  if (_task.fdepth < 2)
  {
      _task.fdepth = 2;
  }
  depth = _task.fdepth;
 // printf("detph %d",depth);
  int nllen = nl_floodtask(&nlframe[0], &_task.minfo.id[0], depth, &_task.appd);

  unsigned char rtframe[255];
  int rtlen = 255;

//_nl_type &= ~FRMTMASK; //nl use fsk
//_nl_type |= FRMTIIIE;

  nl_frm38(NLT_PARL, nlframe, nllen, rtframe, &rtlen, PLC_DC);
  nl_rtwrite(fd, rtframe, rtlen, 0);

  if (_task.minfo.state & STABMASK) /* broad */
    {
      app_res(NULL, 0); /* need to send confirm frame to dm */
      _rtparas.state &= ~STAMMASK; /* no task, no monit */
      
      printf_s("\n****STAMONIT----CLEAR----rt_floodmntplc****\n");
      
      return 0;
    }

  if(_task.cnt > 0) /* info frame: change another path */
    {
      unsigned char info = INFCHPATH;
      app_info(&info, sizeof(info));
    }

  if (mtp)
  {
    mtp->trycnt++; 
    mtp->dc_cnt++;
  }

  ++_task.cnt;
  _task.flag = TSRUN | TTPLC;
  _rtparas.state &= ~STAMMASK;
  _rtparas.state |= STAMONIT;

  printf_s("\n****STAMONIT----ADD----rt_floodmntplc****\n");
    
  _task.start = currtick();
  _task.wait = fload_waittime(depth, nllen, _task.appd.wretlen);
  return 0;
}
#endif
extern unsigned int flag_rt_mntret_succ;
static int rt_mntret()
{
  int appgb_cfm(unsigned short wait);
  unsigned char data[255];
  unsigned char databuf1[] = { 0x01, 0x01, 0x06, 0x05 };
  unsigned char databuf2[] = { 0x1F, 0x90 };
  unsigned char pro;
  unsigned char temp_item[5];                                                      
  memset(temp_item,0x00,sizeof(temp_item));     //����һ����ʱ�����洢�������ݱ�ʶ 
  memcpy(data, _task.appd.data, _task.appd.datalen);
#if 0
    unsigned char ctemp = 0xF10;
  send_uart_data_blocking(CHN_DM,&ctemp,1);
  send_uart_data_blocking(CHN_DM, data,_task.appd.datalen);
#endif
  pro = _task.appd.protype & PTMASK;
//  if (pro == DLT64507 || pro == DLT64597)
#if 0
  if ((_task.appd.data[0] & 0x40) ==0x00)
    {
      if ((_task.appd.item[0] == 0x01 || _task.appd.item[0] == 0x02) && (_task.appd.item[0] !=0x00))      //�����97Э�飬�ж��������п������Ƿ�����Լ����ݱ�ʶ�Ƿ����
        {
          memcpy(temp_item, _task.appd.item + 1, _task.appd.itemlen-1 );
          if ((_task.appd.item[0] == _task.appd.data[0])||(0 != memcmp(temp_item,_task.appd.data+1, 2))) 
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              return -1;
            }
        }
      if ((_task.appd.item[0] == 0x11 || _task.appd.item[0] == 0x12) && (_task.appd.item[0] !=0x00))      //�����07Э�飬�ж��������п������Ƿ�����Լ����ݱ�ʶ�Ƿ����
        {
          memcpy(temp_item, _task.appd.item + 1, _task.appd.itemlen-1 );
          if ((_task.appd.item[0] == _task.appd.data[0])||(0 != memcmp(temp_item,_task.appd.data+1, 4))) 
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              return -1;
            }
        }
      if (chk_task_appdata() < 0)
        {
          app_gbcomm(_task.minfo.id, pro, NULL, 0);
          return -1;
        }
    }
  #endif
  if (pro == DLT64507 || pro == DLT64597)
  {
      for (int i = 1; i < _task.appd.datalen; ++i)
          data[i] -= 0x33;

#if 0
    if (data[0] == 0x91 && (0 == memcmp(databuf1,data+1, 4)))
      {
        for (int i = 5; i < _task.appd.datalen; ++i)
          if ((data[i] & 0x0F) > 9 || (((data[i] >> 4) & 0x0F) > 9 ))
             {
               app_gbcomm(_task.minfo.id, pro, NULL, 0);
               set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
               flag_rt_mntret_succ++;
               return -1;
             }
      }

    if (data[0] == 0x81 && (0 == memcmp(databuf2, data+1, 2)))
      {
        for (int i = 3; i < _task.appd.datalen; ++i)
          if ((data[i] & 0x0F) > 9 || (((data[i] >> 4) & 0x0F) > 9 ))
            {
              app_gbcomm(_task.minfo.id, pro, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
              flag_rt_mntret_succ++;
              return -1;
            }
      }
#endif

  }

#if 0
   ctemp = 0xF12;
  send_uart_data_blocking(CHN_DM,&ctemp,1);
  send_uart_data_blocking(CHN_DM, data,_task.appd.datalen);
#endif
  if (get_apptype() == PRTCL_RT)
    {
      unsigned char tmpdata[255];
      tmpdata[0] = data[0]; /* ctrl */
      tmpdata[1] = _task.appd.datalen - 1; /* len */
      memcpy(tmpdata + 2, data + 1, _task.appd.datalen - 1); /* data */

      app_res(tmpdata, _task.appd.datalen + 1); /* return data to dm */
    }
  else if(get_apptype() == PRTCL_GB)
  {//�ӽڵ�����ظ�ȷ��
    extern unsigned char callmeter;
    if(callmeter == 1)
    {
      appgb_cfm(2); /* wait 2s */;
      callmeter = 0;
      return 0;
    }
    else
      {
        app_gbcomm(_task.minfo.id, pro, data, _task.appd.datalen);
        set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
        flag_rt_mntret_succ++;
      }

  }

  return 0;
}

static void flood_dc_tmout(void)
{
    del_a_timer(TIMER_FLOOD_RDATA);
    _rtparas.state &= ~STAMMASK;
  
    printf_s("\n****STAMONIT----CLEAR----flood_dc_tmout****\n");
  
    rt_mntret();
    rt_mntclear();
}
extern struct info_frame_iv_up cur_info;

extern unsigned int flag_rt_mntprocess_eeprom;
extern unsigned int flag_rt_mntprocess_fail;
extern unsigned int flag_rt_mntprocess_succ;
static int rt_mntprocess()
{
  int ret;
  unsigned char depth = 0;
  unsigned int time_left =0;
  unsigned char dbuf[255];
  int dlen = 0;
  unsigned char meter_id[6];
  unsigned char nd_dc_v = 0;

  if ((_task.flag & TSMASK) == TSSUCC)
    {
      struct rtinfo strglvl;

      printf_s("\n****rt_mntprocess    TSSUCC****:    ");
      if (_rtparas.dcviv != TYPE53)
        {
          unsigned char aid_tmp[IDLEN];
          memcpy(aid_tmp, _task.minfo.id, IDLEN);
          id_bintobcd(aid_tmp);
          reverse(aid_tmp, 6);
          
          for (int i = 0; i< IDLEN; i++)
            {
              printf_s("%02x ", aid_tmp[i]);
            }
		      printf_s("\n");
        }

      if (_rtparas.dcviv == TYPE43_53) 
      {
          _task.flag &= ~TSMASK;
          _task.flag |= TSRUN;
          return 0; 
      }
      
      if (_share.conswitch & 0x01)
      {
          memset((unsigned char *)&strglvl, 0x00, sizeof(strglvl));
          if((_task.minfo.state & STDISPMASK) == STDISPCOMM)
            ret = dispnl_monitprocess(_commbuf.plc.buf, _commbuf.plc.len, &_task.appd, &strglvl);
          else
            ret = nl_monitprocess(_commbuf.plc.buf, _commbuf.plc.len, &_task.appd, &strglvl);
        if (ret == 0 )
        {
              --_ndscont.num;
              if(_task.ml.opt.mt)
              monit_update(&strglvl, 0);
          _rtparas.state &= ~STAMMASK;
              
          printf_s("\n****STAMONIT----CLEAR1----rt_mntprocess****\n");
          
          if(_task.ml.opt.mt)
            {
              if (((strglvl.dev43 & 0x80) >> 7) == 1 )
              {
                  if ((_task.ml.opt.mt->node.viv & NNDMASK) != NND55 || 
                      ((_task.ml.opt.mt->node.viv & NETMASK) >> 2 == 0x00))
                  {
                      _task.ml.opt.mt->node.viv &= ~NNDMASK;
                      _task.ml.opt.mt->node.viv |= NND55;
                      _task.ml.opt.mt->node.viv &= ~(1 << 2);
                       //ֱ�ӽ���V��������������ʽ��4���ĳ���
                      _task.ml.opt.mt->dc_55_iv_cnt++;
                      

                      if (local_viv_swi != 1 && (_task.ml.opt.mt->dc_55_iv_cnt >= 8)) 
                      {
                          dlen = get_data_item(_task.ml.opt.mt, dbuf);
                          if (dlen > 0 && (dlen < 255))
                          {
                            memcpy(meter_id, _task.ml.opt.mt->node.id, 6);
                            id_bintobcd(meter_id);
                            reverse(meter_id, 6);
                            printf_s("*****************v dc for in net******************\n");
                            nl_p2p(meter_id, dbuf, dlen, _task.dcseq++, PLC_DC);
                            _task.ml.opt.mt->dc_55_iv_cnt = 0;
                            nd_dc_v = 1;
                          }
                      }
                  }
              }
              else
              {
                  _task.ml.opt.mt->node.viv &= ~NNDMASK;
                  _task.ml.opt.mt->node.viv |= NND43;

              }
              clr_strglvl_dev(&strglvl); 

              db_write(_task.ml.opt.mt->addr + offset(struct mtnode, viv), &_task.ml.opt.mt->node.viv, sizeof(_task.ml.opt.mt->node.viv));
              set_dc_fail_cnt(_task.ml.opt.mt->node.id, 1);  //�ɹ������־
              flag_rt_mntprocess_succ++;
              
              flag_rt_mntprocess_eeprom++;
            }
              
              rt_mntret();
              rt_mntclear();
              if (nd_dc_v == 1)
              {
                _task.flag = TSRUN | TTPLC;
                _task.start = currtick();
                _task.wait = 10 * 1000;
              }
        }
        else if (ret == -2 || ret == -8)
        {
            _task.flag &= ~TSMASK;
            _task.flag |= TSRUN;
            return 0;
        }
        else if (ret == -7) //c0 34��
        {
            --_ndscont.num;
            if (_task.ml.opt.mt)
                monit_update(&strglvl, 0);
            _rtparas.state &= ~STAMMASK;
            
            printf_s("\n****STAMONIT----CLEAR2----rt_mntprocess****\n");

            //rt_mntret();
//            app_gbcomm(_task.minfo.id, _task.appd.protype, NULL, 0);
             app_gbcomm(_task.minfo.id, _task.appd.protype & 0x0F, _task.appd.data, _task.appd.datalen);
            set_dc_fail_cnt(_task.minfo.id, 1);  //�ɹ������־
            flag_rt_mntprocess_succ++;
            rt_mntclear();
         }
      }

      if (_share.flswitch & 0x01)
      {
        ret = nl_floodprocess(_commbuf.plc.buf, _commbuf.plc.len, &_task.appd, &depth);
        if (ret == 0)
        {

          time_left = calc_fh_left_time(_commbuf.plc.buf, _commbuf.plc.len);
          if (0 == time_left)
          {
              time_left = 60;
          }
          alloc_a_timer(TIMER_FLOOD_RDATA, time_left, time_left, flood_dc_tmout); //����5s��ʱ
          if ((_task.flag & TSFLOODRMASK) != TSFLOODRCV)//��һ�ε�ʱ��Ÿ�����ȣ�����Ĳ�����
          {
              flood_updata(_task.ml.opt.mt, depth, 1);
          }
          
          if(_task.ml.opt.mt)
            {
              if ((_task.ml.opt.mt->node.viv & NNDMASK) != NND55)
              {
                 _task.ml.opt.mt->node.viv &= ~NNDMASK;
                 _task.ml.opt.mt->node.viv |= NND43; 
              }

              db_write(_task.ml.opt.mt->addr + offset(struct mtnode, viv), &_task.ml.opt.mt->node.viv, sizeof(_task.ml.opt.mt->node.viv));
              set_dc_fail_cnt(_task.ml.opt.mt->node.id, 1);  //�ɹ������־
              flag_rt_mntprocess_succ++;
              
              flag_rt_mntprocess_eeprom++;
            }
          _task.flag &= ~TSFLOODRMASK;
          _task.flag |= TSFLOODRCV;
        }
           _task.flag &= ~TSMASK;
           _task.flag |= TSRUN;
           return 0;
      }
  }
  else
  {
    printf_s("\n****rt_mntprocess    FAIL****");
    if (_rtparas.dcviv != TYPE53)
      {
        unsigned char aid_tmp[IDLEN];
        memcpy(aid_tmp, _task.minfo.id, IDLEN);
        id_bintobcd(aid_tmp);
        reverse(aid_tmp, 6);
        
        for (int i = 0; i< IDLEN; i++)
          {
            printf_s("%02x ", aid_tmp[i]);
          }
		    printf_s("\n");
      }
    
      if ((_task.flag & TSFLOODRMASK) == TSFLOODRCV)//3.5����ʱʱ�䵽�����ǽ��յ�����
      {
          _task.flag &= ~TSFLOODRMASK;
          del_a_timer(TIMER_FLOOD_RDATA);
          flood_dc_tmout();
          _task.flag = TSNO;
          set_dc_fail_cnt(_task.minfo.id, 2); 
          return 0;
      }
      if ((_task.flood & MFMASK) == MFLOOD
          || ((_share.conswitch & 0x01) == 0 && (_share.flswitch & 0x01) == 1)) //fail
      {

          flood_updata(_task.ml.opt.mt, _task.fdepth, 0);

          if (++_task.fdepth > (_task.flood & MFDMASK)) /* If count of flooding equal to mt1->sno[1], flooding over, else continue */
          {
              app_gbcomm(_task.minfo.id, _task.appd.protype & 0x0F, NULL, 0);
              set_dc_fail_cnt(_task.minfo.id, 2);  //����ʧ��
              flag_rt_mntprocess_fail++;
              rt_mntclear();
              return 0;
          }
          _task.fdepth++;
          _nl_type &= ~FRMFFMASK; //�ֲ�ʽʧ�ܣ����´�ʹ��fsk
          _nl_type |= FRMFFAIL;
      }
//       else
//       {
//         app_gbcomm(_task.minfo.id, _task.appd.protype & 0x0F, NULL, 0);
//         rt_mntclear();
//         return 0;
//       }
  }

  _task.flag = TSNO;

  return 0;
}

static void reg_timer()
{
 // int appgb_wkstate_report(unsigned char state);
  if ((_rtparas.state & STARMASK) != STAREG )
    return;
  
  extern unsigned char appgb_reg_v;
  if (appgb_reg_v == 1)
    return;
  
  ++_rtreport.idletm;
  if (_rtreport.left == 0 || --_rtreport.left == 0 || _rtreport.idletm > 20)
    {
      _rtparas.state &= ~STARMASK;
      _task.flag = TSNO;
      set_rts_value(CHN_38_1, 1);
      if (_share.version == NEW_GBPRO && ((_rtparas.wkstate & REGSWIMASK) == REGSWION))
      {
          nw_report_wkstate();
      }
    }
  else
    alloc_a_timer(TIMER_REGTIMER, 60000, 60000, reg_timer);

}

static void report_start()
{
  extern unsigned char lastTno6Sno;   //�ϴ�������������
  void clr_zjbroad_info(void);
  unsigned char err, brd[5] = {0x11, 0xAC, 0xAC, 0xAC, 0xAC};
//  unsigned char frame[255], nlframe[255], err, brd[5] = {0x11, 0xAC, 0xAC, 0xAC, 0xAC};
//  int len, nllen;

  if ((_task.flag & TSMASK) == TSNO)
    {
//      if(_share.version == NEW_GBPRO)
      {
        if(rf_start_broadcast(brd, sizeof(brd), 0x81, _rtreport.left) >= 0)
        {
          _task.flag = TSRUN | TTPLC;
          _task.start = currtick();
          _task.wait = 2000;
          _rtreport.count = 0x83;
          clr_zjbroad_info();
          alloc_a_timer(TIMER_CLR_ZJBRD, 0, 0, clr_zjbroad_info); 
        }
        else
        {
          _rtreport.count = 0x03;
        }
      }
#if 0
      else
      {
        nl_regtask(_rtreport.sno, _rtreport.left / 4, NULL, 0, frame, &len);
        nl_frm38(NLT_PARL, frame, len, nlframe, &nllen);
        _task.flag = TSRUN | TTPLC;
        _task.start = currtick();
        _task.wait = 2000;
        _rtreport.count++;
        nl_rtwrite(fd, nlframe, nllen, 0);
        return;
      }
#endif
    }
  if((_task.flag & TSMASK) == TSSUCC && (_commbuf.plc.mode == PLCCFM))
    _rtreport.count |= 0x80;

  _task.flag = TSNO;
  if ((_rtreport.count & 0x0F) < 3)
    return;

  if (_rtreport.count & 0x80)
    {
      app_cfm(); /* cofirme */
      alloc_a_timer(TIMER_REGTIMER, 60000, 60000, reg_timer);
      _rtreport.state = REPORT_APP;
      set_rts_value(CHN_38_1, 0);
    }
  else
    {
      err = (_rtparas.apptype == PRTCL_GB) ? GBERR_OTHER : RTFERR_NORES;
      app_err(&err, 1);/* negtate */
      _rtparas.state &= ~STARMASK;
    }
}

static int apptask(struct para_report *report)
{
  int ret = -1;
  unsigned char AC[] = {0xAC, 0xAC, 0xAC, 0xAC};

  _task.flag = TSNO;
  _task.appd.protype = 0;

  if (report->type == TNO5)                     //�¼��ϱ�
    ret = app_warnup(report->id, report->tp, report->tplen);
  else if (report->type == TNO5_NEW)
    ret = app_warnup_new(report->id, report->tp, report->tplen);
  else if((report->type == _TNO6) && (_rtparas.state & STARMASK) != STAREG) //�㲥������㽭�ѱ�
  {
    if((_rtparas.wkstate & ZJREGMASK) == ZJREG)
      ret = app_warnup(report->id, report->tp, report->tplen);
  }
  else if((report->type == _TNO6) && (_rtparas.state & STARMASK) == STAREG) //ע�ᷢ����㽭�ѱ�
  {
    unsigned char cid[6], pro;
    if(_share.version == NEW_GBPRO)
    {
      if(report->tplen == 13)
      {
        if(memcmp(&report->tp[2], AC, sizeof(AC) != 0))
          return -1;
        memcpy(cid, report->tp + 7, IDLEN);
        pro = report->tp[5];

        ret = app_regup_new(report->id, cid, pro);
      }
      else
        ret = app_regup_new(report->id, NULL, 0x02);
    }
    else
      ret = app_regup(report->id);
  }
  else if(report->type == TNO6 && (_rtparas.state & STARMASK) == STAREG)
      ret = app_regup(report->id);

#if 0
  if ((report->type == TNO5) || (report->type == _TNO6))
    ret = app_warnup(report->id, report->tp, report->tplen);
  else if(report->type == TNO6 && (_rtparas.state & STARMASK) == STAREG)
    ret = app_regup(report->id);
#endif
  if (ret == 0)
    {
      _task.flag = TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = DM_OVER_TICK;
    }

  return ret;
}

static int report_valid(struct para_report *report)
{
  memset(report, 0x00, sizeof(struct para_report));

  while (_rtreport.len > 0)
    {
      if (report_pop(report) != 0)
        continue;
      if ((report->type == TNO5) || (report->type == TNO5_NEW)||
          (report->type == _TNO6) || (report->type == TNO6 && (_rtparas.state & STARMASK) == STAREG))
        return 0;
    }

  return -1;
}

int rt_sink38mode()
{
  if (sink38mode == SINK38SET)
    return 0;
  return -1;
}

int plc_38_43 = 1;

#if 1
void rt_setsink38()
{

  if ((_task.flag & TSMASK) == TSRUN)
    return;
	_task.cnt = 0;
  sink38mode = SINK38SET;
  _task.flag = TSNO;
}
#endif

int get_curid(unsigned char *id)
{
  memcpy(id, _task.ml.opt.mt->node.id, IDLEN);
  return 0;
}

static int report_pop(struct para_report *report)
{
    unsigned char tmplen = _rtreport.buf[_rtreport.len - 1];

    if ((_rtreport.len < offset(struct para_report, tplen)) ||
        (tmplen + 1 > _rtreport.len))
    {
        _rtreport.len = 0;
        return -1;
    }

    memcpy(report, &_rtreport.buf[_rtreport.len - tmplen - 1], tmplen);
    _rtreport.len -= tmplen + 1;

    if (tmplen < offset(struct para_report, tplen) ||
        (report->type != TNO5 && report->type != TNO5_NEW &&
         report->type != TNO6 && report->type != _TNO6)) return -1;

    return 0;
}
static int flood_updata(struct mtinfo *mt, unsigned char depth, unsigned char suc)
{
   // if (suc != 0 || depth > (mt->node.envi & NFHMASK))
   if(mt == NULL)
   {
     return -1;
   }

  if (suc)
    {
        mt->node.envi &= ~NFHMASK;  //��ǰ����û����db_write�ĵ���
        mt->node.envi |= depth;
        if ((_share.conswitch & 0x01) == 0)//������ʽû���ã������ֲ�ʽ��ʱ��
          {
          mt->rdtick = TICK_NEWEST;
          }
    }
    mt->node.succhops &= ~NFSUC; /* clear success flag */  //��ǰ����û����db_write�ĵ���

    if (suc)
        mt->node.succhops |= NFSUC; /* if flooding succeed, set success flag */

    if (suc && _rtparas.stage == S8)
    {
        mt->node.attr |= NMTIV;  //��ǰ����û����db_write�ĵ���
        _task.ml.opt.reqcnt = depth;
    }

    return 0;
}
#if 0
static int floodreq1()
{
  int ret = 0;
  struct monitinfo *ml = &_task.ml;

  assert((ml->opt.state & OPTNEXIST) == 0); /* in database */

  memset((unsigned char *)&_task.appd, 0x00, sizeof(_task.appd));

  ret = app_request(RQMNTC, ml->opt.reqcnt, ml->opt.mt->node.id);

  if (ret == 0)
    {
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = 2000;
    }

  return ret;
}

static int floodreq2(struct mtlist *mtl)
{
  unsigned char type = _task.appd.protype & (APCMASK | APDMASK);

  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (type == 0 || type == (APCMASK | APDMASK))
        return 0;
      if (_task.appd.protype & APCMASK) /* application confirm */
      {
        if(_task.ml.opt.failcnt == 0)
          _task.ml.opt.mt->node.envi |= NCMD1SUC;
        return -1;
      }

      ++_task.ml.opt.failcnt;
      _task.cnt = 0;
      mtl->state &= ~LSMASK;
      mtl->state |= LPLC;
    }
  else
    --gbmessage.gbmcnt; /*�ط����кŲ���*/
  return 0; /* if failure, continue request */
}

static int floodplc1()
{
  unsigned char msg[255], frame[255];
  int len = sizeof(msg), framelen = sizeof(frame);;
  struct monitinfo *ml = &_task.ml;

  if(_rtparas.stage == S8)
    len =  nl_IVfloodtask(msg, ml->opt.mt->node.id, ml->opt.reqcnt, &_task.appd);
  else
    len =  nl_floodtask(msg, ml->opt.mt->node.id, ml->opt.reqcnt, &_task.appd);

  nl_frm38(NLT_PARL, msg, len, frame, &framelen);
  nl_rtwrite(fd, frame, framelen, 0);
  _task.flag |= TSRUN | TTPLC;
  _task.start = currtick();
  _task.wait = fload_waittime(ml->opt.reqcnt, len, _task.appd.wretlen);
  _task.cnt++;

  return 0;
}



static int floodplc2(struct mtlist *mtl)
{
  int  ret;
  struct monitinfo *ml = &_task.ml;
  unsigned char depth;

  if ((_task.flag & TSMASK) == TSFAIL)
    {
      flood_updata(ml->opt.mt, ml->opt.reqcnt, 0);
 //     if (mtl->sno[0] == mtl->sno[1] && _task.cnt < 2) /* At least twice*/
 //       return 0;
      if (++ml->opt.reqcnt > mtl->sno[1]) /* If count of flooding equal to mt1->sno[1], flooding over, else continue */
        return -1;
      if(_task.cnt > 1)
        return -1;
    }
  else /* task success*/
    {
      if(_rtparas.stage == S8)
        ret = nl_IVfloodprocess(_commbuf.plc.buf, _commbuf.plc.len,  &_task.appd, &depth);
      else
        ret = nl_floodprocess(_commbuf.plc.buf, _commbuf.plc.len,  &_task.appd, &depth);

      if (ret != 0)
        {
          flood_updata(ml->opt.mt, ml->opt.reqcnt, 0);
          return (++ml->opt.reqcnt > mtl->sno[1])? -1: 0; /* If count of flooding equal to mt1->sno[1], flooding over, else continue */
        }

      flood_updata(ml->opt.mt, depth, 1);

      mtl->state &= ~LSMASK;
      mtl->state |= LRET;
      ml->opt.retcnt = 0;
    }

  return 0;
}

static int floodret1()
{
  unsigned char data[255], event;

  memcpy(data, _task.appd.data, _task.appd.datalen);
    if(_task.appd.protype&0x03)
    {
        for (int i = 1; i < _task.appd.datalen; ++i)
        data[i] -= 0x33;
    }
  _task.appd.protype &= ~APCMASK;
  if(_task.appd.protype & 0x10)
    event = 1;
  if (app_data(_task.ml.opt.mt->node.id, data, _task.appd.datalen, event) == 0)
    {
      set_dc_fail_cnt(_task.ml.opt.mt->node.id, 1);  //�ɹ������־
      flag_floodret1_succ++;
      _task.flag |= TSRUN | TTAPD;
      _task.start = currtick();
      _task.wait = 2000;

      return 0;
    }

  return -1;
}

static int floodret2(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;

  if (((_task.flag & TSMASK) == TSSUCC && (_task.appd.protype & APCMASK))
      || (++ml->opt.retcnt >= FAILCNT)) /* if Reported more than 9 times, not continue */
    {
      mtl->state &= ~LSMASK;
      mtl->state |= LREQ;
    }

  if ((_task.flag & TSMASK) != TSSUCC)
    --gbmessage.gbmcnt; /*�ط����кŲ���*/
  return 0; /* continue return data to dm */
}



#endif
static unsigned int fload_waittime(int maxHpd, int frameDownLen, int frameUpLen)
{
    unsigned int frameUpDownLen, waitTime;

    if (frameUpLen == 0)
    {
        frameUpLen = 180;
    }
    frameUpLen = frameUpLen + 4 + 1 + 3 + 12 + 3 + 2 + 2;

    frameUpDownLen = (frameUpLen + frameDownLen > 250 ? 250 : frameUpLen + frameDownLen);
    if (_rtparas.stage == S8)
        frameUpDownLen += 10;

    waitTime = frameUpDownLen * 25 * (maxHpd + 1) + frameUpLen * 25 + 5000 + (maxHpd + 1) * 100 + 400;

    return waitTime;
}
/******************��ʾ��Ԫ*************************/
static int rt_disp_mntplc()
{
  struct mtinfo *mtp;
  struct rpinfo *rp;
  if ((mtp = db_find(_task.minfo.id)) == NULL && _rtparas.apptype == PRTCL_RT)
    {
      seterrno(RTFERR_IDNOT);
      _rtparas.state &= ~STAMMASK;
      
      printf_s("\n****STAMONIT----CLEAR1----rt_disp_mntplc****\n");
      
      return -1;
    }

  unsigned char sno[SNOLEN], cmd, ndsflag = 0; /* ndsflag: organize path successfully or fail */
  if(mtp)
    memcpy(sno, mtp->node.sno, SNOLEN);
  sno[0] &= ~NNEWMASK;

  if ((mtp == NULL) || (mtp->node.sno[0] & NNEWMASK)) /* 7���м̷�ʽ */
    {
      cmd = 0;
      if (_task.cnt > 1) /* no more path, have read two times */
    {
      seterrno(RTFERR_IDFAIL);
      _rtparas.state &= ~STAMMASK;
      
      printf_s("\n****STAMONIT----CLEAR2----rt_disp_mntplc****\n");
      
      return -1;
    }
      if (_task.cnt == 0)
    {
      memset(&_ndscont, 0x00, sizeof (struct ndscont));

      memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      memcpy(_ndscont.nds[_ndscont.num].id, _task.minfo.id, IDLEN);
      _ndscont.nds[_ndscont.num++].len = IDLEN;
      memcpy(_ndscont.nds[_ndscont.num].id, dispidno, IDLEN);
      _ndscont.nds[_ndscont.num++].len = IDLEN;
    }
      /* if _task.cnt == 1, do not need to organize nds */
    }
  else /*cmd = 6��ʽ*/
    {
      cmd = 6;
      if (_task.cnt % 2 == 1)
    ndsflag = 1; /* do not need to organize nds */
      else
    {
      while (rp = db_trav_rpnext(CHAN_TMP, CHAN_TDEF)) /* next rp */
        {
          memset(&_ndscont, 0x00, sizeof (struct ndscont));
          if (ploughpath(rp) == 0)
        {
          ndsrevers(&_ndscont);

          memcpy(_ndscont.nds[_ndscont.num].id, mtp->node.sno, SNOLEN);
          _ndscont.nds[_ndscont.num++].len = SNOLEN;
                  memcpy(_ndscont.nds[_ndscont.num].id, dispidno, IDLEN);
                  _ndscont.nds[_ndscont.num++].len = IDLEN;
          ndsflag = 1;
          break;
        }
          /* next rp */
        }
      if (ndsflag == 0) /* no more rp */
        {
          seterrno(RTFERR_IDFAIL);
          _rtparas.state &= ~STAMMASK;
          
          printf_s("\n****STAMONIT----CLEAR3----rt_disp_mntplc****\n");
          
          return -1;
        }
    }
    }

  memset(&_task.ml, 0x00, sizeof(struct monitinfo));
  _task.ml.opt.mt = mtp;  /* to use monit_update */

  unsigned char mnttkn = 0, nlframe[255];
  int nllen = 255;
  if (_task.cnt % 2 == 0)
    mnttkn |= PARAMNT;

  int ret = dispnl_monittask1(&_task.appd, cmd, mnttkn, sno, nlframe, &nllen); /*  tkn=0, asw=1 */
  assert(ret == 0);

  unsigned char rtframe[255];
  int rtlen = 255;
  nl_frm38(NLT_NORMAL, nlframe, nllen, rtframe, &rtlen, PLC_DC);
  nl_rtwrite(fd, rtframe, rtlen, 0);

  if (_task.minfo.state & STABMASK) /* broad */
    {
      app_res(NULL, 0); /* need to send confirm frame to dm */
      _rtparas.state &= ~STAMMASK; /* no task, no monit */
      
      printf_s("\n****STAMONIT----CLEAR4----rt_disp_mntplc****\n");
      
      return 0;
    }

  if(_task.cnt > 0) /* info frame: change another path */
    {
      unsigned char info = INFCHPATH;
      app_info(&info, sizeof(info));
    }

  ++_task.cnt;
  _task.flag = TSRUN | TTPLC;
  _rtparas.state &= ~STAMMASK;
  _rtparas.state |= STAMONIT;
    
  printf_s("\n****STAMONIT----ADD----rt_disp_mntplc****\n");

  _task.start = currtick();
  if(mtp == NULL || (mtp->node.succhops & NHMASK) == 0x00)
    _task.wait = MAXHOPTM + MAXHOPTM;
  else
    _task.wait = (mtp->node.succhops & NHMASK) * MAXHOPTM + MAXHOPTM; /* max wait time */
  return 0;
}
int get_node_reg_sta()
{
    if ((_rtparas.state & STARMASK) == STAREG)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
/******************7���м�*************************/
int s9_monittask()
{
  int (*taskp)();

  if ((_task.flag & TSMASK) == TSRUN)
    return 0;

  struct monitinfo *ml = &_task.ml;

  if ((ml->list[0].state & LSMASK) == LINIT) /* initalize */
  {
    memset(&ml->opt, 0x00, sizeof(ml->opt));            //�߼��м������޸�
    if((ml->list[0].state & LLMASK) == SNOLEN)
    {
      if ((ml->opt.mt = db_find_sno(ml->list[0].id)) == NULL)
        return -1;
    }
    else
    {
      if ((ml->opt.mt = db_find(ml->list[0].id)) == NULL)
        return -1;
    }

    ml->list[0].state &= ~LSMASK; /* clear meter state */
    ml->list[0].state |= (ml->opt.state & OPTNEXIST) ? LPLC : LREQ;
    _task.cnt = 0;
    ml->opt.reqcnt = 0;
    ml->opt.dlytm = 0;
    ml->list[0].state2 &= ~0x01;
    _task.flag &= ~(TSMASK | TTMASK);
    ++ml->opt.mt->node.envi; /*envi == fail cnt*/  //��ǰ����û����db_write�ĵ���
  }

  size_t pos = (ml->list[0].state & LSMASK) / LREQ - 1;
  if((ml->list[0].state2 & 0x01) != 0)
    pos = 0x03;       // dlytm process
  if ((_task.flag & TSMASK) == TSNO)
    taskp = s9proc[pos].task;
  else
  {
    int ret;
    ret = s9proc[pos].process(&ml->list[0]);
    if (ret == -8) /*plc2 asw = 1, ret = -8*/
    {
      _task.flag &= ~TSMASK;
      _task.flag |= TSRUN;
      return 0;
    }
    if (ret != 0)
      return -1;
    /* process may be change list[i].state */
    pos = (ml->list[0].state & LSMASK) / LREQ - 1;
    if((ml->list[0].state2 & 0x01) != 0)
      pos = 0x03;       // dlytm process
    taskp = s9proc[pos].task;
  }

  _task.flag &= ~(TSMASK | TTMASK);
  if (taskp() == 0)
    return 0;

  return -1;
}

int s9_ploughpath(struct mtinfo *mtptr)
{
  int find = 0;
  struct mtinfo *mt;

  if ((mtptr->node.succhops & NHMASK) != _rtparas.round &&
      (mtptr->node.sno[0] & NNEWMASK) == 0)
    return -1;

  memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
  _ndscont.nds[_ndscont.num++].len = SNOLEN;

  for(int i = 1; i < _rtparas.round; i++)
  {
    find = -1;
    db_trav_reset(CHAN_TMP);
    while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      for(int j = 0; j < _ndscont.num; j++)
      {
        if(memcmp(mt->node.id, _ndscont.nds[j].id, IDLEN) == 0)
          continue;
      }
      if ((mt->node.succhops & NHMASK) == i)
      {
        memcpy(_ndscont.nds[_ndscont.num].id, mt->node.id, IDLEN);
        _ndscont.nds[_ndscont.num++].len = IDLEN;
        find = 0;
        break;
      }
    }
    if(find == -1)
      return -1;
  }
  memcpy(_ndscont.nds[_ndscont.num].id, mtptr->node.id, IDLEN);
  _ndscont.nds[_ndscont.num++].len = IDLEN;

  return 0;
}

static int s9req2(struct mtlist *mtl)
{
  struct monitinfo *ml = &_task.ml;
  unsigned char type = _task.appd.protype & (APCMASK | APDMASK);

  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (type == 0 || type == (APCMASK | APDMASK))
        return 0;
      if (_task.appd.protype & APCMASK) /* application confirm */
    {
      if ((_rtparas.state & STABMASK) == STABROAD) /* broad receive confirm,next meter */
        return -1;
      if (ml->opt.reqcnt > 0)
        return -1;
      /* first request */
          set_testitem(ml->opt.mt);

          ml->opt.state |= OPTDEFAPP; /* cmd = 6 && default item */
    }

      if (_task.appd.protype & APDMASK)
    {
      if (((_rtparas.state & STABMASK) == STABROAD) && (nl_phasecmd(&_task.appd) == 0))
        ml->opt.state |= OPTPCHK;

          if ((_rtparas.state & STABMASK) != STABROAD && _task.appd.datalen <= sizeof(ml->opt.mt->item.data))
          {
            if(ml->opt.dlytm == 0)
              set_mtitem(ml->opt.mt);
#if 0
            ml->opt.mt->item.len  = _task.appd.datalen; /* save recently reading item of the meter */
            ml->opt.mt->item.type = _task.appd.protype;
            ml->opt.mt->item.wretlen = _task.appd.wretlen;
            memcpy(ml->opt.mt->item.data, _task.appd.data, _task.appd.datalen);
#endif
          }
    }

      ++ml->opt.reqcnt; /* only used in broad operation */
      _task.cnt = 0;
      mtl->state &= ~LSMASK;
      mtl->state |= LPLC;
      if(ml->opt.dlytm != 0)
        mtl->state2 |= 0x01;
      else
        mtl->state2 &= ~0x01;
    }
  else
  --gbmessage.gbmcnt; /*�ط����кŲ���*/
  return 0; /* if failure, continue request */
}

static int s9plc1()
{
  unsigned char flag = 0, msg[255], frame[255], sno[2], type = NLT_NORMAL;
  int len = sizeof(msg), ret = 0, framelen = sizeof(frame);;
  struct monitinfo *ml = &_task.ml;

  flag |= PARATKN; /* tkn = 1 */
  if (ml->opt.state & OPTNEXIST)
    flag |= PARANS; /* only read ,no set order */
  else
    memcpy(sno, ml->opt.mt->node.sno, SNOLEN);
  sno[0] &= ~NNEWMASK;
  if ((_task.cnt & 0x01) == 0)
    flag |= PARAMNT; /* mnt = 1 */
  if ((_rtparas.state & STABMASK) == STABROAD) /* asw = 0 */
    flag |= PARAASW;
  if (s9nl_monittask1(&_task.appd, flag, sno, msg, &len) != 0)
    ret = -1;

  if (ml->opt.state & OPTPCHK)
    type = NLT_ZERO;

  if (ret == 0)
    {
      nl_frm38(type, msg, len, frame, &framelen, PLC_DC);
      nl_rtwrite(fd, frame, framelen, 0);
      _task.flag |= TSRUN | TTPLC;
      _task.start = currtick();
      _task.wait = 5000 + (_rtparas.round - 1) * 1000; /* max wait time */
      _task.cnt++;
    }

  return ret;
}

static int s9plc2(struct mtlist *mtl)
{
  int  ret;
  struct rtinfo strglvl;
  struct monitinfo *ml = &_task.ml;

  if ((_task.flag & TSMASK) == TSFAIL)
    {
      if(ml->opt.mt->node.envi > 3) /* del rp*/
      {
        ml->opt.mt->node.succhops = 0;
        ml->opt.mt->node.sno[0] |= NNEWMASK;
        return -1;
      }

      if (_task.cnt > 0x00)
      {
        if (++ml->opt.failcnt >= FAILCNT)
          return -1;

        mtl->state &= ~LSMASK;
        mtl->state |= LREQ; /* continue request until confirm frame received */
        return 0;
      }
    }
  else /* task success*/
    {
      ml->opt.failcnt = 0;
      ret = nl_monitprocess(_commbuf.plc.buf, _commbuf.plc.len, &_task.appd, &strglvl);

      if(ret == -8) /*ret = -8 then continue wait timeout*/
        return -8;

      if (ret != 0)
        return -1;

      unsigned char errp[2] = {0xC0, 0x34};
      if(_task.appd.datalen == 0x02 && memcmp(_task.appd.data, errp, 2) == 0)
      {
        if(ml->opt.mt->node.envi > 3) /* del rp*/
        {
          ml->opt.mt->node.succhops = 0;
          ml->opt.mt->node.sno[0] |= NNEWMASK;
        }
        return -1; /* path error*/
      }

      ml->opt.mt->node.envi = 0; /*fail cnt clear*/  //��ǰ����û����db_write�ĵ���
      ml->opt.mt->node.sno[0] &= ~NNEWMASK;  //��ǰ����û����db_write�ĵ���
      ml->opt.mt->node.succhops &= ~NHMASK;  /* success flag */
      ml->opt.mt->node.succhops |= _ndscont.num - 1;  //��ǰ����û����db_write�ĵ���

      if((ml->opt.state & OPTCMD1) || (ml->opt.state & OPTDEFAPP))
        return -1;

      mtl->state &= ~LSMASK;
      mtl->state |= LRET;
      ml->opt.retcnt = 0;
    }

  return 0;
}

// -1 not all 43,0 all 43
int is_all_nds_43(void)
{
    int i;
    struct mtinfo *mt;
    unsigned char tsno[2] = { 0x7f, 0x00 };


    for (i = _ndscont.num-1; i > 0;  i--) //�ȴ�Ŀ�Ľڵ㿪ʼ��
    {
        if (_ndscont.nds[0].len == SNOLEN)
        {
            if (0 == memcmp(_ndscont.nds[i].id, tsno, SNOLEN)) //�㲥�Ļ������ѡ��ģʽ
            {
                return -2;;
            }
        }

        if (_ndscont.nds[i].len == IDLEN)
        {
            mt = db_find(_ndscont.nds[i].id);
        }
        else if (_ndscont.nds[i].len == SNOLEN)
        {
            mt = db_find_sno(_ndscont.nds[i].id);
        }
        else
        {
            return -1;
        }

        if (mt == NULL)                            //���ڵ����ڣ�ѡ��FSK
        {
            return -1;
        }

        if ((mt->node.phase & NPDTMASK) == NPDTUN)//Ŀ�Ľڵ�����δ֪�����ʹ�õ��Ʒ�ʽ
        {
            return -2;
        }
        if ((mt->node.phase & NPDTMASK) == NPDTN43) //Ŀ�Ľڵ����ͷ�1643��ѡ��Fsk
        {
            return -1;
        }

    }
#if 0
    if (_ndscont.nds[0].len == SNOLEN)
    {
        if (0 == memcmp(_ndscont.nds[i].id, tsno, SNOLEN))//��0���϶������ڵ�
        {
          //  continue;
        }
    }
#endif
    return 0;
}

void chk_to_set_dpsk_mode(unsigned int num43, unsigned int all)
{
    //printf_s("num43:%d, all:%d\n", num43, all);
    unsigned int rat;
    if(all ==0)
    {
      return ;
    }
    rat = (num43 * 100) / all;
    _rtparas.dpsk = 0x00; //clear force flag and so on
    if (num43 == all)
    {
        _rtparas.dpsk |= DPSKFORCE;

    }else if (rat >= THRESH_DPSK) //dev type 43 is greater than  THRESH_DPSK,then can use dpsk
    {
        _rtparas.dpsk |= DPSKRATIO;
    }
    else
    {
        _rtparas.dpsk = 0x00; //clear force flag and so on
    }
}

void rt_stop_mnt(void)
{
    if ((_rtparas.state & STAMMASK) == STAMONIT)
    {
        rt_mntclear();
    }
}
void rt_stop_brd(void)
{
    if ((_rtparas.state & STABMASK) == STABROAD)
    {
        _rtparas.state &= ~(STABMASK | STABMMASK);
        _rtparas.wkstate &= ~DISPBDMASK;
        memset(_task.ml.list, 0x00, sizeof(_task.ml.list));
    }
}
void clear_rtparas_para(void)
{
    _rtparas.dctask = 0;
    _rtparas.sndphs = 0;
    _rtparas.dcnum = 0;
}

#define RT_CTRL_ASWTCH   0x01
extern unsigned int flag_rt_set_mode_fixed_mode;
void rt_set_mode_fixed(int i)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(0 == i)
    {
        if(t & RT_CTRL_ASWTCH)
        {
            return;
        }

        t |= RT_CTRL_ASWTCH;
    }
    else
    {
        if(0 == (t & RT_CTRL_ASWTCH))
        {
            return;
        }

        t &= ~RT_CTRL_ASWTCH;
    }

    eep_set(e2rom_addr(rt_ctrl), t, 1);
    
    flag_rt_set_mode_fixed_mode++;
}

int is_rt_mode_fixed(void)
{
    unsigned char t;

    t = eep_get(e2rom_addr(rt_ctrl));

    if(t & RT_CTRL_ASWTCH)
    {
        return(-1);
    }
    else
    {
        return(0);
    }
}

//���㷺��ȴ���ʱ
int calc_fh_left_time(unsigned char buf[], unsigned char buflen)
{
  int hpd, maxhpd;
  int time;
  struct info_frame_iv_up info;

  hpd = buf[2] & 0x0f;
  maxhpd = buf[3] & 0x0f;

  if(maxhpd == hpd)
  {
    return(0);
  }
  buflen = buflen + ((3 * buflen) / 61);
  time = ((buflen + 15) * 25) + 200;

  //��1����������������ͬԭ��38����ͬ
  if(maxhpd == (hpd + 1))
  {
    return(time);
  }

  return(2 * time);
}
#if 1  //43ע����غ���
void init_taskmanager_info(void)
{
  lastTno6Sno = 0;
  memset(&tno6TaskLft[0], 0x00, sizeof(tno6TaskLft));
  memset(&tno6TaskType[0], 0x00, sizeof(tno6TaskType));
}

/********************************************************************************************************
*  ��ȡ���г������������
*   Input: taskMinutes --����������Ҫִ�е�ʱ��(����)
*  Return:    0 --û�п�ʹ�õ������
*          1~15 --���õ������
********************************************************************************************************/
unsigned char getNewTno6Sno(unsigned int taskMinutes, enum ParallelTaskType ptt)
{
  unsigned char i, j;
  //���ϴ������֮��ʼ���ҿ��������,��ֹ���˼�ʱ��������������ʧ��
  j = lastTno6Sno;

  for(i = 0; i < TNO6_MAX_TASK_NUMBER; i++)
  {
      j++;
      if(j > TNO6_MAX_TASK_NUMBER)
          j = j - TNO6_MAX_TASK_NUMBER;
      if(tno6TaskLft[j - 1] == 0)
      {
          //���10���ӵ�ʱ�䣬���ڱ���ʱ���ʱ��������
          tno6TaskLft[j - 1] = (taskMinutes > MAX_PARALLEL_MINUTES ? MAX_PARALLEL_MINUTES : taskMinutes) + 10;
          lastTno6Sno = j;
          tno6TaskType[j - 1] = ptt;
          return j;
      }
  }
  return 0;
}

/********************************************************************************************************
*  1���Ӽ�ʱʱ�䵽��������ִ�еĲ��������ʣ��ʱ���1,������δ�յ����б��ĵ�ʱ��
********************************************************************************************************/
void Tno6TaskTimer()
{
    int i;

    for(i = 0; i < TNO6_MAX_TASK_NUMBER; i++)
    {
        if(tno6TaskLft[i] > 0)
        {
            tno6TaskLft[i]--;
        }
    }
}

int getTno6TaskType(int sno)
{
    if(sno<1 || sno > 15) return 0;
    if(tno6TaskLft[sno - 1] > 0)
    {
        return tno6TaskType[sno - 1];
    }
   return 0;

}

#endif

#ifdef UPDATE_STA
int rt_mntplc_update_iv(unsigned char *aid, unsigned char *frm, unsigned char len)
{
    unsigned char nlframe[255], info[2] = {0x0, 0x0}, depth = 7;
    int l = 0, pos = 0;
    unsigned char said[IDLEN], aid_hash[IDLEN];
    unsigned char dst_addr[IDLEN] = {0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x7F};
    struct mtinfo *mtp;
    
    memcpy(said, aid, IDLEN);
    memcpy(aid_hash, aid, IDLEN);
    aid_645_tohash(aid_hash);  //����ֱ�Ӵ�aid���޸�����

    if (memcmp(dst_addr, said, sizeof(said)))
    {
      reverse(said, IDLEN);
      id_bcdtobin(said);
    }

    if (((mtp = hash_find(aid_hash)) != NULL) || ((mtp = hash_find(aid)) != NULL))  /* ��ַ�п�����ת����Ҳ������û��ת���� */
      depth = mtp->node.succhops & 0x1F;  /* bit4~bit0: hops */
    else
	  {
	    if (0 == memcmp(dst_addr, said, sizeof(said)))
		    {
			    if (upd_get_hops(PRO_55_3, 0))
			      depth = upd_get_hops(PRO_55_3, 0x1);
			    else
			      depth = 7;
			  }
	  }

    if (depth == 0)
      depth = 7;
    
    int nllen = nl_floodtask_update(nlframe, said, frm, depth, len);
    unsigned char rtframe[255];
    int rtlen = 255;
    nl_frm38(NLT_PARL, nlframe, nllen, rtframe, &rtlen, PLC_UPDATE);

    l = nl_fill_frm(CTL_43_CMD, info, rtframe, rtlen);
    
    tp_chn_buf_write(CHN_38_1, rtframe, l, 5000, 1);
   
}

int rt_mntplc_update_v(unsigned char *aid, unsigned char *frm, unsigned char len)
{
  //�����·�����  nl_p2p();
}

#endif

int get_data_item(struct mtinfo *mt, unsigned char *buf)
{
    int datalen = 0;
    unsigned char pro = 0;
    unsigned char data[255];
    memset(data, 0x00, sizeof(data));

    if (mt->item.len != 0 && mt->item.len <= sizeof(mt->item.data))
    {
        /* _task.appd.protype = mt->item.len == 0x03 ? 0x00 : 0x01; */ /* 97 (645) */
       pro = mt->item.type;
       datalen = mt->item.len;
       memcpy(data, mt->item.data, mt->item.len);
    }
    else if (get_apptype() == (unsigned char)PRTCL_RT)
    {
        pro = 0x00; /* 97 (645) */
        datalen = sizeof(_testdata);
        memcpy(data, _testdata, sizeof(_testdata));
    }
    else
    {
        pro = 0x01; /* 07 (645) */
        datalen = sizeof(_testgb);
        memcpy(data, _testgb, sizeof(_testgb));
    }
    for (int i = 1; i < datalen; i++)
    {
        data[i] -= 0x33;

    }

    if (datalen < 1 || datalen > 255)
    {
      return 0;
    }

    return appgb_build_645cmd(mt->node.id, data[0], data + 1, datalen - 1, buf);

}

int set_dcv_to_dciv()
{
    int start = -1;
    unsigned char buf[255];
    unsigned char pro = 0x02;
    int len = 0;
    id_bcdtobin(_task.minfo.id); 
    reverse(_task.minfo.id, IDLEN); 
    if ((start = get_645_frame(_task.appd.data, _task.appd.datalen)) >= 0)
    {
      buf[0] = _task.appd.data[8 + start];
      len = _task.appd.data[8 + start + 1] + 1;

      for (int i = 1; i < len; ++i)
         buf[i] =  _task.appd.data[8 + start + 1 + i] - 0x33;

      setappd(pro, buf, len, 0);
      refresh_task_appid();
    }
    else
    {

      refresh_task_appid();
    }


    if ((_task.appd.data[0] == 0x9e) && ((_task.appd.protype & PTMASK) == 0x03))
    {
      int len_trans = 0, elen = 0; 
      unsigned short crc1;

      len_trans = _task.appd.datalen;
      
      crc1 = _task.appd.data[len_trans - 1] * 256 + _task.appd.data[len_trans - 2];

      if ((elen = check_9e(&_task.appd.data[0], _task.appd.datalen, crc1)) == -1)
      {
        return 0;
      }
      else
      {
        /* ������� -2��֮��ֱ���ϱ� */
        pro = 0;

        _task.appd.protype = pro;
        _task.appd.datalen -= 2;  //У����˽�len���ȼ�2ֻ��header��payload
        memmove(_task.appd.data, &_task.appd.data[11 + elen], _task.appd.datalen - 11 - elen);
        _task.appd.datalen = _task.appd.datalen - 11 - elen;
      }
    }


      memset(&_ndscont, 0x00, sizeof(struct ndscont));

      memcpy(_ndscont.nds[_ndscont.num].id, sinksno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;
      memcpy(_ndscont.nds[_ndscont.num].id, _task.minfo.id, IDLEN);
      _ndscont.nds[_ndscont.num++].len = IDLEN;
      return 0;
    }

int check_9e(unsigned char *data, unsigned short len, unsigned short crc)
{
  unsigned short crc1 = 0;
  crc1 = crc16_soft(data, len - 2);
  if (crc != crc1)
    return -1;

  /* �ѱ�����ȥ����չ�Ŀ����� */
  unsigned char elen = 0;
  if ((data[1] & 0x01) == 1)  /* 0-bit?0-����û����չ������?1-���������չ������ */
    {
      elen = data[2];  /* ELEN?EXTC���ܳ���?����ELEN?,1�ֽ� */
      return elen;//memmove(&data[2], &data[2 + elen], len - elen);
    }
  
  return 0;
}

