/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: stage4.c
 *
 * Description: Route study stage4
 *
 * Version: v1.0
 * Time:    2010-1-14
 *
 */

#include <time.h>
#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/rt/rt.h"
#include "../include/rt/rtfuns.h"
extern int fd;

static void s4_task(struct stage4 *s4p);
static int s4_initround();

extern unsigned char local_viv_swi;
void stage4()
{
  struct stage4 *s4p = (struct stage4 *) _task.info;

  if ((s4p->info & S4TMASK) == S4TINIT) /* Initalize */
    {
      //printf_s("stage 4: S4TINIT!\n");
      s4_initround();

      db_trav_reset(CHAN_RT1);
      db_trav_reset(CHAN_RT2);
      memset(&_task, 0x00, sizeof(_task));

      s4p->info &= ~S4TMASK;
      s4p->info |= S4TLIST;
    }

  if ((s4p->info & S4MMASK) == S4MONIT) /* monit */
    {
      //printf_s("stage 4: S4MONIT!\n");
      if (monittask() == 0)
    return;
      s4p->info &= ~S4MMASK;
      _task.flag = TSNO;
    }
  //printf_s("stage 4: S4TASK!\n");
  s4_task(s4p); /* list */
}

static int s4_initround()
{
  size_t minround = MAXHOPS;
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if ((mt->node.succhops & NSMASK) != NSUCC && (mt->node.succhops & NHMASK) < minround) /* unsuccess meter */
        minround = mt->node.succhops & NHMASK;
    }

  /* defalult: _rtparas.round = 1 */
  if (_rtparas.maxround > 9)
    {
      if (minround > 3)
    _rtparas.round = minround - 3;
    }
  else
    {
      if (minround > 2)
    _rtparas.round = minround - 2;
    }

  return 0;
}

static int s4_listtask1(struct stage4 *s4p)  /* plough nds */
{
  if (s4p->listmt == NULL)
    {
      if ((s4p->listmt = db_trav_mtnext(CHAN_RT2)) == NULL)
    {
      db_trav_reset(CHAN_RT2);
      s4p->famt = NULL;
    }
    }

  for (; ;)
    {
      if (s4p->famt == NULL) /* next mt */
    {
      if ((s4p->famt = db_trav_mtnext(CHAN_RT1)) == NULL)
        break;
      db_trav_reset(CHAN_RT2);
          s4p->listmt = NULL;
    }
      if ((s4p->famt->node.succhops & NSMASK) != NSUCC  /* success meter */
          || (s4p->famt->node.succhops & NHMASK) != _rtparas.round
          || (local_viv_swi != 1 && (s4p->famt->node.viv & NNDMASK) == NND53)
          || (((s4p->famt->node.viv & TYPEMASK) >> 3) == TYPEGDNODE)) /* depth not match with round */
    {
      s4p->famt = NULL;
      continue;
    }

      saveposition(s4p->famt);

      /* plough nds */
      struct rpinfo *rp;
      memset(&_ndscont, 0x00, sizeof(_ndscont));
      if ((rp = db_getfrp(s4p->famt)) && (ploughpath(rp) == 0x00))
    {
      ndsrevers(&_ndscont);
          memcpy(_ndscont.nds[_ndscont.num].id, s4p->famt->node.sno, SNOLEN);
      _ndscont.nds[_ndscont.num++].len = SNOLEN;

      return 0;
    }
      s4p->famt = NULL;  /* next meter */
      watchdog();
    }

  return -1;
}

static int s4_selmt(struct mtinfo *mtp) /* random select function */
{
  unsigned char slevel = 0x01;

  if (mtp == NULL)
    return -1;

  if((mtp->node.sno[0] & NNEWMASK) && (mtp->node.succhops & NFSUC))
    return -1;

  if((mtp->node.sno[0] & NNEWMASK) && (mtp->node.envi & NTSMASK) == NTANSUC)
    return -1;

  if (_rtparas.mtnum - _rtparas.succnum <= MINRANDOM || _rtparas.mtnum <= 16) /* unsuccess number < minrandom, select directly */
    return 0;
  if ((mtp->node.succhops & NHMASK) < _rtparas.round + 3  /* depth < round + 3 */
      || (mtp->node.succhops & NHMASK) == 0) /* new meter */
    {
      unsigned char threshold = slevel * 8;
      if(_rtparas.mtnum - _rtparas.succnum <= 255) /* adjust threshold */
    {
      int unrate = _rtparas.mtnum / (_rtparas.mtnum - _rtparas.succnum);

      if (unrate > 25) /* select directly */
        return 0;
      if (unrate > 0)
        {
          if (threshold + (unrate - 1) * 5 > 255)
        threshold = 255;
          else
        threshold += (unrate - 1) * 5;
        }
    }
      if (threshold > gainrand()) /* selected */
    return 0;
    }

  return -1; /* unselected */
}

static int s4_addlist(struct stage4 *s4p)
{
  if (s4p->listmt == NULL)
    return -1;
  if ((s4p->listmt->node.succhops & NSMASK) == NSUCC) /* success, ignore */
    return -1;
  if (s4_selmt(s4p->listmt) != 0) /* not selected */
    return -1;

  memcpy(_task.ml.list[_task.ml.num].sno, s4p->listmt->node.sno, SNOLEN);
#if 0
  if ((_rtparas.state & STASMASK) == STAALLSNO) /* all sno */
    mlist_add(s4p->listmt->node.sno, SNOLEN);
  else
#endif
    mlist_add(s4p->listmt->node.id, IDLEN);

  return 0;
}

static int s4_listtask2(struct stage4 *s4p)
{
  unsigned char frame[255], temp[255];
  int framelen = 255, templen = 255;
  unsigned char maxnum = list_maxnode(S4);
  struct monitinfo *mlp = &_task.ml;

  mlist_clear();
  s4_addlist(s4p);

  for (; ;)
    {
      if ((s4p->listmt = db_trav_mtnext(CHAN_RT2)) != NULL) /* no meter */
    {
          if (s4_addlist(s4p) != 0)
            continue;
          framelen = 255;
      int ret = nl_listtask2(_rtparas.round + 1, mlp->list, &mlp->num, frame, &framelen, TASK2_JUDGE);
      assert(ret == 0);
      if (mlp->num >= maxnum && framelen <= 62) /* reach maxnum */
        {
          s4p->listmt = NULL;
          break;
        }
      else if (framelen > 62) /* overflow, back to the last state */
        {
          --_task.ml.num;
          break;
        }
      else if(mlp->num >= 32)
        {
          s4p->listmt = NULL;
          break;
        }
      continue; /* continue, add next */
    }

      break;
    }

  if (mlp->num > 0) /* send */
    {
      framelen = 255;
      int ret = nl_listtask2(_rtparas.round + 1, mlp->list, &mlp->num, frame, &framelen, TASK2_REAL);
      assert(ret == 0);
      ret = is_mlist_all43(mlp->list, mlp->num);
      chek_list_set_modu(ret);
      nl_frm38(NLT_NORMAL, frame, framelen, temp, &templen, PLC_DC);

      if (nl_rtwrite(fd, temp, templen, 0) != 0)
    {
      _task.flag &= ~TSMASK;
      _task.flag |= TSNO;
      return -1;
    }

      s4p->info &= ~S4MONIT; /* make sure not monit */
      _task.flag &= ~(TSMASK | TTMASK);
      _task.flag |= TSRUN | TTPLC;
      _task.start = currtick();

      size_t n = mlp->num / 2 & MAXHOPS;
      _task.wait = ((n == 0 ? 1 : n) + _rtparas.round) * (MAXHOPTM / 2);
#ifdef _DEBUG
      printf("stage4 list \n"); /* for test !! */
#endif
      return 0;
    }
  return -1;
}

static int s4_listprocess(struct stage4 *s4p)
{
  if ((_task.flag & TSMASK) == TSSUCC)
    {
      if (nl_listprocess(_task.ml.num, _commbuf.plc.buf, (_commbuf.plc.buf[0] & 0x3F) + 1,
             _task.ml.list) != 0)
        return -1;
      if (touchnum() == 0)
        return 0;

      touchmt(s4p->famt); /* append rp */

      s4p->info &= ~S4MMASK;
      s4p->info |= S4MONIT;
      _task.cnt = 0;
#ifdef _DEBUG
      printf("stage4 M\n"); /* for test !!*/
#endif
      return 0;
    }

  return -1;
}

static void s4_task(struct stage4 *s4p)
{
  if ((_task.flag & TSMASK) == TSRUN)
    return;
  if ((_task.flag & TSMASK) == TSNO)
    {
      if (s4_listtask1(s4p) == 0) /* plough nds */
        s4_listtask2(s4p); /* list task */
      else
        rtnext();

      return;
    }
  s4_listprocess(s4p); /* task succ, process */
  _task.flag &= ~(TSMASK | TTMASK);
  _task.flag |= TSNO;
}
