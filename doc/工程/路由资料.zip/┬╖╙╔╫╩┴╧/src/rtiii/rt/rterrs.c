/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rterrs.c
 *
 * Description: Error code function
 *
 * Version: v1.0
 * Time:    2010-2-2
 *
 */

static int rtf_error = 0;

int rf_seterr(int errno)
{
  rtf_error = errno;
  
  return 0;
}

int rf_geterr()
{
  return rtf_error;
}
