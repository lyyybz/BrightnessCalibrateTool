/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved
 *
 * File name: rt.c
 *
 * Description: Router funcation interface and inner route strategy
 *
 * Version: v1.0
 * Time:    2009-12-21
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/uart.h"
#include "../include/dev/eeprom.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/plcnl.h"
#include "../include/rt/rtast.h"
#include "../include/rt/rt.h"
#include "../include/rt/broad.h"
#include "../include/app/app.h"
#include "../include/app/appgb.h"

struct commbuf _commbuf; /* global parameter */
struct ndscont _ndscont; /* global parameter */
struct rtpara _rtparas;  /* global parameter */
struct share _share;     /* global parameter */
struct task _task; /* global parameter */
struct ntask _ntask;
struct appdata_bk _appdata_bk;

unsigned char _nl_type = 0;/* global parameter bit 0  1 iii-e   0 iii
                            bit 1-bit2   list type mask,0,unkown  1 not 43,2 is 43*/
                           /*  bit3 list valid flag,1 valid ,0 invalid*/
unsigned char _last_sndtype = 0;/*0 is fsk ,1 is dpsk*/
int fd; /* for test in linux pc */

enum
  {
    CHAN_DM  = 0x00,
    CHAN_PLC = 0x01,
  };

enum
  {
    PRTCL_RT = 0x01,
  };

static struct
{
  int    times;
  size_t start;
  size_t oncetm; /* ms */
  int    dlen;
  unsigned char data[10];
  int (*fun)(unsigned char *, int);

} report[] = {{0, 0, 6000, 1, {INFIDLE}, app_info},  /* idle */
    {0, 0, 10000, 1, {ERRNODIR}, app_err}, /* no effect direct */
    {0, 0, 6000, 0, {0}, NULL},            /* relax */
    {0, 0, 10000, 0, {0}, NULL}};          /* monitor resume time ��30s�ĳ�10s */

static void scanbuf();
static void scanparas();
static int  scanreport();
static void again();
static void empbuf(int chan, int len);
 void rt_first();

void rt_sendmode()
{
    nw_report_rt_info();
}

void rt_exgetid()
{
  unsigned char frame[] = {0x68,0x0F,0x00,0xC7,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x02,0x00,0xCB,0x16};

  if (_rtparas.apptype != PRTCL_RT)
    nl_rtwrite(CHN_DM, frame, sizeof(frame), 0);
}

extern unsigned int flag_rt_init_eeprom;
void rt_init()
{
//    int rf_set_newgb(unsigned char newgb);
    unsigned char state;
    unsigned char inval_add[]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
#ifdef _LINUXPC
    fd = uart_open(1, 9600, 8, 1, 'n');
#else
    fd = CHN_38_1;
    set_rts_value(fd, 1);
    port_reinit();
    init_update_info();
    
    extern unsigned char plc_new;
    plc_new = 1;  /* ֻ֧���µ�38Э�� */

    int chns[] = { CHN_38_1, CHN_38_2, CHN_38_3 };

    for (int i = 0; i < sizeof(chns) / sizeof(chns[0]); ++i) config_uart_info(chns[i], 115200, 8, PARITY_EVEN);

    uart_init_for_38_3(0, 115200);
#endif

    memset(&_commbuf, 0x00, sizeof(_commbuf));
    memset(&_ndscont, 0x00, sizeof(_ndscont));
    memset(&_rtparas, 0x00, sizeof(_rtparas));
    memset(&_task, 0x00, sizeof(_task));
    memset(&_share, 0x00, sizeof(_share));

    eeprom_read(DBSHARE, (unsigned char *)&_share, sizeof(_share));
    if (_share.version != NEW_GBPRO)
    {
        _share.version = NEW_GBPRO;
        eeprom_write(DBSHARE + offset(struct share, version), &_share.version, 1);
      
      flag_rt_init_eeprom++;
      
    }

    if (db_init() == -1)
        rt_first();

    _rtparas.runmd = _share.wkmd;
    /* read parameter from eeprom */
    eeprom_read(DBPBEGIN, (unsigned char *)&_rtparas, offset(struct rtpara, eepend));


    if (memcmp(_rtparas.jzqid_nw, inval_add, sizeof(_rtparas.jzqid_nw)) == 0)
    {
        memcpy(_rtparas.jzqid_nw, _share.jzqid, sizeof(_rtparas.jzqid_nw));
        eeprom_write(DBPBEGIN + offset(struct rtpara, jzqid_nw), _rtparas.jzqid_nw, sizeof(_rtparas.jzqid_nw));
      
      flag_rt_init_eeprom++;
    }
    if (memcmp(_rtparas.jzqid, inval_add, sizeof(_rtparas.jzqid)) == 0)
    {
        memcpy(_rtparas.jzqid, _share.jzqid, sizeof(_rtparas.jzqid));
        eeprom_write(DBPBEGIN + offset(struct rtpara, jzqid), _rtparas.jzqid_nw, sizeof(_rtparas.jzqid));
      
      flag_rt_init_eeprom++;
    }



    db_build();
    init_nw_task_info(); //��ʼ���������������Ϣ
#if 0
    /* switch to mode IV */
    extern unsigned char plc_new;
    state = _share.mode_state;
    if (state == RTSTA_BKING)
    {
        setmode_iv();
        reset_to_main();
    }
#endif
    if (_rtparas.brdclose != 1)
    {
        _rtparas.brdclose = 1;
        eeprom_write(DBPBEGIN + offset(struct rtpara, brdclose), &_rtparas.brdclose, sizeof(_rtparas.brdclose));
      
      flag_rt_init_eeprom++;
    }

    if (_rtparas.slevel & 0x80&&(_rtparas.slevel!=0xFF)) /* auto run */
    {
        _rtparas.slevel &= ~0x80;
        eeprom_write(DBPBEGIN + offset(struct rtpara, slevel), &_rtparas.slevel, sizeof(_rtparas.slevel));
      
      flag_rt_init_eeprom++;
      
        _rtparas.state &= ~STASTMASK;
        _rtparas.state |= STARUN;
        printf_s("\n****STARUN----ADD----rt_init****\n");
    }
    if (is_rt_mode_fixed() < 0) //δ����
    {
        rt_set_mode_fixed(1);
    }

    _rtparas.wrktms = 1;
    _rtparas.round  = 1;
    _rtparas.cycle  = 0;
    _rtparas.wrkmd  = MODENOR; /* default work mode */
    memset(_rtparas.curid, 0x00, IDLEN);
    _report645.type = 0x00;
    _rtparas.extime = 0;
    _rtparas.exstate = 0;
    _rtparas.flood = 0;
    memset(&gbmessage, 0x00, sizeof(gbmessage));
    gbmessage.gblast = 0xFF;
    _rtparas.wkstate |= RPTSWION;

    _rtparas.apptype = 0x02; //����ֱ������Ϊ����ģʽ��
    _share.version = NEW_GBPRO;
    scanparas(); /* scan run parameters */

    int ret = rt_newdb();
    _rtparas.dpsk = 0x00;
    if (ret == 1)
    {
        _rtparas.dpsk |= DPSKFORCE;
    }
    if ((_share.conswitch & 0x01) == 0 && (_share.flswitch & 0x01) == 1)
    {
        _rtparas.dpsk &= ~DPSKFORCE;
    }
    _rtparas.dbfirst = 1; //only when first or para init is reset to 0
    _rtparas.floodtick = FLOODSAVE;
    _rtparas.sndphs = 0;

#if 0
    _rtparas.sndphstick = 15*60;//�տ�ʼ��15����
#endif

    _rtparas.dctask = 0;
    _rtparas.dcmin = 0;
    _rtparas.dcnum = 0;
    _rtparas.cyctime = 0;
    
    /* ��Ҫ�ϵ��һ��ֵ���¼ӵ� */
    appgd_init();
    
}

unsigned char flag_reg_v = 0;
void rt_autorun()
{
    _commbuf.flag = 0x00;
    channel38 = 0;

    scanbuf();

    /* 1. scan communication buffer of dm */

    if ((_commbuf.flag & CBAPD) != 0)
    {
        int pos;
        if ((pos = app_decode(_commbuf.dm.buf, _commbuf.dm.len)) > 0)
        {
            empbuf(CHAN_DM, pos);
            report[REPOIDLE].start = 0x00;
        }
        if (_commbuf.dm.mode == 0)
            _commbuf.flag &= ~CBAPD;

        _commbuf.dm.mode = 0;
    }

    /* 2. scan communication buffer of plc */

    if ((_commbuf.flag & CBPLC) != 0)
    {
        if (_commbuf.plc.mode == PLCSKID || _commbuf.plc.mode == PLCACTIVE)
        {
            _commbuf.flag &= ~CBPLC;
            _commbuf.plc.mode = 0;
        }
        if (((_rtparas.state & STARMASK) != STAREG) && (_commbuf.plc.mode == PLCCFM))
        {
            _commbuf.flag &= ~CBPLC;
            _commbuf.plc.mode = 0;
        }
    }

    if ((_task.flag & TSMASK) == TSNO && (_rtparas.state & STARMASK) != STAREG)
    {
        if (_rtreport.len > 0)
            _rtparas.state |= STARPT;
        else
            set_rts_value(CHN_38_1, 0);
    }

    if ((_task.flag & TSMASK) == TSRUN) /* if nlerr == 1, do not need to reset task */
    {
        if (((_task.flag & TTMASK) == TTPLC && (_commbuf.flag & CBPLCMASK) == CBPLC)
            && (_commbuf.plc.mode == PLCERR))
        {
            _task.flag &= ~TSMASK;
            _task.flag |= TSFAIL;
        }
        else
        {
            if (((_task.flag & TTMASK) == TTPLC && (_commbuf.flag & CBPLCMASK) != CBPLC) ||
                ((_task.flag & TTMASK) == TTAPD && (_commbuf.flag & CBDMMASK) != CBAPD))
            {
                if (currtick() - _task.start >= _task.wait)
                {
                    printf_s("^^^^^^^^^^^^^^^TSFAIL^^^^^^^^^^^^^^^\n"); 
                    _task.flag &= ~TSMASK;
                    _task.flag |= TSFAIL;
                }
            }

            if (((_task.flag & TTMASK) == TTPLC && (_commbuf.flag & CBPLCMASK) == CBPLC) ||
                ((_task.flag & TTMASK) == TTAPD && (_commbuf.flag & CBDMMASK) == CBAPD))
            {
                printf_s("^^^^^^^^^^^^^^^TSSUCCC^^^^^^^^^^^^^^^\n");
                _task.flag &= ~TSMASK;
                _task.flag |= TSSUCC;
            }
        }
    }

    /* if protype is RT then request pwd and wmode first */

    if (_rtparas.apptype == PRTCL_RT && app_pwd() == -1)
    {
        req_pwdwmode();
        return;
    }
#if 1 
    if (rt_sink38mode() == -1)
    {
        rt_setsink38();
        return;
    }
#endif
    if (get_upgrd_state() == UPGRD_UPDATING)  /*����������������������*/
    {
        return;
    }

    /* current task is auto register */
    extern unsigned char appgb_reg_v;

    if ((_rtparas.state & STARMASK) == STAREG)
    {
        if (appgb_reg_v == 1)
          {
            if (flag_reg_v == 0)
              {
                flag_reg_v = 1;  /* һ��ע��ֻ��һ�� */
                nl_start_net();  /* ����V����ע�� */
              }
              
            return;
          }
          
        flag_reg_v = 0;
        rt_autoreg();
        scanparas();
        return;
    }
    scanparas(); /* scan run parameters */
    nw_deal_high_task(); //���������ȼ�����ɨ��

      
    /* current task is monitor */

    if ((_rtparas.state & STAMMASK) == STAMONIT)
    {
        if (_task.minfo.state & ST38MASK)
            rt_appmnt_38();
        else
            rt_appmnt();
        return;
    }

    /* current task is broad */

    extern unsigned char flag_broad_v;
    extern unsigned char local_viv_swi;
    static unsigned char flag_v_bro = 0;
    extern struct gbbrd_info_v brdinfo_v;
    if ((_rtparas.state & STABMASK) == STABROAD)
    {
        if ((0 == _rtparas.flood) || (_rtparas.apptype == PRTCL_RT) || ((_rtparas.wkstate & DISPBDMASK) == DISPBROAD))
          {
            if (flag_broad_v == 1 && (local_viv_swi != 1))
              {
                if (flag_v_bro == 0)
                  {
                    flag_v_bro = 1;
                    nl_broad(0, brdinfo_v.appdata, brdinfo_v.len);/* ����V���㲥���� */
                  }
              }
            else
              {
                flag_v_bro = 0;
                broad();
              }
          }

        return;
    }
   // scan_suc_mt_monitor();

    //scanparas(); /* scan run parameters */

    /* active report task */

    if ((_rtparas.state & STAPMASK) == STARPT)
    {
        if (report_up(&_rtreport.report) < 0)
            _rtparas.state &= ~STAPMASK;
        return;
    }

    if (_rtparas.runmd == 2 && _rtparas.exstate == 1)
    {
        rt_exgetid();
        return;
    }

    if ((_rtparas.state & STARUN) == 0x00)
        report[REPOIDLE].times = 20;
    else
        report[REPOIDLE].times = 0;

    if (scanreport() != 0) /* scan report info task */
    {
        if (report[REPORESUME].times != 0)
            return;
        _rtparas.stage = S5;
        if ((report[REPOIDLE].times != 0) || (report[REPORELAX].times != 0))
            _rtparas.wrkmd |= RUNMDRPT; /* same as stage breakpoint */
    }

    if (_rtparas.srelay == 0x01)
    {
        if ((_rtparas.state & STASTMASK) != STARUN)
            return;
        stage9(); /* hlj 7 relay */
        return;
    }

    switch (_rtparas.stage)
    {
    case S0:
        stage0(); /* stage0 */
        break;

    case S1:
        stage1(); /* stage1 */
        break;

    case S2:
        stage2(); /* stage2 */
        break;

    case S3:
        stage3(); /* stage3 */
        break;

    case S4:
        stage4(); /* stage4 */
        break;

    case S5:
        stage5(); /* stage5 */
        break;
#if 0
    case S6:
        stage6(); /* stage6 */
        break;

    case S7:
        stage7(); /* stage7 */
        break;

    case S8:
        stage8(); /* stage8 */
        break;
#endif
    default:
        again();
        break;
    }
    //nw_deal_task();
}

void rt_report(int chan, int times)
{
  report[chan].times = times;
  report[chan].start = 0;
}

static void scanbuf()
{
#ifdef _LINUXPC

  static size_t pos = 0;
  static clock_t oldclk = 0;

  size_t n = 0;
  if (pos != 0)
    n = uart_read(fd, _commbuf.plc.buf + pos, BUFLEN - pos);
  else
    n = uart_read(fd, _commbuf.plc.buf, BUFLEN);

  if (n == 0)
    {
      if (pos != 0 && (clock() - oldclk) / CLOCKS_PER_SEC * 2 >= 1)
  {
    pos = 0;
    _commbuf.flag |= 0x80;
  }
    }
  else
    pos += n;

  oldclk = clock();

#else

  _commbuf.dm.len = sys_uart_peek_data(CHN_DM, _commbuf.dm.buf, sizeof(_commbuf.dm.buf));
  if (_commbuf.dm.len > 0)
    _commbuf.flag |= CBAPD;

  unsigned char tmp[255];
  int chns[] = {CHN_38_1, CHN_38_2, CHN_38_3}, pos;
  for(int i = 0; i < sizeof(chns)/sizeof(chns[0]); ++i)
    {
      _commbuf.plc.len = sys_uart_peek_data(chns[i], _commbuf.plc.buf, 0xff);
      if (_commbuf.plc.len > 0 && (pos = plc_decode(_commbuf.plc.buf, _commbuf.plc.len, chns[i])) > 0)
  {
          if (_commbuf.plc.mode == PLCEMP)
            {
              sys_uart_read(chns[i], tmp, pos);
              _commbuf.plc.mode = 0;
              continue;
            }
          if (i != 0 &&_commbuf.plc.mode == PLCERR)
            {
              sys_uart_read(chns[i], tmp, pos);
              _commbuf.plc.mode = 0;
              continue;
            }
          else
          {
      _commbuf.flag |= CBPLC;
            empbuf(CHAN_PLC, pos);
      break;
          }
  }
    }
  channel38 = 0;

#endif
}

static void empbuf(int chan, int len)
{
#ifndef _LINUXPC
  unsigned char tmp[0x200];

  if (chan == CHAN_PLC)
    {
      sys_uart_read(CHN_38_1, tmp, len);
      sys_uart_read(CHN_38_2, tmp, len);
      sys_uart_read(CHN_38_3, tmp, len);
    }
  if (chan == CHAN_DM)
    sys_uart_read(CHN_DM, tmp, len);
#endif
}

static void scanparas()
{
  /* scan hash table, get maxround, success/unsuccess amount, rate of seting sno...... */

    size_t mtnum = 0, succnum = 0, setsno = 1,cmd1num = 0,num43 = 0,maxfhround =0;
  size_t minround = MAXHOPS, maxround = 0;
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if ((mt->node.succhops & NSMASK) == NSUCC)
  ++succnum;
      if ((mt->node.envi & NCMD1MASK) == NCMD1SUC)
  ++cmd1num;
      if ((mt->node.phase & NPDTMASK) == NPDT43)
  ++num43;
      if ((mt->node.succhops & NFSUC) && (mt->node.envi & NFHMASK) > maxfhround)
  maxfhround = mt->node.envi & NFHMASK;
      if ((mt->node.succhops & NHMASK) > maxround)
  maxround = mt->node.succhops & NHMASK;
      if ((mt->node.succhops & NHMASK) < minround)
  minround = mt->node.succhops & NHMASK;
      if (mt->node.sno[0] & NNEWMASK)
  setsno = 0;
      
      if (mt->trycnt >= 10)
        {
          mt->trycnt = 0;
          mt->dc_v = 0;
        }

      ++mtnum;
    }

  _rtparas.maxround = maxround;
  _rtparas.minround = minround;
  _rtparas.mtnum    = mtnum;
  _rtparas.succnum  = succnum;
  _rtparas.cmd1num  = cmd1num;
  _rtparas.dev43num = num43;
  _rtparas.maxfhround = maxfhround;

  _rtparas.state   &= ~STAALLSNO;
  _rtparas.state   |= (setsno == 1) ? STAALLSNO : 0;

  if ( _rtparas.mtnum == 0)
    _rtparas.flood = 0;
}

static int scanreport()
{
  int ret = 0;
  int cnt=0;
  int size=0;
  ses_get_task_info(&cnt, &size);

  if (_rtparas.mtnum > 0
      && (_rtparas.state & STASTMASK) == STARUN
      && (_rtparas.mtnum != _rtparas.cmd1num || cnt>0)) //��_rtparas.mtnum != cmd1num����Щ
  {
      rt_report(REPOIDLE, 0);
      rt_report(REPODIR, 0);
      rt_report(REPORELAX, 0);

  }

  for (size_t i = 0; i < sizeof(report) / sizeof(report[0]); ++i)
    {
      if (report[i].times == 0)
  continue;

      if (report[i].start == 0)
  report[i].start = currtick();
      if (currtick() - report[i].start >= report[i].oncetm)
  {
    if (report[i].fun != NULL)
      report[i].fun(report[i].data, report[i].dlen);
    --report[i].times;
    report[i].start = 0;
  }

      if (report[i].times == 0)
  continue;

      ret = -1;
    }

  return ret;
}

extern unsigned int flag_again_eeprom;
static void again()
{
  size_t cmd1num = 0;
  int num43 = 0;//,rat = 0;

  _rtparas.dbfirst = 0;
  _rtparas.stage = 0;
  _rtparas.round = 1;
  memset(&_task, 0x00, sizeof (struct task));/* clear task */

  /* clear success flag */

  struct mtinfo *mt;
  //  unsigned char alliv = 1;
  ++_rtparas.stagectl;
  if (_rtparas.stagectl != 0 && _rtparas.stagectl % 2 == 0)
  {
      if (is_node_need_phs_brd() >= 0)
      {
          _rtparas.sndphs &= ~PHSNEEDSMASK;
          _rtparas.sndphs |= PHSNEEDSND;
      }

  }

  chk_to_fast_task_stage();

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
      if (_rtparas.stagectl != 0 && _rtparas.stagectl % 2 == 0)           /*ÿ2����һ�γɹ���־*/
      {
          mt->node.succhops &= ~NSUCC & ~NREACH;  //��ǰ����û����db_write�ĵ���
          mt->node.envi &= ~NTSMASK;  //��ǰ����û����db_write�ĵ���
      }
      if ((mt->node.envi & NCMD1MASK) == NCMD1SUC)
          ++cmd1num;
      if ((mt->node.phase & NPDTMASK) == NPDT43)
          ++num43;
  }

  if (_share.version == NEW_GBPRO && cmd1num == _rtparas.mtnum && (_rtparas.wkstate & RDOVERMASK) != RDOVER)
  {
      // appgb_wkstate_report(0x01);//����û���ϱ�
      _rtparas.wkstate |= RDOVER;
  }

  chk_to_set_dpsk_mode(num43,_rtparas.mtnum);


  if ((_rtparas.state & STASTMASK) == STARUN && (_rtparas.wrkmd & RUNMDRMASK) != RUNMDRPT)
    {
      /* route must start at stage0 is condition of process below program */
      /* ignore set stage value operate */

      //++_rtparas.cycle;
      if (++_rtparas.cycle >= 0xFE)//unsigned char type max val
      {
          _rtparas.cycle = 1;
      }
      if (++_rtparas.wrktms > MAXWRKTMS)
  _rtparas.wrktms = 1;
      if (++_rtparas.wrkno > MAXWRKSNO)
  _rtparas.wrkno = 1;
      
      static unsigned char again_cnt = 0;
      again_cnt++;
      if (again_cnt >= 100)  /* ����flash��дƵ�� */
        {
          again_cnt = 0;
          eeprom_write(DBPBEGIN + offset(struct rtpara, wrkno), (unsigned char *)&_rtparas.wrkno,
           size(struct rtpara, wrkno));
          
          flag_again_eeprom++;
        }

      /* if suitable location ?? */

      if ((_rtparas.state & STASTMASK) == STARUN)
  {
    db_flush();
#ifdef _DEBUG
    printf("flush\n"); /* for test !! */
#endif
  }
    }

  /* relax */
  if (_rtparas.mtnum == _rtparas.succnum && _rtparas.mtnum == cmd1num)
    rt_report(REPORELAX, 20); /* 20 * 6 = 120's */

  _rtparas.wrkmd &= ~RUNMDRMASK;

  //void rt_selfchk();
  //if (_rtparas.wrkno == MAXWRKSNO)
    //rt_selfchk();

#ifdef _DEBUG
  printf("again\n"); /* for test !! */
#endif
}

extern unsigned int flag_rt_first_eeprom;
 void rt_first()
{
  eeprom_read(DBPBEGIN, (unsigned char *)&_rtparas, offset(struct rtpara, eepend));
  _rtparas.slevel = 0x02;
  _rtparas.wrkno = 1;
  _rtparas.regsno = 0;
  _rtparas.brdclose = 1;
  _rtparas.areset = 0x00;
  if((_rtparas.maxsno[0] == 0 && _rtparas.maxsno[1] == 0) || (_rtparas.maxsno[1] >= 0x6F)
     ||(_rtparas.maxsno[0] > 0x6F))
  {
    _rtparas.maxsno[0] = 0x01;
    _rtparas.maxsno[1] = 0x00;
  }
  memcpy(_rtparas.minsno, _rtparas.maxsno, SNOLEN);

  /* if generate sinkid ?? */
  eeprom_read(DBSHARE + offset(struct share, jzqid), _rtparas.jzqid, sizeof(_rtparas.jzqid));

  memcpy(_rtparas.jzqid_nw, _rtparas.jzqid, sizeof(_rtparas.jzqid));
  eeprom_write(DBPBEGIN + offset(struct rtpara, jzqid_nw), _rtparas.jzqid_nw, sizeof(_rtparas.jzqid_nw));

  if (_rtparas.flag_setid != 0x7E)
  {
      unsigned short t;
      t = nl_get_panid();
    
      for (int i = 0; i < 3; i++)
        {
          if(_rtparas.sinkid[0] == 0x00 && _rtparas.sinkid[1] == 0)
      {
        _rtparas.sinkid[0] = (t&0xFF) % 0x63;
        _rtparas.sinkid[1] = ((t>>8)&0xFF) % 0x63;
      }
          else
      break;
        }
  }

  _share.mode_state = RTSTA_INIT;
  eeprom_write(DBSHARE + offset(struct share, mode_state), &_share.mode_state, 1);
  eeprom_write(DBPBEGIN, (unsigned char *)&_rtparas, offset(struct rtpara, eepend));
  
  flag_rt_first_eeprom++;
}

int get_runinfo(struct run_info* ri)
{
  memset(ri, 0x00, sizeof(struct run_info));
  struct mtinfo *mtp;
  int hops = 0;

  db_trav_reset(CHAN_TMP);
  while (mtp = db_trav_mtnext(CHAN_TMP))  
    {
      hops = (mtp->node.succhops & NHMASK);// == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;
      ri->lvl[hops] += 1;
    }
  
  return 0;
}

int print_ver()
{
  struct node_info
{
  unsigned char aid[6];
  unsigned short tei;
  unsigned char lvl;
  unsigned short pco;
  unsigned char trycnt;
  unsigned char eid[5]; /* 5�� eid */
  unsigned short sid; /* 5��sid */
};
  
  int i = 0;
  struct node_info info;
  struct rpinfo *rp;
  struct mtinfo *mtp, *mt;

  memset(&info, 0x00, sizeof(info));
  db_trav_reset(CHAN_TMP);
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      memcpy(info.aid, mtp->node.id, sizeof(info.aid));
      id_bintobcd(info.aid);
      reverse(info.aid, IDLEN);
      memcpy((unsigned char *)&info.tei, mtp->node.sno, sizeof(info.tei));
      rp = db_getfrp(mtp);
      if ((rp != NULL) && (mt = db_find(&rp->rpid[0])) != NULL)
        memcpy((unsigned char *)&info.pco, mt->node.sno, sizeof(info.pco));
      
      memcpy(info.eid, mtp->node.eid, 5);
      info.sid = mtp->node.sid;

      
      info.lvl = (mtp->node.succhops & NHMASK);// == 0 ? 0 : (mtp->node.succhops & NHMASK) - 1;
      if (info.sid != 0xFFFF)
      {
        info.lvl = mtp->hop;
        info.pco = mtp->fsid;
      }

      if ((mtp->node.viv & NNDMASK) == 0x03) 
      {
          info.lvl = 0;
          info.pco = 0; 
          info.tei = 0;
      }

      printf_s("%03d AID:%02X%02X%02X%02X%02X%02X TYPE:%d, INET_TYPE:%d, TEI:%04X LEVEL:%d PCO:%04X CNT:%d  EID:%02X%02X%02X%02X%02X  SID:%04X  dc_fail_cnt:%02X\n",
               i++, info.aid[5], info.aid[4], info.aid[3], info.aid[2], info.aid[1], info.aid[0], (mtp->node.viv & NNDMASK), (mtp->node.viv & NETMASK) >> (NETMASK - 2), info.tei, info.lvl, info.pco, mtp->trycnt, 
                   info.eid[0], info.eid[1], info.eid[2], info.eid[3], info.eid[4], info.sid, mtp->dc_fail_cnt);
    }
}