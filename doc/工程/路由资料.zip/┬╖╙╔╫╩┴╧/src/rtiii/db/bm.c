/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: bm.c
 * Description: Blank manager
 *
 * Version: v1.0
 * Time:    2009-12-02
 * 
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/db/bm.h"

static struct blanker blankhead;

static int bm_modify(struct blanker *anyblankptr, unsigned short addr, unsigned short num);
static int bm_tidy(struct blanker *anyblankptr);

int bm_init()
{
  return 0;
}

int bm_get(enum blanktype typevalue, unsigned short num, unsigned short *addrptr)
{
  struct blanker *tmp = blankhead.next;
  int returnflag = -1;
  
  for (; tmp; tmp = tmp->next)
    {
      if (tmp->num >= num)
	{
	  returnflag = 0;

	  switch(typevalue)
	    {
	    case NODE:
	      {
		*addrptr = tmp->addr;
		return 0;
	      }
	    case RELAY:
	      *addrptr = tmp->addr + (tmp->num - num) * CELL;
	    }
	}
    }

  return returnflag;
}

int bm_add(unsigned short addr, unsigned short num)
{
  assert((addr % CELL == 0) && (addr <= DBEND));
  
  enum inserttype
  {
    BEFORE,
    AFTER
  };
  struct blanker *tmp = blankhead.next;
  struct blanker *fronter = &blankhead;
  int insertflag = BEFORE;

  for(; tmp; tmp = tmp->next)
    {
      if (addr >= tmp->addr 
	  && addr + num * CELL <= tmp->addr + tmp->num * CELL) /* include totally, ignore this case(7,8)*/
	return 0;

      if ((addr < tmp->addr 
	   && addr + num * CELL > tmp->addr
	   && addr + num * CELL <= tmp->addr + tmp->num * CELL) /* partly include exception (5,9)*/
	  ||
	  (addr >= tmp->addr 
	   && addr < tmp->addr + tmp->num * CELL
	   && addr + num * CELL > tmp->addr + tmp->num * CELL))/* partly include exception (6,10)*/
	  return -1;

      if (tmp->addr + tmp->num * CELL == addr) /* union high address of tmp */
	{
	  bm_modify(tmp, tmp->addr, tmp->num + num);
	  bm_tidy(tmp);
	  return 0;
	}
      if (addr + num * CELL == tmp->addr) /* union low address of tmp */
	{
	  bm_modify(tmp, addr, tmp->num + num);
	  return 0;
	}
      if (addr + num * CELL < tmp->addr) /* insert before of tmp */
	{
	  insertflag = BEFORE;
	  break;
	}
      if (tmp->next != NULL)
	{
	  if (addr + num * CELL < tmp->next->addr) /* insert after of tmp */
	    {
	      insertflag = AFTER;
	      break;
	    }
	}
      else
	{
	  insertflag = AFTER; /* insert after of tmp */
	  break;
	}

      fronter = tmp;
    }

  struct blanker *newblankptr = (struct blanker *)malloc(sizeof(struct blanker));
  if (newblankptr == NULL)
    return seterr(DBERR_MALLOC);
  newblankptr->num = num;
  newblankptr->addr = addr;

  if (insertflag == AFTER)
    {
      newblankptr->next = tmp->next;
      tmp->next = newblankptr;
    }
  if (insertflag == BEFORE)
    {
      newblankptr->next = tmp;
      fronter->next = newblankptr;
    }

  return 0;
}

int bm_del(unsigned short addr, unsigned short num)
{
  assert((addr % CELL == 0) && (addr <= DBEND));

  struct blanker *tmp = blankhead.next;
  struct blanker *fronter = &blankhead;

  for (; tmp; tmp = tmp->next)
    {
      if (tmp->addr >= addr + num * CELL
	  || (tmp->addr + tmp->num * CELL >= addr + num * CELL && addr < tmp->addr))  /* include exception */
	return -1;

      if (tmp->addr == addr && tmp->num == num) /* Exactly */
	{
	  fronter->next = tmp->next;
	  free(tmp);
	  return 0;
	}

      if (tmp->num > num)
	{
	  if (tmp->addr == addr) /* Del from top */
	    {
	      bm_modify(tmp, addr + num * CELL, tmp->num - num);
	      return 0;
	    }
	  if (tmp->addr + tmp->num * CELL == addr + num * CELL) /* Del from bottom */
	    {
	      bm_modify(tmp, tmp->addr, tmp->num - num);
	      return 0;
	    }

	  if (tmp->addr < addr && tmp->addr + tmp->num * CELL > addr + num * CELL) /* Del from middle */
	    {	  
	      struct blanker *midptr = (struct blanker *)malloc(sizeof(struct blanker));
	      if (midptr == NULL)
		return seterr(DBERR_MALLOC);
	      bm_modify(midptr, addr + num * CELL, (tmp->addr + tmp->num * CELL - addr - num * CELL)/CELL);
	      bm_modify(tmp, tmp->addr, (addr - tmp->addr)/CELL);
	      midptr->next = tmp->next;
	      tmp->next = midptr;

	      return 0;
	    }
	}

      fronter = tmp;
    }  

  return -1;
}

int bm_print()
{
  printf("Now Printing...\n");

  struct blanker *tmp = blankhead.next;
  int i = 0;

  for (; tmp; tmp = tmp->next)
    {
      printf("%02d:addr:%d,num:%d\n", i, tmp->addr, tmp->num);
      ++i;
    }
  return 0;
}

void bm_clear()
{
  struct blanker *tmp = blankhead.next;
  for (; tmp; )
    {
      struct blanker *ptr = tmp;   
      tmp = ptr->next;
      free(ptr);
    }

  blankhead.next = NULL;
}

int bm_verify(int couplenum, unsigned short addr[], unsigned short num[])
{
  struct blanker *tmp = blankhead.next;
  size_t blanknum = 0;

  for(; tmp; tmp = tmp->next, blanknum < couplenum, ++blanknum)
    if ((tmp->addr != addr[blanknum]) || (tmp->num != num[blanknum]))
	return -1;

  if ((tmp == NULL) && (blanknum == couplenum))
    return 0;

  return -1;
}

static int bm_modify(struct blanker *anyblankptr, unsigned short addr, unsigned short num)
{
  assert(anyblankptr);
  assert((addr % CELL == 0) && (addr <= DBEND));

  anyblankptr->addr = addr;
  anyblankptr->num = num;

  return 0;
}

static int bm_tidy(struct blanker *anyblankptr)
{
  assert(anyblankptr);

  if (anyblankptr->next != NULL)
    {
      if (anyblankptr->addr + anyblankptr->num * CELL == anyblankptr->next->addr)
	{
	  bm_modify(anyblankptr, anyblankptr->addr, anyblankptr->num + anyblankptr->next->num);

	  struct blanker *tmp = anyblankptr->next;
	  anyblankptr->next = tmp->next;
	  free(tmp);
	}
    }

  return 0;
}
