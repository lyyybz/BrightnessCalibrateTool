/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: hash.c
 * Description: Ram structure of router database
 *              The optimization for search routing table.
 *
 * Version: v1.0
 * Time:    2009-12-02
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/db/bm.h"
#include "../include/db/node.h"
#include "../include/db/db.h"
#include "../include/db/hash.h"

#define HASHTCAP 331  /* hash table capacity */
#define MAXRPNUM 6

static struct
{
  int change;    /* flag of change meter(0 - change, other - no change) */
  size_t tabpos; /* current position of idtab */
  struct hmtcell *cmtp; /* current pointer of meter cell in idtab */
  struct hrpcell *crpp; /* current pointer of repeater cell in idtab */
} travbrk[5];

static struct hmtcell *idtab[HASHTCAP];

static int hash(const unsigned char *str, size_t len);
static int hash_delrp_mtcell(struct hmtcell *mtptr);

void hash_init()
{
  for (size_t i = 0; i < HASHTCAP; ++i)
    idtab[i] = NULL;

  for (size_t i = 0; i < (sizeof(travbrk) / sizeof(travbrk[0])); ++i)
    memset(&travbrk[i], 0x00, sizeof(travbrk[i]));
}

void hash_build()
{
  unsigned short addr, end, idmaxa = 0;
  struct mtinfo mt;

  memset((unsigned char *)&mt, 0x00, sizeof(mt));
  addr = DBBEGIN;
  end  = DBEND;
  while (addr < end)
    {
      db_read(addr, (unsigned char *)&mt.node, CELL);
      if ((mt.node.attr & CELLMASK) == MTFLAG)
        {
          if (addr % (CELL*MTCN) != 0x00) /* some error occur */
            {
              addr += CELL;
              continue;
            }
          db_read(addr + CELL, (unsigned char *)&mt.node + CELL, sizeof(mt.node) - CELL);
          mt.addr = addr;
          mt.rdtick = 0;//init rdtick to zero
          mt.tmout_tims = 0;
          mt.freeze_val = 0;
          hash_addmt(&mt);

          if (addr > idmaxa)
            idmaxa = addr; /* scan meter bound */
        }
      else if ((mt.node.attr & CELLMASK) == RPFLAG)
        {
          bm_add(addr, (end - addr) / CELL); /* repeater storage area */
          break;
        }
      else
        {
          if (mt.node.attr != EMPFLAG)
            assert(0); /* should not appear */

          bm_add(addr, 1);
          addr += CELL;
            watchdog();
          continue;
        }

      addr += CELL * MTCN; /* idnode occupy 2 database cell */
      assert(addr <= DBEND);
      watchdog();
    }

  /* initalize repeater .... */

  struct rpinfo rp;
  for (size_t i = 0; i < HASHTCAP; ++i)
    {
      struct hmtcell *p = idtab[i];
      for (; p; p = p->next)
        {
          addr = p->hcell.node.rpp; /* pointer to repeater */
          if (addr == 0x00 || addr % CELL != 0)
            continue;

          size_t n = 0;
          while (addr && n < 16)
            {
              db_read(addr, (unsigned char *)&rp.node, sizeof(rp.node));
              if ((rp.node.attr & CELLMASK) != RPFLAG)
                break;
              if((rp.node.nextrp != 0)&& (rp.node.nextrp % CELL != 0 || rp.node.nextrp < idmaxa))
                break; /* next repeater pointer is invalid */
              if (rp.node.idptr % (CELL * MTCN) != 0 || rp.node.idptr > idmaxa)
                break; /* idinfo pointer is invalid */

              rp.addr = addr;
              db_read(rp.node.idptr + offset(struct mtnode, id), rp.rpid,
                sizeof(rp.rpid));
              hash_appendrp(p->hcell.node.id, &rp);
              bm_del(addr, 1);

              addr = rp.node.nextrp;
              ++n; /* protection for infinite loops */
            }
        }
      watchdog();
    }
}

void hash_destroy()
{
  struct hmtcell *hmtp;

  for (int i = 0; i < HASHTCAP; ++i)
    {
      while ((hmtp = idtab[i]) != NULL)
  hash_delmt(hmtp->hcell.node.id);
    }
}

struct mtinfo * hash_find(const unsigned char *mtid)
{
  assert(mtid);
  struct hmtcell *p;
  size_t pos = hash(mtid, IDLEN);

  for (p = idtab[pos]; p; p = p->next)
    {
      if (memcmp(p->hcell.node.id, mtid, IDLEN) == 0)
  return &p->hcell;
    }

  return NULL;
}

struct mtinfo * hash_find_sno(unsigned char *mtsno)
{
  assert(mtsno);

  struct mtinfo *mtp;
  unsigned char sno[2];
  hash_trav_reset(CHAN_TMP);
  while (mtp = hash_trav_mtnext(CHAN_TMP))
    {
      memcpy(sno, mtp->node.sno, SNOLEN);
      sno[0] &= ~NNEWMASK;
      if (memcmp(sno, mtsno, SNOLEN) == 0)
  return mtp;
    }

  return NULL;
}

int hash_addmt(const struct mtinfo *mtptr)
{
  assert(mtptr);
  struct hmtcell *p = (struct hmtcell *) malloc(sizeof(struct hmtcell));
  if (p == NULL)
  {
    return seterr(DBERR_MALLOC);
  }

  size_t pos = hash(mtptr->node.id, sizeof(mtptr->node.id));
  p->next = idtab[pos];
  memcpy(&p->hcell, mtptr, sizeof(struct mtinfo));
  memset(&p->hcell.item, 0x00, sizeof(p->hcell.item));
  p->hcell.rpl = NULL; /* initalize rp */
  idtab[pos] = p;

  return 0;
}

int hash_delmt(const unsigned char *mtid)
{
  assert(mtid);

  int pos = hash(mtid, IDLEN);
  struct hmtcell *p = idtab[pos];
  struct hmtcell *fronter = NULL;

  for (; p; p = p->next)
    {
      if (memcmp(mtid, p->hcell.node.id, IDLEN) == 0)
  {
    hash_delrp_mtcell(p); /* free rp */
    if (fronter == NULL)
      {
        idtab[pos] = p->next;
        free(p);
      }
    else
      {
        fronter->next = p->next;
        free(p);
      }

    return 0;
  }

      fronter = p;
    }

  return -1;
}

int hash_appendrp(const unsigned char *mtid, const struct rpinfo *rpptr)
{
  assert(mtid);
  assert(rpptr);

  struct mtinfo *mtp;
  if ((mtp = hash_find(mtid)) == NULL)
    return -1; /* if save error code? */

  struct hrpcell *rpp = (struct hrpcell *) malloc(sizeof(struct hrpcell));
  if (rpp == NULL)
    return seterr(DBERR_MALLOC);
  memcpy(&rpp->hcell, rpptr, sizeof(rpp->hcell));
  rpp->next = NULL; /* initalize next */
  if (mtp->rpl == NULL)
    mtp->rpl = rpp;
  else
    {
      struct hrpcell **pre = &(struct hrpcell *)(mtp->rpl), *p = (struct hrpcell *)mtp->rpl;
      int i = 0;
      for (; p; p = p->next, ++i)
  {
    if (memcmp(p->hcell.rpid, rpp->hcell.rpid, IDLEN) == 0)
      {
        free(rpp);
        return 0; /* already exist */
      }
    if (memcmp(p->hcell.rpid, mtivd, sizeof(mtivd)) == 0)
      break;
    pre = &(struct hrpcell *)(p->next);
  }
      if (i < MAXRPNUM)
  {
    rpp->next = *pre;
    *pre = rpp;
  }
      else
        free(rpp);
    }

  return 0;
}

int hash_insertrp(const unsigned char *mtid, const struct rpinfo *rpptr)
{
  assert(mtid);
  assert(rpptr);

  struct mtinfo *mtp;
  if ((mtp = hash_find(mtid)) == NULL)
    return seterr(DBERR_NOTHISMT);

  if(hash_findrp(mtid, rpptr->rpid) == NULL) /* rpptr->rpid not exist in rp linked list of mtid*/
    {
      struct hrpcell *rpp = (struct hrpcell *) malloc(sizeof(struct hrpcell));
      if (rpp == NULL)
  return seterr(DBERR_MALLOC);
      rpp->next = mtp->rpl;
      mtp->rpl = rpp;
      memcpy(&rpp->hcell, rpptr, sizeof(struct rpinfo));
      rpp->hcell.addr = EMPADDR;
      return 0;
    }

  return hash_toprp(mtid, rpptr);
}

int hash_delrp(const unsigned char *mtid, const unsigned char *rpid)
{
  assert(mtid);
  assert(rpid);
  unsigned char tmpid[IDLEN];
  memcpy(tmpid, rpid, IDLEN);

  struct mtinfo *mtp;
  if ((mtp = hash_find(mtid)) == NULL) /* find the meter */
    return -1;

  struct hrpcell *fronter = NULL;
  struct hrpcell *rp = NULL;
  int findflag = -1;

  for (struct hrpcell *p = mtp->rpl; p; p = p->next)
    {
      if (memcmp(tmpid, p->hcell.rpid, IDLEN) == 0 && findflag == -1) /* find the rp */
  {
          findflag = 0;
    memcpy(p->hcell.rpid, mtivd, IDLEN); /* set invalid */

    if (fronter == NULL)     /* delete the rp from the linked list */
      mtp->rpl = p->next;
    else
      fronter->next = p->next;

    if (p->hcell.addr == EMPADDR) /* if not allot space, delete directly */
      {
        free(p);
              p = NULL;
              return 0;
      }
    rp = p;
    continue;
  }

      fronter = p;
    }
  if (findflag == 0) /* append to tail */
    {
      if (fronter == NULL)
  mtp->rpl = rp;
      else
  fronter->next = rp;
      rp->next = NULL;

      return 0;
    }

  return -1;
}

int hash_toprp(const unsigned char *mtid, const struct rpinfo *rpptr)
{
  assert(mtid);
  assert(rpptr);

  struct mtinfo *mtp;
  if ((mtp = hash_find(mtid)) == NULL) /* find the meter */
    return -1;

  struct hrpcell *fronter = NULL;

  for (struct hrpcell *p = mtp->rpl; p; p = p->next)
    {
      if (memcmp(rpptr->rpid, p->hcell.rpid, IDLEN) == 0) /* find the rp */
  {
    if (fronter)
            {
              fronter->next = p->next;  /* delete the rp from the linked list*/
              p->next = mtp->rpl;      /* step up */
              mtp->rpl = p;
            }

          p->hcell.node.failtms = rpptr->node.failtms; /* update rp info */
          p->hcell.node.succtms = rpptr->node.succtms;
          p->hcell.node.rsv1 = rpptr->node.rsv1;
    return 0;
  }

      fronter = p;
    }

  return -1;
}

void hash_trav_reset(size_t chan)
{
  memset(&travbrk[chan], 0x00, sizeof(travbrk[chan]));
}

void hash_trav_rpreset(size_t chan)
{
  if (travbrk[chan].cmtp == NULL)
    return;

  travbrk[chan].change = 0;
  travbrk[chan].crpp = travbrk[chan].cmtp->hcell.rpl;
}

struct mtinfo * hash_trav_mtnext(size_t chan)
{
  if (travbrk[chan].tabpos >= HASHTCAP) /* can not use assert */
    return NULL;

  if (travbrk[chan].cmtp == NULL || travbrk[chan].cmtp->next == NULL)
    {
      if (travbrk[chan].cmtp != NULL && travbrk[chan].cmtp->next == NULL)
  ++travbrk[chan].tabpos;

      for (; travbrk[chan].tabpos < HASHTCAP; ++travbrk[chan].tabpos)
  {
    travbrk[chan].cmtp = idtab[travbrk[chan].tabpos];
    if (travbrk[chan].cmtp != NULL)
      break;
  }
      if (travbrk[chan].tabpos >= HASHTCAP || travbrk[chan].cmtp == NULL)
  return NULL;
    }
  else
    travbrk[chan].cmtp = travbrk[chan].cmtp->next;

  travbrk[chan].change = 0;
  travbrk[chan].crpp = travbrk[chan].cmtp->hcell.rpl;

  return &travbrk[chan].cmtp->hcell;
}

struct rpinfo * hash_trav_rpnext(size_t chan, int pattern)
{
  if (travbrk[chan].cmtp == NULL)
    return NULL;
  if (travbrk[chan].crpp == NULL)
    return NULL;
  if (travbrk[chan].change++ == 0)
    {
      if (pattern == CHAN_TDEF && memcmp(travbrk[chan].crpp->hcell.rpid,
           mtivd, sizeof(mtivd)) == 0)
  return NULL;

      return &travbrk[chan].crpp->hcell;
    }
  if (travbrk[chan].crpp->next == NULL)
    return NULL;

  if (pattern == CHAN_TDEF)
    {
      if (memcmp(travbrk[chan].crpp->next->hcell.rpid, mtivd,
     sizeof(mtivd)) == 0) /* deleted repeater, traverse end */
  return NULL;
    }

  travbrk[chan].crpp = travbrk[chan].crpp->next;

  return &travbrk[chan].crpp->hcell;
}

struct rpinfo * hash_getfrp(struct mtinfo *mtptr)
{
  if (mtptr == NULL)
    return NULL;

  return &mtptr->rpl->hcell;
}

struct rpinfo * hash_findrp(const unsigned char *mtid, const unsigned char *rpid)
{
  assert(mtid);
  assert(rpid);

  struct mtinfo *mtp = hash_find(mtid);
  if (mtp == NULL)
    return NULL;
  for (struct hrpcell *rpp = mtp->rpl; rpp; rpp = rpp->next)
    {
      if (memcmp(rpp->hcell.rpid, rpid, IDLEN) == 0)
  return &rpp->hcell;
    }

  return NULL;
}

int hash_verifymt(size_t num, struct mt_vfy *mtid_vfy)
{
  size_t couplenum = 0;
  size_t i = 0;

  for (; i < HASHTCAP; ++i)
    {
      if (idtab[i] != NULL)
  {
    struct hmtcell *p = idtab[i];
    if (memcmp(p->hcell.node.id, sinkidno, sizeof(sinkidno)) == 0)
      continue;

    if (mtid_vfy[couplenum].pos == i)
      {
        size_t tmpindex = 0;
        for (p = idtab[i]; p; p = p->next) /* verify mt */
    {
      if (mtid_vfy[couplenum].index != tmpindex)
        return -1;
      if (memcmp(p->hcell.node.id, mtid_vfy[couplenum].mtid, IDLEN) != 0) /* mt id */
        return -2;
      ++tmpindex;
      ++couplenum;
    }

        continue;
      }

    return -1;
  }
    }

  if (couplenum != num || i != HASHTCAP) /* hash num */
    {
      return -1;
    }

  return 0;
}

int hash_find_pos(const unsigned char *str, size_t len)
{
  return hash(str,len);
}

struct hmtcell ** get_idtab()
{
  return &idtab[0];
}

static int hash(const unsigned char *str, size_t len)
{
  unsigned long hash = 0;

  for (size_t i = 0; i < len; ++i)
    hash = (hash * 16777619) ^ (unsigned long) str[i];

  return hash % HASHTCAP;
}

static int hash_delrp_mtcell(struct hmtcell *mtptr)
{
  struct hrpcell *p = mtptr->hcell.rpl;

  for (; p; )
    {
      struct hrpcell *tmp = p;
      p = tmp->next;
      free(tmp);
    }
  mtptr->hcell.rpl = NULL;

  return 0;
}

void hash_print()
{
#ifdef _LINUXPC

  struct hmtcell *hmt;
  struct hrpcell *hrp;

  for(size_t i = 0, n = 0, m = 0; i < HASHTCAP; ++i, n = 0, m = 0)
    {
      if ((hmt = idtab[i]) == NULL)
  continue;
      printf("pos = %d :\n", i);
      do
  {
    printf ("\t meter %d - ID is", ++n);
    for (int j = 0; j < IDLEN; j++)
      printf(" %x",hmt->hcell.node.id[j]);
    printf (",EEP Address is %x, sno is %d ,",hmt->hcell.addr, *(unsigned short*) hmt->hcell.node.sno);
    printf (" mtnode.rpp = %x\n ", hmt->hcell.node.rpp);
    if ((hrp = hmt->hcell.rpl) == NULL)
      continue;
    printf ("\t repeater :\n");

    do
      {
        printf ("\t\t reapter %d - ID is",++m);
        for (int j = 0; j < IDLEN; j++)
    printf(" %x", hrp->hcell.rpid[j]);
        printf (", eep address is  %x,rpnode.nextrpp = %x \n",hrp->hcell.addr, hrp->hcell.node.nextrp);
      }
    while (hrp = hrp->next);
  }
      while ( hmt = hmt->next);
    }

#endif
}

void hash_printmt()
{
#ifdef _LINUXPC

  struct hmtcell *hmt;
  struct hrpcell *hrp;
  unsigned char buf[200];
  FILE *fp;
  fp = fopen("print.txt", "w");
  assert(fp != NULL);
  for(size_t i = 0, n = 0, m = 0; i < HASHTCAP; ++i, n = 0, m = 0)
    {
      sprintf(buf, "pos = %d :\n", i);
      fwrite(buf,sizeof(buf[0]),strlen(buf),fp);
      if ((hmt = idtab[i]) == NULL)
  continue;
      memset(buf,0x00,200);
      do
  {
    sprintf (buf,"\t meter %d - ", ++n);
    sprintf (buf + strlen(buf),"ID is ");
    for (int j = 0; j < IDLEN; j++)
      sprintf(buf + strlen(buf)," %x",hmt->hcell.node.id[j]);
    sprintf(buf + strlen(buf),"\n");
    fwrite(buf,sizeof(buf[0]),strlen(buf),fp);
    if ((hrp = hmt->hcell.rpl) == NULL)
      continue;
    assert(0);
  }
      while ( hmt = hmt->next);
    }

#endif
}

