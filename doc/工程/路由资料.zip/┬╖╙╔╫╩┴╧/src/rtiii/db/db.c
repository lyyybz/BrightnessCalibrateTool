/*
 * Copyright by Qingdao EASTSOFT Computer Ltd.,Co. 2009 All right reserved.
 *
 * File name: db.c
 *
 * Description: rt data manager
 *
 * Version: v1.0
 * Time:    2009-12-01
 *
 */

#include "../include/tool/ague.h"
#include "../include/tool/toolfun.h"
#include "../include/dev/eeprom.h"
#include "../include/db/bm.h"
#include "../include/db/node.h"
#include "../include/db/hash.h"
#include "../include/db/db.h"
#include "../include/rt/rtpara.h"
#include "../include/rt/rtpara.h"
#include "../../user/router.h"
#include "flash.h"
#include "ee_flash.h"

static int dberr;
unsigned char mtivd[IDLEN] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
unsigned char sinksno[SNOLEN] = {0x7D, 0x00};
unsigned char sinkidno[IDLEN] = {0x7D, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned char broadsno[SNOLEN] = {0x7F, 0x00};
unsigned char broadidno[IDLEN]  = {0x7F, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned char dispidno[IDLEN]   = {0x7B, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned char dispbdidsno[SNOLEN] = {0x7C, 0x00};
unsigned char dispbdidno[IDLEN] = {0x7C, 0x00, 0x00, 0x00, 0x00, 0x00};

static int db_new();
static void db_flushmt(struct mtinfo *mtptr, ADDRESS idmaxa);
void db_bound(ADDRESS *idmaxa, ADDRESS *rpmina);


int db_init0()
{
  init_ee_flash_map();
  bm_init();
  hash_init();

  return 0;
}
 
int db_init()
{
  return db_new();
}

void db_build()
{
  hash_build();
}

void db_destroy()
{
  bm_clear();
  hash_destroy();
}

extern unsigned int flag_db_format_eeprom;
void db_format()
{
  unsigned long addr;
  unsigned char c[0x80];
  unsigned int len;

  memset(c, EMPFLAG, sizeof(c));

  for(addr = DBBEGIN; addr < DBEND; addr += sizeof(c))
    {
      len = (DBEND - addr) > sizeof(c) ? sizeof(c) : (DBEND -addr);
      eeprom_write(addr, c, len);
      
      flag_db_format_eeprom++;
      
    }

  struct mtnode node;
  memset(&node, 0x00, sizeof(node));
  memcpy(node.sno, sinksno, sizeof(node.sno));
  memcpy(node.id, sinkidno, sizeof(node.id));
  node.attr |= MTFLAG;
  addr = DBBEGIN;
  eeprom_write(addr, (unsigned char *)&node, sizeof(node));
  flag_db_format_eeprom++;
}

int db_read(ADDRESS addr, unsigned char *dest, size_t len)
{
  assert(addr < DBEND);

  return (eeprom_read(addr, dest, len));
}

int db_write(ADDRESS addr, unsigned char *src, size_t len)
{
  assert(addr < DBEND);

  eeprom_write(addr + 1, src + 1, len - 1 );
  eeprom_write(addr, src, 1);

  return len;
}

int db_unit_empty(ADDRESS addr)
{
  unsigned char c = 0;

  assert((addr % CELL == 0) && (addr < DBEND));
  eeprom_read(addr, &c, sizeof(unsigned char));

  return (EMPFLAG == c ? 0 : -1);
}

int db_seterr(int errno)
{
  return dberr = errno;
}

int db_geterr()
{
  return dberr;
}

struct mtinfo * db_find(const unsigned char *mtid)
{
  return hash_find(mtid);
}

struct mtinfo * db_find_sno(unsigned char *mtsno)
{
  return hash_find_sno(mtsno);
}

extern unsigned int flag_db_addmt_eeprom;
int db_addmt(struct mtinfo *mtptr)
{
  assert(mtptr);
  if (hash_find(mtptr->node.id) != NULL)
    return seterr(DBERR_MTEXIST);

  ADDRESS addr, idmax, rpmin;

  db_bound(&idmax, &rpmin);
  if (bm_get(NODE, MTCN, &addr) != 0) /* 2 is number of unit in NODE */
  {
  
    return seterr(DBERR_MTMOF);
  }
  

  if (addr + CELL >= rpmin)
  {
    
    return seterr(DBERR_MTMOF); /* beyond address bound */
  }
  if ((addr % (CELL * MTCN) != 0x00) || (addr >= DBEND))
  {
   
    return seterr(DBERR_BM); /* id node address always align to 0x10 */
  }

  mtptr->node.rpp = 0x0000;
  mtptr->node.attr &= ~CELLMASK;
  mtptr->node.attr |= MTFLAG;
  
  /* V�����ݿ��ֶ�Ĭ��Ϊ0xFF */
  memset(mtptr->node.eid, 0xFF, 5); /* 5�� eid */
  mtptr->node.sid = 0xFFFF;         /* 5��sid */
  //mtptr->node.viv = 0xFF;
  
  db_write(addr, (unsigned char *)&mtptr->node, sizeof(struct mtnode));
  
  flag_db_addmt_eeprom++;
  
  bm_del(addr, MTCN);
  mtptr->addr = addr;
  mtptr->rdtick = 0;
  mtptr->tmout_tims = 0;
  mtptr->freeze_val = 0; 
  mtptr->dc_succ_rate = 100;
  return hash_addmt(mtptr);
}

extern unsigned int flag_db_delmt_eeprom;
int db_delmt(unsigned char *mtid)
{
  assert(mtid);

  ADDRESS addr;
  unsigned char c = EMPFLAG;
  struct mtinfo *mtp;

  if ((mtp = hash_find(mtid)) == NULL)
    return seterr(DBERR_NOTHISMT);
  addr = mtp->addr;
  if((addr % CELL != 0) || (addr + CELL >= DBEND))
    return -1;
  
  struct mtnode tmpmt;
  db_read(addr, (unsigned char *)&tmpmt, sizeof(struct mtnode));
  if ((tmpmt.attr & CELLMASK) == MTFLAG)
    {
      /* delete the first unit of meter from eeprom */
      db_write(addr, &c, sizeof(unsigned char));
      /* delete the second unit of meter from eeprom */
      db_write(addr + CELL, &c, sizeof(unsigned char));
      /* delete the third unit of meter from eeprom */
      db_write(addr + CELL + CELL, &c, sizeof(unsigned char));
      
      flag_db_delmt_eeprom++;
      
      bm_add(addr, MTCN);
    }
  else
    return -1;

  addr = tmpmt.rpp; /* the first rp */
  size_t n = 0;
  while (addr != 0x0000 && n < 16) /* next rp */
    {
      if((addr % CELL != 0) || (addr >= DBEND))
  return -1;

      struct rpnode tmprp;
      db_read(addr, (unsigned char *)&tmprp, sizeof(struct rpnode));
      if ((tmprp.attr & CELLMASK) == RPFLAG)
  {
    db_write(addr, &c, sizeof(unsigned char)); /* delete rp from eeprom */
    
    flag_db_delmt_eeprom++;
    
    bm_add(addr, RPCN);

    addr = tmprp.nextrp;
  }
      else
  return -1;

      ++n; /* protection for infinite loops */
    }

  hash_delmt(mtid); /* delete meter from hash */

  return 0;
}

extern unsigned int flag_db_clrall_newmtmask_eeprom;
int db_clrall_newmtmask()
{
  struct mtinfo *mtnode;

  db_trav_reset(CHAN_TMP);
  while ((mtnode = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if ((mtnode->node.attr & CELLMASK) != MTFLAG)
        continue;
      if (mtnode->node.sno[0] & NNEWMASK)
        continue;
      mtnode->node.sno[0] |= NNEWMASK;
      eeprom_write(mtnode->addr + offset(struct mtnode, sno[0]), (unsigned char *)&mtnode->node.sno[0],
                   sizeof(mtnode->node.sno[0]));
      
      flag_db_clrall_newmtmask_eeprom++;
      
      watchdog();
    }

  return 0;
}

int db_appendrp(const unsigned char *mtid, const struct rpinfo *rpptr)
{
  return hash_appendrp(mtid, rpptr);
}

int db_insertrp(const unsigned char *mtid, const struct rpinfo *rpptr)
{
  return hash_insertrp(mtid, rpptr);
}

void db_flush()
{
  ADDRESS idmaxa, rpmina;
  struct mtinfo *mtptr;

  static unsigned char flush_cnt = 0;
  flush_cnt++;
  if (flush_cnt < 100)  /* ����flash��дƵ�� */
    return;
  else
    flush_cnt = 0;
  
  db_bound(&idmaxa, &rpmina);

  db_trav_reset(CHAN_TMP);
  while ((mtptr = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    db_flushmt(mtptr, idmaxa);
    watchdog();
  }
}

void db_trav_reset(size_t chan)
{
  hash_trav_reset(chan);
}

void db_trav_rpreset(size_t chan)
{
  hash_trav_rpreset(chan);
}

struct mtinfo * db_trav_mtnext(size_t chan)
{
  struct mtinfo *p;
  for (;;)
    {
      p = hash_trav_mtnext(chan);
      if (p == NULL)
  break;
      if (memcmp(p->node.sno, sinksno, sizeof(p->node.sno)) == 0
    && memcmp(p->node.id, sinkidno, sizeof(p->node.id)) == 0)
  continue;
      break;
    }

  return p;
}

struct rpinfo * db_trav_rpnext(size_t chan, int pattern)
{
  return hash_trav_rpnext(chan, pattern);
}

struct rpinfo * db_getfrp(struct mtinfo *mtptr)
{
  return hash_getfrp(mtptr);
}

void db_bound(ADDRESS *idmaxa, ADDRESS *rpmina)
{
  struct mtinfo *mtp;
  struct rpinfo *rpp;

  db_trav_reset(CHAN_TMP);

  *idmaxa = DBBEGIN;
  *rpmina = DBEND;
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      if (mtp->addr == EMPADDR)
  continue;
      if (mtp->addr > *idmaxa)
  *idmaxa = mtp->addr;

      while (rpp = db_trav_rpnext(CHAN_TMP, CHAN_TALL))
  {
    if (rpp->addr == EMPADDR)
      continue;
    if (rpp->addr < *rpmina)
      *rpmina = rpp->addr;
  }
    }
}

void db_clr_allrp()
{
  db_trav_reset(CHAN_TMP);  /* initialize */

  struct mtinfo *mtp = NULL;
  while (mtp = db_trav_mtnext(CHAN_TMP))
    {
      struct rpinfo *rp; /* rp to random delete */

      db_trav_rpreset(CHAN_TMP);
      for (; ;)
      {
        if ((rp = db_trav_rpnext(CHAN_TMP, CHAN_TALL)) == NULL)
          break;
        if (memcmp(rp->rpid, mtivd, IDLEN) == 0) /* invalid */
          break;
        rp->node.failtms = 0x40;
      }
      watchdog();
    }

  return;
}

int db_delrp(unsigned char *mtid, unsigned char *rpid)
{
  return hash_delrp(mtid, rpid);
}

int db_find_pos(const unsigned char *str, size_t len)
{
  return hash_find_pos(str,len);
}

struct hmtcell ** db_get_idtab()
{
  return get_idtab();
}

extern unsigned int flag_db_new_eeprom;
static int db_new()
{
  unsigned char *cpr = "Ebstsofb", state;  /* ������Ebstsoft��������Ļ��� */
#if 1
  if ((memcmp(_share.newcmp, cpr, sizeof(_share.newcmp)) == 0))
    return 0;
#endif

  /* write mode = RT-III */
    _share.mode_state = RTSTA_IV_III_FORMAT;

  db_format();
  
  eeprom_read(DBSHARE + offset(struct share, mode_state), &_share.mode_state, 1);
  _share.flag = 0x57;//Ĭ������Ϊ0x57ģʽ  _share.flag = MDTYPE;
#if 0  
  /* ����3���������0x55ģʽ */
  _share.conswitch = 0x1d;
  _share.flswitch = 0x1c;
  _share.plswitch = 0x1d;
#else
  /* ����3���������0x57ģʽ */
  _share.conswitch = 0x1d;
  _share.flswitch = 0x1d;
  _share.plswitch = 0x1d;
#endif
  memcpy(_share.newcmp, cpr, sizeof(_share.newcmp));
  eeprom_write(DBSHARE, (unsigned char *)&_share, sizeof(_share));
  
  flag_db_new_eeprom++;

  return -1;
}

struct rpinfo *db_findrp(unsigned char *mtid, unsigned char *rpid)
{
  return hash_findrp(mtid, rpid);
}

static int db_ivdrp(unsigned char rpid[])
{
  if (memcmp(rpid, mtivd, IDLEN) == 0)
    return 0;
  if (hash_find(rpid) == NULL)
    return 0;

  return -1;
}

extern unsigned int flag_db_flushmt_eeprom;
static void db_flushmt(struct mtinfo *mtptr, ADDRESS idmaxa)
{
  ADDRESS rpaddr = 0,nulladdr = 0x0000;
  ADDRESS curaddr = mtptr->addr + offset(struct mtnode, rpp), *hashaddr = &((ADDRESS)(mtptr->node.rpp));
  ADDRESS phaaddr = mtptr->addr + offset(struct mtnode, phase);
  ADDRESS hopaddr = mtptr->addr + offset(struct mtnode, succhops);
  unsigned char c = EMPFLAG, data = mtptr->node.succhops & NFSUC;

  if((mtptr->node.sno[0] & NNEWMASK) && (mtptr->node.succhops & NFSUC))
  {
    db_write(hopaddr, &data, 1);
    data = mtptr->node.envi & NFHMASK;
    db_write(mtptr->addr + offset(struct mtnode, envi), &data, 1);
    db_write(phaaddr, (unsigned char *)&mtptr->node.phase, sizeof(mtptr->node.phase));
    
    flag_db_flushmt_eeprom++;
    
    return;
  }
  if(mtptr->rpl == NULL)
    return;

  struct hrpcell *hrp = mtptr->rpl;
  do
    {
      if (db_ivdrp(hrp->hcell.rpid) == 0)
  {
    if (hrp->hcell.addr != EMPADDR)
      {
        db_write(hrp->hcell.addr, &c, sizeof(c));
        
        flag_db_flushmt_eeprom++;
        
        bm_add(hrp->hcell.addr, RPCN);
        hrp->hcell.addr = EMPADDR;
      }
  }
      else
  {
    if (hrp->hcell.addr == EMPADDR)
      {
        if ((bm_get(RELAY, RPCN, &rpaddr) != 0) || (rpaddr <= idmaxa + CELL))
    {
      seterr(DBERR_MTMOF);
      continue;
    }
        if ((rpaddr % CELL != 0) || (rpaddr >= DBEND))
    {
      seterr(DBERR_BM);
      continue;
    }
        bm_del(rpaddr, RPCN);
        hrp->hcell.addr = rpaddr;
        hrp->hcell.node.nextrp = 0x0000;
      }
    rpaddr = hrp->hcell.addr;
    hrp->hcell.node.attr &= ~CELLMASK;
    hrp->hcell.node.attr |= RPFLAG;
    db_write(rpaddr, (unsigned char *)&hrp->hcell.node, sizeof(struct rpnode));

    //mtptr->node.succhops &= NHMASK; /* clear success flag */
          //mtptr->node.succhops &= ~NSUCC & ~NREACH;
    db_write(curaddr, (unsigned char *)&rpaddr, sizeof(rpaddr));

    flag_db_flushmt_eeprom++;
      
    *hashaddr = rpaddr;
    curaddr = hrp->hcell.addr + offset(struct rpnode, nextrp);
    hashaddr = &((ADDRESS)(hrp->hcell.node.nextrp));
  }
    }
  while ((hrp = hrp->next) != NULL);

  *hashaddr = 0x0000;
  data = mtptr->node.succhops;
  data &= ~NSUCC & ~NREACH;
  db_write(hopaddr, (unsigned char *)&mtptr->node.succhops, sizeof(mtptr->node.succhops));
  db_write(phaaddr, (unsigned char *)&mtptr->node.phase, sizeof(mtptr->node.phase));
  db_write(curaddr, (unsigned char *)&nulladdr, sizeof(nulladdr));
    
  flag_db_flushmt_eeprom++;
    
}
#if 0
static void para_init()
{
  unsigned int u, uid[3];

  eeprom_read(DBPBEGIN, (unsigned char *)&_rtparas, offset(struct rtpara, eepend));
  _rtparas.slevel = 0x02;
  _rtparas.wrkno = 1;
  _rtparas.regsno = 0;
  _rtparas.brdclose = 1;
  _rtparas.areset = 0x00;
  if((_rtparas.maxsno[0] == 0 && _rtparas.maxsno[1] == 0) || (_rtparas.maxsno[1] >= 0x6F)
     ||(_rtparas.maxsno[0] > 0x6F))
  {
    _rtparas.maxsno[0] = 0x01;
    _rtparas.maxsno[1] = 0x00;
  }
  memcpy(_rtparas.minsno, _rtparas.maxsno, SNOLEN);

  /* if generate sinkid ?? */
  eeprom_read(DBSHARE + offset(struct share, jzqid), _rtparas.jzqid, sizeof(_rtparas.jzqid));

  get_rand_info(&uid[0]);
  u = uid[0] + uid[1] + uid[2];
  u ^= uid[0];
  u ^= uid[1];
  u ^= uid[2];
  srand(u);

  _rtparas.sinkid[0] = rand() % 0x63;
  _rtparas.sinkid[1] = rand() % 0x63;
  for (int i = 0; i < 3; i++)
    {
      if(_rtparas.sinkid[0] == 0x00 && _rtparas.sinkid[1] == 0)
  {
    _rtparas.sinkid[0] = rand() % 0x63;
    _rtparas.sinkid[1] = rand() % 0x63;
  }
      else
  break;
    }
  eeprom_write(DBPBEGIN, (unsigned char *)&_rtparas, offset(struct rtpara, eepend));
}
#endif
static int data_all_same(unsigned char data[],int len , unsigned char same)
{
  int i;
  for( i = 0x00 ; i < len ; i++)
  {
    if(data[i] != same) break;
  }
  if( i >= len) return(0x01);
  return(0x00);
}

static int rt_incrsno(unsigned char *maxsno)
{
  if (++maxsno[0] > 0x6F)
    {
      maxsno[0] = 0;
      if (++maxsno[1] > 0x6F)
  {
          maxsno[1] = 0;
    ++maxsno[0];
  }
    }
  return 0;
}

int db_regnum_53()
{
  int num = 0;
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
    {
      if(mt->node.sid != 0xFFFF) /* sid��Ϊ0xFFFF, ��Ϊע��ɹ� */
        num++;
      
      watchdog();
    }
  return num;
}

int db_find_vsid(unsigned short sid)
{
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    if (mt->node.sid == sid)
      return 1;  /* ˵��������sid */

    watchdog();
  }

  return 0;
}


struct mtinfo* db_vsid(unsigned short sid)
{
  struct mtinfo *mt;

  db_trav_reset(CHAN_TMP);
  while ((mt = db_trav_mtnext(CHAN_TMP)) != NULL)
  {
    if (mt->node.sid == sid)
      return mt;  /* ˵��������sid */

    watchdog();
  }

  return NULL;
}
