/******************************************************************
*	�ൺ�������Լ������޹�˾
*	�ļ���		interrupt.c
*	�汾��		v2.00
*	ժҪ��		ϵͳ�ж����������жϴ�������
*	�����ˣ�	����
*	����ʱ�䣺	2009-06-05
******************************************************************/
#include "stm8s_conf.h"
#include "stm8s_type.h"
#include "stm8s.h"
#include "config.h"
#include "main.h"
#include "dev_ctrl.h"

@near void _stext();	 /* startup routine */

typedef void @far  (*interrupt_handler_t)(void);

struct interrupt_vector
{
	unsigned char interrupt_instruction;
	interrupt_handler_t interrupt_handler;
};
@far  @interrupt void NonHandledInterrupt(void)
{
	/*
	   in order to detect unexpected events during development,
	   it is recommended to set a breakpoint on the following instruction
	*/
}

@far @interrupt void UART2TX_Interrupt(void)
{
	uint8 c;

	if(((UART2->SR) & (1 << (UART2_IT_TC & 0x0F))))
	{
		if(uart_chn_tx_byte(CHN_RS485,&c))
		{
			/* Write one byte to the transmit data register */
			UART2->DR = c;
		}
		else
		{	   
            UART2_ITConfig(UART2_IT_TC, DISABLE); 
            ENABLE_RS485_RX();
		}    
	}
}

@far @interrupt void UART2RX_Interrupt(void)
{
	uint8 c; 

	if(((UART2->SR) & (1 << (UART2_IT_RXNE & 0x0F))))
	{
		/* Read one byte from the receive data register */ 
		c = UART2->DR;     
        if (uart_chn_rx_byte(CHN_RS485,c))
        {
            uart_rx_hook(CHN_RS485);
        }	        
	}
	if(0x00 != ((UART2->SR) & (1 << (UART2_FLAG_OR_LHE & 0x0F))))
	{
		//over run
		c = UART2->DR;
	}
}
extern vuint8 calibtate_tick;

@far @interrupt void TIM1_CAP_COM_IRQHandler(void)
{
    uint16 capture; 
    struct soft_uart_chn *pchn;   
    /* PLC chn rx  chn 4 */
    if (TIM1_GetITStatus(TIM1_IT_CC4))
    {
        TIM1_ClearITPendingBit(TIM1_IT_CC4);
        pchn = &_uart_chns[0];   

        capture = TIM1_GetCapture4();
        if (0x00 == pchn->rx.bitcnt)
        {
            soft_uart_chnINF_rx_cfg(DISABLE);
            if ((0 == calibtate_tick) && (MEASURE_START == measure_state))
            {
                calibtate_tick = 250; 
                START_CALIBRATION();
            }
            capture += pchn->bit_interval >> 2;
            capture += pchn->bit_interval ;
            TIM1_OC4Init(capture);
            pchn->rx.bitcnt = 1;   
            pchn->rx.data = 0x00; 
            pchn->rx.bit = 0x01;  
        }
        else if (pchn->rx.bitcnt < pchn->databitcnt- 1)
        {
            if (RXPLC_VALUE())
            {
                pchn->rx.data |= pchn->rx.bit ;
            }
            pchn->rx.bit <<= 0x01;
            pchn->rx.bitcnt ++;
            capture += pchn->bit_interval;
            TIM1_SetCompare4(capture);  
        }
        else
        {
            if (RXPLC_VALUE())
            {
                pchn->rx.data |= pchn->rx.bit ;
            }
            TIM1_chn4_capture();
            if (get_soft_uart_rx_data(pchn))
            {
                uart_rx_hook(CHN_PLC); 
            }
            soft_uart_chnINF_rx_cfg(ENABLE);
            pchn->rx.bitcnt = 0;    
        }     
    }
    /* chn PLC tx */
    if (TIM1_GetITStatus(TIM1_IT_CC3))
    {
        TIM1_ClearITPendingBit(TIM1_IT_CC3);  
        pchn = &_uart_chns[0];

        capture = TIM1_GetCapture3();
        capture += pchn->bit_interval; 
        TIM1_SetCompare3(capture); 
        // GPIOC->BRR = GPIOC->BSRR = 1;

        if (pchn->tx.bitcnt--  > 0)
        {
            if (pchn->tx.data & pchn->tx.bit)
            {
                TXPLC_SET();
            }
            else
            {
                TXPLC_CLR();
            }
            pchn->tx.bit <<= 0x01;
        }
        else
        {
            TXPLC_SET(); 
            if (get_soft_uart_tx_data(pchn))
            {
                pchn->tx.bitcnt = pchn->databitcnt; 
                pchn->tx.bit = 0x01;        
                //uart_tx_hook(CHN_PLC);
            }
            else
            {
                TIM1_ITConfig(TIM1_IT_CC3,DISABLE); 
            }
        }    
    }
    /* infrared chn rx  chn 1 */
    if (TIM1_GetITStatus(TIM1_IT_CC1))
    {
        TIM1_ClearITPendingBit(TIM1_IT_CC1);
        pchn = &_uart_chns[1];   

        capture = TIM1_GetCapture1();
        if (0x00 == pchn->rx.bitcnt)
        {
            capture += pchn->bit_interval >> 2;
            capture += pchn->bit_interval ;
            TIM1_OC1Init(capture);
            pchn->rx.bitcnt = 1;   
            pchn->rx.data = 0x00; 
            pchn->rx.bit = 0x01;  
        }
        else if (pchn->rx.bitcnt < pchn->databitcnt- 1)
        {
            if (RXINF_VALUE())
            {
                pchn->rx.data |= pchn->rx.bit ;
            }
            pchn->rx.bit <<= 0x01;
            pchn->rx.bitcnt ++;
            capture += pchn->bit_interval;
            TIM1_SetCompare1(capture);  
        }
        else
        {
            if (RXINF_VALUE())
            {
                pchn->rx.data |= pchn->rx.bit ;
            }
            TIM1_chn1_capture();
            if (get_soft_uart_rx_data(pchn))
            {
                uart_rx_hook(CHN_INFRARED); 
            }

            pchn->rx.bitcnt = 0;    
        }     
    }
    /* chn infrared tx */
    if (TIM1_GetITStatus(TIM1_IT_CC2))
    {
        TIM1_ClearITPendingBit(TIM1_IT_CC2);   
        pchn = &_uart_chns[1];
        capture = TIM1_GetCapture2();

        capture += pchn->bit_interval; 
        TIM1_SetCompare2(capture); 
        
        if (pchn->tx.bitcnt--  > 0)
        {
            if (pchn->tx.data & pchn->tx.bit)
            {
                TIM2->CR1 &= (u8)(~TIM2_CR1_CEN);
                TXINF_SET();
            }
            else
            {
                TIM2->CR1 = (u8)TIM2_CR1_CEN;
                TXINF_CLR();
            }
            pchn->tx.bit <<= 0x01;
        }
        else
        {
            TIM2->CR1 &= (u8)(~TIM2_CR1_CEN);
            TXINF_SET();

            if (get_soft_uart_tx_data(pchn))
            {
                pchn->tx.bitcnt = pchn->databitcnt;
                pchn->tx.bit = 0x01;
            }
            else
            {
                TIM1_ITConfig(TIM1_IT_CC2,DISABLE);   
                TIM1->IER |= (u8)TIM1_IT_CC1;
                infrared_gpio();
            }
        }    
    }
} 

#if 1
u16 TIM3_GetCapture1(void)
{
    /* Get the Capture 1 Register value */
    u16 tmpccr1 = 0;
    u8 tmpccr1l=0, tmpccr1h=0;

    tmpccr1h = TIM3->CCR1H;
    tmpccr1l = TIM3->CCR1L;

    tmpccr1 = (u16)(tmpccr1l);
    tmpccr1 |= (u16)((u16)tmpccr1h << 8);
    /* Get the Capture 1 Register value */
    return(u16)tmpccr1;
}


u16 TIM3_GetCapture2(void)
{
	/* Get the Capture 2 Register value */
	u16 tmpccr2 = 0;
	u8 tmpccr2l=0, tmpccr2h=0;

	tmpccr2h = TIM3->CCR2H;
	tmpccr2l = TIM3->CCR2L;

	tmpccr2 = (u16)(tmpccr2l);
	tmpccr2 |= (u16)((u16)tmpccr2h << 8);
	/* Get the Capture 2 Register value */
	return(u16)tmpccr2;
}
#endif

@far @interrupt void TIM3_CAP_COM_IRQHandler(void)
{
    static uint16 first_capture,last_capture;

    if(TIM3->SR1 & TIM3_IT_CC1)
	{
		TIM3->SR1 = (u8)(~TIM3_IT_CC1);
		if((MEASURE_START != measure_state))
		{
			return;
		}
		first_capture = TIM3_GetCapture1();
		measure_state = MEASURE_INPROGRESS;
	}
	if(TIM3->SR1 & TIM3_IT_CC2)
	{
		TIM3->SR1 = (u8)(~TIM3_IT_CC2); 
		if(MEASURE_INPROGRESS != measure_state)
		{
			return;
		}
		last_capture = TIM3_GetCapture2();
		diff = (last_capture - first_capture);
		
		TIM3->IER = 0x00;//disable the interrupt
		TIM3->CR1 = 0x00;//disable the tim2
		measure_state = MEASURE_COMPLETED;
	}
}

@far @interrupt void TIM4_UPD_OVF_IRQHandler(void)
{ 
    TIM4->SR1 = (u8)(~TIM4_IT_UPDATE);
    __sys_tick += 2;
}
struct interrupt_vector const _vectab[] = {
	{0x82, (interrupt_handler_t)_stext},			//Reset
	{0x82, NonHandledInterrupt}, /* trap  */
	{0x82, NonHandledInterrupt}, /* irq0  */
	{0x82, NonHandledInterrupt}, /* irq1  */
	{0x82, NonHandledInterrupt}, /* irq2  */
	{0x82, NonHandledInterrupt}, /* irq3  */
	{0x82, NonHandledInterrupt}, /* irq4  */		//PortB
	{0x82, NonHandledInterrupt}, /* irq5  */
	{0x82, NonHandledInterrupt}, /* irq6  */		//PortD
	{0x82, NonHandledInterrupt}, /* irq7  */		//PortE
	{0x82, NonHandledInterrupt}, /* irq8  */
	{0x82, NonHandledInterrupt}, /* irq9  */
	{0x82, NonHandledInterrupt}, /* irq10 */
	{0x82, NonHandledInterrupt}, /* irq11 */
	{0x82, TIM1_CAP_COM_IRQHandler},/* irq12 */				//TIM1 Capture/Compare
	{0x82, NonHandledInterrupt}, /* irq13 */
	{0x82, NonHandledInterrupt}, /* irq14 */	//TIM2 Capture/Compare
	{0x82, NonHandledInterrupt}, /* irq15 */					//TIM3 Update/Overflow
	{0x82, TIM3_CAP_COM_IRQHandler},  /* irq16 */			//TIM3 Capture/Compare
	{0x82, NonHandledInterrupt},	  /* irq17 */	
	{0x82, NonHandledInterrupt},	  /* irq18 */
	{0x82, NonHandledInterrupt},	  /* irq19 */
    {0x82, UART2TX_Interrupt},        /* irq20 */         //UART2 Tx interrupt
    {0x82, UART2RX_Interrupt},        /* irq21 */        //UART2 Rx interrupt
    {0x82, NonHandledInterrupt},	  /* irq22 */
    {0x82, TIM4_UPD_OVF_IRQHandler},  /* irq23 */
};
