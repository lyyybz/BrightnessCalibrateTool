/*
 * �汾: V1.02 �޸�ʱ��:2010-03-23 ���ķ�
 * �Ķ�(��� V1.01)
 * ��Զ��Ͳɼ�������PCB����֮��[PLC485MS-GW-II(v1.02)],�ɼ���������Ӧ��������:
 * 1.PCB��485���ز��Ľ��չܽŶԵ���,�Դ˳������,`1.�ܽŶ������,`2.ģ�⴮��ͨ������
 * 2.PCB��485���ز���ָʾ�ƹܽŶԵ���,�Դ˳������,`1.�ܽŶ������.
 *  
 * �汾: V1.1 �޸�ʱ��:2010-04-07 ���ķ� 
 * �Ķ�(��� V1.02) 
 * ֧�ֲɼ�����ַ 
 * ֧�ֶ�ȡ�ɼ��������汾�� 
 * ���36GM��3����3.5��,�ȴ�ʱ����ӳ�,�ɼ�������ȥ��ÿ��100ms��FEι36GM 
 */

#include "stm8s_conf.h"
#include "config.h"
#include "dev_ctrl.h"
#include "headfiles.h"
#include "main.h"
#include "comfunc.h"

void clr_mt_rep_flag(uint8 addr[]);

@near uint8 s[212];//645 datalen <=200
static uint8 chn_back = 0xFF;
//chn_back   0x0f��ͨ��ͨ��
//           0x30������ʹ��������
//           0x80: ����ʹ�õ�ַ��ʽ

@near vuint8 radiate_tick = 0;
@near vuint8 rx485_valid_tick = 0;
@near uint8 cjq_addr[0x06];

#if SKMT_CONFIG
@near struct s_meter mp_slot_pool[MAX_MP_CNT];
@near static struct _CHN_SLOT skmt_slot;
@near static uint8 skaddress[6];
@near static uint8 sk_no;
@near uint8 skmt_protocol;
#endif
#if SHANG_HAI
@near uint8 meter_addr[0x06];
@near uint8 rx485_bps = 0;
#endif
//@near vuint8 meteradd_valid_tick = 0;
@near struct _READY_TASK_FLAG task_flag;

uint8 is_rd_ver(struct frame645 *pframe)
{
    uint8 result = 0;
    const unsigned char rdverid1_07[] = {0x01,0x01,0xA0,0x04};   
    const unsigned char rdverid2_07[] = {0x01,0x00,0x80,0x04};  
    const unsigned char rd_hw_ver[]={0x02,0x00,0x80,0x04};//0x04800002
#if JIANG_SU
    const unsigned char ver[]= "PLCM1641-II(V1.8)-JS-121122";
#else    
    const unsigned char ver[]= "PLCM1641-II(V1.5)-121122";
#endif        
#if defined(STM8S105)
    const unsigned char hw_ver[]= "PLCM1641-II(v3.5)-STM8S005x";
#else defined(STM8S103)
    const unsigned char hw_ver[]= "PLCM1641-II(v3.5)-STM8S103x";
#endif

	if((0x00 == memcmp_my(rdverid1_07,pframe->data,pframe->datalen))
       || (0x00 == memcmp_my(rdverid2_07,pframe->data,pframe->datalen)))
	{
        memset_my(&pframe->data[pframe->datalen], 0x20, 32);
        mymemcpy(&pframe->data[pframe->datalen], ver, strlen(ver));
        result = 32; 
	}
    else if(0x00 == memcmp_my(rd_hw_ver,pframe->data,pframe->datalen))
    {
        memset_my(&pframe->data[pframe->datalen], 0x20, 32);
        mymemcpy(&pframe->data[pframe->datalen], hw_ver, strlen(hw_ver));
        result = 32; 
    }
	return(result);
}

#if SHANG_HAI
uint8 is_set_baud(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x04+0x33,0x07+0x33,0x00+0x33,0x04+0x33};

    if ((0x14 != pframe->control_code.control_byte)
        || (pframe->datalen > 0x0c+ 6)) {
        return(0);
    }
    if (0x00 == memcmp_my(rdverid07,pframe->data,4)) {
        return(1);
    }
    return(0);
}
#endif
#if SKMT_CONFIG
uint8 read_mp_slot(struct frame645 *pframe)
{
    uint8 i, cnt = 0;
    const unsigned char rdverid07[] = {0x01,0x03,0xA0,0x04};
    const unsigned char rdverid07_bord[] = {0x01+0x33,0x03+0x33,0xA0+0x33,0x04+0x33};

    if(0x00 == memcmp_my(rdverid07_bord,pframe->data,4))
    {
        buf_add_value(pframe->data, pframe->datalen, -0x33);
        goto rd_lbl;
    }
    if (0x00 != memcmp_my(rdverid07,pframe->data,4))
    {
        return(0);
    }
rd_lbl:
    for (i = 0; i < MAX_MP_CNT; i++)
    {
        if (mp_slot_pool[i].protocol)
        {
            mymemcpy(&pframe->data[pframe->datalen+1+cnt*7], (uint8 *)&mp_slot_pool[i], 7);
            cnt++;
        }
    }
    pframe->data[pframe->datalen] = cnt;
    return(cnt*7 +1);
}
void start_skmt(void)
{
    if((task_flag.doing_task == SEEK_MT) || (task_flag.pending_task == SEEK_MT)) return;
    //�����ѱ�,ÿ�������ѱ������ԭ��������485��
    memset_my((uint8 *)&mp_slot_pool, 0x00, sizeof(mp_slot_pool));
    skmt_protocol = PROTOCOL_07;
    task_flag.pending_task = SEEK_MT;
    skmt_re_init();
}
#endif
#if JIANG_SU
uint8 read_lost_cnt(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x01,0x02,0xA0,0x04};

    if (0x00 != memcmp_my(rdverid07,pframe->data,4)) 
	{
        return(0);
    }
    EEP_Read(OF_POWER_LOST_CNT, &pframe->data[pframe->datalen], 2);
    return(2);
}
uint8 system_init(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x01+0x33,0x04+0x33,0xA0+0x33,0x04+0x33};
    uint8 data[2];

    if ((0x14 != pframe->control_code.control_byte)
        || (pframe->datalen > 0x0c+ 1)) 
    {
        return(FRAME_ERROR);
    }
    if (0x00 != memcmp_my(&rdverid07[1],&pframe->data[1],3))
    {
        return(FRAME_ERROR);
    }
    switch (pframe->data[0]-0x33)
    {
    case 0x01:
    case 0x03:
        delay_reset_sys = 10;
        if(0x03 == pframe->data[0]-0x33)
        {
            EEP_Write_byte(OF_CHN485_VALID, 0x00);
        }
        break;
    case 0x02:
        data[0] = 0x00;
        data[1] = 0x00;
        EEP_Write(OF_POWER_LOST_CNT, data,0x02);
        memset_my((uint8 *)&mp_slot_pool, 0x00, sizeof(mp_slot_pool));//��������ʼ�����ӶԱ��ŵ����
  //      delay_reset_sys = 10;
        break;
//    case 0x03:
//        memset_my((uint8 *)&mp_slot_pool, 0x00, sizeof(mp_slot_pool));
//        break;
    default:
        return(FRAME_ERROR);
    }
    return(0);
}
uint8 rd_cjq_addr(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x03+0x33,0x03+0x33,0xA0+0x33,0x04+0x33};

    if ((0x11 != pframe->control_code.control_byte)
        ||(0x00 != memcmp_my(rdverid07,pframe->data,pframe->datalen)))
	{
        return(FRAME_ERROR);
    }
    buf_add_value(pframe->data,pframe->datalen, -0x33);
    mymemcpy(pframe->addr, cjq_addr, 6);
    mymemcpy(&pframe->data[pframe->datalen], pframe->addr, 6);
    return(6);
}

uint8 set_cjq_addr(struct frame645 *pframe)
{
    uint8 i;
    const unsigned char rdverid07[] = {0x03+0x33,0x03+0x33,0xA0+0x33,0x04+0x33};

    if((0x14 != pframe->control_code.control_byte)
       || (0x00 != memcmp_my(rdverid07,pframe->data,4)) 
       || (pframe->datalen != 0x12))
	{
        return(FRAME_ERROR);
    }
    if(!is_all_xx(&pframe->data[12], 0x00+0x33, 6)
       || !is_all_xx(&pframe->data[12], 0x99+0x33, 6))
    {
        return(FRAME_ERROR);
    }
    buf_add_value(pframe->data,pframe->datalen, -0x33);
    if(!is_data_all_bcd(&pframe->data[12], 6))
    {
        return(FRAME_ERROR);
    }
    mymemcpy(cjq_addr, &pframe->data[12], 6);
    EEP_Write(OF_ADDR, cjq_addr, 6);
    EEP_Write_byte(OF_ADDR_MAGIC,0x55);
    mymemcpy(pframe->addr, cjq_addr, 6);
    return(0);
}

uint8 rd_jzq_addr(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x00,0x03,0xA0,0x04};
    uint8 result=0;

    if(0x00 != memcmp_my(rdverid07,pframe->data,4)) 
    {
        return(0);
    }
    EEP_Read(OF_JZQ_ADDR, &pframe->data[pframe->datalen], 2);
    result += 2;
    pframe->data[pframe->datalen+result] = 0x01;
    result += 1;
    memset_my(&pframe->data[pframe->datalen+result], 0xff, 2);
    result += 2;
    pframe->data[pframe->datalen+result] = 0x00;
    result += 1;
    return(result);
}
uint8 set_jzq_addr(struct frame645 *pframe)
{
    const unsigned char rdverid07[] = {0x00+0x33,0x03+0x33,0xA0+0x33,0x04+0x33};
    unsigned char tmp[2];
    if ((0x14 != pframe->control_code.control_byte)
        || (0x00 != memcmp_my(rdverid07,pframe->data,4))
        || (0x0E != pframe->datalen))
    {
        return(FRAME_ERROR);
    }
    mymemcpy(tmp, &pframe->data[0x0C], 2);
    buf_add_value(tmp,2, -0x33);
    if(!is_data_all_bcd(tmp, 2))
    {
        return(FRAME_ERROR);
    }
    EEP_Write(OF_JZQ_ADDR, tmp, 2);
    return(0);
}
#endif

struct _radiate
{
	uint8 len;
	uint8 buf[22];
};
@near static struct _radiate radiate_tmp;
void radiate_retx(void)
{
	SET_CHN485_BAUD(1200);
    task_flag.doing_task = REALT_READ;//͸����������
	sys_uart_write(CHN_RS485,radiate_tmp.buf,radiate_tmp.len);
}
void radiate_opt(uint8 frame[],uint8 len)
{
	if(len > sizeof(radiate_tmp.buf)) return;

	SET_CHN485_BAUD(2400);
    task_flag.doing_task = REALT_READ;//͸����������
	sys_uart_write(CHN_RS485,frame,len);
	mymemcpy(radiate_tmp.buf,frame,len);
	radiate_tmp.len = len;
	radiate_tick = 10;
}

uint8 del_cjq_addr(struct frame645 *pframe)
{
	if(0x00 != memcmp_my(pframe->addr,cjq_addr,6))	return(0);
	if(pframe->datalen < 8) return(0);

	mymemcpy(pframe->addr,&pframe->data[pframe->datalen-6],6);
	buf_add_value(pframe->addr,6, -0x33);
	pframe->datalen -= 6;
	pframe->data[pframe->datalen] = checksum((const unsigned char*)pframe,pframe->datalen + 10);
	pframe->data[pframe->datalen+1] = 0x16;
	
	return(pframe->datalen + 12);
}
uint8 add_cjq_addr(struct frame645 *pframe)
{
	mymemcpy(&pframe->data[pframe->datalen],pframe->addr,6);
	buf_add_value(&pframe->data[pframe->datalen],6, 0x33);
	mymemcpy(pframe->addr,cjq_addr,6);
	pframe->datalen += 6;
	pframe->data[pframe->datalen] = checksum((const unsigned char*)pframe,pframe->datalen + 10);
	pframe->data[pframe->datalen+1] = 0x16;
	
	return(pframe->datalen + 12);
}

#if SHANG_HAI
uint8 get_485_baud(uint8 b)
{
    uint8 i;
    unsigned char baud[] = {96, 48, 24, 12};
    unsigned char bps[] = {0x03, 0x02, 0x01, 0x00};

    for (i = 0; i < sizeof(bps); i++) {
        if (b == bps[i]) {
            return(baud[i]);
        }
    }
    return(baud[2]);
}
#endif
#if SKMT_CONFIG
uint8 is_rd_mt_info(struct frame645 * pframe)
{
    uint8 i, len = 0;

#if JIANG_SU
    skmt_delay = 4*60;
#endif
    for(i = 0; i < MAX_MP_CNT; i++)
    {
        if(0x00 == memcmp_my(pframe->addr, mp_slot_pool[i].addr, 6)) break;
    }
    if(i < MAX_MP_CNT)
    {
        pframe->data[pframe->datalen] = mp_slot_pool[i].protocol;
        pframe->data[pframe->datalen+1] = mp_slot_pool[i].protocol;
    }
    else if(0x00 == memcmp_my(pframe->addr, cjq_addr, 6))
    {
        pframe->data[pframe->datalen] = 0x02;
        pframe->data[pframe->datalen+1] = 0x04;
    }
    else
    {
        return(0);
    }
    mymemcpy(&pframe->data[pframe->datalen+2], cjq_addr, 6);
    buf_add_value(pframe->data,pframe->datalen, -0x33);
        
    return(pframe->datalen+2+6);
}
#endif
@near const uint8 up_channel[] = {CHN_INFRARED, CHN_PLC};
#if 1
void scan_up_channel(void)
{
	uint8 i, result, len,reallen = 0, baud = 12, status = 0;
	struct frame645 *pframe;

    //���485�����Ƿ�����ʹ��
    if((REALT_READ != task_flag.doing_task)
       && (NOING_READ != task_flag.doing_task))
    {
        return;
    }

    for(i = 0; i < sizeof(up_channel); i++)
    {
        len = sys_uart_peek_data(up_channel[i], s, sizeof(s));
        if(len == 0)
        {
            continue;
        }

        pframe = get_645_frame(s, len,up_channel[i]);
        if(NULL == pframe)
        {
            continue;
        }
        sys_uart_read(up_channel[i], s, len);
        if(CHN_PLC == up_channel[i])
        {
            set_led(PLC_RX_LED);
        }
        if((0x0A == pframe->control_code.control_byte) || (0x15 == pframe->control_code.control_byte))
        {
            if(set_addr(pframe)) continue;//write cjq addr
        }
        else if(0x13 == pframe->control_code.control_byte)
        {
            reallen = read_cjq_addr(pframe);
        }
        else if((pframe->data[0] == 0xAF+0x33) && (pframe->data[1] == 0x02+0x33))
        {
            reallen = read_cjq_addr_gm(pframe);
        }
#if SKMT_CONFIG            
        else if ((0x9F == pframe->control_code.control_byte) && (0x00 == pframe->datalen)) 
        {//�ز�Ӧ��
            clr_mt_rep_flag(pframe->addr);
            continue;
        }
#else
        else if ((0x9F == pframe->control_code.control_byte) && (0x00 == pframe->datalen)) 
        {
            if (memcmp_my(pframe->addr, cjq_addr , 6))
            {
                continue;
            }
        }
#endif
          
#if SKMT_CONFIG		
        else if (0x00 == is_all_xx(pframe->data, 0xAC+0x33, 4))
        {
            if (0x11 == pframe->control_code.control_byte)
            {
                reallen = is_rd_mt_info(pframe);
                if(0x00 == reallen) continue;
            }
            else if(0x00 == memcmp_my(cjq_addr,pframe->addr,6))
            {
                continue;
            }
            else
            {
                goto relayto485;
            }
        }
#endif    
        else if (0x00 == memcmp_my(cjq_addr,pframe->addr,6)) 
        {
            if((0x11 == (pframe->control_code.control_byte)) && (0x04 == pframe->datalen))
            {
                buf_add_value(pframe->data,pframe->datalen, -0x33);

                if(result = is_rd_ver(pframe)) reallen = result;
#if BAUD_CONFIG				
                else if(result = read_baud(pframe)) reallen = result;
#endif				

#if SKMT_CONFIG                
                else if (result = read_mp_slot(pframe)) reallen = result;
#endif                

#if JIANG_SU
                else if(result = read_lost_cnt(pframe)) reallen = result;
                else if(result = rd_jzq_addr(pframe))reallen = result;
#endif
                else
                {
                    buf_add_value(pframe->data,pframe->datalen, 0x33);
                    goto relayto485;
                }
                if (reallen >= 1)
                {
                    reallen += pframe->datalen;
                }
            }
#if BAUD_CONFIG			
            else if (is_set_baud(pframe)) 
            {
                reallen = set_baud(pframe);
            }
#endif            
#if JIANG_SU
            else if(FRAME_ERROR != (result = system_init(pframe))) 
            {
                reallen = result;
            }
            else if(FRAME_ERROR != (result = set_jzq_addr(pframe)))
            {
                reallen = result;
            }
#endif
            else
            {//need send to 485
                status = RELAY_DATA_TO_RS485;
            }
        }      
		else if(0x00 == is_all_xx(pframe->addr, 0x99, sizeof(pframe->addr)))
		{//�㲥��ַ
#if SKMT_CONFIG
            if((0x1F == (pframe->control_code.control_byte)) 
               && (0x00 == is_all_xx(pframe->data, 0xAB+0x33, 4)))
            {//0xABABABAB�����ѱ�����
                start_skmt();
                continue;
            }
            else
#endif
            {
                radiate_opt(s, len);
                continue;
            }
		}
#if JIANG_SU
        else if ((CHN_INFRARED == up_channel[i]) && (0x00 == is_all_xx(pframe->addr, 0xAA, 6)))
        {//ֻ�Ժ��������ƣ�û�жԵ�ַ�����ƣ���ַΪȫ0xAA
            if (FRAME_ERROR != (result = rd_cjq_addr(pframe))) reallen = result+pframe->datalen;
            else if (FRAME_ERROR != (result = set_cjq_addr(pframe))) reallen = result;
            else if (result = read_mp_slot(pframe))
            {
                if (is_all_xx(cjq_addr, 0xFF, 6))
                {
                    mymemcpy(pframe->addr, cjq_addr, 6);
                }
                reallen = result+pframe->datalen;
            }
            else
            {//need send to 485
                status = RELAY_DATA_TO_RS485;
            }
        }
#endif                
        else
        {
relayto485:
            status = RELAY_DATA_TO_RS485;
        }
        if(status != RELAY_DATA_TO_RS485)
        {
            len = form_645_frame(pframe,NULL,reallen); 
            sys_uart_write(up_channel[i],(unsigned char*)pframe,len);
            continue;
        }
        if ((pframe->control_code.control_byte & 0x10) 
            || (0x03 == pframe->control_code.control_byte))//07 meter pw
        {
#if BAUD_CONFIG            
            baud = get_485_baud(rx485_bps);
#else            
            baud = 24;
#endif            
        }
		if(0x10 == pframe->control_code.control_byte)
		{
			baud = 12; //clear max demand 97
		}
#if SHANG_HAI		
        if (pframe->control_code.control_bits.direction_flag) 
		{
            baud = 12;//shanghai prot
            if (0x00 == pframe->datalen) 
			{
                mymemcpy(meter_addr, pframe->addr, sizeof(meter_addr));
                pframe->addr[5] = 0xFF;
                pframe->addr[3] = BCD2BIN(pframe->addr[3]);
                pframe->data[pframe->datalen] = checksum((const unsigned char*)pframe,pframe->datalen + 10);
            }
        }
#endif        
		chn_back = up_channel[i];
		SET_CHN485_BAUD(baud*100);//Urat
        task_flag.doing_task = REALT_READ;//͸����������
        if(pframe->control_code.control_bits.direction_flag)
        {
            chn_back |= 0x10;
        }
#if ADDR_CFG
		reallen = del_cjq_addr(pframe);
		if(reallen > 0)
		{
			chn_back |= 0x80;
			sys_uart_write(CHN_RS485,(unsigned char*)pframe,reallen);
		}
		else
#endif
		{
			chn_back &= ~0x80;
			sys_uart_write(CHN_RS485,(unsigned char*)pframe,len-((unsigned char*)pframe - (unsigned char*)s));
		}
	}
}
#endif
#if SKMT_CONFIG
static uint8 skmt_97_flag = 0;
//ÿ�ο�ʼ�任bps,��Ҫʹ��ȫͨ���ַ�ж��Ƿ��¹��д�����485��
static void send_data_to_485(uint8 item[])
{
    uint8 frame1_97[] = {0xFE,0xFE,0x68,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0x68,0x01,0x02,0x43,0xC3,0x00,0x16};
    uint8 frame2_97[] = {0xFE,0xFE,0x68,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0x68,0x01,0x02,0x52,0xC3,0x00,0x16};
	uint8 frame07[]   = {0xFE,0xFE,0x68,0xAA,0xAA,0xAA,0xAA,0xAA,0xAA,0x68,0x11,0x04,0x33,0x33,0x34,0x33,0x00,0x16};
    struct frame645 *pframe = NULL;
    uint8 len, baud=12;

    len = sizeof(frame1_97);
    pframe = (struct frame645 *)&frame1_97[2];

    if(skmt_protocol == PROTOCOL_07)
    {//����ʹ�����ò�������������485��
        len = sizeof(frame07);
        pframe = (struct frame645 *)&frame07[2];
        baud = get_485_baud(rx485_bps);
    }
    else if(skmt_97_flag)
    {
        pframe = (struct frame645 *)&frame2_97[2];
    }
    if(NULL != item)
    {
        mymemcpy(pframe->data, item, 2);
        buf_add_value(pframe->data, 2, 0x33);
    }
    SET_CHN485_BAUD(baud*100);
    mymemcpy(pframe->addr, skaddress, 6);
    pframe->data[pframe->datalen] = checksum((uint8 *)pframe, pframe->datalen + 10);
    //������֯����
    sys_uart_write(CHN_RS485,((unsigned char*)pframe)-2,len);
    rx485_valid_tick = 20;//�����ʱ2s
}
#endif

void realt_read(struct frame645 *pframe, uint8 len)
{
	if((NULL == pframe) && rx485_valid_tick)
	{//δ���ܵ�����֡,δ��ʱ
		return;
	}
    task_flag.relay = 1;//�ٴβ鿴�����Ƿ���������Ҫת��
    task_flag.doing_task = NOING_READ;
    if(NULL == pframe) return;
    rx485_valid_tick = 0;
    set_led(RS485_RX);

#if SHANG_HAI	
    if (0x00 == pframe->control_code.control_bits.direction_flag) 
    {//shang hai meter address
        mymemcpy(pframe->addr, meter_addr, sizeof(meter_addr));
        pframe->data[pframe->datalen] = checksum((const unsigned char*)pframe,pframe->datalen + 10);
    }
#endif	
	if(((chn_back&0x0F)>=0) && ((chn_back&0x0F)<=2))
	{
#if ADDR_CFG		
        if (chn_back & 0x80) {
            len = add_cjq_addr(pframe);
            chn_back &= ~0x80;
        }
#endif        
        if((chn_back >> 4) != pframe->control_code.control_bits.direction_flag)
        {
            chn_back &= 0x0F;
            sys_uart_write(chn_back,(unsigned char*)pframe,len);
        }
	}
}
#if SKMT_CONFIG
void seekmeter_init(void)
{
    skmt_slot.data_cnt = 0x00;
    skmt_slot.data_max = 0x40;//�����ظ���(5*12)
    skmt_slot.tx = INVALID_PTR;
    skmt_slot.rx = INVALID_PTR;
}
void skmt_re_init(void)
{
    empty_a_chn_slot(&skmt_slot);
    memset(skaddress, 0xAA, 6);
    skaddress[0] =0;
    sk_no = 0;
}

uint8 skmt_step(void)
{
    uint8 k;

    skaddress[sk_no] = BCD2BIN(skaddress[sk_no]);
    skaddress[sk_no]++;
    if(skaddress[sk_no] > 99 )
    {
        //get another conflict id
        k = get_chn_bytes(&skmt_slot,&sk_no,1);
        if(k < 1) return(0);
        if(sk_no > 6) return(0);
        k = get_chn_bytes(&skmt_slot,skaddress,sk_no);
        if(k != sk_no)
        {
            return(0);
        }
        skaddress[sk_no] = 0;
    }
    skaddress[sk_no] = BIN2BCD(skaddress[sk_no]);
    return(1);
}
void skmt_notify_conflict(void)
{
    uint8 k;
    k = sk_no + 1;
    if( k > 5) return;
    put_chn_bytes(&skmt_slot,&k,1);
    put_chn_bytes(&skmt_slot,skaddress,k);
}
uint8 find_mt(uint8 addr[])
{
    uint8 i;

    for(i = 0 ; i < MAX_MP_CNT; i++)
    {
        if(0x00 == memcmp_my(mp_slot_pool[i].addr, addr, 6))
        {
            break;
        }
    }
    return(i);
}
void add_mt_infor(uint8 address[])
{
    static uint8 index = 0x00;

    if(find_mt(address) < MAX_MP_CNT) return;
    if(index >= MAX_MP_CNT) index = 0x00;    
    mp_slot_pool[index].protocol = skmt_protocol;
    mymemcpy(mp_slot_pool[index].addr, address, 6);
    mp_slot_pool[index].report_flag = 0x01;//485����ַ��Ч
    index++;
}
void get_485_addr(struct frame645 *pframe, uint8 len)
{
    if(rx485_valid_tick && (NULL == pframe)) return;
    if(NULL != pframe)
    {
        buf_add_value(pframe->data, pframe->datalen, -0x33);
        add_mt_infor(&pframe->data[2]);
    }
    task_flag.doing_task = SEEK_MT;
}

static uint8 mtaddr_item97[] = {0x32, 0xC0};//485����
void mt_read(struct frame645 *pframe, uint8 len)
{
    static uint8 wait_flag=0;
    if((rx485_valid_tick <= 10) && (0x00 == len) && (0x00==wait_flag)) goto skmt_step_lbl;//��������ٶ�

    if(rx485_valid_tick && (NULL == pframe)) return;

    if (NULL != pframe)
    {//bak meter address
        //����97��,��������ַ,�����жϵ�ַ��Ч,��ֹ���ֱ���ַΪ�·���ַ��ʽ
        if(0xAA == pframe->addr[5])
        {
            if(skmt_protocol == PROTOCOL_97)
            {
                send_data_to_485(mtaddr_item97);
                task_flag.doing_task = RD_ADDR;
                return;
            }
            else goto rd_skmt_lbl;
        }
        //�������ѵ�ַ���Ӧ�ĵ�ַ��ͬ
        if(memcmp_my(pframe->addr, skaddress, sk_no+1)) goto rd_skmt_lbl;
        add_mt_infor(pframe->addr);
        //�����������֡ǰ�������ݣ������ж��
        if((s != (uint8 *)pframe) && (is_all_xx(s, 0xFE, (uint8 *)pframe - s))) goto rd_skmt_lbl;
        if(rx485_valid_tick)
        {//�ȴ����ܳ��ֶ�֡���
            wait_flag = 1;
			return;
        }
    }
    else if(len)
    {
rd_skmt_lbl:
        skmt_notify_conflict();
        empty_a_chn_slot(&(uart_file_infor[CHN_RS485].rx_slot));
    }
skmt_step_lbl:
    if(0x00 == skmt_step())
    {//��ǰЭ�鲨��������485��ַ
        if(skmt_protocol == PROTOCOL_97)
        {//�����ѱ�
            if(0x00 == skmt_97_flag)
            {
                skmt_97_flag = 1;
                goto exit_lbl;
            }
            skmt_97_flag = 0;
            task_flag.pending_task = NOING_READ;
            task_flag.doing_task = NOING_READ;
            return;
        }
        if(skmt_protocol == PROTOCOL_07)
        {
            skmt_protocol = PROTOCOL_97;
        }
   exit_lbl:
        skmt_re_init();
    }
	wait_flag = 0;
    task_flag.pending_task = SEEK_MT;
    task_flag.relay = 1;
    task_flag.doing_task = NOING_READ;
}
#endif

#if SKMT_CONFIG
//0x80 -- report mt, 0x03-- mt
uint8 get_mt_rep_flag(void)
{
    uint8 i;

    for (i = 0 ; i < MAX_MP_CNT; i++)
    {
        if (mp_slot_pool[i].report_flag) //��485��ַ��Ҫ�ϱ�
        {
            break;
        }
    }
    return(i);
}
#endif

#if SKMT_CONFIG
static uint8 time_rep_mt_interval = 0;
void clr_mt_rep_flag(uint8 addr[])
{
    int8 index;
    
    if((index = find_mt(addr)) < MAX_MP_CNT)
    {
        mp_slot_pool[index].report_flag = 0x00;
        time_rep_mt_interval = 50;
    }
}

void event_report_hook(void)
{    
    uint8 tmp = 0x55;
    int8 index;

    if(time_rep_mt_interval++ > 100)
    {
        if((index = get_mt_rep_flag()) < MAX_MP_CNT)
        {
            sys_uart_write(CHN_PLC, &tmp, sizeof(tmp));
        }
        time_rep_mt_interval = 0;
    }
}
#endif

void scan_down_channel(void)
{
    uint8 len =0;
	struct frame645 *pframe;
    
    if(task_flag.doing_task)
    {
        len = sys_uart_peek_data(CHN_RS485, s, sizeof(s));
       
        pframe = get_645_frame(s, len,CHN_RS485);
        if(NULL != pframe)
        {
            len = pframe->datalen+12;
            sys_uart_read(CHN_RS485, s, (uint8 *)pframe-s+len);
        }
    }
    switch(task_flag.doing_task)
    {
    case REALT_READ://͸��
        realt_read(pframe, len);
        break;
#if SKMT_CONFIG        
    case SEEK_MT:
        mt_read(pframe, len);
        break;
    case RD_ADDR:
        get_485_addr(pframe, len);
        break;
#endif        
    default:
        task_flag.doing_task = NOING_READ;
        break;
    }
    if(task_flag.doing_task) return;//��ǰ����
#if SKMT_CONFIG 
    if(task_flag.relay)
    {
        task_flag.relay = 0;
        return;
    } 

    if (task_flag.pending_task) {
        task_flag.doing_task = task_flag.pending_task;
        task_flag.pending_task = NOING_READ;
    }  
    if (SEEK_MT == task_flag.doing_task) 
    {
        send_data_to_485(NULL);
    }
#endif    
}
#if ZHE_JIANG_MT_EVENT
uint8 init_event_frame(uint8 buf[])
{
    uint8 len = 0;

    memset_my(&buf[0], 0xAB, 4);
    len += 4;
   
    buf[len] = 0x01;
    len += 1;

    mymemcpy(&buf[len], meter_addr, 6);
    len += 6;   
    buf[len] = skmt_protocol;
    len += 1; 

    return(len);
}
#endif

void main(void)
{
	disableInterrupts();
	modules_init(); 
	enableInterrupts();   
#if SKMT_CONFIG
    seekmeter_init();//seekmeter_init();
#endif  
	while(1)
	{
        clr_wdt();
		timer_handle();//
		scan_up_channel();//����ͨ�����ݴ������ز�������
		scan_down_channel();//����ͨ�����ݴ�����485    
        general_hdl();//include function clear watch dog,wait for interrupt and so on .
        //wfi();//��������ģʽ���ȴ��жϻ��ѡ�
	}
}

