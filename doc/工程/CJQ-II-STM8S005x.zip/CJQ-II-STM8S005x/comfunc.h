#ifndef _COMFUNC_H_
#define _COMFUNC_H_

#include"headfiles.h"
#include "config.h"

#define offset_of(obj_type,mb)  ((unsigned int)&(((obj_type*)0)->mb))

#define GET_NBITS_VAL(val,x1,x2)            (((val)>>(x1))&((1<<((x2)-(x1)+1))-1))
//#define MIN(x,y)    (x > y ? y : x )
//#define MAX(x,y)    (x > y ? x : y )

#define BCD2BIN(x)  bcd2bin(x)

#define BIN2BCD(x)  bin2bcd(x)

uint8 bin2bcd(uint8 val);
uint8 bcd2bin(uint8 val);

struct frame645
{
    unsigned char frame_start_flag1;
    unsigned char addr[6];
    unsigned char frame_start_flag2;
    union
    {
        unsigned char control_byte;
        struct
        {
            unsigned char function_flag:5;
            unsigned char following_flag:1;
            unsigned char exception_flag:1;
            unsigned char direction_flag:1;
        } control_bits;
    } control_code;
    unsigned char datalen;
    unsigned char data[1];
};

enum RXTX_STATUS
{
    PLC_RX_LED=0x00,PLC_TX=0x01,RS485_RX=0x02,RS485_TX=0x03,NO_STATUS
};

uint8 checksum (const unsigned char *data,uint8 len);
struct frame645 *get_645_frame(unsigned char rxframe_raw[],uint8 rxlen, uint8 chn);
void mymemcpy(void *dst,void *src,uint8 len);
void buf_add_value(unsigned char buf[],uint8 len, int8 value);
void set_led(enum RXTX_STATUS status);
uint8 get_rxtx_status(void);
uint8 memcmp_my(const void *s1, const void *s2, uint8 n);
void memset_my(void *s1, uint8 value, uint8 n);
uint8 is_all_xx(const void *s1, uint8 value, uint8 n);
uint8 is_data_all_bcd(unsigned char data[], uint8 len );
#endif
