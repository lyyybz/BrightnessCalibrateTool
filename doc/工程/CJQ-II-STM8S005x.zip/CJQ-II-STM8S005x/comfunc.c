//#include <string.h>
#include "comfunc.h"
#include "headfiles.h"
#include "main.h"
#include "config.h"
uint8 bcd2bin(uint8 val)
{
    uint8 bin = 0; 
    while(val >= 0x10)
    {
        val -= 0x10;
        bin += 10;
    } 
    bin += val; 
    return(bin);
}
uint8 bin2bcd(uint8 val)
{
    uint8 bcd = 0 ;
    while(val >= 10)
    {
        val -= 10;
        bcd+= 0x10;
    } 
    bcd += val; 
    return(bcd);
}
void buf_add_value(uint8 buf[], uint8 len, int8 value)
{
    while(len-- > 0)
    {
		*(buf++) += value;
	}
}
uint8 checksum (const unsigned char *data,uint8 len)
{
	unsigned char cs = 0;

	while(len-- > 0)
		cs += *data++;
	return(cs);
}
struct frame645 *get_645_frame(unsigned char rxframe_raw[],uint8 rxlen, uint8 chn)
{
	uint8  i = 0;
	struct frame645 *pframe;
	uint8 framelen;

check_frame:
	while(i < rxlen)
	{
		if(0x68 == rxframe_raw[i])
			break;
		i++;
	}
	if(i>=rxlen)
    {
        if (CHN_INFRARED == chn)
        {
            empty_a_chn_slot(&(uart_file_infor[CHN_INFRARED].rx_slot));
        }
        return(NULL);
    }
	if(i>=rxlen) return(NULL);
	pframe = (struct frame645 *)(rxframe_raw+i);
	framelen = rxlen -i;
    if (framelen < 10 )  return(NULL);
	if(0x68 != pframe->frame_start_flag1) return(NULL);
	if(0x68 != pframe->frame_start_flag2)
	{
		i++;
		goto check_frame;
	}

	if (pframe->datalen +10+2 >framelen) return(NULL);

    if(pframe->data[pframe->datalen] != checksum(rxframe_raw+i, pframe->datalen +10)) return(NULL);
	if(pframe->data[pframe->datalen+1] !=0x16) return(NULL);
	return(pframe);
}
void mymemcpy(void *dst,void *src,uint8 len)
{
	while(len--)
	{
		*(char *)dst = *(char *)src;
		dst = (char *)dst + 1;
		src = (char *)src + 1;
	}
}
uint8 memcmp_my(const void *s1, const void *s2, uint8 n)
{
    while (n && *(char*)s1 == *(char*)s2) 
    {
        s1 = (char*)s1 + 1;
        s2 = (char*)s2 + 1;
        n--;
    }

    if(n > 0)
    {
        return(1);
    }
    return(0);
}
uint8 is_all_xx(const void *s1, uint8 value, uint8 n)
{
    while(n && *(char*)s1 == value)
    {
        s1 = (char*)s1 + 1;
        n--;
    }
    return(n);
}
uint8 is_data_all_bcd(unsigned char data[], uint8 len )
{
	uint8 i;
	for( i = 0x00 ; i < len ; i++) 
	{
		if(((data[i] & 0x0F) > 0x09)||((data[i] & 0xF0) > 0x90)) break;
	}
	if( i >= len) return(0x01);
	return(0x00);
}
void memset_my(void *s1, uint8 value, uint8 n)
{
    do
    {
        *(char*)s1 = value;
        s1 = (char *)s1 + 1;
    }
    while(--n);
}
#if 1
struct RXTX_QUEUE {
    uint8 cnt;
    uint8 queue;
};
static struct RXTX_QUEUE rxtx_queue;
/******************************************** 
 ָʾ�ƶ��д�������ӣ�
 ���������ȳ�����������ԭ��
 rxtx_queue.queue ��ǰ����
 rxtx_queue.cnt   ��ǰ�����е�ָʾ�Ƹ���
********************************************/
void set_led(enum RXTX_STATUS status)
{
    if (rxtx_queue.cnt < 0x04)
    {
        rxtx_queue.queue <<= 2;
        rxtx_queue.queue |= status;
        rxtx_queue.cnt++;
    }
}
/******************************************** 
 ָʾ�ƶ��д���������
 ���������ȳ�����������ԭ��
 rxtx_queue.queue ��ǰ����
 rxtx_queue.cnt   ��ǰ�����е�ָʾ�Ƹ���
********************************************/
uint8 get_rxtx_status(void)
{
    /* queue empty */
    if (0x00 == rxtx_queue.cnt) return(NO_STATUS);

    rxtx_queue.cnt--;
    return((rxtx_queue.queue >> (rxtx_queue.cnt<<1)) & 0x03);
}
#endif
