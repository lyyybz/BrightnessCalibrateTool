#ifndef _CONFIG_H_
#define _CONFIG_H_

#define DATA_SEG			@near
typedef signed long         int32;
typedef signed short        int16;
typedef signed char         int8;
typedef unsigned long       uint32;
typedef unsigned short      uint16;
typedef unsigned char       uint8;

typedef volatile signed long    vint32;
typedef volatile signed short   vint16;
typedef volatile signed char    vint8;

typedef volatile uint32         vuint32;
typedef volatile unsigned short vuint16;
typedef volatile unsigned char  vuint8;

typedef  unsigned short int time_t;

#define HSE_VALUE ((u32)16000000)
#define HSI_VALUE ((u32)16000000) /* Value of the Internal oscillator in Hz*/
#define SYS_CLK						HSI_VALUE

#define TIM_CLK_FREQUENCY			SYS_CLK
#define TICK_TIMER_FREQUENCY		((u32)500)

#define	CHN_PLC				0x00
#define	CHN_RS485		    0x01
#define CHN_INFRARED		0x02

#define ADDR_CFG	1
#define MAX_MP_CNT  8

#define GUANG_DONG	0x00
#define BAUD_CONFIG 0x01
#define SHANG_HAI	0x01
#define SKMT_CONFIG 0x01
#define JIANG_SU    0x01
#define ZHE_JIANG_MT_EVENT 0x00

/* each chn will delete the data received when cpu not operate after 1s */
#define	UART_CHAR_MAX_DELAY	30//100 ms unit

#define TXPLC_PIN		GPIO_PIN_3
#define TXPLC_PORT		GPIOC

#define RXPLC_PIN		GPIO_PIN_4
#define RXPLC_PORT		GPIOC

#define TXINF_PIN		GPIO_PIN_2
#define TXINF_PORT		GPIOC

#define RXINF_PIN		GPIO_PIN_1
#define RXINF_PORT		GPIOC

#define LED_485_PIN		GPIO_PIN_6
#define LED_485_PORT	GPIOC

#define LED_PLC_PIN		GPIO_PIN_5
#define LED_PLC_PORT	GPIOE

#if GUANG_DONG
    #define LED_ALARM_PIN	GPIO_PIN_6
    #define LED_ALARM_PORT	GPIOC
#else
    #define LED_STA_PIN		GPIO_PIN_0
    #define LED_STA_PORT	GPIOB
#endif

#if GUANG_DONG
    #define LED_TX_PIN	GPIO_PIN_5
    #define LED_TX_PORT	GPIOB
    #define LED_RX_PIN	GPIO_PIN_4
    #define LED_RX_PORT	GPIOB
#endif

#define PWM_38K_PIN		GPIO_PIN_4
#define PWM_38K_PORT	GPIOD

#define EN_485_PIN      GPIO_PIN_7
#define EN_485_PORT     GPIOD

#define SET_485_LED		do{(LED_485_PORT->ODR |= LED_485_PIN);}while(0)
#define RESET_485_LED	do{(LED_485_PORT->ODR &= ~(LED_485_PIN));}while(0)
#define SET_PLC_LED		do{(LED_PLC_PORT->ODR |= LED_PLC_PIN);}while(0)
#define RESET_PLC_LED	do{(LED_PLC_PORT->ODR &= ~(LED_PLC_PIN));}while(0)
#define RESET_PWM_PIN   do{(PWM_38K_PORT->ODR &= ~(PWM_38K_PIN));}while(0)
#if GUANG_DONG
    #define SET_ALARM_LED	do{(LED_ALARM_PORT->ODR |= LED_ALARM_PIN);}while(0)
    #define RESET_ALARM_LED	do{(LED_ALARM_PORT->ODR &= ~(LED_ALARM_PIN));}while(0)
    //#define SET_TX_LED	do{(LED_TX_PORT->ODR |= LED_TX_PIN);}while(0)
    //#define RESET_TX_LED	do{(LED_TX_PORT->ODR &= ~(LED_TX_PIN));}while(0)
    #define SET_TX_LED		do{(LED_TX_PORT->ODR &= ~(LED_TX_PIN));}while(0)
    #define RESET_TX_LED	do{(LED_TX_PORT->ODR |= LED_TX_PIN);}while(0)
    //#define SET_RX_LED	do{(LED_RX_PORT->ODR |= LED_RX_PIN);}while(0)
    //#define RESET_RX_LED	do{(LED_RX_PORT->ODR &= ~(LED_RX_PIN));}while(0)
    #define SET_RX_LED	    do{(LED_RX_PORT->ODR &= ~(LED_RX_PIN));}while(0)
    #define RESET_RX_LED	do{(LED_RX_PORT->ODR |= LED_RX_PIN);}while(0)
#else
    #define SET_STA_LED		do{(LED_STA_PORT->ODR |= LED_STA_PIN);}while(0)
    #define RESET_STA_LED	do{(LED_STA_PORT->ODR &= ~(LED_STA_PIN));}while(0)
#endif

#define GPIO_WriteHigh(port,pin) 	(port->ODR |= (uint8)pin)
#define GPIO_WriteLow(port,pin) 	(port->ODR &= (uint8)(~pin))
#define GPIO_ReadInputPin(port,pin) (port->IDR & pin)

#define	TXPLC_SET()					GPIO_WriteHigh(TXPLC_PORT,TXPLC_PIN)
#define	TXPLC_CLR()					GPIO_WriteLow(TXPLC_PORT,TXPLC_PIN)
#define	TXINF_SET()					GPIO_WriteHigh(TXINF_PORT,TXINF_PIN)
#define	TXINF_CLR()					GPIO_WriteLow(TXINF_PORT,TXINF_PIN)
#define	RXPLC_VALUE()				GPIO_ReadInputPin(RXPLC_PORT,RXPLC_PIN)
#define	RXINF_VALUE()				GPIO_ReadInputPin(RXINF_PORT,RXINF_PIN)

#define ENABLE_RS485_TX()              GPIO_WriteHigh(EN_485_PORT,EN_485_PIN)
#define ENABLE_RS485_RX()              GPIO_WriteLow(EN_485_PORT,EN_485_PIN) 

enum
{
    MEASURE_START = 0,MEASURE_INPROGRESS,MEASURE_COMPLETED,MEASURE_FAILED,MEASURE_DISABLE
};

#define OF_EEPROM_ADDRESS (0x4000)
#define OF_ADDR 	(0x00)
#define SZ_ADDR 	6
#define OF_ADDR_MAGIC 	(OF_ADDR + SZ_ADDR+2)
#define OF_CHN485_BAUD	(OF_ADDR_MAGIC+4)//shanghai 485bps
#define OF_CHN485_VALID (OF_CHN485_BAUD+4)
#define OF_POWER_LOST_CNT   (OF_CHN485_VALID + 4)
#define OF_CJQ_ADDR     (OF_POWER_LOST_CNT+2)
#define OF_JZQ_ADDR     (OF_CJQ_ADDR+6)

#define SET_CHN485_BAUD(baud) UART_DeInit(baud)

#define START_CALIBRATION()\
do{\
    TIM3->SR1 = 0x00;\
    TIM3->IER = TIM3_IER_CC1IE | TIM3_IER_CC2IE;\
    TIM3->CR1 = TIM3_CR1_CEN;\
}while(0)

#endif




