#ifndef _DEV_CTRL_H_
#define _DEV_CTRL_H_

#include "headfiles.h"
#include "alloter.h" 

typedef volatile unsigned char    OS_CPU_SR;

#define FRAME_OK        0x01
#define FRAME_ERROR     0xFF
#define TIMER_COUNT     0X64

#define RELAY_DATA_TO_RS485        0x55

#define sys_uart_peek_data(chn, buffer, len) peek_chn_byte(&(uart_file_infor[chn].rx_slot),buffer,len)

#define sys_uart_read(chn, buffer, len)   get_chn_bytes(&(uart_file_infor[chn].rx_slot),buffer,len)


#define  soft_uart_chnPLC_tx_cfg(state)     do{TIM1_ITConfig(TIM1_IT_CC3, state);}while(0) 
#define  soft_uart_chnPLC_rx_cfg(state)     do{TIM1_ITConfig(TIM1_IT_CC4, state);}while(0)//for v1.02
#define  soft_uart_chnINF_tx_cfg(state)     do{TIM1_ITConfig(TIM1_IT_CC2, state);}while(0)
#define  soft_uart_chnINF_rx_cfg(state)     do{TIM1_ITConfig(TIM1_IT_CC1, state);}while(0)//for v1.02

#define  OS_CRITICAL_METHOD   3
#define  OS_ENTER_CRITICAL()  do{cpu_sr = ITC_GetSoftIntStatus() & 0x08;disableInterrupts();}while(0)
#define  OS_EXIT_CRITICAL()   do{if(cpu_sr){ disableInterrupts();}else{ enableInterrupts(); }}while(0)

struct soft_uart
{
	vuint16 bit;
	vuint16 data;
	vint8 bitcnt;	 //tx or rx bit count
}; 

#define UART_CH_CNT                 0x03
#define  clr_wdt()	IWDG->KR = IWDG_KEY_REFRESH;//�忴�Ź�
struct _UART_FILE_INFOR
{
	struct _CHN_SLOT    tx_slot;
	struct _CHN_SLOT    rx_slot;
	uint8   chn_no;    
	uint8   busy_rxing; 
	uint8   over_time_tick;
};

struct soft_uart_chn
{
	struct soft_uart tx;
	struct soft_uart rx;   
	uint8 databitcnt;	//data bit count
	int bit_interval; 
	struct _UART_FILE_INFOR *puart;
};

#define UART_RX_FLAG(chn)					(1 << (0+(chn<<1)))
#define UART_TX_FLAG(chn)					(1 << (1+(chn<<1))) 

@near extern volatile struct soft_uart_chn _uart_chns[2];
@near extern volatile struct _UART_FILE_INFOR uart_file_infor[ UART_CH_CNT];
@near extern uint8 delay_reset_sys;
@near extern volatile time_t __sys_tick;
@near extern vuint8 measure_state;
@near extern vuint16 diff;
@near extern uint8 skmt_delay;

void uart_rx_hook(uint8 chn);
void sys_uart_write(uint8 chn,unsigned char buffer[],uint8 len);

void modules_init(void);
uint8 get_soft_uart_tx_data(struct soft_uart_chn *pchn);
uint8 get_soft_uart_rx_data(struct soft_uart_chn *pchn);

uint8 uart_chn_rx_byte(uint8 chn,uint8 c);
uint8 uart_chn_tx_byte(uint8 chn,uint8 buffer[]);

void chk_tick(void);
void swim2io(void);
uint8 form_645_frame(struct frame645 *pframe,uint8 data[],uint8 len);
uint8 set_addr(struct frame645 *pframe);
uint8 read_cjq_addr(struct frame645 *pframe);
uint8 read_cjq_addr_gm(struct frame645 *pframe);
//uint8 read_ver(struct frame645 *pframe);
uint8 set_baud(struct frame645 *pframe);
uint8 read_baud(struct frame645 *pframe);
void EEP_Read(uint8 addr, uint8 buf[], uint8 len);
void EEP_Write(uint8 addr, uint8 buf[], uint8 len);
void EEP_Write_byte(uint8 addr, uint8 data);
uint8 EEP_Read_byte(uint8 addr);
void empty_a_chn_slot(struct _CHN_SLOT *pCHN_SLOT);
uint8 count_bit_in_char(uint8 x); 
//void UART2_ITConfig(UART2_IT_TypeDef UART2_IT, FunctionalState NewState);
void infrared_gpio(void);
void general_hdl(void);
void timer_handle(void);
#endif

