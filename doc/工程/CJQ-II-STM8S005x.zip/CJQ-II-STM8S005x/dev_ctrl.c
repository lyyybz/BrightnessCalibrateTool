#include "dev_ctrl.h"
#include "config.h"
#include "stm8s_conf.h"
#include "stm8s.h"
#include "comfunc.h"
#include "main.h"

@near vuint8 measure_state = MEASURE_START;
@near vuint16 diff;
@near uint8 delay_reset_sys;
//extern @near vuint8 meteradd_valid_tick;
@near uint8 skmt_delay = 60;//�ϵ���ʱ�ѱ����������г�������ʱ�ѱ�

u8 ITC_GetCPUCC(void)
{
	_asm("push cc");
	_asm("pop a");
	return;	/* Ignore compiler warning, the returned value is in A register */
}
u8 ITC_GetSoftIntStatus(void)
{
	return(u8)(ITC_GetCPUCC() & CPU_CC_I1I0);
}

void TIM1_chn1_capture(void)
{
	TI1_Config();
	TIM1_ClearFlag(TIM1_FLAG_CC1);
} 
void TIM1_chn4_capture(void)
{
	TI4_Config();
	TIM1_ClearFlag(TIM1_FLAG_CC4);
} 

void infrared_gpio(void)
{
    TIM2_DeInit();
	GPIO_Init(PWM_38K_PORT,PWM_38K_PIN ,GPIO_MODE_OUT_PP_HIGH_FAST);//38k PD4
	RESET_PWM_PIN; 
}

void pwm_generator_init(void)
{
	TIM2_DeInit();

	TIM2->ARRH = (u8)((TIM_CLK_FREQUENCY / 38000) >> 8);//set auto reload value
	TIM2->ARRL = (u8)(TIM_CLK_FREQUENCY / 38000);

	TIM2->CCER1 = (u8)((TIM2_OUTPUTSTATE_ENABLE & TIM2_CCER1_CC1E) | (TIM2_OCPOLARITY_HIGH & TIM2_CCER1_CC1P));//low level avalid
	TIM2->CCMR1 = (u8)TIM2_OCMODE_PWM1;
	TIM2->CCR1L = (u8)(TIM_CLK_FREQUENCY / 38000 / 2);
}
void UART_DeInit(uint16 baud)
{
	UART2->CR1 = UART2_CR1_RESET_VALUE;

	UART2->CR1 |= (UART2_WORDLENGTH_9D | UART2_PARITY_EVEN); 

	UART2->CR3 |= UART2_STOPBITS_1;	

    UART2->BRR2 = (u8)(((SYS_CLK/baud >> 8) & 0xF0) | (SYS_CLK/baud & 0x0F));
    UART2->BRR1 = (u8)((SYS_CLK/baud >> 4) & 0xFF);

	UART2->CR2 = (u8)UART2_CR2_TEN | (u8)UART2_CR2_REN; 

    UART2->CR1 &= (u8)(~UART2_CR1_UARTD); 
}
    
void UART2_ITConfig(UART2_IT_TypeDef UART2_IT, FunctionalState NewState)
{
    u8 itpos = 0x00;

    itpos = (u8)((u8)1 << (u8)((u8)UART2_IT & (u8)0x0F));

	if(NewState != DISABLE)
	{
		UART2->CR2 |= itpos;
	}
	else
	{
		UART2->CR2 &= (u8)(~itpos);
	}
}

@near volatile struct _UART_FILE_INFOR uart_file_infor[UART_CH_CNT];
@near volatile struct soft_uart_chn _uart_chns[2];

void UART_CHN_Soft_Init(int chn)
{
	struct _UART_FILE_INFOR *puart_infor;    

	puart_infor = &uart_file_infor[chn];

	puart_infor->chn_no = chn;
	puart_infor->rx_slot.data_cnt = 0x00;
	puart_infor->rx_slot.data_max = 0xF0 ;
	puart_infor->rx_slot.tx = INVALID_PTR;
	puart_infor->rx_slot.rx = INVALID_PTR;

	mymemcpy(&puart_infor->tx_slot,&puart_infor->rx_slot,sizeof(puart_infor->rx_slot));

	puart_infor->over_time_tick = UART_CHAR_MAX_DELAY ;
}
void empty_a_chn_slot(struct _CHN_SLOT *pCHN_SLOT)
{
	unsigned char c;

	while(get_chn_bytes(pCHN_SLOT, &c, 1));  
}

uint8 uart_chn_tx_byte(uint8 chn,uint8 buffer[])
{
	return(get_chn_bytes(&(uart_file_infor[chn].tx_slot),buffer,1));
}

uint8 uart_chn_rx_byte(uint8 chn,uint8 c)
{
	return(put_chn_bytes(&(uart_file_infor[chn].rx_slot),&c,1));
}

void uart_rx_hook(uint8 chn)
{
#if OS_CRITICAL_METHOD == 3
	OS_CPU_SR     cpu_sr = 0;
#endif

	OS_ENTER_CRITICAL();
	uart_file_infor[chn].busy_rxing = uart_file_infor[chn].over_time_tick;
	OS_EXIT_CRITICAL();       
}

void uart_tick_hook(void)
{
    uint8 i;
    
    for(i = 0 ; i < UART_CH_CNT; i++)
    {
        if(uart_file_infor[i].busy_rxing  > 0x00)
        {
            uart_file_infor[i].busy_rxing--;
            if(0x00 == uart_file_infor[i].busy_rxing)
            {
                empty_a_chn_slot(&(uart_file_infor[i].rx_slot));
            }
        }
    }
}

void sys_uart_write(uint8 chn,unsigned char buffer[],uint8 len)
{
    uint8 fe_buff[4] = {0xFE,0xFE,0xFE,0xFE};
    if (1 == len)
    {
        if (0x55 == buffer[0])
        {
            goto here_chn;
        }
    }
	if(CHN_INFRARED == chn)
    {
        put_chn_bytes(&(uart_file_infor[chn].tx_slot),fe_buff,4);
    }
    else
    {
        put_chn_bytes(&(uart_file_infor[chn].tx_slot),fe_buff,2);
    }
here_chn:
    put_chn_bytes(&(uart_file_infor[chn].tx_slot),buffer,len);
	if(CHN_INFRARED == chn)
	{
		pwm_generator_init();
        soft_uart_chnINF_rx_cfg(DISABLE);
        soft_uart_chnINF_tx_cfg(ENABLE);
	}
	if(CHN_RS485 == chn)
	{
         
		rx485_valid_tick = 30;
        set_led(RS485_TX);
        ENABLE_RS485_TX();
        UART2_ITConfig(UART2_IT_TC, ENABLE);
        UART2_ITConfig(UART2_IT_RXNE_OR, ENABLE); 
	}
	if(CHN_PLC == chn)
	{
        set_led(PLC_TX);
        soft_uart_chnPLC_tx_cfg(ENABLE);
	}
}  

#define UART_RX_BIT     (1 << 0)
#define UART_TX_BIT     (1 << 1)

uint8 count_bit_in_char(uint8 x)
{
	uint8 n =0; 

	if(x)
	{
		do
		{
			n++;
		}
		while((x = x&(x-1))) ; 
	}
	return(n);
}
uint16 _send_fmt_even(uint8 x)
{
	uint8 cs;
	uint16 databit = x;
	cs = count_bit_in_char(x);
	if(cs & 0x01)
	{
		databit |= 1 << 8; //cs
	}
	databit |= 1 << 9; //stop bit
	return(databit);
}
uint8 recv_chk_even(unsigned int x)
{
	return(x == _send_fmt_even(x & 0xFF));
}
//used in interrupt
uint8 get_soft_uart_rx_data(struct soft_uart_chn *pchn)
{
	if(recv_chk_even(pchn->rx.data))
	{
		return(uart_chn_rx_byte(pchn->puart->chn_no,pchn->rx.data));
	}
	return(0);   
}

uint8 get_soft_uart_tx_data(struct soft_uart_chn *pchn)
{
	unsigned char c;
	// int parity  = pchn->puart->uart_cfg.parity;

	if(uart_chn_tx_byte(pchn->puart->chn_no,&c))		  //edit by du
	{
		//tx->bit_interval = TIM_CLK_FREQUENCY / 1200;/////ready to be configed
		//tx->bit_interval = TIM_CLK_FREQUENCY / uart_file_infor[chn].uart_cfg.baud;
		pchn->tx.data = _send_fmt_even(c); 
		pchn->tx.data  <<= 0x01;
		pchn->tx.data &= (1 << 11)-1;
		pchn->databitcnt =  1+ 8 + 1+1;         
		return(1);
	}

    return(0);
}

void GPIO_Init(GPIO_TypeDef* GPIOx,
			   GPIO_Pin_TypeDef GPIO_Pin,
			   GPIO_Mode_TypeDef GPIO_Mode)
{
	if((((u8)(GPIO_Mode)) & (u8)0x80) != (u8)0x00) /* Output mode */
	{
//		if((((u8)(GPIO_Mode)) & (u8)0x10) != (u8)0x00) /* High level */
//		{
			GPIOx->ODR |= (u8)GPIO_Pin;
//		}
//		else /* Low level */
//		{
//			GPIOx->ODR &= (u8)(~(GPIO_Pin));
//		}
		/* Set Output mode */
		GPIOx->DDR |= (u8)GPIO_Pin;
	}
	else /* Input mode */
	{
		/* Set Input mode */
		GPIOx->DDR &= (u8)(~(GPIO_Pin));
	}

//	if((((u8)(GPIO_Mode)) & (u8)0x40) != (u8)0x00) /* Pull-Up or Push-Pull */
//	{
		GPIOx->CR1 |= (u8)GPIO_Pin;
//	}
//	else /* Float or Open-Drain */
//	{
//		GPIOx->CR1 &= (u8)(~(GPIO_Pin));
//	}

	if((((u8)(GPIO_Mode)) & (u8)0x20) != (u8)0x00) /* Interrupt or Slow slope */
	{
		GPIOx->CR2 |= (u8)GPIO_Pin;
	}
	else /* No external interrupt or No slope control */
	{
		GPIOx->CR2 &= (u8)(~(GPIO_Pin));
	}

}

void soft_uart_init(void)
{
	//TIM1_DeInit();
	TIM1_TimeBaseInit(0, TIM1_COUNTERMODE_UP, 0xFFFF, 0);

	/* INF chn */
	GPIO_Init(TXINF_PORT, TXINF_PIN, GPIO_MODE_OUT_PP_HIGH_FAST);//inf TXD PB4
	GPIO_Init(RXINF_PORT, RXINF_PIN, GPIO_MODE_IN_PU_NO_IT);
	TIM1_OC2Init(0);
	TIM1_ClearFlag(TIM1_FLAG_CC2); 
	TIM1_chn1_capture();//for v1.02

	/*plc chn*/
	GPIO_Init(TXPLC_PORT, TXPLC_PIN, GPIO_MODE_OUT_PP_HIGH_FAST);//PLC TXD PD2
	GPIO_Init(RXPLC_PORT, RXPLC_PIN, GPIO_MODE_IN_PU_NO_IT);
	//GPIO_Init(GPIOD, GPIO_PIN_2, GPIO_MODE_IN_PU_NO_IT);
	TIM1_OC3Init(0);
	TIM1_ClearFlag(TIM1_FLAG_CC3);
	TIM1_chn4_capture();//for v1.02

	TIM1_Cmd(ENABLE);
}
/********************************************** 
  ָʾ�ƴ�����һ��ֻ�ܵ���һ��ָʾ�ƣ�
***********************************************/
void set_rxtx_led(int8 status)
{
#if GUANG_DONG
    RESET_RX_LED;
    RESET_TX_LED;
#endif
    RESET_PLC_LED;
	RESET_485_LED;

	switch(status)
	{
#if GUANG_DONG	
	case PLC_RX_LED:
		SET_RX_LED;
		SET_PLC_LED;
		break;
	case PLC_TX:
		SET_TX_LED;
		SET_PLC_LED;
		break;
	case RS485_RX:
		SET_RX_LED;
		SET_485_LED;
		break;
	case RS485_TX:
		SET_TX_LED;
		SET_485_LED;
		break;
#else
    case PLC_RX_LED:
	case PLC_TX:
		SET_PLC_LED;
		break;
	case RS485_RX:
	case RS485_TX:
		SET_485_LED;
		break;
#endif
	}
}
@near volatile time_t __sys_tick = 0;
uint8 timer_tick(void)
{
	@near static volatile time_t last_tick=0;
	time_t deltms;

	deltms = __sys_tick - last_tick;//�������Σ�ʹ׼ȷ�ȸ���
    if (deltms != __sys_tick - last_tick)
    {
        deltms = __sys_tick - last_tick;
    }
    if(deltms >= TIMER_COUNT)
    {
		last_tick += TIMER_COUNT;
        return TRUE;
    }
    return FALSE;
}
vuint8 calibtate_tick = 0;
void timer_handle(void)
{
	static uint8 led_sta_flag, timer_rxtx;

#if GUANG_DONG
    static uint8 timer_sta = 50;
#else
    static uint8 timer_sta = 10;
#endif

	if(timer_tick())
	{
		uart_tick_hook();
#if SKMT_CONFIG		
        event_report_hook();
#endif	
        //rx and tx led handle	
		if(timer_rxtx > 0)
		{
			timer_rxtx = 0;
		}
		else
		{
            timer_rxtx = 1;
			set_rxtx_led(get_rxtx_status());//led queue handle 
		}
#if GUANG_DONG
		if(timer_sta > 0)
		{
			SET_ALARM_LED;
			timer_sta--;
		}
		else
		{
			RESET_ALARM_LED;
		}
#else
		//state led must flash 0.5Hz
		if(timer_sta > 0)
		{
			if(led_sta_flag)
				SET_STA_LED;
			else
				RESET_STA_LED;
			timer_sta--;
		}
		else
		{
			led_sta_flag ^= 1;
			timer_sta = 10;
#if SKMT_CONFIG
            if (skmt_delay > 0)
            {
                skmt_delay--;
                if (0x00 == skmt_delay)
                {
                    start_skmt();
                }
            }
#endif                        
		}
#endif
		if(calibtate_tick > 0)
		{
			calibtate_tick--;
		}
		if(radiate_tick > 0)
		{
			radiate_tick--;
			if(0 == radiate_tick)
			{
				radiate_retx();
			}
		}
		if(rx485_valid_tick > 0)
		{
			rx485_valid_tick--;
    		if(0 == rx485_valid_tick)
    		{
                UART2_ITConfig(UART2_IT_RXNE_OR, DISABLE); 
    		}	
        }
#if JIANG_SU
		if(delay_reset_sys > 0)
		{
			delay_reset_sys--;
			if(0x00 == delay_reset_sys)
			{
				while(1);
			}
		}   
#endif
	}
}
#define IDEAL_BIT_INTERVAL_CNT_VALUE 1667//Actually 16000000/9600=1666.666667
#define MAX_TRIM_VAL 3
#define MIN_TRIM_VAL -4
#define MAX_ERR 9*(1+8+1)
void crystal_calibration(void)
{
	vs8 trim_val;
	uint8 i = 0;

	if(MEASURE_COMPLETED != measure_state)
	{
		return;
	}
	while(diff >= IDEAL_BIT_INTERVAL_CNT_VALUE)
	{
		diff -= IDEAL_BIT_INTERVAL_CNT_VALUE;
		i++;
	}
	if(diff >= (IDEAL_BIT_INTERVAL_CNT_VALUE>>1))
	{
		i++;
	}
	if(i > 11)
	{
		measure_state = MEASURE_START;
		return;
	}

	trim_val = CLK->HSITRIMR & CLK_HSITRIMR_HSITRIM;
	if(trim_val & (0x01 << 2))
	{
		trim_val = ((~trim_val) & 0x07) + 1;
		trim_val = -trim_val;
	}
	if((diff >= 9*i) && (diff < (IDEAL_BIT_INTERVAL_CNT_VALUE>>1)))//faster,should be slower
	{
		trim_val++;
		if(trim_val > 3)
		{
			trim_val = 3;
		}
		CLK->HSITRIMR = (trim_val & CLK_HSITRIMR_HSITRIM);
	}
	else if((diff >= (IDEAL_BIT_INTERVAL_CNT_VALUE>>1)) && (diff < IDEAL_BIT_INTERVAL_CNT_VALUE - 9*i))//slower,should be faster
	{

		trim_val--;
		if(trim_val < -4)
		{
			trim_val = -4;
		}
		CLK->HSITRIMR = (trim_val & CLK_HSITRIMR_HSITRIM);
	}
	measure_state = MEASURE_START;
}

void TIM2_DeInit(void)
{
#if 1
	TIM2->CR1 = (u8)TIM2_CR1_RESET_VALUE;
	TIM2->IER = (u8)TIM2_IER_RESET_VALUE;
	TIM2->SR2 = (u8)TIM2_SR2_RESET_VALUE;

	/* Disable channels */
	TIM2->CCER1 = (u8)TIM2_CCER1_RESET_VALUE;
	TIM2->CCER2 = (u8)TIM2_CCER2_RESET_VALUE;

	/* Then reset channel registers: it also works if lock level is equal to 2 or 3 */
	TIM2->CCER1 = (u8)TIM2_CCER1_RESET_VALUE;
	TIM2->CCER2 = (u8)TIM2_CCER2_RESET_VALUE;
	TIM2->CCMR1 = (u8)TIM2_CCMR1_RESET_VALUE;
	TIM2->CCMR2 = (u8)TIM2_CCMR2_RESET_VALUE;
	TIM2->CCMR3 = (u8)TIM2_CCMR3_RESET_VALUE;
	TIM2->CNTRH = (u8)TIM2_CNTRH_RESET_VALUE;
	TIM2->CNTRL = (u8)TIM2_CNTRL_RESET_VALUE;
	TIM2->PSCR = (u8)TIM2_PSCR_RESET_VALUE;
	TIM2->ARRH  = (u8)TIM2_ARRH_RESET_VALUE;
	TIM2->ARRL  = (u8)TIM2_ARRL_RESET_VALUE;
	TIM2->CCR1H = (u8)TIM2_CCR1H_RESET_VALUE;
	TIM2->CCR1L = (u8)TIM2_CCR1L_RESET_VALUE;
	TIM2->CCR2H = (u8)TIM2_CCR2H_RESET_VALUE;
	TIM2->CCR2L = (u8)TIM2_CCR2L_RESET_VALUE;
	TIM2->CCR3H = (u8)TIM2_CCR3H_RESET_VALUE;
	TIM2->CCR3L = (u8)TIM2_CCR3L_RESET_VALUE;
	TIM2->SR1 = (u8)TIM2_SR1_RESET_VALUE;
#endif	
}

void TIM3_DeInit(void)
{

  TIM3->CR1 = (u8)TIM3_CR1_RESET_VALUE;
  TIM3->IER = (u8)TIM3_IER_RESET_VALUE;
  TIM3->SR2 = (u8)TIM3_SR2_RESET_VALUE;

  /* Disable channels */
  TIM3->CCER1 = (u8)TIM3_CCER1_RESET_VALUE;

  /* Then reset channel registers: it also works if lock level is equal to 2 or 3 */
  TIM3->CCER1 = (u8)TIM3_CCER1_RESET_VALUE;
  TIM3->CCMR1 = (u8)TIM3_CCMR1_RESET_VALUE;
  TIM3->CCMR2 = (u8)TIM3_CCMR2_RESET_VALUE;
  TIM3->CNTRH = (u8)TIM3_CNTRH_RESET_VALUE;
  TIM3->CNTRL = (u8)TIM3_CNTRL_RESET_VALUE;
  TIM3->PSCR = (u8)TIM3_PSCR_RESET_VALUE;
  TIM3->ARRH  = (u8)TIM3_ARRH_RESET_VALUE;
  TIM3->ARRL  = (u8)TIM3_ARRL_RESET_VALUE;
  TIM3->CCR1H = (u8)TIM3_CCR1H_RESET_VALUE;
  TIM3->CCR1L = (u8)TIM3_CCR1L_RESET_VALUE;
  TIM3->CCR2H = (u8)TIM3_CCR2H_RESET_VALUE;
  TIM3->CCR2L = (u8)TIM3_CCR2L_RESET_VALUE;
  TIM3->SR1 = (u8)TIM3_SR1_RESET_VALUE;
}
void tim3_capture_cfg(void)
{
	GPIO_Init(GPIOD,GPIO_PIN_0,GPIO_MODE_IN_PU_NO_IT);//calibrate hsi

	TIM3_DeInit();
	TIM3->PSCR = (u8)(TIM2_PRESCALER_1);//not Prescaler
	TIM3->ARRH = 0xFF;//set auto reload value
	TIM3->ARRL = 0xFF;
	TIM3->CCMR1 = 0x02 << 0;//TI2FP1
	TIM3->CCER1 = 0x01 << 1;//CC1P falling edge
	TIM3->CCMR2 = 0x01 << 0;//TI2FP2
	TIM3->CCER1 &= ~(0x01 << 5);//CC2P rising edge
 	TIM3->CCER1 |=  TIM3_CCER1_CC1E | TIM3_CCER1_CC2E;
}

uint8 form_645_frame(struct frame645 *pframe,uint8 data[],uint8 len)
{
	switch(pframe->control_code.control_byte)
	{
	case 0x0A: //set addr 97
	case 0x15: //set addr 07
	case 0x13: //read addr 07
		mymemcpy(pframe->addr,cjq_addr,6);
		break;
	default:
		break;
	}
	pframe->control_code.control_bits.direction_flag = 1;
	if((len > 0) && (NULL != data))
	{
		mymemcpy(pframe->data,data,len);
	}
	pframe->datalen = len;
	buf_add_value(pframe->data,pframe->datalen, 0x33);
	pframe->data[pframe->datalen] = checksum((const unsigned char*)pframe,pframe->datalen+10);
	pframe->data[pframe->datalen+1] = 0x16;

	return(pframe->datalen + 12);
}

void EEP_Read(uint8 addr, uint8 buf[], uint8 len)
{
	uint8 i;

	FLASH_Unlock(FLASH_MEMTYPE_DATA);
	for(i = 0; i < len; i++)
	{
		buf[i] = FLASH_ReadByte(OF_EEPROM_ADDRESS+addr+i);
	}
	FLASH_Lock(FLASH_MEMTYPE_DATA);
}

uint8 EEP_Read_byte(uint8 addr)
{
	uint8 result; 
	
	EEP_Read(addr, &result, 1);
	return(result);
}

void EEP_Write(uint8 addr, uint8 buf[], uint8 len)
{
	uint8 i;

	FLASH_Unlock(FLASH_MEMTYPE_DATA);
	for (i = 0; i < len; i++) 
	{
		FLASH_ProgramByte(OF_EEPROM_ADDRESS+addr+i,buf[i]);
	}
	FLASH_Lock(FLASH_MEMTYPE_DATA);
}
void EEP_Write_byte(uint8 addr, uint8 data)
{
	EEP_Write(addr, &data, 1);
}

#if 1
uint8 set_addr(struct frame645 *pframe)
{
    if (6 != pframe->datalen) return(FRAME_ERROR);

	if((!is_all_xx(pframe->data, 0x99+0x33, 6))
	   || (!is_all_xx(pframe->data, 0xAA+0x33,6))
	   || (!is_all_xx(pframe->data, 0x00+0x33,6)))
	{
		return(FRAME_ERROR);
	}

    buf_add_value(&pframe->data[0], 6, -0x33);
    EEP_Write(OF_ADDR, &pframe->data[0], 6);
    if (0xFF != pframe->data[0]) 
    {
        EEP_Write_byte(OF_ADDR_MAGIC,0x55);
    }
    mymemcpy(cjq_addr,&pframe->data[0],6);
    return(0);
}
uint8 read_cjq_addr(struct frame645 *pframe)
{
    mymemcpy(pframe->data, cjq_addr, 6);
    
    return(6);
}
#endif
/****************************************************** 
 �ز�оƬ�����ַ������
     ���ղɼ����յ��˱��ĺ�Ҫ���ж�485�������������Ƿ�
     ����Ҫ�ϱ��ı��ţ�����У�����������AF.02��ߵ�
     0xFF��Ϊ485���ţ����ݳ���Ϊ08���ϱ����ز�оƬ�� 
******************************************************/
uint8 read_cjq_addr_gm(struct frame645 *pframe)
{
	uint8 len = 8;
	uint8 buf[20];
	int8 index;

	buf[0] = 0xAF;
	buf[1] = 0x02;

	//���¼�������������Ϊ��Чid
	memset_my(&buf[2], 0xFF, 6);
    if(cjq_addr[0] != 0xFF) 
    {
        mymemcpy(pframe->addr,cjq_addr,6);
    }
	//�Ƿ���485��ַ��Ҫ�ϱ�,
#if SKMT_CONFIG		
	if ((index = get_mt_rep_flag()) < MAX_MP_CNT) 
	{//�ϱ������¼���������485����,�ȴ�оƬӦ��
		mymemcpy(&buf[2], mp_slot_pool[index].addr, 6);
#if ZHE_JIANG_MT_EVENT		
        len += init_event_frame(&buf[8]);
#endif		
	}
#endif
    mymemcpy(pframe->data, buf, len);

    return(len);
}

#if JIANG_SU
void power_lost_record(void)
{
    uint8 cnt[2];

    EEP_Read(OF_POWER_LOST_CNT, cnt, 2);
	cnt[0] = BCD2BIN(cnt[0]);
    if (cnt[0] < 99)
    {
        cnt[0]++;
		cnt[0] = BIN2BCD(cnt[0]);
    }
    else
    {
		cnt[1] = BCD2BIN(cnt[1]);
		cnt[1]++;
		cnt[1] = BIN2BCD(cnt[1]);
		cnt[0] = 0x00;
    }
	EEP_Write(OF_POWER_LOST_CNT, cnt, 2);
}
#endif


#if BAUD_CONFIG
void get_baud(void)
{
	if(0xAA != EEP_Read_byte(OF_CHN485_VALID))
	{
		EEP_Write_byte(OF_CHN485_VALID, 0xAA);
		EEP_Write_byte(OF_CHN485_BAUD, 0x01);//2400bps
	}
	rx485_bps = EEP_Read_byte(OF_CHN485_BAUD);
}

uint8 set_baud(struct frame645 *pframe)
{
	pframe->data[pframe->datalen-1] -= 0x33;
	if(pframe->data[pframe->datalen-1] > 3)
	{
		pframe->data[0] = 0x01;
		pframe->control_code.control_bits.exception_flag = 1;
        return(1);
 	}
    rx485_bps = pframe->data[pframe->datalen-1];
    EEP_Write_byte(OF_CHN485_BAUD,pframe->data[pframe->datalen-1]);
	return(0);
}


uint8 read_baud(struct frame645 *pframe)
{
	const unsigned char rdverid07[] = {0x04,0x07,0x00,0x04};

    if (0x00 != memcmp_my(rdverid07,pframe->data,4)) 
	{
        return(0);
    }
    pframe->data[pframe->datalen] = rx485_bps;
    return(sizeof(rx485_bps));
}
#endif
#if 0
void clk_init(void) 
{ 

    CLK_DeInit(); 

    /* Configure the Fcpu to DIV1*/ 
    CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1); 

    /* Configure the HSI prescaler to the optimal value */ 
    CLK_SYSCLKConfig(CLK_PRESCALER_HSIDIV1); 

    /* Initilize the CLock controller according to CLK_InitStructure */ 
    CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSE, DISABLE, DISABLE); 

    CLK_HSECmd(ENABLE); 
} 
#endif
void modules_init(void)
{
	int i;   

#if 1//�����ʼ��
    /* hsi 16MHz. Hsi is the default clock source when system power on */    
    CLK->CKDIVR = (u8)((u8)CLK_PRESCALER_CPUDIV1 & (u8)CLK_CKDIVR_CPUDIV) 
                  | ((u8)((u8)CLK_PRESCALER_HSIDIV1 & (u8)CLK_CKDIVR_HSIDIV));//not prescaler

    CLK->SWR = (u8)CLK_SOURCE_HSI;
    while (!(CLK->ICKR & 0x02));//wait for hsi ready
    CLK->ICKR |= CLK_ICKR_HSIEN;
#else
    clk_init();
#endif	    

    /**********************led gpio init************************/ 
	GPIO_Init(LED_485_PORT,LED_485_PIN ,GPIO_MODE_OUT_PP_HIGH_FAST);//485ָʾ�ƣ�������ߵ�ƽ
	GPIO_Init(LED_PLC_PORT,LED_PLC_PIN ,GPIO_MODE_OUT_PP_HIGH_FAST);//plcָʾ�ƣ�������ߵ�ƽ
#if GUANG_DONG
	GPIO_Init(LED_ALARM_PORT,LED_ALARM_PIN,GPIO_MODE_OUT_PP_HIGH_FAST);
	GPIO_Init(LED_TX_PORT,LED_TX_PIN,GPIO_MODE_OUT_OD_LOW_FAST);
	GPIO_Init(LED_RX_PORT,LED_RX_PIN,GPIO_MODE_OUT_OD_LOW_FAST);
#else
	GPIO_Init(LED_STA_PORT,LED_STA_PIN,GPIO_MODE_OUT_PP_HIGH_FAST);//�ز��շ�ָʾ�ƣ�������ߵ�ƽ
#endif

    //control enable 485
    GPIO_Init(EN_485_PORT, EN_485_PIN, GPIO_MODE_OUT_PP_HIGH_FAST);//485ʹ�ܿ���
	infrared_gpio();
    
	//system second
    /* use timer4 cpu clk = 16M 16000000/128/*/
	TIM4->PSCR = TIM4_PRESCALER_128;
	TIM4->ARR  = (u8)((TIM_CLK_FREQUENCY/128)/TICK_TIMER_FREQUENCY - 1);
    TIM4->IER |= (u8)TIM4_IT_UPDATE;
	TIM4->CR1 |= TIM4_CR1_CEN;

    init_chn_pool_mgr();//����
    memset_my(cjq_addr, 0xFF, 6);
	if(0x55 == EEP_Read_byte(OF_ADDR_MAGIC))
	{
		EEP_Read(OF_ADDR, cjq_addr, 6);
	}

#if BAUD_CONFIG	
    get_baud();//485 baut rate 2400
#endif	
	for(i = 0x00; i < UART_CH_CNT; i++)
	{
		UART_CHN_Soft_Init(i);
	}

	memset(_uart_chns,0x00,sizeof(_uart_chns));
	//PLC chn
	_uart_chns[0].bit_interval = TIM_CLK_FREQUENCY / 9600;
	_uart_chns[0].databitcnt = 1+ 8 + 1 + 1;   
	_uart_chns[0].puart = &uart_file_infor[CHN_PLC];
	//infrared chn
	_uart_chns[1].bit_interval = TIM_CLK_FREQUENCY / 1200;
	_uart_chns[1].databitcnt = 1+ 8 + 1+ 1;
	_uart_chns[1].puart = &uart_file_infor[CHN_INFRARED];

	soft_uart_init();//ģ�⴮�ڳ�ʼ��---plc��inf
	UART_DeInit(2400);//Ӳ�����ڳ�ʼ��---485

    soft_uart_chnPLC_rx_cfg(ENABLE); 
    soft_uart_chnINF_rx_cfg(ENABLE); 

    //init watchdog
    IWDG->KR = IWDG_KEY_ENABLE;/* Enable the IWDG*/
	IWDG->KR = (u8)IWDG_WriteAccess_Enable;	/* Write Access */
	IWDG->PR = (u8)IWDG_Prescaler_128; //will reset after 510ms
	IWDG->RLR = 0xFF;
	IWDG->KR = IWDG_KEY_REFRESH;/* Refresh IWDG */

    //config time3 calibrate
    tim3_capture_cfg();//��ʱ����Ϊģ�⴮���ṩʱ��
#if JIANG_SU	
    power_lost_record();
#endif	
}

void general_hdl(void)
{
    crystal_calibration();//
}


